from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT_BASE = ROOT / "outputs"
DEFAULT_REQUIRED_COMMANDS = [
    "python scripts\\check_apv2_mainpaper_runtime_draft.py",
    "python -m pytest tests\\test_apv2_publication_figures_supplement.py tests\\test_apv2_bottom_loop_p0_materials.py tests\\test_apv2_p1_hardening_materials.py tests\\test_apv2_public_freeze_clean_room.py -q",
]


def _tail(text: str, limit: int = 5000) -> str:
    if len(text) <= limit:
        return text
    return text[-limit:]


def find_manifest(freeze_dir: Path) -> Path:
    direct = freeze_dir / "public_freeze_manifest.json"
    if direct.exists():
        return direct
    nested = freeze_dir / "package" / "public_freeze_manifest.json"
    if nested.exists():
        return nested
    matches = sorted(freeze_dir.rglob("public_freeze_manifest.json"))
    if matches:
        return matches[0]
    raise FileNotFoundError(f"public_freeze_manifest.json not found under {freeze_dir}")


def package_root_from_manifest(manifest_path: Path) -> Path:
    return manifest_path.parent


def copy_package(source: Path, stage_root: Path) -> None:
    if stage_root.exists():
        shutil.rmtree(stage_root)
    ignore = shutil.ignore_patterns("__pycache__", ".pytest_cache", "*.pyc", "*.pyo")
    shutil.copytree(source, stage_root, ignore=ignore)


def run_command(command: str, cwd: Path) -> dict[str, Any]:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(cwd)
    started = time.perf_counter()
    completed = subprocess.run(
        command,
        cwd=str(cwd),
        shell=True,
        text=True,
        capture_output=True,
        env=env,
        timeout=240,
    )
    duration = time.perf_counter() - started
    return {
        "command": command,
        "returncode": completed.returncode,
        "duration_seconds": round(duration, 3),
        "stdout_tail": _tail(completed.stdout),
        "stderr_tail": _tail(completed.stderr),
        "passed": completed.returncode == 0,
    }


def report_text(result: dict[str, Any]) -> str:
    rows = "\n".join(
        f"| `{row['command']}` | {row['returncode']} | {row['duration_seconds']} | {row['passed']} |"
        for row in result["commands"]
    )
    return f"""# APV2 Same-Machine Clean-Room Rerun Report

Generated: `{result['created_at_utc']}`

## Scope

- scope: `{result['scope']}`
- rerun_level: `{result['rerun_level']}`
- source_package: `{result['source_package']}`
- staging_root: `{result['staging_root']}`
- all_passed: `{result['summary']['all_passed']}`

## Commands

| command | returncode | seconds | passed |
|---|---:|---:|---|
{rows}

## Boundary

This is a same-machine clean-room rerun from a copied freeze package. It is stronger than running in the original workspace, but weaker than an independent clean-machine or third-party reproduction.
"""


def run(freeze_dir: Path, output_base: Path | None = None, commands: list[str] | None = None) -> dict[str, Any]:
    manifest_path = find_manifest(freeze_dir)
    package_source = package_root_from_manifest(manifest_path)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = (output_base or DEFAULT_OUTPUT_BASE) / f"apv2_clean_room_rerun_{stamp}"
    stage_root = output_dir / "stage"
    output_dir.mkdir(parents=True, exist_ok=True)
    copy_package(package_source, stage_root)

    manifest = json.loads((stage_root / "public_freeze_manifest.json").read_text(encoding="utf-8"))
    command_list = list(commands or manifest.get("rerun_commands", {}).get("required", []) or DEFAULT_REQUIRED_COMMANDS)
    command_results = [run_command(command, stage_root) for command in command_list]
    result = {
        "schema_id": "apv2_same_machine_clean_room_rerun/v1",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "AP-Core architecture/runtime main-paper reproducibility candidate",
        "rerun_level": "same_machine_clean_room_staging_copy",
        "source_manifest": str(manifest_path),
        "source_package": str(package_source),
        "staging_root": str(stage_root),
        "environment": {
            "python": sys.version,
            "platform": platform.platform(),
            "machine": platform.machine(),
        },
        "commands": command_results,
        "summary": {
            "command_count": len(command_results),
            "passed": sum(1 for row in command_results if row["passed"]),
            "failed": sum(1 for row in command_results if not row["passed"]),
            "all_passed": all(row["passed"] for row in command_results),
        },
        "boundary": {
            "same_machine_rerun": True,
            "independent_clean_machine_claim": False,
            "third_party_replication_claim": False,
        },
    }
    json_path = output_dir / "clean_room_rerun.json"
    report_path = output_dir / "clean_room_rerun_report.md"
    json_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    report_path.write_text(report_text(result), encoding="utf-8")
    result["artifacts"] = {
        "json_path": str(json_path),
        "report_path": str(report_path),
        "output_dir": str(output_dir),
    }
    json_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--freeze-dir", type=Path, required=True)
    parser.add_argument("--output-base", type=Path, default=None)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    result = run(args.freeze_dir, output_base=args.output_base)
    print(json.dumps({
        "summary": result["summary"],
        "artifacts": result["artifacts"],
        "staging_root": result["staging_root"],
    }, ensure_ascii=False, indent=2))
    return 0 if result["summary"]["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

