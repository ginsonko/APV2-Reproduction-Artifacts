from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import re
import shutil
import sys
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT_BASE = ROOT / "outputs"

REQUIRED_COMMANDS = [
    "python scripts\\check_apv2_mainpaper_runtime_draft.py",
    "python -m pytest tests\\test_apv2_publication_figures_supplement.py tests\\test_apv2_bottom_loop_p0_materials.py tests\\test_apv2_p1_hardening_materials.py tests\\test_apv2_p2_stress_mechanism_evidence.py tests\\test_apv2_public_freeze_clean_room.py -q",
]

OPTIONAL_COMMANDS = [
    "python experiments\\apv2_bottom_loop_p0_materials.py",
    "python experiments\\apv2_p1_hardening_materials.py",
    "python experiments\\apv2_p2_stress_mechanism_evidence.py",
    "python scripts\\build_apv2_publication_figures_supplement.py --output-dir outputs\\cleanroom_figures --supplement-path docs\\APV2_MainPaper_Supplement_Index_20260611.md",
]

SECRET_PATTERNS = [
    re.compile(r"sk-[A-Za-z0-9_\-]{12,}"),
    re.compile(r"(?i)(api[_-]?key|authorization|bearer|password|secret)\s*[:=]\s*[A-Za-z0-9_\-]{12,}"),
]

EXCLUDE_DIR_NAMES = {
    ".git",
    ".pytest_cache",
    "__pycache__",
    "node_modules",
    ".venv",
    "venv",
}

EXCLUDE_FILE_SUFFIXES = {
    ".pyc",
    ".pyo",
    ".tmp",
    ".bak",
    ".log",
    ".err",
}

EXCLUDE_FILE_NAMES = {
    ".env",
    ".env.local",
    ".env.dpp1.local",
    "desktop_pet.lock",
}

INCLUDE_DIRS = [
    "config",
    "core",
    "memory",
    "channels",
    "sensors",
    "education",
    "legacy_apv2/sensors",
]

INCLUDE_FILES = [
    "learning_events.py",
    "README.md",
    "LICENSE",
    "NOTICE.md",
    "SECURITY_AND_PRIVACY.md",
    "docs/APV2_MainPaper_ArchitectureRuntime_Draft_20260611.md",
    "docs/APV2_MainPaper_Supplement_Index_20260611.md",
    "docs/Design_APV2_BottomLoopP0Materials_20260610.md",
    "docs/Design_APV2_P1HardeningMaterials_20260610.md",
    "docs/Design_APV2_P2StressMechanismEvidence_20260611.md",
    "docs/Review_APV2_P2StressMechanismEvidence_20260611.md",
    "docs/Design_APV2_MainPaper_RuntimeRewrite_20260611.md",
    "docs/ReviewRubric_APV2_MainPaper_RuntimeRewrite_20260611.md",
    "docs/Design_APV2_PublicationFiguresSupplement_20260611.md",
    "docs/Review_APV2_PublicationFiguresSupplement_20260611.md",
    "docs/ReviewerReport_APV2_MainPaper_ArchitectureRuntime_20260611.md",
    "docs/FinalReport_APV2_MainPaper_RuntimeRewrite_20260611.md",
    "docs/FinalReport_APV2_PublicationFiguresSupplement_20260611.md",
    "docs/FinalReport_APV2_MainPaper_EnglishCitationReview_20260611.md",
    "docs/Design_APV2_PublicFreezeCleanRoomRerun_20260611.md",
    "docs/Review_APV2_PublicFreezeCleanRoomRerun_20260611.md",
    "scripts/check_apv2_mainpaper_runtime_draft.py",
    "scripts/build_apv2_publication_figures_supplement.py",
    "scripts/build_apv2_public_freeze_candidate.py",
    "scripts/run_apv2_clean_room_rerun.py",
    "experiments/apv2_bottom_loop_p0_materials.py",
    "experiments/apv2_p1_hardening_materials.py",
    "experiments/apv2_p2_stress_mechanism_evidence.py",
    "tests/test_apv2_publication_figures_supplement.py",
    "tests/test_apv2_bottom_loop_p0_materials.py",
    "tests/test_apv2_p1_hardening_materials.py",
    "tests/test_apv2_p2_stress_mechanism_evidence.py",
    "tests/test_apv2_public_freeze_clean_room.py",
    "outputs/apv2_bottom_loop_p0_materials_20260611_021431/apv2_bottom_loop_p0_materials.json",
    "outputs/apv2_bottom_loop_p0_materials_20260611_021431/apv2_bottom_loop_p0_materials_report.md",
    "outputs/apv2_p1_hardening_materials_20260611_021432/apv2_p1_hardening_materials.json",
    "outputs/apv2_p1_hardening_materials_20260611_021432/apv2_p1_hardening_materials_report.md",
    "outputs/apv2_p1_hardening_materials_20260611_021432/artifact_freeze_manifest.json",
    "outputs/apv2_p1_hardening_materials_20260611_021432/jsonl_persistence/apv2_memory.jsonl",
    "outputs/apv2_p2_stress_mechanism_evidence_20260611_021433/apv2_p2_stress_mechanism_evidence.json",
    "outputs/apv2_p2_stress_mechanism_evidence_20260611_021433/apv2_p2_stress_mechanism_evidence_report.md",
    "outputs/apv2_p2_stress_mechanism_evidence_20260611_021433/artifact_manifest.json",
    "outputs/apv2_publication_figures_supplement_20260611_002510/figure_manifest.json",
]

INCLUDE_OUTPUT_DIRS = [
    "outputs/apv2_p1_hardening_materials_20260611_021432/figures",
    "outputs/apv2_publication_figures_supplement_20260611_002510/figures",
]


@dataclass(frozen=True)
class PackagePaths:
    output_dir: Path
    package_dir: Path
    zip_path: Path


def rel(path: Path, *, base: Path = ROOT) -> str:
    return path.resolve().relative_to(base.resolve()).as_posix()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def is_binary_like(path: Path) -> bool:
    try:
        sample = path.read_bytes()[:4096]
    except OSError:
        return True
    return b"\x00" in sample


def should_skip(path: Path) -> bool:
    parts = set(path.parts)
    if parts.intersection(EXCLUDE_DIR_NAMES):
        return True
    if path.name in EXCLUDE_FILE_NAMES:
        return True
    if path.name.startswith(".env"):
        return True
    if path.suffix.lower() in EXCLUDE_FILE_SUFFIXES:
        return True
    return False


def iter_included_files() -> tuple[list[Path], list[str]]:
    files: list[Path] = []
    missing: list[str] = []

    for item in INCLUDE_FILES:
        path = ROOT / item
        if path.exists() and path.is_file() and not should_skip(path):
            files.append(path)
        else:
            missing.append(item)

    for item in INCLUDE_DIRS + INCLUDE_OUTPUT_DIRS:
        root = ROOT / item
        if not root.exists():
            missing.append(item)
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = sorted(name for name in dirnames if name not in EXCLUDE_DIR_NAMES)
            base = Path(dirpath)
            for name in sorted(filenames):
                path = base / name
                if path.is_file() and not should_skip(path):
                    files.append(path)

    unique = sorted(set(files), key=lambda p: rel(p).lower())
    return unique, missing


def classify(relative_path: str) -> str:
    if relative_path.startswith(("config/", "core/", "memory/", "channels/", "sensors/", "legacy_apv2/sensors/")):
        return "AP-Core runtime dependency"
    if relative_path.startswith("education/") or relative_path == "learning_events.py":
        return "Runtime support dependency"
    if relative_path.startswith("experiments/apv2_"):
        return "AP-Core paper experiment"
    if relative_path.startswith("tests/test_apv2_"):
        return "AP-Core paper test"
    if relative_path.startswith("scripts/"):
        return "Paper reproducibility script"
    if relative_path.startswith("docs/"):
        return "Paper documentation"
    if relative_path.startswith("outputs/apv2_"):
        return "Frozen paper evidence output"
    return "Other included file"


def scan_secret_like(path: Path) -> list[dict[str, str]]:
    if is_binary_like(path):
        return []
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return []
    findings: list[dict[str, str]] = []
    for pattern in SECRET_PATTERNS:
        for match in pattern.finditer(text):
            snippet = text[max(0, match.start() - 20): match.end() + 20]
            snippet = re.sub(r"sk-[A-Za-z0-9_\-]{8,}", "sk-***REDACTED***", snippet)
            snippet = re.sub(
                r"(?i)((api[_-]?key|authorization|bearer|password|secret)\s*[:=]\s*)[A-Za-z0-9_\-]{8,}",
                r"\1***REDACTED***",
                snippet,
            )
            findings.append({"path": rel(path), "pattern": pattern.pattern, "redacted_preview": snippet})
            if len(findings) >= 20:
                return findings
    return findings


def repository_status() -> dict[str, Any]:
    git_dir = ROOT / ".git"
    if not git_dir.exists():
        return {"kind": "not_git_repository", "commit": None, "tag": None}
    return {"kind": "git_repository_unqueried_by_freeze_script", "commit": None, "tag": None}


def make_paths(output_base: Path | None = None) -> PackagePaths:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = (output_base or DEFAULT_OUTPUT_BASE) / f"apv2_public_freeze_candidate_{stamp}"
    package_dir = output_dir / "package"
    zip_path = output_dir / "apv2_public_freeze_candidate.zip"
    return PackagePaths(output_dir=output_dir, package_dir=package_dir, zip_path=zip_path)


def copy_files(files: list[Path], package_dir: Path) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    for source in files:
        relative = rel(source)
        target = package_dir / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        entry = {
            "path": relative,
            "bytes": int(source.stat().st_size),
            "sha256": sha256_file(source),
            "category": classify(relative),
            "mtime_utc": datetime.fromtimestamp(source.stat().st_mtime, timezone.utc).isoformat(),
        }
        entries.append(entry)
    return entries


def write_package_readme(package_dir: Path, manifest_name: str = "public_freeze_manifest.json") -> Path:
    readme = package_dir / "APV2_PUBLIC_FREEZE_README.md"
    readme.write_text(
        "\n".join(
            [
                "# APV2 Public Freeze Candidate",
                "",
                "This package is a local hash-frozen AP-Core architecture/runtime paper-material candidate.",
                "",
                "It supports same-machine clean-room rerun of the main paper check and selected P0/P1/P2 paper-material tests.",
                "",
                "Boundary: GL learning, DPP/Skill37, and product-shell artifacts are adjacent work, not AP-Core runtime proof in this package.",
                "",
                f"Manifest: `{manifest_name}`",
                "",
            ]
        ),
        encoding="utf-8",
    )
    return readme


def build_zip(package_dir: Path, zip_path: Path) -> None:
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(package_dir.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(package_dir).as_posix())


def build_manifest(entries: list[dict[str, Any]], missing: list[str], secret_findings: list[dict[str, str]], zip_path: Path) -> dict[str, Any]:
    by_category: dict[str, dict[str, int]] = {}
    for entry in entries:
        bucket = by_category.setdefault(str(entry["category"]), {"file_count": 0, "bytes": 0})
        bucket["file_count"] += 1
        bucket["bytes"] += int(entry["bytes"])
    total_bytes = sum(int(entry["bytes"]) for entry in entries)
    return {
        "schema_id": "apv2_public_freeze_candidate/v1",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "AP-Core architecture/runtime main-paper reproducibility candidate",
        "not_scope": "GL learning proof / DPP / Skill37 / desktop-pet product-shell proof",
        "repository_status": repository_status(),
        "environment": {
            "python": sys.version,
            "platform": platform.platform(),
            "machine": platform.machine(),
        },
        "rerun_commands": {
            "required": REQUIRED_COMMANDS,
            "optional_regeneration": OPTIONAL_COMMANDS,
        },
        "exclusions": {
            "dir_names": sorted(EXCLUDE_DIR_NAMES),
            "file_suffixes": sorted(EXCLUDE_FILE_SUFFIXES),
            "file_names": sorted(EXCLUDE_FILE_NAMES),
            "note": "Secrets, caches, logs, compiled bytecode, and temporary debug outputs are excluded.",
        },
        "boundary": {
            "ap_core_scope_only": True,
            "gl_learning_protocol_scope": False,
            "product_shell_scope": False,
            "answer_table_lookup": False,
            "keyword_hard_gate": False,
            "regex_route": False,
            "student_side_llm": False,
            "hidden_solver": False,
            "full_sentence_macro": False,
        },
        "summary": {
            "file_count": len(entries),
            "total_bytes": total_bytes,
            "category_summary": by_category,
            "missing_requested_inputs": missing,
            "secret_like_finding_count": len(secret_findings),
            "zip_path": str(zip_path),
            "zip_bytes": int(zip_path.stat().st_size) if zip_path.exists() else 0,
            "zip_sha256": sha256_file(zip_path) if zip_path.exists() else None,
        },
        "secret_like_findings_redacted": secret_findings,
        "files": entries,
    }


def report_text(manifest: dict[str, Any]) -> str:
    summary = manifest["summary"]
    categories = "\n".join(
        f"| {name} | {row['file_count']} | {row['bytes']} |"
        for name, row in sorted(summary["category_summary"].items())
    )
    commands = "\n".join(f"- `{cmd}`" for cmd in manifest["rerun_commands"]["required"])
    return f"""# APV2 Public Freeze Candidate Report

Generated: `{manifest['created_at_utc']}`

## Scope

- scope: `{manifest['scope']}`
- not_scope: `{manifest['not_scope']}`
- repository_status: `{manifest['repository_status']['kind']}`

## Summary

- file_count: `{summary['file_count']}`
- total_bytes: `{summary['total_bytes']}`
- zip_path: `{summary['zip_path']}`
- zip_bytes: `{summary['zip_bytes']}`
- zip_sha256: `{summary['zip_sha256']}`
- secret_like_finding_count: `{summary['secret_like_finding_count']}`
- missing_requested_inputs: `{json.dumps(summary['missing_requested_inputs'], ensure_ascii=False)}`

## Category Summary

| category | files | bytes |
|---|---:|---:|
{categories}

## Required Rerun Commands

{commands}

## Boundary

This package strengthens AP-Core runtime traceability. It does not claim GL learning proof, DPP/Skill37 open-dialogue proof, product-shell proof, DOI-level release, or independent third-party replication.
"""


def build(output_base: Path | None = None) -> dict[str, Any]:
    paths = make_paths(output_base)
    paths.package_dir.mkdir(parents=True, exist_ok=True)
    files, missing = iter_included_files()
    entries = copy_files(files, paths.package_dir)
    readme = write_package_readme(paths.package_dir)
    entries.append(
        {
            "path": readme.relative_to(paths.package_dir).as_posix(),
            "bytes": int(readme.stat().st_size),
            "sha256": sha256_file(readme),
            "category": "Package metadata",
            "mtime_utc": datetime.fromtimestamp(readme.stat().st_mtime, timezone.utc).isoformat(),
        }
    )
    secret_findings: list[dict[str, str]] = []
    for source in files:
        secret_findings.extend(scan_secret_like(source))
    build_zip(paths.package_dir, paths.zip_path)
    manifest = build_manifest(entries, missing, secret_findings, paths.zip_path)

    manifest_path = paths.package_dir / "public_freeze_manifest.json"
    summary_path = paths.package_dir / "public_freeze_summary.json"
    report_path = paths.output_dir / "apv2_public_freeze_candidate_report.md"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    summary_path.write_text(json.dumps(manifest["summary"], ensure_ascii=False, indent=2), encoding="utf-8")
    report_path.write_text(report_text(manifest), encoding="utf-8")

    # Rebuild the zip after manifest and summary are written so extraction is self-describing.
    build_zip(paths.package_dir, paths.zip_path)
    manifest["summary"]["zip_bytes"] = int(paths.zip_path.stat().st_size)
    manifest["summary"]["zip_sha256"] = sha256_file(paths.zip_path)
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    summary_path.write_text(json.dumps(manifest["summary"], ensure_ascii=False, indent=2), encoding="utf-8")
    report_path.write_text(report_text(manifest), encoding="utf-8")

    return {
        "output_dir": str(paths.output_dir),
        "package_dir": str(paths.package_dir),
        "manifest_path": str(manifest_path),
        "summary_path": str(summary_path),
        "report_path": str(report_path),
        "zip_path": str(paths.zip_path),
        "zip_sha256": manifest["summary"]["zip_sha256"],
        "file_count": manifest["summary"]["file_count"],
        "repository_status": manifest["repository_status"]["kind"],
        "secret_like_finding_count": manifest["summary"]["secret_like_finding_count"],
        "missing_requested_inputs": manifest["summary"]["missing_requested_inputs"],
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-base", type=Path, default=None)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    result = build(output_base=args.output_base)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
