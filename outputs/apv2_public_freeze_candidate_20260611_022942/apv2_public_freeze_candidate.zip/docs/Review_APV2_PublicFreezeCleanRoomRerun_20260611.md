# APV2 Public Freeze And Clean-Room Rerun Review

Date: 2026-06-11

## 1. Boundary Review

The freeze package should be narrow enough to support the main APV2 architecture/runtime paper, and broad enough to rerun the current paper-material checks. The correct boundary is:

- Include AP-Core runtime dependencies: `config`, `core`, `memory`, `channels`, `sensors`, selected `legacy_apv2/sensors`, `education`, and `learning_events.py`.
- Include paper-material scripts/tests: main-paper check, publication-figure builder, P0/P1 experiments, and their tests.
- Include paper docs/reports/figure outputs already cited by the manuscript.
- Exclude GL curriculum packages, DPP live artifacts, desktop-pet product shell, secrets, caches, logs, and temporary debug outputs unless explicitly needed by the AP-Core paper checks.

## 2. Risk Review

The strongest risk is hidden dependency on the original workspace. To reduce it, the rerun script must execute from the copied staging root and set `PYTHONPATH` to that root. Another risk is overclaiming the rerun level. The report must say "same-machine clean-room rerun candidate", not "independent clean-machine replication".

The workspace is not a git repository. This should be reported as a remaining limitation rather than hidden.

## 3. Acceptance Review

This round is accepted if:

- freeze script succeeds and writes manifest, summary, report, package directory, and zip archive;
- clean-room rerun executes the manuscript check and selected pytest suite from the staging root;
- paper check remains green in the original workspace;
- selected tests remain green in the original workspace;
- the final report includes a full-score evidence gap matrix with local-feasible and external-resource categories.

## 4. Score Impact

Before this round, the reviewer-style score was 7.75/10. If the freeze and same-machine rerun pass, the score should move to roughly 8.2/10. It still should not be scored as 9+ until a public commit/tag/hash, artifact DOI or equivalent archive, independent machine rerun, and broader stress/baseline/OOD evidence exist.

