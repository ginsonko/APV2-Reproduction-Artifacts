# APV2 P2 Stress Mechanism Evidence Review

Date: 2026-06-11

## 1. Review Summary

The proposed P2 suite is worth adding because it fills a gap left by P0/P1. P0 showed default-parameter and order-ablation behavior. P1 showed long-run recovery, rhythm replay, persistence reload, and figure/freeze material. P2 should pressure the same AP-Core mechanisms with larger mixed evidence and broader parameter sweeps.

## 2. Design Corrections Before Landing

### ResidualDepth-Stress-1

Keep the acceptance criterion qualitative but strict. Winner order may change because MemoryStore combines label overlap, energy overlap, vector/posting support, temporal weighting, and online features. The correct invariant is not "AB must be first"; it is "distinct supported B objects appear round by round while residual mass declines."

### LongRun-Stability-1

Do not require the slot to perfectly preserve every early label. A humanlike short-term slot should tolerate drift. Require main-thread recovery, interruption/resumption traces, and readback availability instead of exact replay.

### ShortTermSlot-Grid-1

Do not treat every extreme parameter as evidence of optimal behavior. The grid should check boundedness and monotonicity. If clipping occurs at low capacity, that is acceptable when it is explicitly recorded as capacity clipping, not hidden.

## 3. Risk Controls

- Use only the local AP-Core runtime objects.
- Do not call any provider or LLM.
- Do not introduce answer routes, regex branches, or table lookup.
- Save outputs as JSON/Markdown so paper claims can cite exact artifacts.

## 4. Review Decision

Approved for implementation as a P2 AP-Core stress package.

