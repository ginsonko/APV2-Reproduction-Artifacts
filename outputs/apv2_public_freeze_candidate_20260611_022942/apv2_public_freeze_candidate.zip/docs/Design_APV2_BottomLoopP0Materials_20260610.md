# APV2 Bottom-Loop P0 Publication Materials Design

Date: 2026-06-10

## 1. Scope

This material package is AP-Core only. It prepares publication evidence for the current APV2 bottom-loop runtime:

- short-term narrative slot as a tick-level inner-sense packet;
- residual B recall as one-winner-per-round SA-mass absorption;
- successor lag shaping as next-tick peak plus decaying tail;
- reward/punishment-derived repair state;
- default parameter table and representative tick trace.

It does not claim GL curriculum learning, DPP/Skill37 learning maturity, desktop-pet product capability, hidden solver performance, or student-side LLM generation.

## 2. Experiments

### APV2-BottomLoop-ParamSensitivity-1

Definition: scan conservative perturbations around the default bottom-loop parameters and verify that core qualitative traces still hold.

Why: the paper needs to show that the bottom-loop evidence is not a single lucky point in parameter space.

Observable evidence:

- short-term slot virtual mass remains positive and bounded;
- residual B recall still produces multiple non-repeating winners and declining residual mass;
- successor lag kernel still has a next-tick peak, sharp second-tick drop, and tail;
- punishment-dominant text still becomes a repair context rather than positive text payload.

Failure boundary:

- extreme parameters may flatten order effects, over-inject short-term-slot energy, or make residual recall too shallow. Such failures should be reported as boundaries rather than hidden.

### ShortTermSlot-OrderAblation-1

Definition: compare recall from ordered slot packets against reversed and order-ablated packets.

Why: the short-term slot is meant to be a soft narrative order bias, not a keyword bag and not a hard sequence gate.

Observable evidence:

- same item set with correct order receives a higher recall score than reversed order;
- removing order rows weakens the advantage but does not make recall impossible;
- item-only overlap still works, proving that order is a soft energy bias rather than a regex route.

Failure boundary:

- current implementation proves slot-packet order SA and sequence/bigram scoring effects. It does not yet prove a fully generalized multi-slot temporal grammar over arbitrary long narratives.

## 3. Publication Materials

The script should generate:

- `apv2_bottom_loop_p0_materials.json`;
- `apv2_bottom_loop_p0_materials_report.md`;
- default parameter table for RuntimeConfig, ShortTermSlotConfig, MemoryStore residual recall, and TransitionStore lag kernel;
- representative tick trace showing state input, short-term slot packet, fast B/C recall, attention, slow B/C recall, and module boundaries.

## 4. Acceptance Policy

The package passes only if:

- both P0 experiments pass;
- default parameter extraction is present;
- representative trace includes short-term-slot, residual recall, and successor lag evidence;
- boundary flags explicitly reject answer tables, regex routes, student-side LLM, hidden solver, and full-sentence action macros.

