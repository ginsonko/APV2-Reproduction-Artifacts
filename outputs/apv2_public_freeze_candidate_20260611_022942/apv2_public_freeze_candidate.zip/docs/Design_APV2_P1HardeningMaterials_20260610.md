# APV2 P1 Hardening Materials Design

Date: 2026-06-10

## 1. Scope

This package continues the AP-Core publication-material hardening after the P0 bottom-loop package. It prepares evidence for:

- formal static figures;
- long-run interruption recovery;
- rhythm successor replay;
- real local persistence reload;
- artifact freeze manifest.

This package does not test GL learning stages, DPP/Skill37 dialogue learning, desktop-pet product safety, external tools, or student-side LLM ability.

## 2. Experiments

### LongRun-InterruptionRecovery-1

Definition: run a repeated narrative rhythm, inject distractor interruptions, then return to the original cue and verify that AP-Core traces recover short-term slot continuity, successor expectation, and focus resumption.

Why this design matters: AP should not only pass a single tick probe. A humanlike narrative loop must tolerate local interruption and reassemble the ongoing thought from short-term-slot readback plus state/memory recall.

Observable evidence:

- interruption and resumption traces appear in focus continuity dynamics;
- short-term-slot virtual mass remains positive after return;
- return ticks recover expected successor labels more strongly than distractor labels;
- module ablation or no-return control weakens the recovery signal.

Counterexample / forbidden interpretation:

- This does not prove open-world dialogue skill learning. It proves AP-Core bottom-loop continuity under controlled interruption.

Example: `sun -> moon -> star` repeats; alarm-like distractors interrupt; returning to `sun` should restore `moon/star` successor pressure and short-term-slot narrative objects.

### RhythmSuccessor-Replay-1

Definition: feed periodic salient focus pulses and verify rhythm feeling, slot rhythm rows, and successor lag prediction align around a next-pulse replay expectation.

Why this design matters: the user expects AP's inner replay to be time-like. If a song or poem has a periodic pattern, AP should not flatten all successors; the next beat should be strongest, with later ticks forming a tail.

Observable evidence:

- `rhythmfelt::pulse` or `rhythmfelt::phase_expectation` appears after enough periodic hits;
- the short-term slot carries `short_term_slot::rhythm`;
- TransitionStore successor predictions show lag 1 peak, lag 2 drop, and lag tail;
- disabling lag shaping flattens the successor kernel.

Counterexample / forbidden interpretation:

- This is not a full music-performance claim. It is a controlled AP-Core rhythm/replay dynamics probe.

Example: every 4 ticks a salient `text::beat` focus appears; AP records a stable period and exposes phase expectation around the next pulse.

### PersistenceBackend-Reload-1

Definition: write memory snapshots to a real local JSONL persistence adapter, instantiate a fresh MemoryStore, warm-load from disk, and verify B recall, C successor prediction, and short-term-slot recall.

Why this design matters: in-memory test adapters are useful, but paper reviewers will ask whether reload survives an actual process boundary and file boundary.

Observable evidence:

- JSONL file exists and has nonzero bytes;
- file SHA-256 is recorded;
- fresh MemoryStore loads persisted snapshots;
- state recall, successor prediction, and short-term-slot recall work after reload.

Counterexample / forbidden interpretation:

- This is a local-file persistence proof, not a PostgreSQL production deployment proof. It exercises the same MemoryPersistenceAdapter contract.

Example: write `cue context -> outcome` plus a short-term-slot snapshot; after cold reload, `cue context` recalls the state row and predicts `outcome`.

### ArtifactFreeze-1

Definition: collect generated reports, JSON outputs, scripts, tests, and design files into a manifest with SHA-256, size, and relative path.

Why this design matters: the paper needs a stable bridge from claims to artifacts. A freeze manifest lets the final paper cite exact local evidence rather than vague "we ran tests".

Observable evidence:

- manifest contains P0 and P1 artifacts;
- each file exists, size is nonzero, SHA-256 length is 64;
- boundary flags state AP-Core only and no hidden solver / answer table / student-side LLM.

Counterexample / forbidden interpretation:

- A local freeze is not yet a public DOI or public release. It is the local pre-freeze used before public packaging.

## 3. Figures

The package should emit Mermaid/static Markdown diagrams for:

- APV2 runtime loop;
- state pool versus short-term narrative slot;
- residual B recall absorption;
- successor lag and rhythm replay;
- evidence-layer split: AP-Core / GL / Product Shell.

These are publication-material figures, not runtime claims by themselves.

## 4. Acceptance Policy

The package passes only if all four experiments pass and the generated report includes:

- figure files;
- JSON results;
- Markdown report;
- artifact freeze manifest;
- boundary fields rejecting keyword hard gates, regex routes, answer tables, student-side LLM, hidden solvers, and full-sentence macros.

