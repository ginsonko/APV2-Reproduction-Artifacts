# APV2 Main Paper Supplement Index

Date: 2026-06-11

This index connects the concise APV2 architecture/runtime main paper to the long technical report and local evidence artifacts. It is an index, not a second copy of the full report.

## 1. Source Relationship

| item | path | role |
|---|---|---|
| Main paper draft | `docs/APV2_MainPaper_ArchitectureRuntime_Draft_20260611.md` | concise architecture/runtime manuscript |
| Master technical report | `docs/APV21_PublicPaper_InitialDraft_v1_0n_20260610.md` | long-form source, appendix material, full evidence context |
| P0 report | `outputs/apv2_bottom_loop_p0_materials_20260611_021431/apv2_bottom_loop_p0_materials_report.md` | parameter sensitivity, order ablation, defaults, tick trace |
| P1 report | `outputs/apv2_p1_hardening_materials_20260611_021432/apv2_p1_hardening_materials_report.md` | long-run recovery, rhythm replay, persistence reload, artifact freeze |
| P2 report | `outputs/apv2_p2_stress_mechanism_evidence_20260611_021433/apv2_p2_stress_mechanism_evidence_report.md` | residual-depth stress, long-run stability, short-term-slot parameter grid |
| Public freeze report | `outputs/apv2_public_freeze_candidate_20260611_021647/apv2_public_freeze_candidate_report.md` | 163-file local AP-Core paper-material freeze candidate |
| Clean-room rerun report | `outputs/apv2_clean_room_rerun_20260611_021658/clean_room_rerun_report.md` | same-machine staging-copy rerun, 2/2 commands passed |

## 2. Figure Inventory

| id | title | svg | png |
|---|---|---|---|
| F1 | APV2 runtime loop | `outputs/apv2_publication_figures_supplement_20260611_002510/figures/f1_apv2_runtime_loop.svg` | `outputs/apv2_publication_figures_supplement_20260611_002510/figures/f1_apv2_runtime_loop.png` |
| F2 | State pool vs short-term narrative slot | `outputs/apv2_publication_figures_supplement_20260611_002510/figures/f2_state_pool_vs_short-term_narrative_slot.svg` | `outputs/apv2_publication_figures_supplement_20260611_002510/figures/f2_state_pool_vs_short-term_narrative_slot.png` |
| F3 | Residual B recall absorption | `outputs/apv2_publication_figures_supplement_20260611_002510/figures/f3_residual_b_recall_absorption.svg` | `outputs/apv2_publication_figures_supplement_20260611_002510/figures/f3_residual_b_recall_absorption.png` |
| F4 | Successor lag and rhythm replay | `outputs/apv2_publication_figures_supplement_20260611_002510/figures/f4_successor_lag_and_rhythm_replay.svg` | `outputs/apv2_publication_figures_supplement_20260611_002510/figures/f4_successor_lag_and_rhythm_replay.png` |
| F5 | Evidence layer split | `outputs/apv2_publication_figures_supplement_20260611_002510/figures/f5_evidence_layer_split.svg` | `outputs/apv2_publication_figures_supplement_20260611_002510/figures/f5_evidence_layer_split.png` |

Manifest: `outputs/apv2_publication_figures_supplement_20260611_002510/figure_manifest.json`

## 3. Main Paper To Technical Report Map

| main paper section | technical report support | evidence artifact | boundary note |
|---|---|---|---|
| Abstract | Summary and APV2 bottom-loop additions | P0/P1/P2 reports | Claims runtime mechanisms, not full open-world mastery |
| 1. Introduction | Chapter 1.0-1.8 | technical report chapter 1 | APV2 is positioned as continuous cognition runtime |
| 2. Minimal objects | Chapter 2.2-2.8 | technical report chapter 2 | External fields are ordinary SA, not AP-native feelings |
| 3. Runtime architecture | Chapter 3.0-3.5 | F1/F2 figures | GL and product shell stay outside AP-Core proof |
| 4. Core mechanisms | Chapter 4.1-4.10.1 | P0/P1/P2 reports, F3/F4 | Residual recall and successor lag are mechanisms, not macro routes |
| 5. P0/P1/P2 evidence | Chapter 6.12 and recent P0/P1/P2 reports | P0/P1/P2 JSON/report artifacts | Evidence supports AP-Core bottom-loop dynamics |
| 6. Related systems | Chapter 7 and 8.2-8.5 | technical report discussion | LLMs are complementary carriers/teachers/tools |
| 7. Evidence boundary | Chapter 1.6, 5, 6.11, 9 | F5 evidence layer figure | DPP/Skill37/product shell are adjacent evidence lines |
| 8. Conclusion | Chapter 8 and 9 | technical report synthesis | Keep the claim positive but bounded |

## 4. P0/P1/P2 Evidence Map

| evidence | result | manuscript use |
|---|---|---|
| `APV2-BottomLoop-ParamSensitivity-1` | `16/16 pass` | bottom-loop mechanisms remain qualitatively stable under conservative parameter perturbations |
| `ShortTermSlot-OrderAblation-1` | full-order margin `18.2466`, without-order margin `9.0539` | order is a soft bias, not a hard gate |
| `LongRun-InterruptionRecovery-1` | interruptions `2`, resumptions `2`, final slot virtual mass `1.3715` | short-term narrative traces can recover after controlled interruption |
| `RhythmSuccessor-Replay-1` | lag 1 `1.0`, lag 2 `0.42`, lag 4 `0.172` | successor shaping has a next-tick peak and decaying tail |
| `PersistenceBackend-Reload-1` | warm-load loaded `3`, JSONL SHA-256 recorded | MemoryStore crosses a real local file persistence boundary |
| `ArtifactFreeze-1` | local manifest `12` entries | local pre-public traceability exists |
| `ResidualDepth-Stress-1` | 8 winners, 7 residual rounds, mass `14.3126 -> 0.7448` | residual B recall remains roundwise and inspectable under a larger mixed query |
| `LongRun-Stability-1` | interruptions `4`, resumptions `5`, final slot virtual mass `0.4791` | short-term narrative continuity remains recoverable under a longer interruption sequence |
| `ShortTermSlot-Grid-1` | `108/108 pass`, virtual mass `0.8706-4.1611`, clipped cases `81` | slot packets remain bounded, monotonic, and capacity-limited across a broader grid |
| `APV2-PublicFreezeCandidate-1` | 163 files, zip SHA-256 `4b60d7c4640a7bb189b416e5bfebbd7f9dda3babc8d132b1e47735aa1ceea826` | current AP-Core paper package is locally hash-frozen |
| `APV2-CleanRoomRerun-1` | 2/2 commands passed, including P0/P1/P2 tests | freeze package is rerunnable from a same-machine staging copy |

## 5. Boundary Notes

| line | correct use |
|---|---|
| AP-Core runtime | Use P0/P1/P2 to support bottom-loop mechanism claims |
| AP-Core tasks | Use KeySuite/STP only as adjacent task-evidence context unless Paper 2 expands it |
| GL learning | Use DPP/Skill37 only after GL-side teacher-off/cold retest and no-leakage audit |
| Product shell | Use desktop pet or UI demos as product/integration evidence, not AP-Core proof |
| Cognitive feelings | Treat them as process-grounded SA generated from internal process quantities |
| Forbidden substitutes | Do not replace learning with answer tables, regex routes, hidden solvers, student-side LLM, or full-sentence macros |

## 6. Next Supplement Work

1. Convert this index into a venue-specific appendix after choosing a target format.
2. Add static line-number anchors if the technical report is frozen.
3. Add public artifact freeze commit/tag/hash when the release package is ready.
4. Add independent clean-machine or VM rerun once an isolated environment is available.
5. Add GL learning evidence only as a separate appendix or companion paper once GL validation is complete.
