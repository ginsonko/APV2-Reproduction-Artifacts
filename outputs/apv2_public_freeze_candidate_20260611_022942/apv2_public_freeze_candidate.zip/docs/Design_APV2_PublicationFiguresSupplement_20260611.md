# APV2 投稿图表与 Supplement 整理设计

日期: 2026-06-11

## 1. 目标

本轮目标是在已经完成的 APV2 架构/runtime 主文草稿基础上, 继续推进投稿材料:

1. 将当前 Mermaid 草图转成可复现生成的静态图表;
2. 建立主文与 long technical report 之间的 supplement / appendix 映射;
3. 增加轻量验收脚本, 检查图表、manifest、supplement 和主文引用是否一致。

本轮仍然只服务 AP-Core architecture/runtime 主文。GL 学习协议、DPP、Skill37 和桌面/桌宠产品壳继续保持独立证据线, 不写成 AP-Core runtime 证明。

## 2. 输入材料

| 输入 | 用途 |
|---|---|
| `docs/APV2_MainPaper_ArchitectureRuntime_Draft_20260611.md` | 主文图表与 supplement 引用对象 |
| `docs/APV21_PublicPaper_InitialDraft_v1_0n_20260610.md` | long technical report / supplement 来源 |
| `outputs/apv2_p1_hardening_materials_20260611_000013/figures/*.mmd` | Mermaid 草图来源 |
| `outputs/apv2_bottom_loop_p0_materials_20260610_234817/apv2_bottom_loop_p0_materials_report.md` | P0 参数、tick trace 和顺序消融数据 |
| `outputs/apv2_p1_hardening_materials_20260611_000013/apv2_p1_hardening_materials_report.md` | P1 长跑、节奏、持久化与 artifact freeze 数据 |

## 3. 输出材料

| 输出 | 作用 |
|---|---|
| `scripts/build_apv2_publication_figures_supplement.py` | 生成静态图、图表 manifest、supplement 索引 |
| `tests/test_apv2_publication_figures_supplement.py` | 验收图表生成与 supplement 结构 |
| `outputs/apv2_publication_figures_supplement_*/figures/*.svg` | 投稿级矢量图源 |
| `outputs/apv2_publication_figures_supplement_*/figures/*.png` | 快速预览图 |
| `outputs/apv2_publication_figures_supplement_*/figure_manifest.json` | 图表大小、哈希、标题与来源 |
| `docs/APV2_MainPaper_Supplement_Index_20260611.md` | 主文与 technical report / evidence artifact 映射 |
| `docs/FinalReport_APV2_PublicationFiguresSupplement_20260611.md` | 本轮最终报告 |

## 4. 图表清单

| figure id | 标题 | 目的 |
|---|---|---|
| F1 | APV2 runtime loop | 主文入口图, 展示 sensor/state/recall/attention/slot/action/feedback 闭环 |
| F2 | State pool vs short-term narrative slot | 说明快系统无序能量场与慢系统有序叙事槽的分工 |
| F3 | Residual B recall absorption | 说明逐轮 winner 与 matched SA mass 吸收 |
| F4 | Successor lag and rhythm replay | 说明 lag 1 波峰、lag 2 急降、尾部和 rhythm phase |
| F5 | Evidence layer split | 说明 AP-Core runtime、AP-Core task、GL learning、product shell 的证据分层 |

## 5. Supplement 组织原则

Supplement 不机械复制整篇 long technical report, 而先建立索引:

1. 主文每个核心章节对应 long technical report 的章节范围;
2. 每个机制对应 P0/P1 证据与输出路径;
3. 每个边界声明对应禁止误读;
4. GL 学习证据和 product shell 只列为相邻证据线, 不纳入 AP-Core runtime 证明。

索引采用“主文 claim -> technical report 支撑位置 -> evidence artifact -> boundary note”的表格结构。

## 6. 审查标准

图表:

- 每张图必须有 SVG 和 PNG;
- 每张图必须记录 sha256、文件大小、标题和来源;
- 图中文字应短、清楚, 不出现 APV2.1 / APV2.2 概念版本分裂;
- 图表不表达超出主文的 claim。

Supplement:

- 必须覆盖主文 8 个主要章节;
- 必须覆盖 P0/P1 六个关键证据;
- 必须明确 AP-Core / GL / product shell 分层;
- 不把 DPP/Skill37 或桌宠展示写成 AP-Core runtime 证明;
- 不把外部字段直接写成 AP-native 认知感受。

## 7. 验收命令

计划运行:

```powershell
python scripts\build_apv2_publication_figures_supplement.py
python -m pytest tests\test_apv2_publication_figures_supplement.py -q
python scripts\check_apv2_mainpaper_runtime_draft.py
```

若 P0/P1 证据需要重新确认, 同时运行:

```powershell
python -m pytest tests\test_apv2_bottom_loop_p0_materials.py tests\test_apv2_p1_hardening_materials.py -q
```
