# APV2 架构/runtime 主文内部审查准则

日期: 2026-06-11

## 1. 审查目标

本准则用于检查 `docs/APV2_MainPaper_ArchitectureRuntime_Draft_20260611.md` 是否已经达到“可读、可信、边界清楚、证据对齐”的主文草稿标准。

## 2. 总体判断

一版合格主文应满足:

1. 读者不需要先读 long technical report, 也能理解 APV2 的问题域、对象、runtime 流程和证据。
2. 每个关键机制都有“定义 -> 为什么这样设计 -> 可观测证据 -> 反例/禁区 -> 示例”的隐含结构, 但正文不写成僵硬条目。
3. 证据说服力来自可运行实验、消融、参数扰动、持久化边界和 trace, 不是来自宣传性比喻。
4. AP-Core runtime、GL 学习协议、产品壳展示三条路线边界清楚。
5. 语言积极严谨, 避免连续防御式否定。

## 3. 逐项审查表

| 项目 | 合格标准 | 常见问题 |
|---|---|---|
| 主题聚焦 | 主线是 APV2 architecture/runtime | 被 KeySuite、GL、桌宠或 FAQ 抢走主线 |
| 新读者可读性 | 先解释问题域, 再解释对象, 再解释机制 | 一上来堆术语和文件路径 |
| 机制闭环 | sensor/SA/state pool/recall/prediction/feeling/action/feedback/memory 能连成 tick 循环 | 模块像散点名词 |
| 快慢系统 | 快系统是状态池上的无序场召回; 慢系统使用短期叙事槽、顺序和回读 | 把慢系统写成单个焦点标签召回 |
| 短期叙事槽 | 每 tick 作为叙事性内感受槽注入虚能量; 槽内弱顺序、槽间相对顺序软偏置 | 写成关键词缓存或绝对顺序匹配 |
| 残差 B 召回 | 一轮一个 B winner, 已匹配 SA 质量被吸收, 后续轮次转向剩余成分 | 写成普通 top-k 或 winner-take-all |
| C/C* 后继 | lag 1 波峰、lag 2 急降、远端尾巴; rhythm 可形成周期相位 | 写成 n-gram 查表或整句续写 |
| 认知感受 | 来自过程量, 可入池、可记忆、可消融 | 把外界字段直接当感受 |
| 行动反馈 | 奖惩/正确性/后果写回影响 drive 和修正态 | 写成独立文本正负标签系统 |
| 证据对齐 | P0/P1 数值准确, claim 与实验对应 | 结果泛化到未测试领域 |
| 版本表述 | 正文只写 APV2 当前实现 | 概念上拆 APV2.1/APV2.2 |
| 边界写法 | 用证据分层说明当前支持范围 | 长串“我们不声称”式防御 |

## 4. 必须出现的证据

主文必须出现并正确解释:

- `APV2-BottomLoop-ParamSensitivity-1`: `16/16 pass`。
- `ShortTermSlot-OrderAblation-1`: full-order margin `18.2466`, without-order margin `9.0539`, order 是软偏置。
- `LongRun-InterruptionRecovery-1`: interruptions `2`, resumptions `2`, final slot virtual mass `1.3715`。
- `RhythmSuccessor-Replay-1`: lag 1 `1.0`, lag 2 `0.42`, lag 4 `0.172`, rhythm slot row 出现。
- `PersistenceBackend-Reload-1`: JSONL persistence, warm-load loaded `3`, SHA-256 可追溯。
- `ArtifactFreeze-1`: local pre-public manifest `12` entries。

## 5. 自动验收建议

主文完成后运行:

```powershell
python scripts\check_apv2_mainpaper_runtime_draft.py
python -m pytest tests\test_apv2_bottom_loop_p0_materials.py tests\test_apv2_p1_hardening_materials.py -q
```

第一条检查主文结构和禁止性污染; 第二条确认 P0/P1 证据包仍可运行。

## 6. 人工审查问题

审查者需要逐段问:

1. 这一段在推进主线, 还是只是在堆历史材料?
2. 这一段的 claim 有没有对应实验、trace 或实现对象?
3. 这一段有没有把外部教师、GL 或产品壳能力偷换为 AP-Core runtime 能力?
4. 这一段如果被审稿人引用反驳, 是否有足够精确的边界?
5. 这一段是否可以更积极地写成“证据支持什么”, 而不是“我们不是什么”?

## 7. 通过标准

通过条件:

- 自动验收通过;
- 六个 P0/P1 证据完整出现;
- 审查表无 P0 blocker;
- 至少完成一次人工修订;
- 最终报告记录验证命令、结果、剩余缺口和下一步。
