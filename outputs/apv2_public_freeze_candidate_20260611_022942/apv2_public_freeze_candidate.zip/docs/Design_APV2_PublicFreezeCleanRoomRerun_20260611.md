# APV2 Public Freeze And Clean-Room Rerun Design

Date: 2026-06-11

## 1. Definition

This round builds a paper-specific APV2 public-freeze candidate and a same-machine clean-room rerun. The scope is the AP-Core architecture/runtime main-paper evidence package: manuscript, supplement, P0/P1 bottom-loop evidence, publication figures, selected tests, selected scripts, and the runtime modules needed to rerun those tests.

It is not a GL learning-protocol package, not a DPP/Skill37 proof package, and not a desktop-pet/product-shell release.

## 2. Why This Design

The current paper has stronger architectural prose and local P0/P1 mechanism evidence, but a reviewer can still ask whether the evidence is traceable and rerunnable. A freeze candidate answers the traceability part by recording files, byte sizes, SHA-256 hashes, environment metadata, and rerun commands. A clean-room rerun answers the local reproducibility part by copying only the frozen package to a separate staging directory and executing the paper checks there.

Because this workspace is not a git repository, this round cannot produce a commit hash or tag. The honest artifact level is therefore: local hash freeze plus same-machine clean-room rerun candidate. A true public artifact would still need a public repository/archive, release tag, and independent rerun.

## 3. Observable Evidence

The freeze script must produce:

- `public_freeze_manifest.json` with schema, environment, repository status, command list, file entries, SHA-256 hashes, category/layer tags, and exclusion notes.
- `public_freeze_summary.json` for quick paper/reference use.
- `apv2_public_freeze_candidate_report.md` with the evidence boundary and full rerun command list.
- A zip archive with SHA-256 digest.

The rerun script must produce:

- A separate staging directory copied from the freeze package.
- `clean_room_rerun.json` with each command, return code, duration, stdout/stderr tails, and environment metadata.
- `clean_room_rerun_report.md` with pass/fail summary.

The acceptance tests must verify:

- The manifest has nonempty files, valid SHA-256 digests, command list, and archive hash.
- Excluded sensitive/noisy files are not copied: `.env*`, `__pycache__`, `.pytest_cache`, `*.pyc`, temporary debug directories.
- The command list includes the main paper check, P0/P1 tests, publication figure tests, and public-freeze tests.
- The package preserves AP-Core / GL / product-shell boundary language.

## 4. Contraindications

Do not present this as:

- a DOI or final public release,
- an external independent reproduction,
- evidence that GL learning or DPP/Skill37 proves AP-Core runtime mechanisms,
- evidence that product-shell integration proves AP-Core mechanisms,
- evidence built from answer tables, regex routes, student-side LLMs, hidden solvers, or full-sentence macros.

## 5. Example

A reviewer reads the paper, opens the freeze report, checks the zip hash, extracts the package, runs:

```powershell
python scripts\check_apv2_mainpaper_runtime_draft.py
python -m pytest tests\test_apv2_publication_figures_supplement.py tests\test_apv2_bottom_loop_p0_materials.py tests\test_apv2_p1_hardening_materials.py tests\test_apv2_public_freeze_clean_room.py -q
```

The expected result is that the paper check passes and the paper-material tests pass inside the staging copy. This does not replace future public hosting or third-party replication, but it removes a major local traceability weakness.

