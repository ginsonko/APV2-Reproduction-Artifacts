# Reviewer Report: APV2 Architecture/Runtime Main Paper

Date: 2026-06-11

## 1. Summary

The manuscript presents APV2 as a white-box predictive-action runtime for continuous cognition. Its central claim is bounded and technically meaningful: APV2 organizes state atoms, a dual-energy state pool, short-term narrative slots, residual B recall, successor prediction, process-grounded cognitive feelings, emotion-like slow modulation, action feedback, and persistence into a runnable and auditable tick loop.

The paper is not framed as a complete AGI system or as an open-world dialogue benchmark. It instead argues for a runtime substrate and supports this claim with P0/P1 mechanism evidence: parameter sensitivity, short-term slot order ablation, interruption recovery, rhythm successor replay, persistence reload, and local artifact freeze.

## 2. Overall Assessment

The paper is promising as a systems/architecture manuscript. Its strongest contribution is the explicit organization of cognitive-runtime objects that are often left implicit in LLM-agent systems: state-field energy, process-grounded feelings, action feedback, and short-term narrative readback. The current draft is substantially more readable than a long technical report and has a clearer evidence boundary.

The main remaining weakness is that the evidence is still mostly local and mechanism-probe based. The paper should be careful to position P0/P1 as runtime-mechanism evidence, not as broad cognitive capability evidence. It also needs stronger artifact freezing before external submission and a clearer bridge from mechanism probes to why the runtime matters for downstream learning.

## 3. Scores

| Criterion | Score | Rationale |
|---|---:|---|
| Novelty and positioning | 1.6 / 2.0 | The state-prediction-action-feedback framing is distinctive, especially the first-class treatment of feelings and feedback. The relation to older cognitive architectures still needs more depth. |
| Technical clarity | 1.5 / 2.0 | Core objects are now understandable, but some terms such as B/C/C*, virtual energy, and cognitive pressure still need a compact formal summary. |
| Evidence and reproducibility | 1.35 / 2.0 | P0/P1 artifacts are precise and test-backed, but the evidence is local and not yet publicly frozen or externally replicated. |
| Related work and fairness | 1.1 / 1.5 | Major neighboring areas are acknowledged. The comparison is fair but still compressed. |
| Writing/readability | 0.8 / 1.0 | The main line is readable. Some sections remain dense and may need venue-specific compression. |
| Boundary honesty | 1.4 / 1.5 | The paper is notably careful about AP-Core vs GL/product-shell boundaries. |

Total: **7.75 / 10**

Recommendation: **Weak Accept / Borderline-Positive**, conditional on artifact hardening and a stronger formal summary of the runtime.

## 4. Strengths

1. Clearer problem framing than many agent papers: continuous cognition is distinguished from longer context, external memory, or tool orchestration.
2. Good internal object model: SA, state pool, short-term narrative slot, B/C/C*, cognitive feelings, emotion-like modulation, action feedback, and persistence are connected into one runtime.
3. P0/P1 evidence is concrete: pass counts, margins, lag kernels, persistence hashes, and targeted tests are cited.
4. The evidence boundary is unusually explicit. GL learning and product shell demonstrations are not conflated with AP-Core runtime proof.
5. The figures materially improve readability.

## 5. Major Concerns

### Concern 1: The runtime formalism needs a compact definition block.

The paper defines objects across several sections, but reviewers will benefit from a single compact block that states:

```text
APV2 runtime = <SA, R, M, S, B, C, E, A, F, P>
```

or an equivalent notation. This would reduce perceived hand-waviness.

### Concern 2: Mechanism probes need a clearer claim-to-evidence mapping.

The P0/P1 table is useful, but the paper should explicitly state which claim each experiment supports and which claim it does not support. This can be done in a short table without becoming defensive.

### Concern 3: Reproducibility is local, not yet public.

The manuscript mentions scripts, outputs, and hashes, but there is not yet a public release tag or DOI-level artifact freeze. This is acceptable for an internal draft, but a serious submission needs a public artifact snapshot.

### Concern 4: Related work remains compressed.

The paper cites LLM agents, Soar/ACT-R, predictive processing, and related theories, but the difference from each route is still described at a high level. A venue submission may need a more formal comparison table or additional prose.

## 6. Minor Concerns

1. Some English captions mix mechanism explanation and boundary language; this is acceptable but can be tightened later.
2. The abstract is strong but close to the upper density limit; a venue-specific version should be shorter.
3. The main paper currently contains explicit file paths. For final publication these should move to appendix or artifact footnotes.
4. The paper would benefit from one representative tick trace figure or table in the main text if space allows.

## 7. Immediate Revision Suggestions

The following changes can be made without new experiments:

1. Add a compact formal runtime definition table.
2. Add a claim-to-evidence-and-boundary table immediately after P0/P1 evidence.
3. Add a short paragraph explaining why mechanism probes are scientifically useful despite being controlled and local.
4. Clarify the artifact status as local pre-public material and list exactly what public freeze still needs.
5. Slightly strengthen related-work wording around Soar/ACT-R and LLM-agent complementarity.

## 8. Suggested Future Experiments

1. ResidualDepth-Stress-1 with larger mixed queries and more distractors.
2. LongRun-Stability-1 with longer tick runs, sleep/wake, task switching, and skill recovery.
3. Public artifact freeze with environment lock and reproducibility script.
4. External replication candidate on a clean machine.
5. GL-side learning experiments only after teacher-off/cold retest/no-leakage audit is complete.

## 9. Reviewer Verdict

This is a credible and interesting architecture/runtime paper draft. It is not yet a polished final submission, mainly because the artifact status and related-work positioning still need hardening. However, the core idea is clear, the evidence is better bounded than in many early architecture papers, and the P0/P1 materials give enough mechanism support to justify continued development toward submission.

Final score: **7.75 / 10**.  
Recommendation: **Weak Accept / Borderline-Positive after revision**.
