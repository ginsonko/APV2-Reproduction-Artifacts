# APV2 P2 Stress Mechanism Evidence Design

Date: 2026-06-11

## 1. Scope

This package is AP-Core runtime evidence. It tests whether the current bottom-loop mechanisms remain inspectable and qualitatively stable under stronger local pressure than the P0/P1 probes.

It does not test GL curriculum learning, Skill38/OpenWorld-Foundation language maturity, desktop-pet product integration, or the ACG-j third-party implementation.

## 2. Evidence Targets

### ResidualDepth-Stress-1

Definition: build a larger mixed state-memory field, query it with multiple supported components plus distractors, and require residual B recall to proceed round by round.

Why this matters: the current AP design treats B recall as a physical-like absorption process. One B object should absorb the query components it matches, leaving the remaining query mass to make other objects salient in later rounds. This is different from one-shot top-k retrieval.

Observable evidence:

- at least five residual rounds;
- winners are distinct;
- residual mass decreases across traced rounds;
- early paired memories are recovered before distractors dominate;
- drained labels are visible in the trace.

Boundary:

- no answer table;
- no regex or keyword route;
- no hidden solver;
- no language-learning claim.

### LongRun-Stability-1

Definition: run a longer white-box focus sequence with repeated main-narrative segments, multiple interruptions, and resumptions. Each tick builds a short-term-slot packet and stores it through the actual MemoryStore.

Why this matters: the short-term slot is the narrative inner-sense packet. Under interruptions, it should not behave like a brittle exact string buffer. It should show interruption/resumption events, preserve readback, and allow state/slot recall to recover the main thread.

Observable evidence:

- at least two interruptions and two resumptions;
- final slot still contains main-narrative labels;
- readback is available;
- replay candidates exist for interrupted episodes;
- MemoryStore recall can recover the main state and recent/resumed slot snapshots.

Boundary:

- the focus sequence is a white-box AP-Core stress probe;
- it is not an open-dialogue benchmark.

### ShortTermSlot-Grid-1

Definition: run a parameter grid over slot capacity, virtual budget, order decay, and continuity gain.

Why this matters: P0 already showed conservative sensitivity around defaults. P2 asks a broader question: does the slot packet remain bounded, monotonic, and interpretable across a wider range?

Observable evidence:

- capacity caps are respected;
- virtual mass remains finite and nonzero;
- order coefficients are monotonic when order rows exist;
- summary and continuity rows are present;
- broad cases pass, while any edge behavior is reported rather than hidden.

Boundary:

- this validates slot packet mechanics;
- it does not prove final parameter optimality.

## 3. Route Split

| route | included here | excluded here |
|---|---|---|
| AP-Core runtime | residual recall, short-term slot, focus continuity, memory recall | GL learning protocol, product shell |
| GL learning | none | Skill38, DPP, OpenWorld-Foundation |
| third-party replication | only referenced as pending external evidence | no ACG-j rerun or claim of accepted replication |

## 4. Acceptance

The suite passes only if all three mechanism experiments pass and the boundary flags remain locked:

- `answer_table_lookup=false`
- `keyword_hard_gate=false`
- `regex_route=false`
- `student_side_llm=false`
- `hidden_solver=false`
- `full_sentence_macro=false`

