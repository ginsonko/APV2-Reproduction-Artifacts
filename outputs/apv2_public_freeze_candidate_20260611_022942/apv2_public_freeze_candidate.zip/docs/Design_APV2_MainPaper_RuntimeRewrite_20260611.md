# APV2 架构/runtime 主文改写设计

日期: 2026-06-11

## 1. 目标

本轮工作的目标是从现有长稿中抽取一版更短、更清晰、更适合投稿主文阅读的 APV2 架构/runtime 草稿。现有长稿继续保留为 master technical report, 承担完整历史、FAQ、长证据链、术语表和复现细节; 新主文只承担一条主线:

> APV2 是一个可运行、可观测、可消融的白箱预测-行动闭环 runtime。它把 SA、双能量状态池、短期叙事槽、残差式 B 召回、Cn/C* 后继预测、过程性认知感受、情绪慢量、行动反馈、持久化与审计 trace 组织成持续 tick 循环。

主文要让第一次接触 AP 的读者能看懂三个问题:

1. APV2 解决的不是“更长上下文”问题, 而是持续认知 runtime 问题。
2. APV2 的核心机制如何在 tick 循环中互相作用。
3. 当前 P0/P1 证据具体支持了哪些底层动力学结论。

## 2. 输入材料

本轮主文抽取使用以下材料:

| 材料 | 用途 |
|---|---|
| `docs/APV21_PublicPaper_InitialDraft_v1_0n_20260610.md` | master technical report 来源, 不直接大删 |
| `docs/Outline_APV2_Paper1_ArchitectureAndRuntime_20260610.md` | 章节骨架 |
| `docs/Design_APV2_PublicationSplitAndMaterialBacklog_20260610.md` | 一篇主文 + technical report / companion paper 策略 |
| `outputs/apv2_bottom_loop_p0_materials_20260610_234817/apv2_bottom_loop_p0_materials_report.md` | P0 参数敏感性、顺序消融、默认参数与代表 tick trace |
| `outputs/apv2_p1_hardening_materials_20260611_000013/apv2_p1_hardening_materials_report.md` | P1 长跑打断恢复、节奏后继、持久化重载、artifact freeze |
| `docs/FinalReport_APV2_P1HardeningMaterials_20260611.md` | P1 验收总结与边界 |

## 3. 输出文件

本轮计划落地:

| 文件 | 作用 |
|---|---|
| `docs/APV2_MainPaper_ArchitectureRuntime_Draft_20260611.md` | APV2 架构/runtime 主文草稿 |
| `docs/ReviewRubric_APV2_MainPaper_RuntimeRewrite_20260611.md` | 内部审查准则 |
| `scripts/check_apv2_mainpaper_runtime_draft.py` | 轻量文档验收脚本 |
| `docs/FinalReport_APV2_MainPaper_RuntimeRewrite_20260611.md` | 最终汇总报告 |

## 4. 主文结构

主文按如下结构展开:

1. 摘要与关键词。
2. 引言: 持续认知为什么不是更长 prompt / 外接记忆。
3. APV2 的最小对象: SA、状态池、记忆、行动、反馈、感受、预测、教师/技能入口。
4. runtime 架构: sensor 到 SA, SA 到双能量状态池, fast recall, attention, short-term narrative slot, slow recall, action competition, feedback writeback。
5. 核心机制:
   - 双能量状态池;
   - 快系统与慢系统;
   - 短期叙事槽作为叙事性内感受槽;
   - 残差式 B 召回;
   - successor lag 与 rhythm;
   - 过程性认知感受、情绪慢量与行动反馈;
   - 持久化与审计 trace。
6. P0/P1 evidence:
   - `APV2-BottomLoop-ParamSensitivity-1`;
   - `ShortTermSlot-OrderAblation-1`;
   - `LongRun-InterruptionRecovery-1`;
   - `RhythmSuccessor-Replay-1`;
   - `PersistenceBackend-Reload-1`;
   - `ArtifactFreeze-1`。
7. 与 LLM agent 和传统认知架构的关系。
8. 证据边界与后续路线。
9. 结论。

## 5. 写作原则

主文采用正向、可审计、少防御的写法:

- 用“该结果支持什么”组织证据, 不把正文写成连续否定清单。
- 证据层级清楚: AP-Core runtime 证据、AP-Core task 证据、GL 学习协议证据、product shell 展示证据分开。
- 不在论文正文概念上区分 APV2.1 / APV2.2; 全部写成当前 APV2。
- 不把 GL replay、DPP、Skill37 或桌宠产品壳写成 AP-Core runtime 证明。
- 不把外界输入字段直接写成 AP-native 认知感受; 认知感受必须来自过程量。
- 不把发言文本、动作宏或外部教师输出写成 AP 自身学到的完整答案。
- 参数、实验名、pass 数、关键数值必须可追溯到 P0/P1 输出。

## 6. 验收标准

本轮完成标准:

1. 主文草稿能独立阅读, 不依赖读者先读 20 万字 technical report。
2. 必须出现六个 P0/P1 证据名与关键数值。
3. 必须有默认参数表、证据表和代表性 tick trace 摘要。
4. 不出现概念性 APV2 版本拆分。
5. 不使用硬路由、整句宏、隐藏求解器等替代学习的表述。
6. 文档验收脚本通过。
7. P0/P1 targeted tests 仍通过, 证明引用的证据包未漂移。

## 7. 后续连接

若本轮通过, 下一步不是继续加长主文, 而是:

1. 生成投稿图表的静态版本;
2. 把 technical report 整理为 supplement / appendix;
3. 等 GL 侧学习协议证据稳定后, 再写学习协议或 evidence/audit companion paper;
4. 针对目标 venue 压缩字数、统一引用格式和图表编号。
