# APV2 投稿图表与 Supplement 审查准则

日期: 2026-06-11

## 1. 审查目标

本准则用于检查本轮图表和 supplement 索引是否真正提升投稿材料质量, 而不是只增加文件数量。

## 2. 图表审查

| 检查项 | 通过标准 |
|---|---|
| 可复现 | 图表由脚本生成, manifest 记录哈希 |
| 可读性 | 节点文本短, 层次清楚, 不依赖长段说明 |
| 主文一致 | 图表名称与主文核心机制一致 |
| 边界正确 | F5 清楚区分 AP-Core runtime、AP-Core task、GL learning、product shell |
| 投稿可用 | SVG 用于矢量源, PNG 用于预览 |

## 3. Supplement 审查

| 检查项 | 通过标准 |
|---|---|
| 映射完整 | 覆盖主文 8 个主要章节 |
| 证据齐全 | 覆盖 P0/P1 六项证据 |
| 不机械复制 | 以索引和定位为主, 不把 long report 再复制一遍 |
| 边界清楚 | GL/DPP/Skill37/product shell 只作为相邻证据线 |
| 术语统一 | 概念上统一写 APV2 当前实现 |

## 4. 自动验收

通过条件:

1. `build_apv2_publication_figures_supplement.py` 能生成 5 张 SVG、5 张 PNG、manifest 和 supplement index;
2. `tests/test_apv2_publication_figures_supplement.py` 通过;
3. `check_apv2_mainpaper_runtime_draft.py` 仍通过;
4. 输出 manifest 中每个 figure 的 sha256 非空且文件 size 大于 0。

## 5. 人工审查问题

1. 读者看 F1 能否立刻理解 APV2 runtime loop?
2. F2 是否真正说明了快系统和慢系统分工?
3. F3 是否避免把 residual recall 误画成普通 top-k?
4. F4 是否体现下一拍波峰和节奏相位?
5. F5 是否保护 AP-Core / GL / product shell 边界?
6. Supplement 是否能帮助审稿人找到证据, 而不是逼他读完整长稿?
