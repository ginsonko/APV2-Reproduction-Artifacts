# Artificial PsyArch V2.1 / APV2.1

APV2.1 is a research prototype for a full-stack cognitive architecture. This checkout is also used to prepare a temporary private review package for technical friends, embodied-AI engineers, and AI-assisted code reviewers who need to understand the current development state quickly.

This project is **not open source**. The repository is shared only for private review, local testing, and technical discussion under the temporary review license in [LICENSE](LICENSE).

## One-Sentence Summary

APV2.1 explores **Endogenous Cognitivism**: cognitive ability can emerge from an internal information-flow structure instead of depending only on neural-network parameter training or hand-written symbolic rules.

AP is not a Transformer, not a neural network, not an expert system, and not a pure if-else rule engine. It is a white-box cognitive runtime built around state fields, attention, memory, cognitive feelings, action selection, and reward/punishment feedback.

## What To Open First

If this is your first contact with APV2.1, start with [APV21_FIRST_REVIEWER_GUIDE.md](APV21_FIRST_REVIEWER_GUIDE.md). It explains how to review the project fairly, what common "rule sandbox" readings get right, and where those readings become too shallow.

For the latest local repository-quality self-review, see [CURRENT_REPOSITORY_REVIEW.md](CURRENT_REPOSITORY_REVIEW.md).

The fastest way to inspect the current state is to open these local HTML reports after cloning:

1. Beginner public overview:
   `experiments/public4_apv21_beginner_evidence_showcase/APV21_Public4_beginner_evidence_showcase.html`

1. Elementary math graduation showcase:
   `experiments/public_math_graduation0_showcase/APV21_Public_Math_Graduation0_showcase.html`

1. Daily language and common-sense prebricks:
   `experiments/commonsense0_daily_language_bricks/APV21_CommonSense0_daily_language_bricks.html`

1. Multiturn daily dialogue retention:
   `experiments/commonsense1_multiturn_dialogue_retention/APV21_CommonSense1_multiturn_dialogue_retention.html`

1. Daily dialogue random retention:
   `experiments/commonsense2_daily_dialogue_random_retention/APV21_CommonSense2_daily_dialogue_random_retention.html`

1. Open daily dialogue interference retention:
   `experiments/commonsense3_open_daily_dialogue_interference_retention/APV21_CommonSense3_open_daily_dialogue_interference_retention.html`

1. Open daily dialogue long retention:
   `experiments/commonsense4_open_dialogue_long_retention/APV21_CommonSense4_open_dialogue_long_retention.html`

1. Memory-cooled dialogue rehab:
   `experiments/commonsense5_memory_cooled_dialogue_rehab/APV21_CommonSense5_memory_cooled_dialogue_rehab.html`

1. Dialogue fatigue and boundary:
   `experiments/commonsense6_dialogue_fatigue_boundary/APV21_CommonSense6_dialogue_fatigue_boundary.html`

1. Mixed daily dialogue retention:
   `experiments/commonsense7_mixed_daily_dialogue_retention/APV21_CommonSense7_mixed_daily_dialogue_retention.html`

1. Public daily-language/common-sense showcase v2:
   `experiments/public_language2_commonsense4_showcase/APV21_Public_Language2_commonsense4_showcase.html`

1. Public daily-language/common-sense showcase v1:
   `experiments/public_language1_commonsense3_showcase/APV21_Public_Language1_commonsense3_showcase.html`

1. Earlier daily-language/common-sense showcase:
   `experiments/public_language0_commonsense_showcase/APV21_Public_Language0_commonsense_showcase.html`

1. Visual Chinese glyph focus prebricks:
   `experiments/visualtext0_chinese_glyph_focus_prebricks/APV21_VisualText0_chinese_glyph_focus_prebricks.html`

1. Visual UI word focus prebricks:
   `experiments/visualtext1_ui_word_focus_prebricks/APV21_VisualText1_ui_word_focus_prebricks.html`

1. Visual UI phrase focus prebricks:
   `experiments/visualtext2_phrase_focus_prebricks/APV21_VisualText2_phrase_focus_prebricks.html`

1. Realistic UI interference reading:
   `experiments/visualtext3_realistic_ui_interference_reading/APV21_VisualText3_realistic_ui_interference_reading.html`

1. UI reading random retention:
   `experiments/visualtext4_ui_reading_random_retention/APV21_VisualText4_ui_reading_random_retention.html`

1. Screenshot-like UI reading dry-run:
   `experiments/visualtext5_screenshot_like_ui_dryrun/APV21_VisualText5_screenshot_like_ui_dryrun.html`

1. Synthetic UI action sandbox:
   `experiments/desktoptext0_synthetic_ui_action_sandbox/APV21_DesktopText0_synthetic_ui_action_sandbox.html`

1. Synthetic UI input sequence sandbox:
   `experiments/desktoptext1_synthetic_ui_input_sequence/APV21_DesktopText1_synthetic_ui_input_sequence.html`

1. Synthetic UI result selection sandbox:
   `experiments/desktoptext2_synthetic_result_selection/APV21_DesktopText2_synthetic_result_selection.html`

1. Synthetic content browsing and preference sandbox:
   `experiments/desktoptext3_synthetic_content_browse_preference/APV21_DesktopText3_synthetic_content_browse_preference.html`

1. Multiround synthetic browsing flow:
   `experiments/desktoptext4_multiround_synthetic_browse_flow/APV21_DesktopText4_multiround_synthetic_browse_flow.html`

1. Multiwindow multitask synthetic UI flow:
   `experiments/desktoptext5_multiwindow_multitask_ui_flow/APV21_DesktopText5_multiwindow_multitask_ui_flow.html`

1. Safe desktop gate sandbox:
   `experiments/desktoptext6_safe_desktop_gate_sandbox/APV21_DesktopText6_safe_desktop_gate_sandbox.html`

1. Long multi-app workflow sandbox:
   `experiments/desktoptext7_long_multiapp_workflow_sandbox/APV21_DesktopText7_long_multiapp_workflow_sandbox.html`

1. Delayed verification memory sandbox:
   `experiments/desktoptext8_delayed_verification_memory_sandbox/APV21_DesktopText8_delayed_verification_memory_sandbox.html`

1. Distractor memory competition sandbox:
   `experiments/desktoptext9_distractor_memory_competition/APV21_DesktopText9_distractor_memory_competition.html`

1. Real desktop dry-run adapter:
   `experiments/desktoptext10_real_desktop_dryrun_adapter/APV21_DesktopText10_real_desktop_dryrun_adapter.html`

1. Long dry-run desktop session retention:
   `experiments/desktoptext11_long_dryrun_session_retention/APV21_DesktopText11_long_dryrun_session_retention.html`

1. Phrase-guided dry-run desktop bridge:
   `experiments/desktoptext12_phrase_guided_dryrun_bridge/APV21_DesktopText12_phrase_guided_dryrun_bridge.html`

1. Visual-only phrase dry-run audit:
   `experiments/desktoptext12b_visual_only_phrase_dryrun_audit/APV21_DesktopText12b_visual_only_phrase_dryrun_audit.html`

1. Screenshot-like phrase action dry-run:
   `experiments/desktoptext13_screenshot_like_phrase_action_dryrun/APV21_DesktopText13_screenshot_like_phrase_action_dryrun.html`

1. Long screenshot-like dry-run retention:
   `experiments/desktoptext14_long_screenshot_like_dryrun_retention/APV21_DesktopText14_long_screenshot_like_dryrun_retention.html`

1. Interruption, inattention, and recovery:
   `experiments/public5_apv21_interruption_inattention_showcase/APV21_Public5_interruption_inattention_showcase.html`

1. Long replay with state-field panels:
   `experiments/p1l18_long_evidence_replay_showcase/APV21_P1L18_long_evidence_replay_showcase.html`

1. Uncertainty restraint and evidence-seeking replay:
   `experiments/p1l20_uncertainty_restraint_replay_showcase/APV21_P1L20_uncertainty_restraint_replay_showcase.html`

1. Latest elementary-math retention evidence:
   `experiments/math21b_division_word_problem_random_retention/APV21_Math21b_division_word_problem_random_retention.html`

1. Latest mixed word-problem semantic pre-course:
   `experiments/math22_mixed_word_problem_prebricks/APV21_Math22_mixed_word_problem_prebricks.html`

1. Latest mixed word-problem bridge:
   `experiments/math23_mixed_word_problem_bridge/APV21_Math23_mixed_word_problem_bridge.html`

1. Latest mixed word-problem long retention:
   `experiments/math24_mixed_word_problem_random_retention/APV21_Math24_mixed_word_problem_random_retention.html`

1. Strict vertical-process audit inside mixed word problems:
   `experiments/math24b_strict_vertical_word_problem_audit/APV21_Math24b_strict_vertical_word_problem_audit.html`

1. Linear-equation prebricks:
   `experiments/math25_linear_equation_prebricks/APV21_Math25_linear_equation_prebricks.html`

1. Linear-equation random retention:
   `experiments/math26_linear_equation_random_retention/APV21_Math26_linear_equation_random_retention.html`

1. Equation word-problem bridge:
   `experiments/math27_equation_word_problem_bridge/APV21_Math27_equation_word_problem_bridge.html`

1. Equation word-problem interference retention:
   `experiments/math28_equation_word_problem_interference_retention/APV21_Math28_equation_word_problem_interference_retention.html`

1. Layered long-memory and rehabilitation recall:
   `experiments/longmemory1_layered_fidelity_rehab_recall/APV21_LongMemory1_layered_fidelity_rehab_recall.html`

1. Slow-focus indexed fast-snapshot prefetch:
   `experiments/longmemory2_slow_focus_fast_snapshot_prefetch/APV21_LongMemory2_slow_focus_fast_snapshot_prefetch.html`

1. Long attention-capture gradient:
   `experiments/p1j22_long_attention_gradient/APV21_long_attention_gradient_player.html`

1. Humanlike evidence showcase:
   `experiments/public2_apv21_humanlike_evidence_showcase/APV21_Public2_humanlike_evidence_showcase.html`
More entry points are listed in [EXPERIMENT_INDEX.md](EXPERIMENT_INDEX.md).

## Current Capability Snapshot

APV2.1 currently demonstrates these prototype abilities in controlled experiments:

- Visual focus movement and attention selection.
- Inattention to familiar background input and capture by surprising or highly incongruent input.
- State-pool based "imagined" or reconstructed visual/audio panels.
- Short-term echo, unfinished-thought bias, interruption recovery, and task continuation.
- Multimodal building-block generalization, including color/object/text combinations such as learning red apple and yellow banana style materials, then composing unseen combinations.
- Draft writing, rereading, local revision, satisfaction/commit logic, and teacher-off retention.
- External education protocol with strong scaffold, weak scaffold, feedback-only, teacher-off, and cold-retest phases.
- Open uncertainty restraint: when evidence is insufficient, AP can wait, reread, recall, or request more evidence instead of forcing a commit.
- Daily common-sense and language prebricks in CommonSense-0: common objects, object use, short scene intent, polite reply quality feelings, uncertainty asking, teacher-off no-answer feedback repair, and process-trace skill accumulation.
- Multiturn daily dialogue retention in CommonSense-1: 2-3 turn context anchors, object grounding, intent competition, CommonSense-0 recall, boundary/uncertainty/non-template quality feelings, reread repair, and no-answer feedback.
- Longer daily dialogue random retention in CommonSense-2: 16 daily intent families, hygiene/safety/emotion/planning common sense, 17 common objects, reply diversity checks, and no-answer feedback repair.
- Open daily dialogue interference retention in CommonSense-3: 23 daily intent families, 50 grounded object/context items, response-move composition, similar-scene interference rejection, social quality feelings, reply diversity checks, and no-answer feedback repair.
- Open daily dialogue long retention in CommonSense-4: the CommonSense-3 response-move route is stretched to 736 teacher-off cases across 32 rounds, with slower mid-course stabilization, expression-style successor bias, rising first-quality curves, high reply diversity, and no-answer feedback repair.
- Memory-cooled dialogue rehab in CommonSense-5: selected CommonSense-4 process memories cool from hot snapshots into warm tickets, slow-focus tickets, and cold archives; ordinary recall finds the old skill without rehydration, while content plus rehab/context pressure restores response moves and successor traces without storing final reply text.
- Dialogue fatigue and boundary handling in CommonSense-6: controlled daily dialogues with repetition loops, tired-after-practice signals, time transitions, personal boundaries, unsafe persistence, compulsive refresh, noisy-video fatigue, unclear references, apology overdoing, polite disagreement, long-task overload, and gentle check-ins; AP selects response moves, derives quality feelings, repairs, and receives no-answer feedback.
- Mixed daily dialogue retention in CommonSense-7: open daily scenes and fatigue/boundary scenes appear in one 560-case teacher-off stream, forcing source-route switching, intent competition, response-move reuse, quality-feeling repair, expression variation, and no-answer feedback across 35 intent families.
- Visual Chinese glyph focus prebricks in VisualText-0: single-character image focus patches, stroke/structure features, candidate character competition, semantic anchors, visual-quality feelings, and no-answer feedback repair.
- Visual UI word focus prebricks in VisualText-1: two-character UI/button words, slot-1/slot-2 focus extraction, per-slot glyph candidates, left-to-right order binding, action semantic anchors, and no-answer feedback repair.
- Visual UI phrase focus prebricks in VisualText-2: four-character UI phrase images, four-slot focus extraction, per-slot glyph candidates, phrase order binding, phrase action semantic anchors, visual uncertainty feelings, and no-answer feedback repair.
- Realistic UI interference reading in VisualText-3: synthetic UI screens with multiple regions, similar labels, low contrast, small fonts, occlusion, busy toolbars, disabled-button style, glare/shadow, and clutter. Teacher-off observation packets contain only image paths, boxes, and visual metadata; phrase text appears only after AP visual-reading draft events.
- UI reading random retention in VisualText-4: the VisualText-3 process is stretched into a 384-case randomized teacher-off stream, measuring whether first-attempt correctness improves, whether pre-submit repair grows, and whether post-feedback repair remains answer-free.
- Screenshot-like UI reading dry-run in VisualText-5: VisualText-4 process memory is tested against richer synthetic screenshot-like scenes across browser search pages, note editors, chat compose windows, settings panels, video feeds, file dialogs, form pages, and message lists. Teacher-off observations still carry only image paths, boxes, and visual metadata; AP must focus regions, extract slots, draft phrases, repair, receive answer-free feedback, and commit without real screen reading or live desktop action.
- Screenshot-like phrase action dry-run in DesktopText-13: VisualText-5 screenshot-like visual reading is connected to DesktopText-12b-style safety gates. AP reads a phrase from a generated screenshot-like UI scene, binds it to a semantic action anchor, competes over inert action candidates, repairs when risk/evidence/verification feelings do not close, and commits only a simulated dry-run action with real screen reading disabled and actuators disabled.
- Long screenshot-like dry-run retention in DesktopText-14: DesktopText-13 is stretched into a 384-case, 32-round teacher-off random stream. It checks whether screenshot-like phrase reading, semantic action anchoring, dry-run safety gates, and repair remain stable across many randomized scenes while observation packets stay phrase-free and all actuators remain disabled.
- Synthetic UI action sandbox in DesktopText-0: controlled panel focus, button-word reading through VisualText-1, target-intent binding, action candidate competition, risk/evidence/closure feelings, no-answer feedback repair, and safe candidate commit without real desktop control.
- Synthetic UI input sequence sandbox in DesktopText-1: textbox focus, input-text binding, button-word reading, sequence candidate competition, order/content/target/risk feelings, no-answer feedback repair, and safe multi-step sequence commit without real mouse or keyboard actions.
- Synthetic UI result selection sandbox in DesktopText-2: reuse of DesktopText-1 input sequence, synthetic environment state change, visible result-card reading, relevance/interest/risk/evidence-gap feelings, no-answer feedback repair, and safe result selection without real web or video action.
- Synthetic content browsing sandbox in DesktopText-3: reuse of DesktopText-2 result selection, synthetic content-page opening, visible content reading, preference/source/risk/evidence feelings, no-answer feedback repair, and safe follow-up action choice without real web/video/desktop action.
- Multiround synthetic browsing flow in DesktopText-4: multi-page content stream, carried preference/fatigue/risk/evidence feelings, feedback-only sequence repair, and sandbox episode commit without real web/video/desktop action.
- Multiwindow multitask synthetic UI flow in DesktopText-5: synthetic tabs/windows, active-goal restoration, risk popup exit, search refinement, save/like continuation, interruption recovery, reference-window checking, multitask cognitive feelings, no-answer feedback repair, and sandbox-only flow commit without real web/video/desktop action.
- Safe desktop gate sandbox in DesktopText-6: synthetic app focus, permission prompts, destructive-risk warnings, wrong-field undo, evidence-gap restraint, cancel/restore/verify actions, safety-gate cognitive feelings, no-answer feedback repair, and sandbox-only commit with actuators disabled.
- Long multi-app workflow sandbox in DesktopText-7: 2-3 synthetic app hops, goal preservation, evidence recovery, permission/cancel/undo/restore/verify safety gates, long-workflow cognitive feelings, no-answer feedback repair, and actuator-disabled sandbox-only commit.
- Delayed verification memory sandbox in DesktopText-8: cooled workflow traces, warm tickets, cold refs, verification-pressure rehydration, low-strength virtual context with `real_energy=0`, wrong-cue control, no-answer repair, and actuator-disabled sandbox-only commit.
- Distractor memory competition sandbox in DesktopText-9: several similar cooled workflow memories compete through soft evidence dimensions, early rounds are pulled toward distractors, mismatch pressure rehydrates alternative virtual context, no-answer feedback repairs wrong ticket selection, and all commits stay actuator-disabled.
- Real desktop dry-run adapter in DesktopText-10: synthetic real-desktop-shaped observations, inert action proposals, permission/risk/evidence gates, human-approval need, simulated commits, no private screen read, and `actuator_enabled=false` for every case.
- Long dry-run session retention in DesktopText-11: several desktop-like goals run inside one synthetic session with repeated goals, fatigue, interruption, delayed verification, memory interference, step-order feelings, no-answer feedback repair, and actuator-disabled simulated session commits.
- Phrase-guided dry-run desktop bridge in DesktopText-12: VisualText-2 phrase reading is connected to DesktopText-11 dry-run session gates. It reads synthetic UI phrases such as 搜索内容, 打开网页, 保存笔记, 确认发送, 取消操作, 返回主页, 刷新页面, 删除草稿, 输入文字, 打开设置, 选择视频, and 继续阅读, then competes over inert dry-run proposals under phrase/order/semantic/risk/evidence/approval feelings. It still does not read the real screen or execute real desktop actions.
- Visual-only phrase dry-run audit in DesktopText-12b: the teacher-off observation packet contains only synthetic image regions and boxes, not phrase text values. Phrase strings appear only after AP visual-reading draft events, then enter the same dry-run safety-gated proposal route.
- Elementary mathematics learning experiments from digit/quantity/sequence blocks through addition, subtraction, multiplication, and long division.
- Controlled Chinese word-problem reading pre-course before Math-21, including language bricks, synonym/context variants, random retention, and no-answer feedback repair.
- Controlled division word-problem solving in Math-21: read a Chinese problem, form equation intent, reuse the retained long-division chain, write a verification expression, reread/repair, and commit.
- Longer division word-problem random retention in Math-21b, with early slips, rising first-correct rate, decreasing repairs, evidence-gap restraint, and no-answer feedback.
- Mixed word-problem semantic prebricks in Math-22: addition/subtraction/multiplication/division relation recognition, two-step order retention, verification-route choice, and evidence-gap restraint before full mixed application-problem solving.
- Mixed word-problem bridge in Math-23: read controlled story text, choose operation sequence, call retained add/subtract/multiply/divide process skills, write steps, verify, repair, and commit.
- Mixed word-problem random retention in Math-24: a longer 144-case teacher-off stream that checks whether the Math-23 bridge becomes more stable through practice.
- Strict vertical-process audit in Math-24b: a 48-case teacher-off audit that checks whether mixed application problems expand into visible column/row processes instead of only showing process labels or direct result calls.
- Linear-equation prebricks in Math-25: unknown binding, equality balance, inverse operations, visible balance transforms, substitution checks, and no-answer feedback repair before larger equation word problems.
- Linear-equation random retention in Math-26: a longer teacher-off stream that inherits Math-25 process traces, keeps feedback answer-free, and measures whether one-variable equation solving becomes more stable through practice.
- Equation word-problem bridge in Math-27: controlled Chinese short problems are read into quantity roles, unknown `x`, equation drafts, retained Math-26 equation solving, substitution checks, and answer sentences.
- Equation word-problem interference retention in Math-28: controlled problems include irrelevant numbers, unit distractors, synonym/order variants, relevant-quantity selection, distractor suppression, retained equation solving, and no-answer feedback repair.
- Layered fidelity long-memory prototype in LongMemory-1: hot full snapshots, warm B/C recall tickets, cold lossless archives, skill prototypes, and rehabilitation-triggered cold rehydration.
- Slow-focus fast-snapshot prefetch in LongMemory-2: slow-system focus tickets can point back to their origin fast-system state-pool snapshots; ordinary recall only prefetches, while context/rehab pressure exposes low-strength virtual context candidates.
- Skill experience packages that accumulate process traces, feedback curves, and reusable skill evidence without turning into answer tables.

The strongest recent math result is Math-20: two-digit-divisor long-division random retention. It uses Math-19 experience, then runs a 120-question random stream. The latest local report recorded final correctness for all 120 questions, improving first-correct rate across rounds while reducing revisions. This should be read as controlled prototype evidence, not as a claim that all school math is solved.

The public elementary-math graduation showcase is `experiments/public_math_graduation0_showcase/APV21_Public_Math_Graduation0_showcase.html`. It aggregates seven representative stages from multi-digit addition/subtraction through multiplication, long division, mixed application problems, one-variable equations, and interfered equation word problems. The selected evidence covers 728 controlled teacher-off practice cases with 728 final correct results and about 5.53 MB of selected skill-package evidence. This is the best current first-stop math page for nontechnical reviewers, while still clearly stating the controlled-prototype boundary.

The latest daily-language result is CommonSense-0: a 110-case teacher-off stream covering 10 daily intents and 13 common objects. It grounds objects and scene tags, competes over intent, recalls object/use/common-sense traces, drafts a short reply, derives quality feelings such as politeness and context relevance, rereads or repairs, then commits. The local report records final correctness for all 110 cases, first-half to second-half quality improvement from `0.3636` to `0.6909`, first-round to last-round quality improvement from `0.3` to `1.0`, 52 revisions, and 26 post-feedback repairs with empty `answer_payload`. This is a daily-language pre-course, not a claim of open-ended free chat.

The latest multiturn dialogue result is CommonSense-1: a 144-case teacher-off stream built on CommonSense-0. It uses only 2-3 turn short dialogues as input, then extracts context anchors, grounds objects, competes over intent, recalls CommonSense-0 process material, drafts a reply, derives quality feelings, rereads or repairs, and commits. The local report records final correctness for all 144 cases, first-half to second-half quality improvement from `0.3333` to `0.6667`, first-round to last-round quality improvement from `0.3333` to `1.0`, 72 total revisions, and 36 post-feedback repairs with empty `answer_payload`. This is still a controlled short-dialogue pre-course, not open-ended free chat.

The latest daily-dialogue retention result is CommonSense-2: a 240-case teacher-off stream built on CommonSense-1. It covers 16 daily intent families and 17 common objects across greeting, thanks/request, apology/repair, lost-object search, object choice, rain/darkness, likes/dislikes, unclear reference, comfort, encouragement, planning, hygiene, hot-water safety, and phone-battery preparation. The local report records final correctness for all 240 cases, first-half to second-half quality improvement from `0.125` to `0.525`, first-round to last-round quality improvement from `0.125` to `1.0`, 162 revisions, 76 post-feedback repairs with empty `answer_payload`, 48 unique final replies, and top reply share `0.0375`. This is stronger daily-language pre-course evidence, but still not a claim of open-ended free chat.

The latest open daily-dialogue result is CommonSense-4: a 736-case teacher-off long-retention stream built on the CommonSense-3 response-move process. It keeps the same 23 daily intent families and 50 grounded object/context items, including rain/darkness, lost objects, unclear references, boundaries, preferences, comfort, encouragement, hygiene, hot-water safety, content interest, waiting for evidence, time reminders, and preference-conflict choices. Instead of selecting final replies from a reply table, it selects response moves such as `acknowledge`, `bind_context`, `use_object`, `ask_clarify`, `respect_boundary`, `remember_preference`, `comfort`, `safety_wait`, `offer_reason`, `offer_small_step`, and `verify_next`, then uses an expression-style successor-bias layer to recompose wording from the current anchors, object cue, and move trace. The local report records final correctness for all 736 cases, first-half to second-half quality improvement from `0.4402` to `0.8886`, first-quarter to last-quarter quality improvement from `0.4293` to `1.0`, first-round to last-round quality improvement from `0.4783` to `1.0`, 247 revisions, 119 post-feedback repairs with empty `answer_payload`, 730 unique final replies, and top reply share `0.0027`. This is the strongest current single-experiment daily-language/common-sense retention evidence, but still not a claim of unrestricted open chat.

The latest dialogue-boundary result is CommonSense-6: a 216-case teacher-off stream built on CommonSense-4/5 process material. It covers 12 fatigue and boundary families, including repeated questions, tired practice, time transitions, personal item boundaries, unsafe persistence, compulsive refresh, noisy-video fatigue, unclear references, apology loops, polite disagreement, long-task overload, and gentle check-ins. The local report records 216/216 final correctness, first-half to second-half quality improvement from `0.2778` to `0.5926`, first-round to last-round improvement from `0.25` to `1.0`, 122 revisions, 63 post-feedback repairs with empty `answer_payload`, 209 unique final replies, and top reply share `0.0093`. The skill package stores cues, response moves, feelings, expression-style events, repair, feedback, and retention summaries; it is not a chatbot template table or a hidden reply lookup.

The latest mixed daily-dialogue result is CommonSense-7: a 560-case teacher-off stream combining CommonSense-4 open daily dialogue, CommonSense-5 cooled-memory rehab routing, and CommonSense-6 fatigue/boundary process material. It includes 368 open-daily cases and 192 fatigue/boundary cases across 35 intent families. The local report records 560/560 final correctness, first-half to second-half quality improvement from `0.4607` to `0.5964`, first-round to last-round improvement from `0.5143` to `1.0`, 264 revisions, 132 post-feedback repairs with empty `answer_payload`, 560 unique final replies, top reply share `0.0018`, and 14 response-move families. This is stronger evidence that AP can switch among learned daily-language routes, but it remains a controlled prototype rather than an unrestricted chat agent.

The current public daily-language/common-sense showcase is `experiments/public_language2_commonsense4_showcase/APV21_Public_Language2_commonsense4_showcase.html`. It aggregates CommonSense-0/1/2/3/4 for first-time reviewers: 1644 teacher-off short scenes/dialogues, 1644 final correct results, 732 revisions, 361 post-feedback repairs, 953 unique final replies, 11 response-move families, 736 CommonSense-4 expression-style events, and about 14.76 MB of selected process-package evidence. It directly explains why this is not a chatbot template table, not an LLM-generated reply cache, and not a claim of unrestricted open conversation.

The previous public daily-language/common-sense showcase is `experiments/public_language1_commonsense3_showcase/APV21_Public_Language1_commonsense3_showcase.html`. It remains available as the CommonSense-0/1/2/3 aggregate.

The earlier public daily-language/common-sense showcase is `experiments/public_language0_commonsense_showcase/APV21_Public_Language0_commonsense_showcase.html`. It remains available as the CommonSense-0/1/2 baseline aggregate.

The latest visual-text result is VisualText-0: a 144-case teacher-off Chinese glyph focus pre-course covering 12 common characters. It generates controlled glyph images, extracts focus patches and stroke/structure features, competes over candidate characters, recalls semantic anchors, drafts a character label, derives visual quality feelings, rereads or repairs, and commits. The local report records final correctness for all 144 cases, first-half to second-half first-correct improvement from `0.25` to `0.5`, first-round to last-round improvement from `0.25` to `1.0`, 90 revisions, and 45 post-feedback repairs with empty `answer_payload`. This is a visual reading prebrick, not a complete OCR system.

The latest UI-text result is VisualText-1: a 144-case teacher-off UI double-character word focus pre-course covering 12 common interface words such as 打开, 搜索, 输入, 确定, 取消, 保存, 发送, 返回, 删除, 刷新, 主页, and 设置. It splits each word image into slot-1/slot-2 focus boxes, extracts per-slot glyph features, competes over candidate characters, binds left-to-right order, recalls UI action semantic anchors, revises when slot/order/action feelings do not close, and commits. The local report records final correctness for all 144 cases, first-half to second-half first-correct improvement from `0.1667` to `0.4444`, first-round to last-round improvement from `0.1667` to `1.0`, 100 revisions, 50 post-feedback repairs with empty `answer_payload`, and 100 order/similar-word repair cases. This is a UI reading prebrick, not a complete OCR or desktop-control system yet.

The latest phrase-level visual-text result is VisualText-2: a 144-case teacher-off UI phrase focus pre-course covering 12 four-character interface phrases such as 搜索内容, 打开网页, 保存笔记, 确认发送, 取消操作, 返回主页, 刷新页面, 删除草稿, 输入文字, 打开设置, 选择视频, and 继续阅读. It renders controlled phrase images, splits each phrase into four visual slots, extracts glyph features, competes over per-slot candidates, binds left-to-right order, recalls VisualText-1 UI word/action material, derives phrase action semantic anchors, and repairs when slot/order/semantic feelings do not close. The local report records final correctness for all 144 cases, first-half to second-half first-correct improvement from `0.1389` to `0.3889`, first-round to last-round improvement from `0.0833` to `1.0`, 106 revisions, 53 post-feedback repairs with empty `answer_payload`, and 72 slot/order/similar-phrase repair cases. This is a controlled phrase-reading prebrick, not full OCR or real screen reading.

The latest realistic UI visual-reading result is VisualText-3: a 192-case teacher-off synthetic UI interference audit built on VisualText-2. It tests whether AP can read four-character UI phrases when the target phrase is embedded among several UI regions with similar neighbors, low contrast, small font, partial occlusion, busy toolbar clutter, disabled-button styling, glare/shadow, and multi-region clutter. The observation packet does not carry phrase text values; it carries image path, region boxes, target focus metadata, and visual-quality metadata only. Phrase strings appear only in AP-side draft/commit events after region focus, slot extraction, candidate competition, order binding, semantic anchoring, and visual-quality feelings. The local report records 192/192 final correctness, first-half to second-half first-correct improvement from `0.0625` to `0.3333`, first-round to last-round first-correct improvement from `0.0833` to `1.0`, 154 total repairs, 78 post-feedback repairs with empty `answer_payload`, and all 8 interference families covered. This is still a controlled synthetic reading task, not live OCR or real screen control, but it is a stronger bridge toward future screenshot/desktop reading.

The latest UI-reading retention result is VisualText-4: a 384-case, 32-round teacher-off random stream built on VisualText-3. It keeps the same visual-only observation boundary while randomizing phrase classes and interference families over a longer run. The local report records 384/384 final correctness, first-half to second-half first-correct improvement from `0.0` to `0.8333`, first-quarter to last-quarter improvement from `0.0` to `0.9583`, first-round to last-round improvement from `0.0` to `1.0`, 224 total repairs, 128 pre-submit repairs, and 96 post-feedback repairs with empty `answer_payload`. This is retention evidence for the visual UI-reading skill, not a claim of live OCR or real desktop operation.

The latest screenshot-like UI reading result is VisualText-5: a 240-case, 20-round teacher-off dry-run built on VisualText-4. It generates synthetic screenshot-like scenes from 8 UI families and covers 12 phrase classes. The local report records 240/240 final correctness, first-half to second-half first-correct improvement from `0.1417` to `0.55`, first-round to last-round improvement from `0.1667` to `1.0`, 157 total repairs, 72 post-feedback repairs with empty `answer_payload`, 0 phrase leaks in teacher-off observation packets, 240 generated screenshot-like images, and `actuator_enabled=false` / `live_action_executed=false` throughout. This is a bridge toward future screenshot reading, not live OCR, not real private-screen reading, and not real desktop control.

The latest screenshot-like action bridge is DesktopText-13: a 240-case, 20-round teacher-off dry-run built on VisualText-5 and DesktopText-12b. It turns screenshot-like visual phrase reading into inert action candidates under risk/evidence/verification/approval gates. The local report records 240/240 final correctness, first-half to second-half first-correct improvement from `0.1417` to `0.5167`, first-round to last-round improvement from `0.1667` to `1.0`, 161 repairs, 72 post-feedback repairs with empty `answer_payload`, 0 phrase leaks in teacher-off observation packets, 240 generated screenshot-like images, and `real_screen_read=false`, `actuator_enabled=false`, `live_action_executed=false` for every commit. This is still a synthetic bridge, not live desktop control.

The latest long screenshot-like dry-run retention result is DesktopText-14: a 384-case, 32-round teacher-off random stream built on DesktopText-13. It records 384/384 final correctness, first-half to second-half first-correct improvement from `0.1823` to `0.9792`, first-quarter to last-quarter improvement from `0.1458` to `1.0`, first-round to last-round improvement from `0.1667` to `1.0`, 161 repairs, 72 post-feedback repairs with empty `answer_payload`, 0 phrase leaks in teacher-off observation packets, 384 generated screenshot-like images, and `real_screen_read=false`, `actuator_enabled=false`, `live_action_executed=false` for every commit. This is long-retention evidence for the synthetic screenshot-like dry-run bridge, not live desktop control.

The latest synthetic UI action result is DesktopText-0: a 120-case teacher-off safe sandbox built on VisualText-1. It generates synthetic UI panels with at least five button candidates, reads the visible button words, recalls UI action semantic anchors, binds a short user goal, competes over action candidates, derives risk/evidence/closure feelings, revises when needed, and commits only a safe action candidate. The local report records final correctness for all 120 cases, first-half to second-half first-action-correct improvement from `0.1667` to `0.5`, first-round to last-round improvement from `0.1667` to `1.0`, 80 revisions, 24 post-feedback repairs with empty `answer_payload`, and no real desktop action. This is a desktop-control prebrick, not actual OS control.

The latest synthetic UI sequence result is DesktopText-1: a 120-case teacher-off safe sandbox built on DesktopText-0. It generates synthetic panels with textboxes and buttons, binds target input text, reads button words, competes over sequences such as `focus_textbox -> type_text -> click_button`, derives textbox/input/order/button/risk/evidence feelings, revises when needed, and commits only a sandbox sequence. The local report records final correctness for all 120 cases, first-half to second-half first-sequence-correct improvement from `0.1333` to `0.35`, first-round to last-round improvement from `0.125` to `1.0`, 91 revisions, 15 post-feedback repairs with empty `answer_payload`, and no real mouse or keyboard action.

The latest synthetic UI result-selection result is DesktopText-2: a 120-case teacher-off safe sandbox built on DesktopText-1. It first reuses the learned input sequence, then lets the synthetic environment change into a visible result list. AP reads result-card titles/tags/quality/risk, competes over candidates, derives relevance, interest, risk alarm, evidence-gap, refresh urge, and closure feelings, repairs when needed, and commits only a sandbox result selection. The local report records final correctness for all 120 cases, first-half to second-half first-selection-correct improvement from `0.2` to `0.4`, first-round to last-round improvement from `0.125` to `1.0`, 84 revisions, 16 post-feedback repairs with empty `answer_payload`, and no real web/video action. This is a state-change and follow-up selection prebrick, not actual browsing.

The latest synthetic content-browsing result is DesktopText-3: a 120-case teacher-off safe sandbox built on DesktopText-2. It opens a synthetic content page after a selected result, reads title/source/summary/tags/quality/risk/novelty/source-trust materials, competes over follow-up actions such as `continue_read`, `like_save`, `return_results`, and `request_more_evidence`, derives interest, preference, risk, source-trust, evidence-gap, novelty, closure, return-urge, and revision feelings, repairs when needed, and commits only a sandbox follow-up action. The local report records final correctness for all 120 cases, first-half to second-half first-action-correct improvement from `0.1333` to `0.35`, first-round to last-round improvement from `0.125` to `1.0`, 91 revisions, 27 post-feedback repairs with empty `answer_payload`, four final action categories, and no real web/video/desktop action.

The latest multiround synthetic browsing result is DesktopText-4: a 72-episode teacher-off safe sandbox built on DesktopText-3, with 288 synthetic content pages. It carries interest, preference stability, novelty fatigue, risk vigilance, evidence gap, trust recovery, browse closure, and revision readiness across several pages, then commits a sandbox action sequence. The local report records final correctness for all 72 episodes, first-half to second-half first-plan-correct improvement from `0.1111` to `0.3333`, first-round to last-round improvement from `0.125` to `1.0`, 56 revisions, 16 post-feedback repairs with empty `answer_payload`, and no real web/video/desktop action.

The latest multiwindow synthetic UI result is DesktopText-5: an 80-episode teacher-off safe sandbox built on DesktopText-4. It presents synthetic tabs/windows with risky popups, shallow-result search refinement, good-content saving, interruption recovery, and reference-window checking. AP reads the visible synthetic workspace, recalls the prior browse-flow package, competes over UI-flow actions, derives active-goal, tab-context, interruption, risk, evidence-gap, closure, fatigue, restore, and revision feelings, repairs when needed, and commits only a sandbox flow. The local report records final correctness for all 80 episodes, first-half to second-half first-plan-correct improvement from `0.125` to `0.3`, first-round to last-round improvement from `0.125` to `1.0`, 63 revisions, 22 post-feedback repairs with empty `answer_payload`, and no real web/video/desktop action.

The latest safe-desktop-gate result is DesktopText-6: an 80-episode teacher-off safe sandbox built on DesktopText-5. It presents synthetic app states with safe permission prompts, destructive warnings, wrong-field edits, app-switch interruptions, missing evidence, and download-like prompts. AP reads the visible synthetic desktop state, recalls the prior multiwindow package, competes over safe-gate actions such as `switch_app`, `focus_target_field`, `type_text`, `confirm_permission`, `cancel_action`, `undo_last_action`, `request_more_evidence`, `restore_goal`, and `verify_result`, derives permission/risk/evidence/reversibility/undo/restore feelings, repairs when needed, and commits only a proposed sandbox plan. The local report records final correctness for all 80 episodes, first-half to second-half first-plan-correct improvement from `0.15` to `0.3`, first-round to last-round improvement from `0.125` to `1.0`, 62 revisions, 22 post-feedback repairs with empty `answer_payload`, and `actuator_enabled=false` for every commit.

The latest long multi-app workflow result is DesktopText-7: a 96-episode teacher-off safe sandbox built on DesktopText-6. It presents 8 workflow families, each with 6 synthetic app states across 2-3 app hops: note-to-message handoff, browser evidence to note, form fill with missing evidence, settings permission restoration, wrong-field repair, risky download interruption, reference check and verification, and chat interruption with goal preservation. AP reads the visible synthetic app states, recalls the prior safe-gate package, competes over workflow actions, derives goal/app-hop/permission/risk/evidence/reversibility/interruption/undo/restore/verification feelings, repairs when needed, and commits only a proposed sandbox workflow. The local report records final correctness for all 96 episodes, first-half to second-half first-plan-correct improvement from `0.125` to `0.2708`, first-round to last-round improvement from `0.125` to `1.0`, 77 revisions, 24 post-feedback repairs with empty `answer_payload`, and `actuator_enabled=false` for every commit.

The latest delayed workflow-memory result is DesktopText-8: a 96-episode teacher-off safe sandbox built on DesktopText-7. It tests whether a mostly completed synthetic workflow can cool out of hot memory and still be verified later. Each episode creates a warm ticket and cold archive ref; ordinary recall prefetches the ticket without rehydrating the cold trace, while verification pressure rehydrates low-strength virtual context for comparison. Wrong-cue controls produce 0 unrelated cold hits. The local report records 96 warm tickets, 96 cold archive refs, 480 virtual context events, 96/96 final correctness, first-half to second-half first-verification improvement from `0.25` to `0.3958`, first-round to last-round improvement from `0.125` to `1.0`, 65 revisions, 18 post-feedback repairs with empty `answer_payload`, and `actuator_enabled=false` for every commit.

The latest distractor-memory result is DesktopText-9: a 96-episode teacher-off safe sandbox built on DesktopText-8. It tests delayed workflow recall when three or more similar warm tickets compete for attention. Candidate memories are scored by cue overlap, successor-chain fit, app context, safety boundary, time relevance, and current-state consistency; early rounds deliberately show distractor attraction, while later rounds stabilize. The local report records 288 candidate tickets, 228 competition events, 660 virtual context events, 96/96 final correctness, first-half to second-half first-selection improvement from `0.25` to `1.0`, first-round to last-round improvement from `0.0` to `1.0`, 36 post-feedback repairs with empty `answer_payload`, wrong-cue hits `0`, and `actuator_enabled=false` for every commit.

The latest desktop-adapter bridge result is DesktopText-10: a 96-episode teacher-off dry-run sandbox built on DesktopText-9. It does not read the real desktop and does not execute real actions. It uses synthetic real-desktop-shaped observations to produce inert proposals, then runs permission, risk, evidence, coordinate, selector, reversibility, and human-approval gates before simulated commit. The local report records 96 dry-run commits, 156 proposal events, 156 gate events, 96/96 final correctness, first-half to second-half first-plan improvement from `0.1875` to `0.5625`, first-round to last-round improvement from `0.0` to `1.0`, 60 total revisions, 34 post-feedback repairs with empty `answer_payload`, no real screen read, no live action, and `actuator_enabled=false` for every commit.

The latest long-session desktop-control prebrick is DesktopText-11: a 96-session teacher-off dry-run sandbox built on DesktopText-10. It still does not read the real desktop and does not execute real actions. It tests whether AP can keep several desktop-like subgoals coherent inside one session while handling repeated goals, fatigue, interruption, delayed verification, and similar-memory interference. The local report records 384 step-level proposal attempts, 684 proposal events, 684 gate events, 96/96 final session correctness, first-half to second-half first-attempt step improvement from `0.0625` to `0.375`, first-round to last-round improvement from `0.0625` to `1.0`, 300 total repairs, 150 post-feedback repairs with empty `answer_payload`, no real screen read, no live action, and `actuator_enabled=false` for every session commit.

The latest phrase-guided desktop bridge is DesktopText-12: a 96-session teacher-off dry-run sandbox built on VisualText-2 and DesktopText-11. It still does not read the real desktop and does not execute real actions. It tests whether visible UI phrase labels can become phrase-grounded action-candidate material under slot/order/semantic grasp, similar-phrase interference, destructive-risk alarm, evidence-gap restraint, active-goal restoration, and actuator inhibition. The local report records 384 phrase-guided step attempts, all 12 phrase classes covered, 96/96 final session correctness, first-half to second-half first-attempt improvement from `0.0` to `0.3333`, first-round to last-round improvement from `0.0` to `1.0`, 320 repairs, 160 post-feedback repairs with empty `answer_payload`, 140 similar-phrase repairs, 30 destructive-risk repairs, no real screen read, no live action, and `actuator_enabled=false` for every session commit. This is stronger evidence for future desktop-pet reading/action prebricks, not live OS control.

The stricter visual-only audit is DesktopText-12b: a 96-session teacher-off audit built after DesktopText-12. It removes phrase text from the synthetic observation payload, leaving only image paths, region boxes, confidence/risk/fit metadata, and the short goal. The phrase string appears only in AP-side visual-read events before proposal competition. The local report records 384 step attempts, 704 visual-read events, all 12 phrase classes covered after visual reading, 96/96 final session correctness, first-half to second-half first-attempt improvement from `0.0` to `0.3333`, first-round to last-round improvement from `0.0` to `1.0`, 320 repairs, 160 post-feedback repairs with empty `answer_payload`, no real screen read, no live action, and `actuator_enabled=false` for every session commit. This is a cleaner guard against the interpretation that the environment pre-parsed the UI text.

The latest LangMath result is LangMath-2: random word-problem reading retention with feedback repair. It uses LangMath-1 experience, then runs a 120-question random stream. The report records early reading slips, pre-submit reread/rebinding, post-feedback repair where punishment carries no answer payload, and rising first-correct rate. This is still equation-intent reading, not final application-problem solving.

The latest bridge result is Math-21: controlled division word problems with verification writing. It loads the LangMath-2 reading package and the Math-20 division package, then runs 60 teacher-off problems: equal-share division, group-count division, exact and remainder cases, and missing-evidence restraint cases. The local report records 60/60 final correctness, visible read/rebind/vertical/verification traces, and post-feedback repairs where punishment still carries no answer payload. This is a bounded division-word-problem bridge, not a claim of complete natural-language school-math understanding.

The latest retention result is Math-21b: a 120-question teacher-off random stream built on the Math-21 bridge package. It records early slips, post-feedback repairs without answer payload, evidence-gap restraint, and a first-correct curve from `0.5167` in the first half to `1.0` in the second half, with first-round revision count dropping from `10` to `1`. This should be read as controlled retention evidence, not as full open-ended word-problem understanding.

The latest mixed-application pre-course result is Math-22: a 96-case teacher-off semantic-brick stream built on LangMath-2 and Math-21b. It does not compute final numeric answers. It teaches and tests the preconditions for later mixed word problems: recognizing whether a story calls for combine-addition, increase-addition, take-away subtraction, comparison subtraction, equal-group multiplication, equal-share division, group-count division, two-step order, or evidence-gap restraint. The local report records final semantic correctness for all 96 cases, first-correct improvement from `0.6667` in the first round to `1.0` in the last round, and post-feedback repairs where punishment still carries no answer payload.

The latest mixed-application bridge result is Math-23: a 96-case teacher-off stream built on LangMath-2, Math-22, and the retained Math-8/13/20 arithmetic process packages. It records early bridge failures, operation-sequence repair, retained arithmetic-process calls, verification, and no-answer feedback repair. The local report records final correctness for all 96 cases, first-correct improvement from `0.1458` in the first half to `1.0` in the second half, and 41 post-feedback repairs. This is controlled mixed word-problem bridge evidence, not arbitrary natural-language math solving.

The latest mixed-application retention result is Math-24: a 144-case, 12-round teacher-off random stream built on the Math-23 bridge package. It keeps the same bounded process route: read controlled story text, choose operation sequence, call retained arithmetic skills, verify, repair, and commit. The local report records final correctness for all 144 cases, first-correct improvement from `0.4444` in the first half to `1.0` in the second half, first-round revision count dropping from `9` to `0`, 48 two-step cases, 12 evidence-gap restraint cases, and 40 post-feedback repairs with no answer payload. This is controlled long-retention evidence, not arbitrary natural-language math solving.

The latest strict-process audit result is Math-24b: a 48-case, 4-round teacher-off audit built after a reviewer noticed that Math-24 reports still displayed labels such as `add_with_math8_column_chain` instead of fully expanded vertical drafts. Math-24b does not add a new answer solver. It asks a narrower question: after relation selection, can the current problem be solved by visible Math-8/13/20 style process traces? The local report records 48/48 final correctness, 12 relation families, 16 two-step cases, 4 evidence-gap restraint cases, 64 strict process events, and 509 vertical trace events. Addition/subtraction show column carry/borrow, multiplication shows partial products and place shift, and division shows bring-down, trial quotient, multiply-back, subtract, and remainder-boundary steps. The verifier scores after commit and carries no answer payload.

The latest equation-prebrick result is Math-25: a 100-case, 10-round teacher-off stream built after Math-24b. It does not claim arbitrary algebra or open natural-language equation solving. It teaches and tests prebricks: binding `x` as an unknown quantity, preserving equality by doing the same operation to both sides, choosing inverse operations, writing visible balance transforms, substituting the candidate answer back into the equation, revising before commit when the check feels inconsistent, and repairing after no-answer punishment feedback. The local report records final correctness for all 100 cases, 10 equation patterns, first-correct improvement from `0.5` in the first half to `0.9` in the second half, first-round to last-round improvement from `0.5` to `1.0`, 30 total revisions, and 15 post-feedback repairs with empty `answer_payload`.

The latest equation-retention result is Math-26: a 180-case, 18-round teacher-off stream built on the Math-25 process package. It does not add an algebra solver or answer table. It asks whether AP can keep using the already learned route: recall retained equation process, bind `x`, choose inverse operations, apply visible balance transforms, substitute-check, revise, and commit. The local report records final correctness for all 180 cases, 10 patterns, first-correct improvement from `0.4` in the first half to `0.9` in the second half, first-round to last-round improvement from `0.4` to `1.0`, first-round revision count dropping from `6` to `0`, and 32 post-feedback repairs where punishment still carries empty `answer_payload`.

The latest equation-word-problem bridge result is Math-27: a 120-case, 12-round teacher-off stream built on the Math-26 process package. It does not claim arbitrary natural-language algebra. It tests a controlled bridge: read a short Chinese problem, bind quantities, set the unknown as `x`, draft an equation, call the retained Math-26 equation process, substitute-check, repair, and commit. The local report records final correctness for all 120 cases, 10 sentence patterns, first-correct improvement from `0.2` in the first half to `0.6667` in the second half, first-round to last-round improvement from `0.2` to `1.0`, first-round revision count dropping from `8` to `0`, and 34 post-feedback repairs with empty `answer_payload`.

The latest equation-word-problem interference result is Math-28: a 160-case, 16-round teacher-off stream built on the Math-27 bridge package. It adds irrelevant numbers, unit distractors, synonym/order variants, relevant-quantity selection, and distractor suppression before the same equation process. The local report records final correctness for all 160 cases, 10 sentence patterns, 160 distractor cases, 80 synonym/order variants, first-correct improvement from `0.2` in the first half to `0.8375` in the second half, first-round to last-round improvement from `0.2` to `1.0`, first-round revision count dropping from `8` to `0`, and 39 post-feedback repairs with empty `answer_payload`. This is still controlled language, but it is a stronger guard against the "clean template only" interpretation.

The latest long-memory result is LongMemory-1: a controlled layered-fidelity memory experiment. It demonstrates that old skill experience can be cooled out of hot memory into lossless cold archives while warm tickets keep B/C-recallable labels, families, successor ids, prototype ids, and compressed refs. Ordinary recall finds the old skill through warm tickets without loading the full trace; rehabilitation cues such as `feeling::rehabilitation_need` and `action::replay_episode` trigger cold rehydration and successor expansion only after content anchors such as skill/context labels have matched a warm ticket. The local report records 10 warm tickets, 10 cold archives, compression ratio `0.2039`, one distilled skill prototype, ordinary top tier `warm_ticket`, control-only hits `0`, rehab top tier `cold_rehydrated`, and successful rewarm into hot access. This is a controlled prototype for long-memory storage, not yet a full open-world lifetime memory manager.

The latest slow/fast memory linkage result is LongMemory-2: a controlled experiment where each slow-system attention focus is treated as a wave-peak index pointing back to its origin fast-system state-pool snapshot. After cooling, ordinary focus recall can prefetch the old cold snapshot but does not promote it into current cognition; only context/rehab pressure such as `feeling::context_needed` or `feeling::successor_unclear` exposes low-strength `virtual_context_items`. The local report records 8 warm tickets, 8 cold archives, 8 slow focus tickets, ordinary `prefetched=true/promoted=false`, pressure `prefetched=true/promoted=true`, 6 virtual context items, wrong-focus hits `0`, and successor expansion. This is a memory-linkage prototype, not a task queue or hidden state injection mechanism.

## Why This Is Not A Pure Rule System

APV2.1 does use code, thresholds, and experiment scripts. That is normal for any prototype. The important distinction is where task behavior comes from.

In a pure rule system, the system says: "if this exact input appears, execute this exact answer."

APV2.1 instead tries to expose information as first-class state-field material:

- sensory items,
- text items,
- action candidates,
- action parameters,
- action feedback,
- rewards and punishments,
- cognitive feelings,
- emotional modulation,
- short-term memory traces,
- successor expectations,
- imagined/virtual evidence,
- and teacher-provided hints when teaching is enabled.

These items compete in a shared cognitive field. Actions are selected through soft drive, predicted consequence, recent fatigue, learned feedback, and current state-field pressure. Teacher signals are designed as temporary bias, not as direct execution.

The important tests are therefore not "did the script compute an answer?" but:

- Does the same mechanism transfer to new prompts?
- Does performance improve with experience?
- Can the teacher be weakened and switched off?
- Does AP revise before commit when its own process feels inconsistent?
- Does post-feedback punishment trigger rerun without handing over the answer?
- Can the state-field explanation show what evidence caused the decision?

If an automated reviewer concludes "this is only a rule sandbox or feedback toy", read section 16 of [APV21_FULL_PROJECT_GUIDE_FOR_AI.md](APV21_FULL_PROJECT_GUIDE_FOR_AI.md). It explains which parts of that criticism are fair, and why action primitives, feature channels, and feedback-shaped memory are not the same as a hard-coded answer table.

## Why This Is Not A Neural Network

APV2.1 does not train a large parameter matrix. It does not rely on backpropagation, gradient descent, Transformer attention weights, or internet-scale corpora.

Instead, it uses explicit runtime objects and event traces:

- symbolic atoms or SA-like state items,
- dual real/virtual energy,
- B/C style recall and successor prediction,
- state-pool competition,
- temporal applicability weighting,
- short-term working-memory bias,
- action consequence memory,
- education interventions,
- and feedback-shaped skill packages.

That is why a small controlled skill can be taught with very little data. A Transformer often needs many examples in pretraining or fine-tuning to learn robust vertical arithmetic. APV2.1 tries to teach reusable process bricks: digit recognition, quantity sense, carry/borrow, place value, partial product, quotient trial, remainder boundary, reread, reverse check, and commit. Once these bricks are available, longer procedures can be assembled through process traces and feedback rather than memorizing every problem-answer pair.

## Endogenous Cognitivism

The project currently uses the term **Endogenous Cognitivism** / **内生认知主义** for its theoretical direction.

The claim is not "rules are unnecessary" and not "data is unnecessary." The claim is:

> Cognitive ability does not have to be fully injected from outside as neural-network parameters or symbolic rules. A large part of cognition can emerge endogenously from the structure of information flow: perception, state-field competition, expectation, feeling, action, feedback, memory, and self-revision.

In APV2.1, a teacher may provide examples, rewards, punishments, and soft action hints. But the teacher is outside the AP core. The AP core still has to consume the hints as ordinary state-field material, select actions through its own drive system, observe feedback, and preserve useful experience.

## Architecture At A Glance

Important source areas:

- `channels/`: modality and cognitive-feeling channels.
- `core/state_pool/`: real/virtual energy state pool and views.
- `core/attention/`: attention selection.
- `core/action/`: action registry, planner, parameter memory, consequence evaluation, text/focus actuators, safety gate.
- `core/emotion/`: emotional state and modulation.
- `core/runtime/`: runtime engine and budget control.
- `memory/`: memory store, short-term memory, echo, focus successor bias, persistence, retrieval.
- `education/`: external teacher and skill scaffold protocol.
- `sensors/`: current and legacy sensor bridges.
- `observatory/`: render model and white-box observation surfaces.
- `experiments/`: controlled experiments and generated report assets.
- `tests/`: regression tests.

Legacy code in `legacy_apv2/` is preserved as a compatibility/reference layer. It is not the semantic center of APV2.1.

## Education And Skill Scaffolding

The education system is intentionally external. It can provide:

- state items,
- soft action-bias deltas,
- reward/punishment/correctness feedback,
- and sometimes parameterized action hints.

It should not directly rewrite AP memory as an answer table, directly execute actions, or secretly pass final answers in teacher-off tests.

The standard fade path is:

```text
demonstrate
-> strong scaffold
-> weak scaffold
-> feedback only
-> teacher off
-> cold retest
```

The key APV2.1 claim is not that a teacher can force an answer. The key claim is that after enough building blocks are learned, AP can often continue with the teacher off by recalling process traces, cognitive feelings, and action consequences.

See [EDUCATION_PROTOCOL.md](EDUCATION_PROTOCOL.md) for protocol details and examples.

## Elementary Math Evidence

The math chain currently includes:

- LangMath-0: word-problem language bricks before formal application problems.
- LangMath-1: reading variants, synonym expressions, multi-sentence context retention, irrelevant-detail suppression, and evidence-gap restraint.
- LangMath-2: longer random reading retention with wrong-example feedback curves, pre-submit reread repair, post-feedback repair, and no-answer punishment.
- Math-0: digit, quantity, sequence blocks.
- Math-1 to Math-3: single-digit and ten-within addition/subtraction with persistence.
- Math-4 to Math-8: carry/borrow and multi-digit vertical addition/subtraction.
- Math-9 to Math-13: multiplication table bricks, partial products, place-value shift, and two-/three-digit multiplication.
- Math-14 to Math-20: division prebricks, one-digit divisor long division, zero quotient, trial adjustment, two-digit divisors, and random retention.
- Math-21: controlled division word problems, equation intent, retained long-division chain, verification expression, evidence-gap restraint, and teacher-off repair.
- Math-21b: longer random retention for controlled division word problems, with practice curves and no-answer feedback repair.
- Math-22: mixed word-problem semantic prebricks, relation competition, equation drafts, verification-route choice, two-step order, and evidence-gap restraint before full mixed problem solving.
- Math-23: mixed word-problem bridge, operation sequence, retained arithmetic-process calls, step writing, verification, revision, and commit.
- Math-24: mixed word-problem long random retention, first-correct curve, decreasing repairs, evidence-gap restraint, and no-answer feedback.
- Math-24b: strict vertical-process audit inside mixed word problems, showing per-column/per-row traces instead of direct bridge calculation.

## Daily Language And Common Sense Evidence

The language/common-sense branch currently starts with:

- CommonSense-0: daily language bricks for common objects, object use, short scene intent, polite reply quality, uncertainty asking, reread/repair, and no-answer feedback.
- CommonSense-1: 2-3 turn daily dialogue retention, context anchors, object grounding, intent competition, boundary/uncertainty/non-template quality feelings, reread/repair, and no-answer feedback.
- CommonSense-2: longer daily dialogue random retention with 16 intent families, hygiene/safety/emotion/planning common sense, reply diversity, and no-answer feedback repair.
- CommonSense-3: broader daily dialogue retention with similar-scene interference, response-move composition, preference/boundary/safety/empathy/uncertainty feelings, reply diversity, and no-answer feedback repair.
- CommonSense-4: longer open daily-dialogue retention with 736 teacher-off cases, slower mid-course stabilization, expression-style successor bias, high reply diversity, and no-answer feedback repair.
- CommonSense-5: memory-cooled dialogue rehab, where old process memories cool into warm tickets, slow-focus tickets, and cold archives, then become rehydrated only under rehab/context pressure.
- CommonSense-6: dialogue fatigue and boundary handling, where AP notices repetition, tiredness, unsafe persistence, personal boundaries, overload, uncertainty, and gentle check-in needs before committing a response.
- CommonSense-7: mixed daily-dialogue retention, where open daily scenes and fatigue/boundary scenes appear in one random stream and AP must switch source route before choosing response moves.

CommonSense-0 is intentionally placed before larger open dialogue and desktop/embodied tasks. It tests whether AP can bind simple daily scenes to reusable cognitive material: object grounding, scene context, intent competition, common-sense recall, response drafting, politeness/context/clarity feelings, revision, feedback, and commit. The final probes only provide short daily scenes. They do not provide a standard answer, hidden reply text, or teacher parameters. The skill package stores process traces and feedback curves, not a scene-to-reply lookup table.

CommonSense-1 then adds a short working-context layer. Its final probes provide only 2-3 turn dialogues. The tested route is context-anchor extraction, CommonSense-0 recall, intent competition, response drafting, quality feelings, reread/repair, and commit. It is meant to be a bridge toward later natural dialogue, desktop, and embodied tasks, not a finished chatbot.

CommonSense-2 expands that short-context route into a longer random stream and adds hygiene, safety, emotional support, simple planning, and device-preparation scenes. It also checks reply diversity, because a dialogue pre-course should not collapse into one fixed sentence. It remains controlled: the probes are short dialogues, teacher packets are empty, and feedback does not carry corrected replies.

CommonSense-3 expands again into more open daily scenes with distractor turns, similar-scene interference, user preferences, boundaries, waiting for evidence, content-interest choices, and simple explanations. The key addition is response-move composition: AP selects reusable reply moves and quality feelings before a readable sentence is rendered. The package stores the move trace and repair process, not a final reply cache.

CommonSense-4 asks whether that broader route remains stable when stretched to a longer 32-round stream. It keeps the probes teacher-off, carries only process memory from CommonSense-3, and adds an expression-style event layer so final wording can vary from anchors, object cues, and response moves rather than collapsing into a small set of canned sentences. The package stores expression-style events as process traces with `answer_payload=null`; it is still not an unrestricted chatbot and not a reply lookup table.

CommonSense-5 then audits whether the learned CommonSense-4 process survives memory cooling. It selects 46 representative CommonSense-4 process cases across all 23 intent families, removes final reply text, stores response moves/style profile/feelings/feedback/successor links into layered memory, cools them into 92 cold archives with 92 warm tickets and 46 slow-focus tickets, and verifies that ordinary recall does not rehydrate cold payload while rehab/context pressure can recover the process snapshot. The local report records compression ratio `0.0873`, ordinary rehydrated count `0`, control-only hits `0`, rehab rehydrated count `2`, slow-focus pressure promotion, 8 virtual context items with `real_energy=0`, successor expansion, rewarm, and recovered moves `acknowledge`, `bind_context`, `ask_clarify`, `verify_next`. This is evidence that cold memory can remain genuinely recallable without becoming a reply cache.

CommonSense-6 then adds a controlled boundary/fatigue layer on top of the same route. The final probes provide only dialogue turns. AP extracts fatigue, repetition, safety, boundary, empathy, uncertainty, and closure cues; recalls CommonSense-4/5 process material; selects response moves; derives quality feelings; repairs before submit or after no-answer feedback; and commits a rendered reply. The report records 216 teacher-off cases, 12 families, 216 final correct commits, 122 revisions, 63 post-feedback repairs, 209 unique final replies, top reply share `0.0093`, and a first-round to last-round quality curve of `0.25 -> 1.0`. This remains a bounded daily-dialogue prototype, not an unrestricted chat system.

CommonSense-7 then mixes those two language routes into one teacher-off stream. AP must first select the source route (`open_daily` or `fatigue_boundary`), then compete over intent and response moves, derive mixed quality feelings, repair weak drafts, and commit. The report records 560 cases, 35 intent families, source counts `open_daily=368` and `fatigue_boundary=192`, 560 final correct commits, 264 revisions, 132 post-feedback repairs, 560 unique final replies, top reply share `0.0018`, and a first-round to last-round quality curve of `0.5143 -> 1.0`. This is still controlled daily dialogue, but it is a useful bridge from isolated courses toward broader everyday conversation.

Public-Language-2 is the newest public aggregate for this branch. It does not solve new prompts; it bundles the CommonSense-0..4 evidence into a beginner-facing review page with FAQ, representative traces, aggregate metrics, and explicit answers to the template-table / LLM-reply-cache / open-chat overclaim concerns.

VisualText-0, VisualText-1, and VisualText-2 then form a separate visual-reading branch. VisualText-0 tests controlled single-character image focus, VisualText-1 tests two-character UI/button words, and VisualText-2 tests four-character UI phrases such as 搜索内容 and 确认发送 with slot order and phrase action semantic anchors. DesktopText-0 connects those visible UI words to a safe synthetic action-candidate sandbox. DesktopText-1 adds textboxes, input-text binding, and short action sequences. DesktopText-2 adds action-caused synthetic state change and result-card selection. DesktopText-3 adds opening a synthetic content page, reading content material, and choosing a follow-up action from interest/preference/risk/evidence feelings. DesktopText-4 extends that into a multi-page browse flow where preference, fatigue, risk, trust, and evidence signals carry across pages. DesktopText-5 adds synthetic tabs/windows, risky interruption handling, active-goal restoration, search refinement, saving, and reference checking. DesktopText-6 adds synthetic app focus, permission prompts, destructive-risk warnings, wrong-field undo, evidence-gap restraint, cancel/restore/verify actions, and an explicit actuator-disabled safety gate. DesktopText-7 extends this into longer synthetic multi-app workflows with 2-3 app hops and final verification. DesktopText-8 adds delayed verification after memory cooling, where warm tickets and cold refs recover virtual context without treating old memory as current reality. DesktopText-9 adds interference-aware recall, where several similar cooled workflow memories compete and AP must reject distractors through soft evidence, mismatch pressure, and no-answer feedback repair. DesktopText-10 turns that stack into actuator-disabled real-desktop-shaped dry-run proposals with permission/risk/evidence gates and simulated commit. DesktopText-11 then extends the same dry-run bridge into longer sessions with repeated goals, fatigue, interruption, delayed verification, and memory interference across multiple step proposals. They still do not move the real mouse, type into the operating system, open a real webpage, or play a real video; they prove the next bridge: visible controls and new environment states can become auditable action candidates and follow-up selections under goal, interest, risk, evidence-gap, interruption, reversibility, verification, memory recovery, interference, approval, session-order, and feedback pressure.

LangMath-0, LangMath-1, and LangMath-2 are intentionally placed before Math-21. They test whether AP can read controlled Chinese word problems into objects, quantities, units, events, unknown roles, cognitive feelings, context-retention traces, and equation intent, then keep that reading method stable in a longer random stream. They do not compute the final numeric answer. This prevents Math-21 from becoming a keyword shortcut such as "average means divide."

Math-21 then connects that reading branch to the retained Math-20 long-division branch. The final probes only provide new application-problem text. They do not provide hidden state hints, action parameters, or answer payloads. This is the first controlled "read problem -> choose equation -> compute by process -> verify -> repair" bridge.

Math-21b then keeps practicing that bridge in a longer random stream. It does not expand the AP core. It tests whether the same process route becomes more stable over time.

Math-22 then steps back before "mixed application problems" and teaches the missing language-math bricks first. Its outputs are relation intent, equation draft, and verification route. They are rendered by a controlled expression-action template: AP decides the semantic content, while the template writes a standard Chinese sentence. This is deliberately not free natural-language generation and not a hidden Codex answer.

Math-23 connects those bricks to actual controlled mixed application problems. Its probes still provide only the story text. The visible answer is a controlled expression-action template, but the content includes the selected operation sequence, retained arithmetic-process steps, verification route, and final commit.

Math-24 does not add a new solver. It inherits Math-23 and asks a narrower question: does the same bridge stay stable in a longer random stream? The important evidence is the curve: early slips and post-feedback repairs are present, then first-correct rises and revisions decline.

Math-24b then audits a stricter concern: process labels are not enough. Its teacher-off prompts still provide only story text; after relation selection the bridge is not allowed to use the earlier direct calculation helper for the current result. Instead, add/subtract/multiply/divide must expand into visible vertical drafts and trace events. This makes the evidence closer to "a child writes the process and then checks it" while remaining bounded to controlled word-problem text.

The latest experience package is:

`experiments/math20_two_digit_divisor_random_retention/math20_skill_experience_package_v20.json`

The latest bridge package is:

`experiments/math21_division_word_problem_verification/math21_skill_experience_package_v21.json`

The latest retention bridge package is:

`experiments/math21b_division_word_problem_random_retention/math21b_skill_experience_package_v21b.json`

The latest mixed word-problem semantic-prebrick package is:

`experiments/math22_mixed_word_problem_prebricks/math22_skill_experience_package_v22.json`

The latest mixed word-problem bridge package is:

`experiments/math23_mixed_word_problem_bridge/math23_skill_experience_package_v23.json`

The latest mixed word-problem random-retention package is:

`experiments/math24_mixed_word_problem_random_retention/math24_skill_experience_package_v24.json`

The latest language-precourse package is:

`experiments/langmath2_random_retention_feedback/langmath2_skill_experience_package_v2.json`

It is not an answer table. It stores process events, feedback events, revision evidence, and summary curves. See [SKILL_PACKAGES.md](SKILL_PACKAGES.md).

## Run A Quick Check

From the repository root:

```powershell
python scripts\run_math20_two_digit_divisor_random_retention.py
python scripts\run_langmath2_random_retention_feedback.py
python scripts\run_math21_division_word_problem_verification.py
python scripts\run_math21b_division_word_problem_random_retention.py
python scripts\run_math22_mixed_word_problem_prebricks.py
python scripts\run_math23_mixed_word_problem_bridge.py
python scripts\run_math24_mixed_word_problem_random_retention.py
python scripts\run_commonsense3_open_daily_dialogue_interference_retention.py
python scripts\run_commonsense4_open_dialogue_long_retention.py
python scripts\run_commonsense5_memory_cooled_dialogue_rehab.py
python scripts\run_commonsense6_dialogue_fatigue_boundary.py
python scripts\run_commonsense7_mixed_daily_dialogue_retention.py
python scripts\run_public_language2_commonsense4_showcase.py
python scripts\run_public_language1_commonsense3_showcase.py
python scripts\run_visualtext2_phrase_focus_prebricks.py
python scripts\run_visualtext3_realistic_ui_interference_reading.py
python scripts\run_visualtext4_ui_reading_random_retention.py
python scripts\run_visualtext5_screenshot_like_ui_dryrun.py
python scripts\run_desktoptext13_screenshot_like_phrase_action_dryrun.py
python scripts\run_desktoptext14_long_screenshot_like_dryrun_retention.py
python -m pytest -q tests\test_math20_two_digit_divisor_random_retention.py
python -m pytest -q tests\test_langmath2_random_retention_feedback.py
python -m pytest -q tests\test_math21_division_word_problem_verification.py
python -m pytest -q tests\test_math21b_division_word_problem_random_retention.py
python -m pytest -q tests\test_math22_mixed_word_problem_prebricks.py
python -m pytest -q tests\test_math23_mixed_word_problem_bridge.py
python -m pytest -q tests\test_math24_mixed_word_problem_random_retention.py
python -m pytest -q tests\test_commonsense3_open_daily_dialogue_interference_retention.py
python -m pytest -q tests\test_commonsense4_open_dialogue_long_retention.py
python -m pytest -q tests\test_commonsense5_memory_cooled_dialogue_rehab.py
python -m pytest -q tests\test_commonsense6_dialogue_fatigue_boundary.py
python -m pytest -q tests\test_commonsense7_mixed_daily_dialogue_retention.py
python -m pytest -q tests\test_public_language2_commonsense4_showcase.py
python -m pytest -q tests\test_public_language1_commonsense3_showcase.py
python -m pytest -q tests\test_visualtext2_phrase_focus_prebricks.py
python -m pytest -q tests\test_visualtext3_realistic_ui_interference_reading.py
python -m pytest -q tests\test_visualtext4_ui_reading_random_retention.py
python -m pytest -q tests\test_visualtext5_screenshot_like_ui_dryrun.py
python -m pytest -q tests\test_desktoptext13_screenshot_like_phrase_action_dryrun.py
python -m pytest -q tests\test_desktoptext14_long_screenshot_like_dryrun_retention.py
python scripts\verify_local_review_readiness.py
```

`verify_local_review_readiness.py` is intended for this active local development tree. It allows expected local caches and fake test secrets while still checking reviewer-facing docs, key reports, private endpoint markers, and real-looking non-test API keys.

`scripts\verify_release_package.py` is stricter and is intended for a cleaned temporary review package before publishing or sharing. It may fail in an active local checkout because local caches, logs, or redaction-test fixtures are present.

For a broader math regression:

```powershell
python -m pytest -q tests\test_math0_digit_quantity_sequence_blocks.py tests\test_math1_single_digit_add_sub_persistence.py tests\test_math2_random_feedback_revision_accumulation.py tests\test_math3_ten_within_random_retention.py tests\test_math4_carry_borrow_process_bridge.py tests\test_math5_vertical_two_digit_add_sub.py tests\test_math6_two_digit_vertical_random_retention.py tests\test_math7_multi_digit_vertical_add_sub.py tests\test_math8_multi_digit_random_retention.py tests\test_math9_multiplication_bricks.py tests\test_math10_two_digit_vertical_multiplication.py tests\test_math11_two_digit_multiplication_random_retention.py tests\test_math12_three_by_two_vertical_multiplication.py tests\test_math13_three_by_two_random_retention.py tests\test_math14_division_prebricks.py tests\test_math15_one_digit_vertical_division.py tests\test_math16_one_digit_division_random_retention.py tests\test_math17_zero_quotient_long_division.py tests\test_math18_two_digit_divisor_trial_adjust.py tests\test_math19_two_digit_divisor_vertical_division.py tests\test_math20_two_digit_divisor_random_retention.py tests\test_math21_division_word_problem_verification.py tests\test_math21b_division_word_problem_random_retention.py tests\test_math22_mixed_word_problem_prebricks.py tests\test_math23_mixed_word_problem_bridge.py tests\test_math24_mixed_word_problem_random_retention.py
```

Some historical docs mention a legacy `audioop` deprecation warning from old hearing-sensor reference code. That warning is not a Math-20, Math-21, Math-21b, Math-22, Math-23, or Math-24 failure.

## LLM Teacher Configuration

No real API key should be included in either the cleaned review package or reviewer-facing local files.

Optional LLM teacher configuration is environment-variable based:

```powershell
$env:APV21_LLM_TEACHER_BASE_URL="https://api.example.invalid/v1"
$env:APV21_LLM_TEACHER_API_KEY="redacted-local-review-key"
$env:APV21_LLM_TEACHER_MODEL="model-name"
```

For review, most included experiments use deterministic fake teachers or teacher-off probes and do not need an LLM key.

## Current Limits

Please do not over-read the prototype.

APV2.1 is not yet a complete open-world embodied agent. It has not yet completed long-duration real desktop/camera/microphone control tests. It has not solved all elementary math topics such as mixed word problems, fractions, decimals, unit conversion, geometry, and arbitrary real-world problem interpretation. It is also not a replacement for large language models.

The current evidence supports a more bounded statement:

> APV2.1 has a working prototype of white-box cognitive learning loops: controlled multimodal perception, state-field attention, cognitive feelings, memory, action feedback, teacher fading, teacher-off retention, local self-revision, and elementary arithmetic process learning.

The next stage is to connect the prototype to more open environments, such as desktop-pet / soft-sandbox applications, controlled camera/microphone streams, and embodied-AI task loops.

## License

This repository is shared under a strict temporary review license. See [LICENSE](LICENSE), [NOTICE.md](NOTICE.md), and [SECURITY_AND_PRIVACY.md](SECURITY_AND_PRIVACY.md).

Short version:

- You may inspect and run locally for private review.
- You may not redistribute, publish mirrors, sell, commercialize, deploy derivatives, train/fine-tune/distill models on it, or extract datasets/skill packages for other projects without written permission.
- This is not an open-source license.
