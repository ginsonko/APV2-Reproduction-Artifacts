# APV2 Public Freeze Candidate

This package is a local hash-frozen AP-Core architecture/runtime paper-material candidate.

It supports same-machine clean-room rerun of the main paper check and selected P0/P1/P2 paper-material tests.

Boundary: GL learning, DPP/Skill37, and product-shell artifacts are adjacent work, not AP-Core runtime proof in this package.

Manifest: `public_freeze_manifest.json`
