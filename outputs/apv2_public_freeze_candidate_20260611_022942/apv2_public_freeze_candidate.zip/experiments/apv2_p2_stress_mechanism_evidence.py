from __future__ import annotations

import hashlib
import json
import sys
from dataclasses import asdict, replace
from datetime import datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from config.defaults import ShortTermConfig, ShortTermSlotConfig
from memory.short_term.focus_buffer import FocusBuffer
from memory.short_term.slot_packet import ShortTermSlotPacketBuilder
from memory.store import MemoryStore


def _round4(value: float) -> float:
    return round(float(value), 4)


def _item(
    label: str,
    *,
    real: float = 1.0,
    virtual: float = 0.0,
    source_type: str = "external_text",
    family: str | None = None,
    focus_score: float | None = None,
) -> dict:
    token = str(label).split("::")[-1]
    clean_family = family if family is not None else ("text" if str(label).startswith("text::") else "probe")
    row = {
        "sa_label": str(label),
        "display_text": token,
        "family": str(clean_family),
        "source_type": str(source_type),
        "real_energy": float(real),
        "virtual_energy": float(virtual),
        "attention_gain": float(real) * 0.25 + float(virtual) * 0.12,
        "cognitive_pressure": float(real) - float(virtual),
    }
    if focus_score is not None:
        row["focus_score"] = float(focus_score)
    return row


def _labels(rows: list[dict]) -> list[str]:
    return [str(row.get("sa_label", "") or "") for row in rows or [] if str(row.get("sa_label", "") or "")]


def _memory(*, recall_top_k: int = 8, predict_top_k: int = 4) -> MemoryStore:
    return MemoryStore(
        recall_top_k=recall_top_k,
        predict_top_k=predict_top_k,
        prediction_energy_scale=0.55,
        max_snapshots_per_kind=256,
        candidate_limit=128,
        scoring_candidate_limit=96,
        online_enabled=True,
        online_min_support_to_promote=1,
        online_per_tick_update_limit=64,
        transition_learned_weight=0.18,
    )


def _write(memory: MemoryStore, tick: int, labels: list[str], source_text: str, *, memory_kind: str = "state") -> dict:
    return memory.write_snapshot(
        tick_index=int(tick),
        memory_kind=memory_kind,
        items=[_item(label) for label in labels],
        focus_labels=[],
        source_text=source_text,
    )


def _focus_pack(labels: list[str], *, real: float = 1.0, virtual: float = 0.0, source_type: str = "p2_focus_probe") -> list[dict]:
    rows = []
    for index, label in enumerate(labels):
        rows.append(
            _item(
                label,
                real=max(0.2, real - index * 0.05),
                virtual=virtual,
                source_type=source_type,
                focus_score=max(0.18, 1.0 - index * 0.04),
            )
        )
    return rows


def _slot_virtual_mass(packet: dict) -> float:
    return _round4(sum(float(row.get("virtual_energy", 0.0) or 0.0) for row in packet.get("items", []) or []))


def _verdict(passed: bool, partial: bool = False) -> str:
    if passed:
        return "pass"
    if partial:
        return "partial"
    return "fail"


def _boundary() -> dict:
    return {
        "ap_core_scope_only": True,
        "gl_learning_protocol_scope": False,
        "product_shell_scope": False,
        "third_party_replication_scope": False,
        "answer_table_lookup": False,
        "keyword_hard_gate": False,
        "regex_route": False,
        "student_side_llm": False,
        "hidden_solver": False,
        "full_sentence_macro": False,
    }


def run_residual_depth_stress() -> dict:
    memory = _memory(recall_top_k=8, predict_top_k=4)
    supported_pairs = [
        ("AB", ["text::A", "text::B"]),
        ("CD", ["text::C", "text::D"]),
        ("EF", ["text::E", "text::F"]),
        ("GH", ["text::G", "text::H"]),
        ("IJ", ["text::I", "text::J"]),
    ]
    distractors = [
        ("AX", ["text::A", "text::X"]),
        ("CY", ["text::C", "text::Y"]),
        ("noise", ["noise::fog", "text::Q"]),
        ("mixed", ["text::A", "text::D", "text::noise"]),
    ]
    for tick, (name, labels) in enumerate(supported_pairs, start=1):
        _write(memory, tick, labels, f"pair_{name}")
    for tick, (name, labels) in enumerate(distractors, start=20):
        _write(memory, tick, labels, f"distractor_{name}")

    query_energy = {
        "text::A": 1.55,
        "text::B": 1.55,
        "text::C": 1.35,
        "text::D": 1.35,
        "text::E": 1.10,
        "text::F": 1.10,
        "text::G": 0.88,
        "text::H": 0.88,
        "text::I": 0.70,
        "text::J": 0.70,
        "text::X_noise": 0.42,
    }
    query = [_item(label, real=real, virtual=0.15) for label, real in query_energy.items()]
    rows = memory.recall_residual(query, memory_kind="state", top_k=8)
    winners = [str(row.get("source_text", "") or "") for row in rows]
    supported_winners = [winner for winner in winners if winner.startswith("pair_")]
    distractor_winners = [winner for winner in winners if winner.startswith("distractor_")]
    trace = list(rows[-1].get("residual_recall_trace", []) if rows else [])
    masses_before = [float(row.get("residual_mass_before", 0.0) or 0.0) for row in trace]
    masses_after = [float(row.get("residual_mass_after", 0.0) or 0.0) for row in trace]
    trace_declines = bool(trace and all(after < before for before, after in zip(masses_before, masses_after)))
    supported_first = winners[: max(1, len(supported_winners))]
    supported_first_clean = all(winner.startswith("pair_") for winner in supported_first[:5])
    distinct_winners = len(set(winners)) == len(winners)
    drained_label_count = len({label for row in trace for label in row.get("drained_labels", []) or []})
    passed = bool(
        len(rows) >= 7
        and len(trace) >= 6
        and len(supported_winners) >= 5
        and distinct_winners
        and trace_declines
        and supported_first_clean
        and drained_label_count >= 8
    )
    return {
        "experiment": "ResidualDepth-Stress-1",
        "verdict": _verdict(passed, len(supported_winners) >= 5 and trace_declines),
        "design": "Larger mixed AP-Core state query should recall one B winner per round and absorb matched SA mass before later rounds.",
        "observed": {
            "winner_source_texts": winners,
            "supported_winners": supported_winners,
            "distractor_winners": distractor_winners,
            "distinct_winners": distinct_winners,
            "trace_round_count": len(trace),
            "row_count": len(rows),
            "mass_declines_each_traced_round": trace_declines,
            "residual_mass_before": [_round4(value) for value in masses_before],
            "residual_mass_after": [_round4(value) for value in masses_after],
            "drained_label_count": drained_label_count,
            "rounds": [
                {
                    "round_index": row.get("recall_round_index"),
                    "source_text": row.get("source_text"),
                    "score": _round4(float(row.get("score", 0.0) or 0.0)),
                    "match_efficiency": _round4(float(row.get("match_efficiency", 0.0) or 0.0)),
                    "matched_labels": (row.get("residual_absorption", {}) or {}).get("matched_labels", []),
                    "residual_mass_before": (row.get("residual_absorption", {}) or {}).get("residual_mass_before"),
                    "residual_mass_after": (row.get("residual_absorption", {}) or {}).get("residual_mass_after"),
                }
                for row in rows
            ],
        },
        "boundary": {
            **_boundary(),
            "one_b_winner_per_round": True,
            "language_learning_claim": False,
        },
    }


def run_longrun_stability() -> dict:
    short_config = ShortTermConfig(focus_history_limit=12)
    slot_config = ShortTermSlotConfig()
    focus = FocusBuffer(
        focus_history_limit=short_config.focus_history_limit,
        recency_decay=short_config.recency_decay,
        synthetic_query_weight=short_config.synthetic_query_weight,
        replay_decay=short_config.replay_decay,
        replay_query_weight=short_config.replay_query_weight,
        max_replay_items=short_config.max_replay_items,
        episode_break_overlap=short_config.episode_break_overlap,
    )
    slot = ShortTermSlotPacketBuilder(**asdict(slot_config))
    memory = _memory(recall_top_k=6, predict_top_k=4)
    _write(memory, 1, ["text::garden", "text::seed", "text::water", "feeling::care"], "garden_main_memory")
    _write(memory, 2, ["text::sprout", "text::green", "text::grow"], "garden_successor_memory")
    _write(memory, 3, ["text::alarm", "text::red", "text::loud"], "alarm_interrupt_memory")
    _write(memory, 4, ["text::math", "text::number", "text::carry"], "math_interrupt_memory")

    sequence = [
        ("main", ["text::garden", "text::seed", "text::water", "feeling::care"]),
        ("main", ["text::garden", "text::seed", "text::water", "text::sprout"]),
        ("main", ["text::garden", "text::water", "text::sprout", "feeling::care"]),
        ("alarm", ["text::alarm", "text::red", "text::loud"]),
        ("alarm", ["text::alarm", "text::red", "action::orient"]),
        ("main", ["text::garden", "text::seed", "text::water", "text::sprout"]),
        ("main", ["text::garden", "text::sprout", "text::green", "feeling::care"]),
        ("math", ["text::math", "text::number", "text::carry"]),
        ("math", ["text::math", "text::number", "action::count"]),
        ("main", ["text::garden", "text::seed", "text::sprout", "text::green"]),
        ("main", ["text::garden", "text::water", "text::green", "feeling::care"]),
        ("main", ["text::garden", "text::sprout", "text::grow", "feeling::care"]),
    ]
    slot_traces = []
    trace: dict[str, Any] = {}
    for tick, (phase, labels) in enumerate(sequence):
        focus.push(_focus_pack(labels, real=1.15 if phase == "main" else 1.35), tick_index=tick)
        trace = focus.trace(tick_index=tick)
        slot_trace = slot.build(
            tick_index=tick,
            focus_items=_focus_pack(labels, real=1.15 if phase == "main" else 1.35),
            focus_continuation_trace=trace,
            short_term_memory_trace={
                "last_recall": {
                    "available": tick > 0,
                    "score": 0.56 if phase == "main" else 0.34,
                }
            },
            rhythm_trace={},
            runtime_load_trace={"channels": {"load_ratio": 0.08 if phase == "main" else 0.18}},
        )
        slot_traces.append(slot_trace)
        memory.write_snapshot(
            tick_index=100 + tick,
            memory_kind="short_term_slot",
            items=list(slot_trace.get("items", []) or []),
            focus_labels=list(slot_trace.get("focus_labels", []) or []),
            source_text=f"slot_{tick:02d}_{phase}",
        )

    dynamics = focus.continuity_dynamics(tick_index=len(sequence) - 1)
    readback = dict(trace.get("recent_thought_readback", {}) or {})
    replay_candidates = list(trace.get("replay_candidates", []) or [])
    final_slot = slot_traces[-1]
    final_labels = _labels(list(final_slot.get("items", []) or []))
    final_mass = _slot_virtual_mass(final_slot)
    state_bn = memory.recall_residual(
        [_item("text::garden"), _item("text::seed"), _item("text::water"), _item("feeling::care")],
        memory_kind="state",
        top_k=4,
    )
    slot_bn = memory.recall_residual(list(final_slot.get("items", []) or []), memory_kind="short_term_slot", top_k=4)
    state_winners = [str(row.get("source_text", "") or "") for row in state_bn]
    slot_winners = [str(row.get("source_text", "") or "") for row in slot_bn]
    interruptions = list(dynamics.get("recent_interruptions", []) or [])
    resumptions = list(dynamics.get("recent_resumptions", []) or [])
    main_final_labels = [label for label in final_labels if "garden" in label or "sprout" in label or "green" in label or "care" in label]
    passed = bool(
        len(interruptions) >= 2
        and len(resumptions) >= 2
        and final_mass > 0.45
        and len(main_final_labels) >= 3
        and readback.get("available") is True
        and replay_candidates
        and "garden_main_memory" in state_winners
        and any(str(winner).startswith("slot_") for winner in slot_winners)
    )
    return {
        "experiment": "LongRun-Stability-1",
        "verdict": _verdict(passed, len(interruptions) >= 2 and readback.get("available") is True),
        "design": "Repeated AP-Core focus interruptions should preserve a resumable short-term narrative slot without exact replay forcing.",
        "observed": {
            "tick_count": len(sequence),
            "recent_interruptions": interruptions,
            "recent_resumptions": resumptions,
            "episode_summaries": dynamics.get("episode_summaries", []),
            "final_slot_virtual_mass": final_mass,
            "final_slot_labels": final_labels[:32],
            "main_final_labels": main_final_labels,
            "readback": {
                "available": readback.get("available"),
                "labels": readback.get("labels", [])[:12],
                "strength": readback.get("strength"),
                "drift_score": readback.get("drift_score"),
                "mean_continuity": readback.get("mean_continuity"),
            },
            "replay_candidates": replay_candidates[:4],
            "state_recall_winners": state_winners,
            "slot_recall_winners": slot_winners,
            "slot_mass_series": [_slot_virtual_mass(packet) for packet in slot_traces],
        },
        "boundary": {
            **_boundary(),
            "white_box_focus_probe": True,
            "open_dialogue_learning_claim": False,
        },
    }


def _run_slot_grid_case(capacity: int, base_virtual_budget: float, item_order_decay: float, continuity_gain: float) -> dict:
    config = replace(
        ShortTermSlotConfig(),
        capacity=capacity,
        base_virtual_budget=base_virtual_budget,
        item_order_decay=item_order_decay,
        continuity_gain=continuity_gain,
    )
    builder = ShortTermSlotPacketBuilder(**asdict(config))
    focus_labels = [f"text::slot_item_{index:02d}" for index in range(40)]
    focus_items = _focus_pack(focus_labels, real=1.0)
    packet = builder.build(
        tick_index=32,
        focus_items=focus_items,
        focus_continuation_trace={
            "continuation_strength": 1.0,
            "active_episode_id": 3,
            "recent_entries": [
                {"continuity_score": 0.86},
                {"continuity_score": 0.92},
                {"continuity_score": 0.95},
            ],
        },
        short_term_memory_trace={"last_recall": {"available": True, "score": 0.58}},
        rhythm_trace={},
        runtime_load_trace={"channels": {"load_ratio": 0.12}},
    )
    labels = _labels(list(packet.get("items", []) or []))
    order_rows = [row for row in packet.get("items", []) or [] if str(row.get("sa_label", "")).startswith("short_term_slot::order::")]
    item_rows = [row for row in packet.get("items", []) or [] if str(row.get("sa_label", "")).startswith("short_term_slot::item::")]
    order_coeffs = [float((row.get("anchor_meta", {}) or {}).get("slot_order_coeff", 0.0) or 0.0) for row in order_rows]
    item_virtuals = [float(row.get("virtual_energy", 0.0) or 0.0) for row in item_rows]
    packet_count = len(packet.get("items", []) or [])
    clipped = len(focus_labels) > capacity
    monotonic = all(left >= right for left, right in zip(order_coeffs, order_coeffs[1:]))
    virtual_mass = _slot_virtual_mass(packet)
    passed = bool(
        packet.get("enabled") is True
        and packet_count <= capacity
        and "short_term_slot::summary" in labels
        and "short_term_slot::continuity" in labels
        and order_rows
        and item_rows
        and monotonic
        and 0.05 <= virtual_mass <= 8.0
        and max(item_virtuals or [0.0]) <= config.item_max_virtual + 1e-6
    )
    return {
        "case": f"cap{capacity}_budget{base_virtual_budget}_order{item_order_decay}_cont{continuity_gain}",
        "passed": passed,
        "parameters": {
            "capacity": capacity,
            "base_virtual_budget": base_virtual_budget,
            "item_order_decay": item_order_decay,
            "continuity_gain": continuity_gain,
        },
        "observed": {
            "packet_count": packet_count,
            "focus_count": len(focus_labels),
            "capacity_respected": packet_count <= capacity,
            "capacity_clipped": clipped,
            "item_count": len(item_rows),
            "order_count": len(order_rows),
            "virtual_mass": virtual_mass,
            "max_item_virtual": _round4(max(item_virtuals or [0.0])),
            "order_coeffs_head": [_round4(value) for value in order_coeffs[:8]],
            "order_coeff_monotonic": monotonic,
            "slot_summary": packet.get("slot_summary", {}),
        },
    }


def run_short_term_slot_grid() -> dict:
    capacities = [8, 16, 32, 48]
    budgets = [0.36, 0.72, 1.08]
    order_decays = [0.78, 0.92, 0.98]
    continuity_gains = [0.15, 0.35, 0.55]
    cases = [
        _run_slot_grid_case(capacity, budget, order_decay, continuity_gain)
        for capacity in capacities
        for budget in budgets
        for order_decay in order_decays
        for continuity_gain in continuity_gains
    ]
    pass_count = sum(1 for case in cases if case.get("passed"))
    clipped_count = sum(1 for case in cases if case.get("observed", {}).get("capacity_clipped"))
    all_passed = pass_count == len(cases)
    masses = [float(case.get("observed", {}).get("virtual_mass", 0.0) or 0.0) for case in cases]
    return {
        "experiment": "ShortTermSlot-Grid-1",
        "verdict": _verdict(all_passed, pass_count >= int(len(cases) * 0.95)),
        "design": "Broader short-term-slot parameter grid should remain bounded, monotonic, and capacity-limited.",
        "observed": {
            "case_count": len(cases),
            "pass_count": pass_count,
            "pass_rate": _round4(pass_count / max(1, len(cases))),
            "capacity_clipped_count": clipped_count,
            "virtual_mass_min": _round4(min(masses) if masses else 0.0),
            "virtual_mass_max": _round4(max(masses) if masses else 0.0),
            "cases": cases,
        },
        "boundary": {
            **_boundary(),
            "parameter_optimality_claim": False,
            "bounded_packet_mechanics_probe": True,
        },
    }


def _sha256_file(path: Path) -> str:
    if not path.exists():
        return ""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _manifest_entry(path: Path) -> dict:
    return {
        "path": str(path),
        "relative_path": str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path),
        "exists": path.exists(),
        "bytes": int(path.stat().st_size) if path.exists() else 0,
        "sha256": _sha256_file(path),
    }


def run_p2_stress_suite(*, output_dir: Path | None = None) -> dict:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = output_dir or (ROOT / "outputs" / f"apv2_p2_stress_mechanism_evidence_{stamp}")
    out_dir.mkdir(parents=True, exist_ok=True)
    experiments = [
        run_residual_depth_stress(),
        run_longrun_stability(),
        run_short_term_slot_grid(),
    ]
    counts = {
        "pass": sum(1 for row in experiments if row.get("verdict") == "pass"),
        "partial": sum(1 for row in experiments if row.get("verdict") == "partial"),
        "fail": sum(1 for row in experiments if row.get("verdict") == "fail"),
    }
    return {
        "schema_id": "apv2_p2_stress_mechanism_evidence/v1",
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "output_dir": str(out_dir),
        "route_split": {
            "this_suite": "AP-Core runtime mechanism stress evidence",
            "not_this_suite": "GL learning protocol, Skill38/OpenWorld, ACG-j third-party rerun, desktop-pet product shell",
        },
        "experiments": experiments,
        "summary": {
            **counts,
            "all_passed": counts["fail"] == 0 and counts["partial"] == 0,
            "acceptance_policy": "pass_requires_residual_depth_longrun_stability_and_slot_grid",
        },
        "boundary": _boundary(),
    }


def write_outputs(result: dict, *, output_dir: Path | None = None) -> dict:
    out_dir = output_dir or Path(result.get("output_dir") or ROOT / "outputs" / "apv2_p2_stress_mechanism_evidence")
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = out_dir / "apv2_p2_stress_mechanism_evidence.json"
    md_path = out_dir / "apv2_p2_stress_mechanism_evidence_report.md"
    manifest_path = out_dir / "artifact_manifest.json"
    result = dict(result)
    result["artifacts"] = {
        "json_path": str(json_path),
        "markdown_path": str(md_path),
        "manifest_path": str(manifest_path),
        "output_dir": str(out_dir),
    }
    json_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    lines = [
        "# APV2 P2 Stress Mechanism Evidence",
        "",
        f"- generated_at: `{result.get('generated_at')}`",
        "- scope: `AP-Core runtime mechanism stress evidence`",
        "- not_scope: `GL learning / Skill38 / OpenWorld / ACG-j rerun / desktop-pet product shell`",
        f"- all_passed: `{result.get('summary', {}).get('all_passed')}`",
        f"- pass: `{result.get('summary', {}).get('pass')}`",
        f"- partial: `{result.get('summary', {}).get('partial')}`",
        f"- fail: `{result.get('summary', {}).get('fail')}`",
        "",
        "## Experiments",
        "",
    ]
    for row in result.get("experiments", []) or []:
        observed = dict(row.get("observed", {}) or {})
        lines.extend(
            [
                f"### {row.get('experiment')}",
                "",
                f"- verdict: `{row.get('verdict')}`",
                f"- design: {row.get('design')}",
                f"- boundary: `{json.dumps(row.get('boundary', {}), ensure_ascii=False)}`",
                "",
            ]
        )
        if row.get("experiment") == "ResidualDepth-Stress-1":
            lines.append(f"- winners: `{json.dumps(observed.get('winner_source_texts', []), ensure_ascii=False)}`")
            lines.append(f"- trace_round_count: `{observed.get('trace_round_count')}`")
            lines.append(f"- mass_before: `{json.dumps(observed.get('residual_mass_before', []), ensure_ascii=False)}`")
            lines.append(f"- mass_after: `{json.dumps(observed.get('residual_mass_after', []), ensure_ascii=False)}`")
            lines.append("")
        if row.get("experiment") == "LongRun-Stability-1":
            lines.append(f"- tick_count: `{observed.get('tick_count')}`")
            lines.append(f"- interruptions: `{len(observed.get('recent_interruptions', []) or [])}`")
            lines.append(f"- resumptions: `{len(observed.get('recent_resumptions', []) or [])}`")
            lines.append(f"- final_slot_virtual_mass: `{observed.get('final_slot_virtual_mass')}`")
            lines.append(f"- state_recall_winners: `{json.dumps(observed.get('state_recall_winners', []), ensure_ascii=False)}`")
            lines.append("")
        if row.get("experiment") == "ShortTermSlot-Grid-1":
            lines.append(f"- pass_rate: `{observed.get('pass_rate')}` ({observed.get('pass_count')}/{observed.get('case_count')})")
            lines.append(f"- virtual_mass_min/max: `{observed.get('virtual_mass_min')}` / `{observed.get('virtual_mass_max')}`")
            lines.append(f"- capacity_clipped_count: `{observed.get('capacity_clipped_count')}`")
            lines.append("")
    md_path.write_text("\n".join(lines), encoding="utf-8")
    manifest = {
        "schema_id": "apv2_p2_stress_artifact_manifest/v1",
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "entries": [
            _manifest_entry(ROOT / "docs" / "Design_APV2_P2StressMechanismEvidence_20260611.md"),
            _manifest_entry(ROOT / "docs" / "Review_APV2_P2StressMechanismEvidence_20260611.md"),
            _manifest_entry(ROOT / "experiments" / "apv2_p2_stress_mechanism_evidence.py"),
            _manifest_entry(ROOT / "tests" / "test_apv2_p2_stress_mechanism_evidence.py"),
            _manifest_entry(json_path),
            _manifest_entry(md_path),
        ],
        "boundary": _boundary(),
    }
    manifest["validation_passed"] = all(row.get("exists") and int(row.get("bytes", 0) or 0) > 0 for row in manifest["entries"])
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return {
        "output_dir": str(out_dir),
        "json_path": str(json_path),
        "markdown_path": str(md_path),
        "manifest_path": str(manifest_path),
    }


def main() -> int:
    result = run_p2_stress_suite()
    artifacts = write_outputs(result)
    print(json.dumps({"summary": result["summary"], "artifacts": artifacts}, ensure_ascii=False, indent=2))
    return 0 if result["summary"]["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

