from __future__ import annotations

import json
import sys
from dataclasses import asdict, replace
from datetime import datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from config.defaults import RuntimeConfig, ShortTermSlotConfig
from core.runtime.engine import APV21Runtime
from memory.short_term.slot_packet import ShortTermSlotPacketBuilder
from memory.spacetime.transition_store import TransitionStore
from memory.store import MemoryStore


def _round4(value: float) -> float:
    return round(float(value), 4)


def _item(label: str, *, real: float = 1.0, virtual: float = 0.0, source_type: str = "external_text") -> dict:
    token = str(label).split("::")[-1]
    return {
        "sa_label": str(label),
        "display_text": token,
        "family": "text",
        "source_type": str(source_type),
        "real_energy": float(real),
        "virtual_energy": float(virtual),
        "attention_gain": float(real) * 0.2 + float(virtual) * 0.1,
        "cognitive_pressure": float(real) - float(virtual),
    }


def _labels(rows: list[dict]) -> list[str]:
    return [str(row.get("sa_label", "") or "") for row in rows or [] if str(row.get("sa_label", "") or "")]


def _memory(*, recall_top_k: int = 4, predict_top_k: int = 4, prediction_energy_scale: float = 0.55) -> MemoryStore:
    return MemoryStore(
        recall_top_k=recall_top_k,
        predict_top_k=predict_top_k,
        prediction_energy_scale=prediction_energy_scale,
        max_snapshots_per_kind=128,
        candidate_limit=64,
        scoring_candidate_limit=64,
        online_enabled=True,
        online_min_support_to_promote=1,
        online_per_tick_update_limit=64,
        transition_learned_weight=0.18,
    )


def _write(memory: MemoryStore, tick: int, labels: list[str], source_text: str, *, memory_kind: str = "state") -> dict:
    return memory.write_snapshot(
        tick_index=int(tick),
        memory_kind=memory_kind,
        items=[_item(label) for label in labels],
        focus_labels=[],
        source_text=source_text,
    )


def _focus_items(labels: list[str]) -> list[dict]:
    rows = []
    for index, label in enumerate(labels):
        rows.append(
            {
                **_item(label, real=max(0.2, 1.0 - index * 0.08)),
                "focus_score": max(0.2, 1.0 - index * 0.06),
                "anchor_meta": {"is_focus": True, "focus_probe_rank": index},
            }
        )
    return rows


def _build_slot_packet(labels: list[str], config: ShortTermSlotConfig | None = None) -> dict:
    slot_config = config or ShortTermSlotConfig()
    builder = ShortTermSlotPacketBuilder(**asdict(slot_config))
    return builder.build(
        tick_index=8,
        focus_items=_focus_items(labels),
        focus_continuation_trace={
            "continuation_strength": 1.0,
            "active_episode_id": 7,
            "recent_entries": [
                {"continuity_score": 0.92},
                {"continuity_score": 0.96},
                {"continuity_score": 1.0},
            ],
        },
        short_term_memory_trace={"last_recall": {"available": True, "score": 0.62}},
        rhythm_trace={},
        runtime_load_trace={"channels": {"load_ratio": 0.12}},
    )


def _slot_virtual_mass(packet: dict) -> float:
    return _round4(sum(float(row.get("virtual_energy", 0.0) or 0.0) for row in packet.get("items", []) or []))


def _payload_labels(memory: MemoryStore) -> list[str]:
    snapshot = memory.latest_snapshot("state") or {}
    return _labels(list(snapshot.get("prediction_payload_items", []) or []))


def _feedback_text_item(token: str, *, punishment: float, reward: float = 0.0, correctness: float = 0.0, outcome: str = "measured") -> dict:
    return {
        **_item(f"text::{token}", real=0.42, virtual=0.04, source_type="internal_draft_read"),
        "last_seen_tick": 1,
        "anchor_meta": {
            "schema_id": "draft_read_token/v1",
            "event_type": "draft_read_token",
            "token": str(token),
            "feedback_outcome": str(outcome),
            "feedback_reward": float(reward),
            "feedback_punishment": float(punishment),
            "feedback_correctness": float(correctness),
            "current_read_tick": True,
            "current_glyph_role": "read_tick_target",
            "prediction_payload_priority": "current_glyph_character",
            "used_in_strict_teacher_off_input": False,
        },
    }


def _verdict(passed: bool, partial: bool = False) -> str:
    if passed:
        return "pass"
    if partial:
        return "partial"
    return "fail"


def _boundary() -> dict:
    return {
        "ap_core_scope_only": True,
        "gl_learning_protocol_scope": False,
        "product_shell_scope": False,
        "answer_table_lookup": False,
        "keyword_hard_gate": False,
        "regex_route": False,
        "student_side_llm": False,
        "hidden_solver": False,
        "full_sentence_macro": False,
    }


def collect_default_parameter_table() -> dict:
    config = RuntimeConfig()
    return {
        "schema_id": "apv2_bottom_loop_default_parameters/v1",
        "runtime": {
            "allow_memory_bootstrap": config.allow_memory_bootstrap,
            "target_tick_ms": config.observability.target_tick_ms,
        },
        "state_pool": {
            key: value
            for key, value in asdict(config.state_pool).items()
            if key
            in {
                "real_decay",
                "virtual_decay",
                "attention_gain_decay",
                "fatigue_decay",
                "r_state_head_limit",
                "r_state_items_per_head",
                "query_limit",
                "snapshot_limit",
                "memory_snapshot_limit",
                "prediction_fatigue_enabled",
                "bootstrap_virtual_energy",
            }
        },
        "memory": {
            key: value
            for key, value in asdict(config.memory).items()
            if key
            in {
                "recall_top_k",
                "predict_top_k",
                "prediction_energy_scale",
                "max_snapshots_per_kind",
                "candidate_limit",
                "core_item_limit",
                "query_feature_limit",
                "scoring_candidate_limit",
                "online_enabled",
                "online_min_support_to_promote",
                "online_per_tick_update_limit",
                "transition_learned_weight",
                "temporal_applicability_enabled",
                "temporal_floor",
            }
        },
        "short_term": asdict(config.short_term),
        "short_term_slot": asdict(config.short_term_slot),
        "attention": asdict(config.attention),
        "successor_lag_kernel": {
            "lag_1": 1.0,
            "lag_2": 0.42,
            "lag_ge_3": "max(0.08, 0.42 * (0.64 ** (lag - 2)))",
            "semantic": "next_tick_peak_then_sharp_drop_and_tail",
        },
        "residual_b_recall": {
            "round_policy": "one_b_winner_per_round",
            "max_rounds": "min(top_k * 2, 12)",
            "matched_label_scale": "max(0.08, 1 - match_efficiency * 0.82)",
            "unmatched_label_scale": "max(0.48, 1 - match_efficiency * 0.20)",
            "energy_semantic": "matched query SA mass is absorbed into the selected B object for the next round only",
        },
        "negative_text_feedback": {
            "repair_condition": "punishment > max(reward, correctness) and punishment >= 0.18, or explicit feedback_outcome='punished'",
            "repair_label_prefix": "text_revision_opportunity::negative_feedback::",
            "positive_text_prediction_allowed": False,
        },
    }


def _run_slot_param_case(name: str, config: ShortTermSlotConfig) -> dict:
    packet = _build_slot_packet(["text::alpha", "text::beta", "text::gamma", "feeling::surprise"], config)
    labels = _labels(packet.get("items", []) or [])
    item_masses = [
        float(row.get("virtual_energy", 0.0) or 0.0)
        for row in packet.get("items", []) or []
        if str(row.get("sa_label", "")).startswith("short_term_slot::item::")
    ]
    mass = _slot_virtual_mass(packet)
    bounded_items = bool(item_masses and max(item_masses) <= config.item_max_virtual + 1e-6)
    passed = bool(
        packet.get("enabled") is True
        and mass > 0.25
        and mass < 3.2
        and "short_term_slot::summary" in labels
        and "short_term_slot::continuity" in labels
        and any(label.startswith("short_term_slot::order::") for label in labels)
        and bounded_items
    )
    return {
        "case": name,
        "kind": "short_term_slot",
        "passed": passed,
        "parameters": asdict(config),
        "observed": {
            "slot_virtual_mass": mass,
            "item_count": len([label for label in labels if label.startswith("short_term_slot::item::")]),
            "order_count": len([label for label in labels if label.startswith("short_term_slot::order::")]),
            "max_item_virtual_energy": _round4(max(item_masses) if item_masses else 0.0),
            "slot_summary": packet.get("slot_summary", {}),
        },
    }


def _run_residual_case(name: str, *, query_scale: float, top_k: int) -> dict:
    memory = _memory(recall_top_k=max(4, top_k), predict_top_k=4)
    _write(memory, 1, ["text::A", "text::B"], "AB")
    _write(memory, 2, ["text::C", "text::D"], "CD")
    _write(memory, 3, ["text::E"], "E")
    _write(memory, 4, ["text::A"], "A")
    query = [
        _item("text::A", real=1.3 * query_scale),
        _item("text::B", real=1.2 * query_scale),
        _item("text::C", real=1.1 * query_scale),
        _item("text::E", real=1.0 * query_scale),
    ]
    rows = memory.recall_residual(query, memory_kind="state", top_k=top_k)
    trace = [dict(row.get("residual_absorption", {}) or {}) for row in rows if row.get("residual_absorption")]
    winners = [str(row.get("source_text", "") or "") for row in rows]
    mass_declines = all(float(row.get("residual_mass_after", 0.0) or 0.0) < float(row.get("residual_mass_before", 0.0) or 0.0) for row in trace)
    distinct = len(set(winners)) == len(winners)
    covers_late_component = any("text::E" in set(row.get("matched_labels", []) or []) for row in trace) or "E" in winners
    passed = bool(len(trace) >= min(3, top_k) and mass_declines and distinct and covers_late_component)
    return {
        "case": name,
        "kind": "residual_b_recall",
        "passed": passed,
        "parameters": {"query_scale": query_scale, "top_k": top_k},
        "observed": {
            "winners": winners,
            "round_count": len(trace),
            "mass_declines": mass_declines,
            "distinct_winners": distinct,
            "covers_late_component": covers_late_component,
            "absorption_trace": trace,
        },
    }


def _run_successor_case(name: str, *, prediction_energy_scale: float) -> dict:
    store = TransitionStore()
    store.register_snapshot({"memory_id": "m0", "memory_kind": "state", "tick_index": 0, "items": []})
    for lag, label in [(1, "text::next"), (2, "text::second"), (4, "text::fourth")]:
        store.register_snapshot(
            {
                "memory_id": f"m{lag}",
                "memory_kind": "state",
                "tick_index": lag,
                "prediction_payload_items": [_item(label, real=1.0)],
            }
        )
        store.link_successor("state", "m0", f"m{lag}")
    shaped = store.successors("state", "m0", top_k=3, prediction_energy_scale=prediction_energy_scale, lag_shaping_enabled=True)
    flat = store.successors("state", "m0", top_k=3, prediction_energy_scale=prediction_energy_scale, lag_shaping_enabled=False)
    kernels = [float(row.get("successor_lag_kernel", 0.0) or 0.0) for row in shaped]
    energies = [
        float((row.get("predicted_items", [{}]) or [{}])[0].get("virtual_energy", 0.0) or 0.0)
        for row in shaped
    ]
    flat_kernels = [float(row.get("successor_lag_kernel", 0.0) or 0.0) for row in flat]
    passed = bool(len(kernels) == 3 and kernels[0] == 1.0 and kernels[0] > kernels[1] > kernels[2] and energies[0] > energies[1] > energies[2] and flat_kernels == [1.0, 1.0, 1.0])
    return {
        "case": name,
        "kind": "successor_lag",
        "passed": passed,
        "parameters": {"prediction_energy_scale": prediction_energy_scale},
        "observed": {
            "kernels": [_round4(value) for value in kernels],
            "predicted_energies": [_round4(value) for value in energies],
            "flat_kernels": [_round4(value) for value in flat_kernels],
        },
    }


def _run_feedback_threshold_case(name: str, *, punishment: float, expected_repair: bool) -> dict:
    memory = _memory()
    memory.write_snapshot(
        tick_index=1,
        memory_kind="state",
        items=[_feedback_text_item(name, punishment=punishment, outcome="measured")],
        focus_labels=[],
        source_text=f"feedback threshold {name}",
    )
    labels = _payload_labels(memory)
    repair_present = any(label.startswith(f"text_revision_opportunity::negative_feedback::{name}") for label in labels)
    positive_present = f"text::{name}" in labels
    passed = bool(repair_present == expected_repair and (positive_present != expected_repair))
    return {
        "case": name,
        "kind": "negative_text_feedback_threshold",
        "passed": passed,
        "parameters": {"punishment": punishment, "expected_repair": expected_repair},
        "observed": {
            "payload_labels": labels,
            "repair_present": repair_present,
            "positive_text_present": positive_present,
        },
    }


def run_bottom_loop_param_sensitivity() -> dict:
    default_slot = ShortTermSlotConfig()
    cases = [
        _run_slot_param_case("slot_default", default_slot),
        _run_slot_param_case("slot_low_virtual_budget", replace(default_slot, base_virtual_budget=0.50)),
        _run_slot_param_case("slot_high_virtual_budget", replace(default_slot, base_virtual_budget=1.08)),
        _run_slot_param_case("slot_steeper_order_decay", replace(default_slot, item_order_decay=0.82)),
        _run_slot_param_case("slot_flatter_order_decay", replace(default_slot, item_order_decay=0.98)),
        _run_slot_param_case("slot_lower_rank_decay", replace(default_slot, item_rank_decay=0.78)),
        _run_slot_param_case("slot_higher_rank_decay", replace(default_slot, item_rank_decay=0.94)),
        _run_residual_case("residual_default_scale", query_scale=1.0, top_k=4),
        _run_residual_case("residual_low_query_mass", query_scale=0.72, top_k=4),
        _run_residual_case("residual_high_query_mass", query_scale=1.35, top_k=4),
        _run_successor_case("successor_default_scale", prediction_energy_scale=0.55),
        _run_successor_case("successor_low_scale", prediction_energy_scale=0.42),
        _run_successor_case("successor_high_scale", prediction_energy_scale=0.82),
        _run_feedback_threshold_case("below_threshold", punishment=0.17, expected_repair=False),
        _run_feedback_threshold_case("at_threshold", punishment=0.18, expected_repair=True),
        _run_feedback_threshold_case("above_threshold", punishment=0.64, expected_repair=True),
    ]
    pass_count = sum(1 for case in cases if case.get("passed"))
    all_passed = pass_count == len(cases)
    return {
        "experiment": "APV2-BottomLoop-ParamSensitivity-1",
        "verdict": _verdict(all_passed, pass_count >= int(len(cases) * 0.85)),
        "design": "Conservative perturbations around APV2 bottom-loop defaults should preserve qualitative mechanism traces.",
        "observed": {
            "case_count": len(cases),
            "pass_count": pass_count,
            "pass_rate": _round4(pass_count / max(1, len(cases))),
            "cases": cases,
        },
        "boundary": _boundary(),
    }


def _filter_without_order_rows(rows: list[dict]) -> list[dict]:
    return [dict(row) for row in rows if not str(row.get("sa_label", "") or "").startswith("short_term_slot::order::")]


def run_short_term_slot_order_ablation() -> dict:
    abc_packet = _build_slot_packet(["text::A", "text::B", "text::C"])
    cba_packet = _build_slot_packet(["text::C", "text::B", "text::A"])
    memory = _memory(recall_top_k=2, predict_top_k=2)
    memory.write_snapshot(
        tick_index=1,
        memory_kind="short_term_slot",
        items=list(abc_packet.get("items", []) or []),
        focus_labels=[],
        source_text="slot_ABC",
    )
    memory.write_snapshot(
        tick_index=2,
        memory_kind="short_term_slot",
        items=list(cba_packet.get("items", []) or []),
        focus_labels=[],
        source_text="slot_CBA",
    )

    full_rows = memory.recall(list(abc_packet.get("items", []) or []), memory_kind="short_term_slot", top_k=2)
    no_order_rows = memory.recall(_filter_without_order_rows(list(abc_packet.get("items", []) or [])), memory_kind="short_term_slot", top_k=2)
    reversed_rows = memory.recall(list(cba_packet.get("items", []) or []), memory_kind="short_term_slot", top_k=2)

    def score_for(rows: list[dict], source_text: str) -> float:
        for row in rows:
            if str(row.get("source_text", "") or "") == source_text:
                return float(row.get("score", 0.0) or 0.0)
        return 0.0

    full_abc = score_for(full_rows, "slot_ABC")
    full_cba = score_for(full_rows, "slot_CBA")
    no_order_abc = score_for(no_order_rows, "slot_ABC")
    no_order_cba = score_for(no_order_rows, "slot_CBA")
    reversed_abc = score_for(reversed_rows, "slot_ABC")
    reversed_cba = score_for(reversed_rows, "slot_CBA")
    full_margin = full_abc - full_cba
    no_order_margin = no_order_abc - no_order_cba
    margin_drop = full_margin - no_order_margin
    wrong_order_still_recalled = full_cba > 0.0
    reversed_prefers_reversed = reversed_cba > reversed_abc
    passed = bool(full_abc > full_cba and no_order_abc > no_order_cba and margin_drop > 0.1 and wrong_order_still_recalled and reversed_prefers_reversed)

    return {
        "experiment": "ShortTermSlot-OrderAblation-1",
        "verdict": _verdict(passed, full_abc > full_cba and wrong_order_still_recalled),
        "design": "Short-term-slot order should provide a soft recall advantage, while item overlap still permits nonmatching order recall.",
        "observed": {
            "full_order_scores": {"slot_ABC": _round4(full_abc), "slot_CBA": _round4(full_cba), "margin": _round4(full_margin)},
            "without_order_rows_scores": {"slot_ABC": _round4(no_order_abc), "slot_CBA": _round4(no_order_cba), "margin": _round4(no_order_margin)},
            "margin_drop_without_order_rows": _round4(margin_drop),
            "reversed_query_scores": {"slot_ABC": _round4(reversed_abc), "slot_CBA": _round4(reversed_cba)},
            "wrong_order_still_recalled": wrong_order_still_recalled,
            "full_order_winners": [row.get("source_text") for row in full_rows],
            "without_order_rows_winners": [row.get("source_text") for row in no_order_rows],
            "reversed_query_winners": [row.get("source_text") for row in reversed_rows],
            "abc_order_labels": [label for label in _labels(list(abc_packet.get("items", []) or [])) if label.startswith("short_term_slot::order::")],
            "cba_order_labels": [label for label in _labels(list(cba_packet.get("items", []) or [])) if label.startswith("short_term_slot::order::")],
        },
        "boundary": {
            **_boundary(),
            "order_is_soft_bias_not_hard_gate": True,
            "item_overlap_recall_still_allowed": True,
        },
    }


def build_representative_tick_trace() -> dict:
    runtime = APV21Runtime()
    for _ in range(3):
        runtime.process_text_tick("sun")
        runtime.process_text_tick("moon")
        runtime.process_text_tick("star")
    trace = runtime.process_text_tick("sun", memory_bootstrap=True)
    slot_items = list(trace.get("short_term_slot", {}).get("items", []) or [])
    fast_bn = list(trace.get("fast_system", {}).get("bn", []) or [])
    fast_cn = list(trace.get("fast_system", {}).get("cn", []) or [])
    slow_bn = list(trace.get("slow_system", {}).get("bn_prime", []) or [])
    slow_cn = list(trace.get("slow_system", {}).get("cn_prime", []) or [])
    focus_order = trace.get("attention", {}).get("focus_order", [])
    if isinstance(focus_order, dict):
        focus_order_preview: Any = dict(list(focus_order.items())[:16])
    elif isinstance(focus_order, list):
        focus_order_preview = list(focus_order[:16])
    else:
        focus_order_preview = focus_order
    successor_rows = []
    for row in fast_cn[:3]:
        successor_rows.append(
            {
                "source_memory_id": row.get("source_memory_id"),
                "successor_memory_id": row.get("successor_memory_id"),
                "lag": row.get("successor_lag_ticks"),
                "kernel": row.get("successor_lag_kernel"),
                "predicted_labels": _labels(list(row.get("predicted_items", []) or []))[:8],
                "predicted_virtual_energy": [
                    _round4(float(item.get("virtual_energy", 0.0) or 0.0))
                    for item in list(row.get("predicted_items", []) or [])[:8]
                ],
            }
        )
    residual_rows = []
    for row in fast_bn[:4]:
        absorption = dict(row.get("residual_absorption", {}) or {})
        residual_rows.append(
            {
                "memory_id": row.get("memory_id"),
                "source_text": row.get("source_text"),
                "score": _round4(float(row.get("score", 0.0) or 0.0)),
                "round_index": row.get("recall_round_index"),
                "matched_labels": absorption.get("matched_labels", []),
                "residual_mass_before": absorption.get("residual_mass_before"),
                "residual_mass_after": absorption.get("residual_mass_after"),
            }
        )
    residual_probe = _run_residual_case("representative_residual_probe", query_scale=1.0, top_k=4)
    return {
        "schema_id": "apv2_representative_tick_trace/v1",
        "trace_source": "sun_moon_star_teacher_off_probe",
        "tick_index": trace.get("tick_index"),
        "input": trace.get("input", {}),
        "short_term_slot": {
            "slot_summary": trace.get("short_term_slot", {}).get("slot_summary", {}),
            "virtual_mass": _slot_virtual_mass(trace.get("short_term_slot", {})),
            "first_labels": _labels(slot_items)[:16],
        },
        "fast_system": {
            "residual_b_recall": residual_rows,
            "residual_b_recall_probe": residual_probe.get("observed", {}),
            "successor_lag_predictions": successor_rows,
        },
        "attention": {
            "selected_labels": trace.get("attention", {}).get("selected_labels", [])[:16],
            "focus_order": focus_order_preview,
        },
        "slow_system": {
            "query_labels": _labels(list(trace.get("slow_system", {}).get("query", []) or []))[:16],
            "bn_prime_source_texts": [row.get("source_text") for row in slow_bn[:4]],
            "cn_prime_predicted_labels": [
                _labels(list(row.get("predicted_items", []) or []))[:6]
                for row in slow_cn[:4]
            ],
        },
        "action": {
            "selected_action": (trace.get("action", {}) or {}).get("selected_action"),
            "candidate_count": len((trace.get("action", {}) or {}).get("candidates", []) or []),
        },
        "boundary": _boundary(),
    }


def run_p0_materials_suite() -> dict:
    experiments = [
        run_bottom_loop_param_sensitivity(),
        run_short_term_slot_order_ablation(),
    ]
    counts = {
        "pass": sum(1 for row in experiments if row.get("verdict") == "pass"),
        "partial": sum(1 for row in experiments if row.get("verdict") == "partial"),
        "fail": sum(1 for row in experiments if row.get("verdict") == "fail"),
    }
    parameter_table = collect_default_parameter_table()
    tick_trace = build_representative_tick_trace()
    all_passed = counts["fail"] == 0 and counts["partial"] == 0
    return {
        "schema_id": "apv2_bottom_loop_p0_publication_materials/v1",
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "route_split": {
            "this_suite": "AP-Core bottom-loop publication materials",
            "not_this_suite": "GL curriculum learning, DPP/Skill37 generalization, desktop-pet product shell",
        },
        "default_parameters": parameter_table,
        "representative_tick_trace": tick_trace,
        "experiments": experiments,
        "summary": {
            **counts,
            "all_passed": all_passed,
            "acceptance_policy": "pass_requires_param_basin_order_ablation_default_parameters_and_trace_materials",
        },
        "boundary": _boundary(),
    }


def _markdown_table(rows: list[tuple[str, Any]]) -> list[str]:
    lines = ["| item | value |", "|---|---|"]
    for key, value in rows:
        lines.append(f"| `{key}` | `{json.dumps(value, ensure_ascii=False)}` |")
    return lines


def write_outputs(result: dict, *, output_root: Path | None = None) -> dict:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = output_root or (ROOT / "outputs" / f"apv2_bottom_loop_p0_materials_{stamp}")
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = out_dir / "apv2_bottom_loop_p0_materials.json"
    md_path = out_dir / "apv2_bottom_loop_p0_materials_report.md"
    json_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    param = result.get("default_parameters", {})
    slot_param = dict(param.get("short_term_slot", {}) or {})
    memory_param = dict(param.get("memory", {}) or {})
    trace = dict(result.get("representative_tick_trace", {}) or {})
    lines = [
        "# APV2 Bottom-Loop P0 Publication Materials",
        "",
        f"- generated_at: `{result.get('generated_at')}`",
        "- scope: `AP-Core bottom-loop publication materials`",
        "- not_scope: `GL learning / DPP / Skill37 / desktop-pet product shell`",
        f"- all_passed: `{result.get('summary', {}).get('all_passed')}`",
        f"- pass: `{result.get('summary', {}).get('pass')}`",
        f"- partial: `{result.get('summary', {}).get('partial')}`",
        f"- fail: `{result.get('summary', {}).get('fail')}`",
        "",
        "## Experiments",
        "",
    ]
    for row in result.get("experiments", []) or []:
        lines.extend(
            [
                f"### {row.get('experiment')}",
                "",
                f"- verdict: `{row.get('verdict')}`",
                f"- design: {row.get('design')}",
                f"- boundary: `{json.dumps(row.get('boundary', {}), ensure_ascii=False)}`",
                "",
            ]
        )
        observed = dict(row.get("observed", {}) or {})
        if "pass_rate" in observed:
            lines.append(f"- pass_rate: `{observed.get('pass_rate')}` ({observed.get('pass_count')}/{observed.get('case_count')})")
            lines.append("")
        if "full_order_scores" in observed:
            lines.append(f"- full_order_scores: `{json.dumps(observed.get('full_order_scores'), ensure_ascii=False)}`")
            lines.append(f"- without_order_rows_scores: `{json.dumps(observed.get('without_order_rows_scores'), ensure_ascii=False)}`")
            lines.append(f"- margin_drop_without_order_rows: `{observed.get('margin_drop_without_order_rows')}`")
            lines.append("")

    lines.extend(
        [
            "## Default Parameters",
            "",
            "### Short-Term Slot",
            "",
            *_markdown_table(list(slot_param.items())),
            "",
            "### Memory And Bottom-Loop Policies",
            "",
            *_markdown_table(list(memory_param.items())),
            "",
            "### Residual B Recall",
            "",
            *_markdown_table(list(dict(param.get("residual_b_recall", {}) or {}).items())),
            "",
            "### Successor Lag Kernel",
            "",
            *_markdown_table(list(dict(param.get("successor_lag_kernel", {}) or {}).items())),
            "",
            "## Representative Tick Trace",
            "",
            f"- trace_source: `{trace.get('trace_source')}`",
            f"- tick_index: `{trace.get('tick_index')}`",
            f"- short_term_slot_virtual_mass: `{trace.get('short_term_slot', {}).get('virtual_mass')}`",
            f"- short_term_slot_first_labels: `{json.dumps(trace.get('short_term_slot', {}).get('first_labels', []), ensure_ascii=False)}`",
            f"- fast_residual_b_recall: `{json.dumps(trace.get('fast_system', {}).get('residual_b_recall', []), ensure_ascii=False)}`",
            f"- fast_residual_b_recall_probe: `{json.dumps(trace.get('fast_system', {}).get('residual_b_recall_probe', {}), ensure_ascii=False)}`",
            f"- fast_successor_lag_predictions: `{json.dumps(trace.get('fast_system', {}).get('successor_lag_predictions', []), ensure_ascii=False)}`",
            f"- attention_selected_labels: `{json.dumps(trace.get('attention', {}).get('selected_labels', []), ensure_ascii=False)}`",
            "",
        ]
    )
    md_path.write_text("\n".join(lines), encoding="utf-8")
    return {
        "output_dir": str(out_dir),
        "json_path": str(json_path),
        "markdown_path": str(md_path),
    }


def main() -> int:
    result = run_p0_materials_suite()
    artifacts = write_outputs(result)
    print(json.dumps({"summary": result["summary"], "artifacts": artifacts}, ensure_ascii=False, indent=2))
    return 0 if result["summary"]["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
