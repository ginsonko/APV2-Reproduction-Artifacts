from __future__ import annotations

import hashlib
import json
import sys
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from channels.rhythm.channel import RhythmChannel
from config.defaults import RhythmConfig, RuntimeConfig, ShortTermConfig, ShortTermSlotConfig
from memory.persistence import JsonlMemoryPersistence
from memory.short_term.focus_buffer import FocusBuffer
from memory.short_term.slot_packet import ShortTermSlotPacketBuilder
from memory.spacetime.transition_store import TransitionStore
from memory.store import MemoryStore


def _round4(value: float) -> float:
    return round(float(value), 4)


def _item(label: str, *, real: float = 1.0, virtual: float = 0.0, source_type: str = "external_text", family: str | None = None) -> dict:
    token = str(label).split("::")[-1]
    clean_family = family if family is not None else ("text" if str(label).startswith("text::") else "probe")
    return {
        "sa_label": str(label),
        "display_text": token,
        "family": str(clean_family),
        "source_type": str(source_type),
        "real_energy": float(real),
        "virtual_energy": float(virtual),
        "attention_gain": float(real) * 0.25 + float(virtual) * 0.1,
        "cognitive_pressure": float(real) - float(virtual),
    }


def _focus_pack(labels: list[str], *, real: float = 1.0, virtual: float = 0.0, source_type: str = "white_box_focus_probe") -> list[dict]:
    rows = []
    for index, label in enumerate(labels):
        row = _item(label, real=max(0.2, real - index * 0.06), virtual=virtual, source_type=source_type)
        row["focus_score"] = max(0.2, 1.0 - index * 0.04)
        row["anchor_meta"] = {"is_focus": True, "focus_probe_rank": index}
        rows.append(row)
    return rows


def _labels(rows: list[dict]) -> list[str]:
    return [str(row.get("sa_label", "") or "") for row in rows or [] if str(row.get("sa_label", "") or "")]


def _memory(*, persistence=None, recall_top_k: int = 4, predict_top_k: int = 4) -> MemoryStore:
    return MemoryStore(
        recall_top_k=recall_top_k,
        predict_top_k=predict_top_k,
        prediction_energy_scale=0.55,
        max_snapshots_per_kind=128,
        candidate_limit=64,
        scoring_candidate_limit=64,
        online_enabled=True,
        online_min_support_to_promote=1,
        online_per_tick_update_limit=64,
        transition_learned_weight=0.18,
        persistence=persistence,
        persistence_required=persistence is not None,
    )


def _write(memory: MemoryStore, tick: int, labels: list[str], source_text: str, *, memory_kind: str = "state") -> dict:
    return memory.write_snapshot(
        tick_index=int(tick),
        memory_kind=memory_kind,
        items=[_item(label) for label in labels],
        focus_labels=[],
        source_text=source_text,
    )


def _verdict(passed: bool, partial: bool = False) -> str:
    if passed:
        return "pass"
    if partial:
        return "partial"
    return "fail"


def _boundary() -> dict:
    return {
        "ap_core_scope_only": True,
        "gl_learning_protocol_scope": False,
        "product_shell_scope": False,
        "answer_table_lookup": False,
        "keyword_hard_gate": False,
        "regex_route": False,
        "student_side_llm": False,
        "hidden_solver": False,
        "full_sentence_macro": False,
    }


def run_longrun_interruption_recovery() -> dict:
    short_config = ShortTermConfig()
    slot_config = ShortTermSlotConfig()
    focus = FocusBuffer(
        focus_history_limit=short_config.focus_history_limit,
        recency_decay=short_config.recency_decay,
        synthetic_query_weight=short_config.synthetic_query_weight,
        replay_decay=short_config.replay_decay,
        replay_query_weight=short_config.replay_query_weight,
        max_replay_items=short_config.max_replay_items,
        episode_break_overlap=short_config.episode_break_overlap,
    )
    slot = ShortTermSlotPacketBuilder(**asdict(slot_config))
    memory = _memory(recall_top_k=4, predict_top_k=4)
    _write(memory, 1, ["text::river", "text::stone", "text::bright"], "river_story")
    _write(memory, 2, ["text::flows", "text::quiet"], "river_successor")
    _write(memory, 3, ["text::alarm", "text::red", "text::loud"], "alarm_distractor")

    packs = [
        _focus_pack(["text::river", "text::stone", "focus::calm"]),
        _focus_pack(["text::river", "text::stone", "text::bright"]),
        _focus_pack(["text::river", "text::stone", "text::bright"]),
        _focus_pack(["text::alarm", "text::red", "text::loud"], real=1.4),
        _focus_pack(["text::alarm", "text::red", "text::loud"], real=1.3),
        _focus_pack(["text::river", "text::stone", "text::bright"]),
        _focus_pack(["text::river", "text::stone", "text::bright"]),
    ]

    slot_traces = []
    last_trace: dict[str, Any] = {}
    for tick, pack in enumerate(packs):
        focus.push(pack, tick_index=tick)
        trace = focus.trace(tick_index=tick)
        last_trace = trace
        slot_trace = slot.build(
            tick_index=tick,
            focus_items=pack,
            focus_continuation_trace=trace,
            short_term_memory_trace={"last_recall": {"available": tick > 0, "score": 0.42 if tick > 0 else 0.0}},
            rhythm_trace={},
            runtime_load_trace={"channels": {"load_ratio": 0.05}},
        )
        slot_traces.append(slot_trace)
        memory.write_snapshot(
            tick_index=10 + tick,
            memory_kind="short_term_slot",
            items=list(slot_trace.get("items", []) or []),
            focus_labels=list(slot_trace.get("focus_labels", []) or []),
            source_text=f"slot_tick_{tick}",
        )

    dynamics = focus.continuity_dynamics(tick_index=len(packs) - 1)
    final_slot = slot_traces[-1]
    final_slot_labels = _labels(list(final_slot.get("items", []) or []))
    final_slot_mass = sum(float(row.get("virtual_energy", 0.0) or 0.0) for row in final_slot.get("items", []) or [])
    readback = last_trace.get("recent_thought_readback", {})
    replay_candidates = last_trace.get("replay_candidates", [])
    state_bn = memory.recall_residual([_item("text::river"), _item("text::stone"), _item("text::bright")], memory_kind="state", top_k=3)
    state_winners = [row.get("source_text") for row in state_bn]
    slot_bn = memory.recall_residual(list(final_slot.get("items", []) or []), memory_kind="short_term_slot", top_k=3)
    slot_winners = [row.get("source_text") for row in slot_bn]
    interruptions = list(dynamics.get("recent_interruptions", []) or [])
    resumptions = list(dynamics.get("recent_resumptions", []) or [])
    passed = bool(
        interruptions
        and resumptions
        and final_slot_mass > 0.0
        and any("text::river" in label for label in final_slot_labels)
        and "river_story" in state_winners
        and slot_winners
        and readback.get("available") is True
    )
    return {
        "experiment": "LongRun-InterruptionRecovery-1",
        "verdict": _verdict(passed, bool(interruptions and final_slot_mass > 0.0)),
        "design": "White-box AP-Core focus packets are interrupted and resumed; short-term-slot and recall traces should recover the earlier narrative.",
        "observed": {
            "recent_interruptions": interruptions,
            "recent_resumptions": resumptions,
            "episode_summaries": dynamics.get("episode_summaries", []),
            "final_slot_virtual_mass": _round4(final_slot_mass),
            "final_slot_labels": final_slot_labels[:24],
            "readback": {
                "available": readback.get("available"),
                "labels": readback.get("labels", [])[:12],
                "strength": readback.get("strength"),
                "mean_continuity": readback.get("mean_continuity"),
            },
            "replay_candidates": replay_candidates[:3],
            "state_recall_winners": state_winners,
            "slot_recall_winners": slot_winners,
        },
        "boundary": {
            **_boundary(),
            "white_box_focus_probe": True,
            "open_dialogue_learning_claim": False,
        },
    }


def run_rhythm_successor_replay() -> dict:
    rhythm_config = RhythmConfig()
    rhythm = RhythmChannel(**asdict(rhythm_config))
    slot = ShortTermSlotPacketBuilder(**asdict(ShortTermSlotConfig()))
    rhythm_trace = {"channels": {}, "items": [], "family": None}
    hit_ticks = [0, 4, 8, 12]
    for tick in hit_ticks:
        rhythm.observe(tick_index=tick, focus_items=_focus_pack(["text::beat"], real=1.0))
        rhythm_trace = rhythm.derive(tick_index=tick)
    phase_traces = []
    for tick in [13, 14, 15, 16]:
        rhythm_trace = rhythm.derive(tick_index=tick)
        phase_traces.append(
            {
                "tick": tick,
                "channels": dict(rhythm_trace.get("channels", {}) or {}),
                "items": _labels(list(rhythm_trace.get("items", []) or [])),
            }
        )
    slot_trace = slot.build(
        tick_index=16,
        focus_items=_focus_pack(["text::beat", "text::next_beat"], real=1.0),
        focus_continuation_trace={
            "continuation_strength": 1.0,
            "recent_entries": [{"continuity_score": 1.0}, {"continuity_score": 1.0}],
        },
        short_term_memory_trace={"last_recall": {"available": True, "score": 0.5}},
        rhythm_trace=rhythm_trace,
        runtime_load_trace={"channels": {"load_ratio": 0.0}},
    )

    store = TransitionStore()
    store.register_snapshot({"memory_id": "m0", "memory_kind": "state", "tick_index": 0, "items": []})
    for lag, label in [(1, "text::next_beat"), (2, "text::second_tail"), (4, "text::period_tail")]:
        store.register_snapshot(
            {
                "memory_id": f"m{lag}",
                "memory_kind": "state",
                "tick_index": lag,
                "prediction_payload_items": [_item(label, real=1.0)],
            }
        )
        store.link_successor("state", "m0", f"m{lag}")
    shaped = store.successors("state", "m0", top_k=3, prediction_energy_scale=1.0, lag_shaping_enabled=True)
    flat = store.successors("state", "m0", top_k=3, prediction_energy_scale=1.0, lag_shaping_enabled=False)
    kernels = [float(row.get("successor_lag_kernel", 0.0) or 0.0) for row in shaped]
    flat_kernels = [float(row.get("successor_lag_kernel", 0.0) or 0.0) for row in flat]
    slot_labels = _labels(list(slot_trace.get("items", []) or []))
    phase_item_seen = any("rhythmfelt::phase_expectation" in row.get("items", []) for row in phase_traces)
    passed = bool(
        phase_item_seen
        and "short_term_slot::rhythm" in slot_labels
        and len(kernels) == 3
        and kernels[0] == 1.0
        and kernels[0] > kernels[1] > kernels[2]
        and flat_kernels == [1.0, 1.0, 1.0]
    )
    return {
        "experiment": "RhythmSuccessor-Replay-1",
        "verdict": _verdict(passed, phase_item_seen and "short_term_slot::rhythm" in slot_labels),
        "design": "Periodic focus pulses should create phase expectation, slot rhythm rows, and next-tick successor peak with a decaying tail.",
        "observed": {
            "hit_ticks": hit_ticks,
            "phase_traces": phase_traces,
            "slot_labels": slot_labels,
            "slot_summary": slot_trace.get("slot_summary", {}),
            "successor_shaped": [
                {
                    "lag": row.get("successor_lag_ticks"),
                    "kernel": row.get("successor_lag_kernel"),
                    "predicted_labels": _labels(list(row.get("predicted_items", []) or [])),
                }
                for row in shaped
            ],
            "flat_kernels": flat_kernels,
        },
        "boundary": {
            **_boundary(),
            "music_performance_claim": False,
            "rhythm_replay_dynamics_probe": True,
        },
    }


def run_persistence_backend_reload(output_dir: Path) -> dict:
    persistence_path = output_dir / "jsonl_persistence" / "apv2_memory.jsonl"
    writer_persistence = JsonlMemoryPersistence(persistence_path)
    writer = _memory(persistence=writer_persistence)
    cue = _write(writer, 1, ["text::cue", "text::context"], "cue context")
    outcome = _write(writer, 2, ["text::outcome"], "outcome")
    slot_snapshot = writer.write_snapshot(
        tick_index=3,
        memory_kind="short_term_slot",
        items=[
            _item("short_term_slot::summary", real=0.04, virtual=0.22, source_type="short_term_slot", family="short_term_slot"),
            _item("short_term_slot::item::text::cue", real=0.06, virtual=0.14, source_type="short_term_slot", family="short_term_slot"),
            _item("short_term_slot::continuity", real=0.0, virtual=0.18, source_type="short_term_slot", family="short_term_slot"),
        ],
        focus_labels=[],
        source_text="slot cue context",
    )
    reader_persistence = JsonlMemoryPersistence(persistence_path)
    reader = _memory()
    reader._persistence = reader_persistence
    warm = reader.warm_load_from_persistence(limit_per_kind=8, process_indexes=True)
    bn = reader.recall([_item("text::cue"), _item("text::context")], memory_kind="state", top_k=2)
    cn = reader.successors(bn[0]["memory_id"], memory_kind="state", top_k=2, source_b_row=bn[0]) if bn else []
    slot_bn = reader.recall(
        [_item("short_term_slot::item::text::cue", real=0.0, virtual=0.5, source_type="short_term_slot", family="short_term_slot")],
        memory_kind="short_term_slot",
        top_k=2,
    )
    predicted_labels = [item.get("sa_label") for row in cn for item in row.get("predicted_items", [])]
    digest = _sha256_file(persistence_path)
    passed = bool(
        persistence_path.exists()
        and persistence_path.stat().st_size > 0
        and len(digest) == 64
        and warm.get("loaded", 0) >= 3
        and bn
        and "text::outcome" in predicted_labels
        and slot_bn
    )
    return {
        "experiment": "PersistenceBackend-Reload-1",
        "verdict": _verdict(passed, bool(warm.get("loaded", 0) >= 3 and bn)),
        "design": "A real local JSONL persistence boundary should support cold MemoryStore reload and restore state, successor, and slot recall.",
        "observed": {
            "persistence_path": str(persistence_path),
            "exists": persistence_path.exists(),
            "bytes": persistence_path.stat().st_size if persistence_path.exists() else 0,
            "sha256": digest,
            "writer_summary": writer.persistence_summary(),
            "reader_summary": reader.persistence_summary(),
            "warm_load": warm,
            "written_memory_ids": [cue.get("memory_id"), outcome.get("memory_id"), slot_snapshot.get("memory_id")],
            "bn_source_texts": [row.get("source_text") for row in bn],
            "predicted_labels": predicted_labels,
            "slot_bn_source_texts": [row.get("source_text") for row in slot_bn],
        },
        "boundary": {
            **_boundary(),
            "local_file_persistence_boundary": True,
            "postgres_production_claim": False,
        },
    }


def _sha256_file(path: Path) -> str:
    if not path.exists():
        return ""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _manifest_entry(path: Path, *, base: Path = ROOT) -> dict:
    return {
        "path": str(path),
        "relative_path": str(path.relative_to(base)) if path.is_relative_to(base) else str(path),
        "exists": path.exists(),
        "bytes": int(path.stat().st_size) if path.exists() else 0,
        "sha256": _sha256_file(path),
    }


def write_static_figures(output_dir: Path) -> dict:
    figures_dir = output_dir / "figures"
    figures_dir.mkdir(parents=True, exist_ok=True)
    figures = {
        "apv2_runtime_loop.mmd": """flowchart LR
  input[\"Sensors / state input\"] --> pool[\"State pool: all-SA dual energy field\"]
  pool --> fast[\"Fast B/C recall\"]
  fast --> attention[\"Attention selection\"]
  attention --> slot[\"Short-term narrative slot\"] 
  slot --> pool
  attention --> slow[\"Slow recall / readback\"]
  slow --> action[\"Action competition\"]
  action --> feedback[\"Action feedback / reward-punishment\"]
  feedback --> pool
""",
        "state_pool_vs_short_term_slot.mmd": """flowchart TB
  pool[\"State pool: unordered bounded energy field\"] --> fast[\"fast matching over SA energy\"]
  focus[\"tick attention packet\"] --> slot[\"short-term slot: ordered narrative packet\"]
  slot --> virtual[\"virtual-energy inner-sense injection\"] --> pool
  slot --> slow[\"slow query with order and continuity bias\"]
""",
        "residual_b_recall_absorption.mmd": """flowchart LR
  q0[\"query SA mixture\"] --> b1[\"round 1 winner B1\"]
  b1 --> r1[\"matched SA mass absorbed\"] --> q1[\"residual query\"]
  q1 --> b2[\"round 2 winner B2\"]
  b2 --> r2[\"remaining mass becomes salient\"] --> q2[\"next residual\"]
""",
        "successor_lag_rhythm_replay.mmd": """flowchart LR
  beat[\"periodic focus pulses\"] --> rhythm[\"rhythmfelt phase expectation\"]
  rhythm --> slot[\"short_term_slot::rhythm\"]
  cue[\"current B object\"] --> c1[\"lag 1 peak\"]
  cue --> c2[\"lag 2 sharp drop\"]
  cue --> c3[\"lag tail\"]
""",
        "evidence_layer_split.mmd": """flowchart TB
  ap[\"AP-Core runtime evidence\"] --> paper[\"APV2 paper core claims\"]
  gl[\"GL curriculum and skill packages\"] --> glpaper[\"learning protocol evidence\"]
  shell[\"Product shell / desktop pet\"] --> demo[\"integration and safety demo\"]
  gl -.not AP-Core proof.-> paper
  shell -.not AP-Core proof.-> paper
""",
    }
    written = []
    for name, content in figures.items():
        path = figures_dir / name
        path.write_text(content.strip() + "\n", encoding="utf-8")
        written.append(_manifest_entry(path))
    return {
        "schema_id": "apv2_static_figures/v1",
        "figure_count": len(written),
        "figures": written,
    }


def run_artifact_freeze(output_dir: Path, extra_paths: list[Path] | None = None) -> dict:
    paths = [
        ROOT / "docs" / "Design_APV2_BottomLoopP0Materials_20260610.md",
        ROOT / "docs" / "Design_APV2_P1HardeningMaterials_20260610.md",
        ROOT / "experiments" / "apv2_bottom_loop_p0_materials.py",
        ROOT / "experiments" / "apv2_p1_hardening_materials.py",
        ROOT / "tests" / "test_apv2_bottom_loop_p0_materials.py",
        ROOT / "tests" / "test_apv2_p1_hardening_materials.py",
        ROOT / "memory" / "persistence" / "jsonl_store.py",
    ]
    if extra_paths:
        paths.extend(extra_paths)
    entries = [_manifest_entry(path) for path in paths]
    passed = bool(entries and all(row.get("exists") and int(row.get("bytes", 0) or 0) > 0 and len(str(row.get("sha256", ""))) == 64 for row in entries))
    manifest = {
        "schema_id": "apv2_p1_artifact_freeze_manifest/v1",
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "status": "local_pre_public_freeze",
        "entry_count": len(entries),
        "entries": entries,
        "validation_passed": passed,
        "boundary": _boundary(),
    }
    manifest_path = output_dir / "artifact_freeze_manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return {
        "experiment": "ArtifactFreeze-1",
        "verdict": _verdict(passed),
        "design": "Local pre-public artifact freeze records exact files, sizes, and SHA-256 hashes for paper-material traceability.",
        "observed": {
            "manifest_path": str(manifest_path),
            "entry_count": len(entries),
            "entries": entries,
            "validation_passed": passed,
        },
        "boundary": {
            **_boundary(),
            "public_doi_claim": False,
            "local_pre_public_freeze": True,
        },
    }


def run_p1_hardening_suite(*, output_dir: Path | None = None) -> dict:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = output_dir or (ROOT / "outputs" / f"apv2_p1_hardening_materials_{stamp}")
    out_dir.mkdir(parents=True, exist_ok=True)
    figures = write_static_figures(out_dir)
    experiments = [
        run_longrun_interruption_recovery(),
        run_rhythm_successor_replay(),
        run_persistence_backend_reload(out_dir),
    ]
    freeze = run_artifact_freeze(
        out_dir,
        extra_paths=[Path(row["path"]) for row in figures.get("figures", [])],
    )
    experiments.append(freeze)
    counts = {
        "pass": sum(1 for row in experiments if row.get("verdict") == "pass"),
        "partial": sum(1 for row in experiments if row.get("verdict") == "partial"),
        "fail": sum(1 for row in experiments if row.get("verdict") == "fail"),
    }
    return {
        "schema_id": "apv2_p1_hardening_materials/v1",
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "output_dir": str(out_dir),
        "route_split": {
            "this_suite": "AP-Core runtime hardening and publication materials",
            "not_this_suite": "GL learning protocol, DPP/Skill37 open dialogue learning, desktop-pet product shell",
        },
        "figures": figures,
        "experiments": experiments,
        "summary": {
            **counts,
            "all_passed": counts["fail"] == 0 and counts["partial"] == 0,
            "acceptance_policy": "pass_requires_longrun_rhythm_persistence_artifact_freeze_and_figures",
        },
        "boundary": _boundary(),
    }


def write_outputs(result: dict, *, output_dir: Path | None = None) -> dict:
    out_dir = output_dir or Path(result.get("output_dir") or ROOT / "outputs" / "apv2_p1_hardening_materials")
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = out_dir / "apv2_p1_hardening_materials.json"
    md_path = out_dir / "apv2_p1_hardening_materials_report.md"
    result = dict(result)
    result["artifacts"] = {
        "json_path": str(json_path),
        "markdown_path": str(md_path),
        "output_dir": str(out_dir),
    }
    json_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    lines = [
        "# APV2 P1 Hardening Materials",
        "",
        f"- generated_at: `{result.get('generated_at')}`",
        "- scope: `AP-Core runtime hardening and publication materials`",
        "- not_scope: `GL learning / DPP / Skill37 / desktop-pet product shell`",
        f"- all_passed: `{result.get('summary', {}).get('all_passed')}`",
        f"- pass: `{result.get('summary', {}).get('pass')}`",
        f"- partial: `{result.get('summary', {}).get('partial')}`",
        f"- fail: `{result.get('summary', {}).get('fail')}`",
        "",
        "## Figures",
        "",
        f"- figure_count: `{result.get('figures', {}).get('figure_count')}`",
    ]
    for figure in result.get("figures", {}).get("figures", []) or []:
        lines.append(f"- `{figure.get('relative_path')}` sha256=`{figure.get('sha256')}`")
    lines.extend(["", "## Experiments", ""])
    for row in result.get("experiments", []) or []:
        lines.extend(
            [
                f"### {row.get('experiment')}",
                "",
                f"- verdict: `{row.get('verdict')}`",
                f"- design: {row.get('design')}",
                f"- boundary: `{json.dumps(row.get('boundary', {}), ensure_ascii=False)}`",
                "",
            ]
        )
        observed = dict(row.get("observed", {}) or {})
        if row.get("experiment") == "LongRun-InterruptionRecovery-1":
            lines.append(f"- interruptions: `{len(observed.get('recent_interruptions', []) or [])}`")
            lines.append(f"- resumptions: `{len(observed.get('recent_resumptions', []) or [])}`")
            lines.append(f"- final_slot_virtual_mass: `{observed.get('final_slot_virtual_mass')}`")
            lines.append(f"- state_recall_winners: `{json.dumps(observed.get('state_recall_winners', []), ensure_ascii=False)}`")
            lines.append("")
        if row.get("experiment") == "RhythmSuccessor-Replay-1":
            lines.append(f"- phase_traces: `{json.dumps(observed.get('phase_traces', []), ensure_ascii=False)}`")
            lines.append(f"- successor_shaped: `{json.dumps(observed.get('successor_shaped', []), ensure_ascii=False)}`")
            lines.append("")
        if row.get("experiment") == "PersistenceBackend-Reload-1":
            lines.append(f"- persistence_path: `{observed.get('persistence_path')}`")
            lines.append(f"- sha256: `{observed.get('sha256')}`")
            lines.append(f"- warm_load: `{json.dumps(observed.get('warm_load', {}), ensure_ascii=False)}`")
            lines.append("")
        if row.get("experiment") == "ArtifactFreeze-1":
            lines.append(f"- manifest_path: `{observed.get('manifest_path')}`")
            lines.append(f"- entry_count: `{observed.get('entry_count')}`")
            lines.append("")
    md_path.write_text("\n".join(lines), encoding="utf-8")
    return {
        "output_dir": str(out_dir),
        "json_path": str(json_path),
        "markdown_path": str(md_path),
    }


def main() -> int:
    result = run_p1_hardening_suite()
    artifacts = write_outputs(result)
    print(json.dumps({"summary": result["summary"], "artifacts": artifacts}, ensure_ascii=False, indent=2))
    return 0 if result["summary"]["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

