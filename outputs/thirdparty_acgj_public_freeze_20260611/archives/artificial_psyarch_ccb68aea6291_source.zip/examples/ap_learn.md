# ap_learn examples

`ap_learn` 是给外部 agent / 脚本用的学习入口。它读一个 `AgentLearningRequest` JSON，执行课程或 probe，然后输出 lesson bundle；如果传了 `--agent-out`，还会保存技能包。

训练：

```bash
cargo run --bin ap_learn -- \
  --input examples/ap_learn_basic_math_train.json \
  --domain generated_math \
  --mode learn
```

默认输出：

```text
.ap/exports/bundles/ap-learning-bundle.json
.ap/skills/external/generated_math-current.apbin
```

加载技能包后 probe：

```bash
cargo run --bin ap_learn -- \
  --input examples/ap_learn_basic_math_probe.json \
  --domain generated_math \
  --agent-in .ap/skills/external/generated_math-current.apbin \
  --mode probe
```

重要字段：

- `intent`: `Learn` 会训练，`Probe` 只做 teacher-off 探测。
- `material`: 可以是 `Stimulus` 或 `TaskSet`。需要自动评分时，任务要带 `expected_action`。
- `teacher_mode`: 训练通常用 `TeacherOn` 或 `FeedbackOnly`；probe 必须用 `TeacherOff`。
- `feedback_policy`: 现在本地闭环常用 `AutomaticExaminer`。
- `holdout`: 用来声明 teacher-off 验证策略。
- `desired_outputs`: 外部 agent 期望拿到的输出通道，比如 `Text`、`Trace`、`SkillPackage`。

边界：

- `TeacherOff` 不允许写记忆，适合验证泛化。
- 当前数学泛化只覆盖简单整数表达式，并且表达式里的运算符必须在奖励样本中学过。
- 这不是 LLM API 包装层；外部 LLM 更适合作为课程生成器、评分器或材料整理器。
