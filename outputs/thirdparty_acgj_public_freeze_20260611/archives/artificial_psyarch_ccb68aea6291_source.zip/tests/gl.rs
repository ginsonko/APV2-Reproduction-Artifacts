use artificial_psyarch::gl::{
    GlExecutionResult, GlOrchestrator, GlPermission, GlRegistryEntry, GlRequest, GlRequestKind,
    GlStepOutcome, PermissionSet, SignedSkillPackage, SkillPackagePolicy, SkillPolicyDecision,
    SkillPolicyError, default_interactive_entries,
};
use artificial_psyarch::learning::{ArtifactKind, ArtifactRef, MediaOutput};
use artificial_psyarch::runtime::APV21Runtime;
use artificial_psyarch::skill_registry::{
    EvidenceGate, SkillBoundary, SkillContext, SkillEvidence, SkillManifest,
};

#[test]
fn gl_orchestrator_denies_trace_export_without_permission() {
    let gl = GlOrchestrator {
        permissions: PermissionSet::new([GlPermission::ProbeRuntime]),
        ..GlOrchestrator::default()
    };
    let plan = gl.plan(GlRequest {
        request_id: "gl-deny".to_owned(),
        kind: GlRequestKind::ExportTrace,
        text: "export".to_owned(),
        desired_outputs: vec![MediaOutput::Trace],
        artifacts: Vec::new(),
    });
    let result = gl.execute(&mut APV21Runtime::default(), plan);

    assert!(matches!(result.outcomes[0], GlStepOutcome::Denied(_)));
}

#[test]
fn gl_orchestrator_plans_runtime_probe_and_media_render() {
    let gl = GlOrchestrator::default();
    let plan = gl.plan(GlRequest {
        request_id: "gl-media".to_owned(),
        kind: GlRequestKind::Probe,
        text: "red circle".to_owned(),
        desired_outputs: vec![MediaOutput::Text, MediaOutput::Image],
        artifacts: vec![ArtifactRef::new(
            "img-0",
            ArtifactKind::Image,
            "file:///tmp/result.png",
        )],
    });
    let result = gl.execute(&mut APV21Runtime::default(), plan);

    assert_has_runtime_tick(&result);
    assert!(result.message.channels.contains(&MediaOutput::Trace));
    assert!(result.message.channels.contains(&MediaOutput::Image));
    assert_eq!(result.message.artifacts[0].artifact_id, "img-0");
}

#[test]
fn gl_tool_translation_uses_registered_tool_names() {
    let gl = GlOrchestrator::default();

    let plan = gl.translate_tool_text("tool-plan".to_owned(), "export trace".to_owned());

    assert_eq!(plan.request_id, "tool-plan");
    assert!(plan.requires_confirmation);
    assert_eq!(plan.steps.len(), 1);
}

#[test]
fn gl_registry_default_entries_are_plugin_descriptors() {
    let names: Vec<_> = default_interactive_entries()
        .into_iter()
        .map(|entry| match entry {
            GlRegistryEntry::Tool(tool) => tool.name,
            GlRegistryEntry::Action(action) => action.name,
        })
        .collect();

    assert_eq!(
        names,
        vec![
            "export_trace",
            "render_media",
            "ap_runtime_tick",
            "ap_train_feedback"
        ]
    );
}

#[test]
fn skill_policy_requires_signature_permission_evidence_and_boundary() {
    let manifest = verified_manifest();
    let package = SignedSkillPackage::sign(manifest.clone(), "local-signer");
    let policy = SkillPackagePolicy::new("local-signer", EvidenceGate::default());
    let context = SkillContext::new("demo", 4);
    let permissions = PermissionSet::new([GlPermission::ImportSkill]);

    assert_eq!(
        policy.review_import(&package, &context, &permissions),
        Ok(SkillPolicyDecision::Allowed)
    );

    let denied = policy
        .review_import(&package, &context, &PermissionSet::new([]))
        .unwrap();
    assert!(matches!(denied, SkillPolicyDecision::Denied { .. }));

    let forged = SignedSkillPackage {
        manifest,
        signature: "bad".to_owned(),
    };
    assert_eq!(
        policy.review_import(&forged, &context, &permissions),
        Err(SkillPolicyError::InvalidSignature)
    );
}

fn assert_has_runtime_tick(result: &GlExecutionResult) {
    assert!(
        result
            .outcomes
            .iter()
            .any(|outcome| matches!(outcome, GlStepOutcome::RuntimeTick(_)))
    );
}

fn verified_manifest() -> SkillManifest {
    SkillManifest::new(
        "skill.demo",
        "demo",
        SkillEvidence {
            train_accuracy: 1.0,
            holdout_accuracy: 1.0,
            sample_count: 4,
        },
        SkillBoundary::new("demo", 1, 8),
    )
}
