use artificial_psyarch::ap::TeacherMode;
use artificial_psyarch::learning::{
    FeedbackPolicy, LearnableAgent, LearningInput, LearningMaterial, LearningSource, LessonTask,
    MaterialStimulus, ScaffoldPhaseId, ScaffoldRunner,
};

#[test]
fn scaffold_protocol_fades_to_teacher_off_and_cold_retest() {
    let lesson = LearningInput::new(
        LearningSource::User,
        LearningMaterial::TaskSet(vec![
            LessonTask::new("shape-0", MaterialStimulus::Text("red circle".to_owned()))
                .with_expected_action("ClassifyRedCircle"),
            LessonTask::new("shape-1", MaterialStimulus::Text("blue square".to_owned()))
                .with_expected_action("ClassifyBlueSquare"),
        ]),
        "classify shapes",
        TeacherMode::FeedbackOnly,
        FeedbackPolicy::AutomaticExaminer,
    )
    .into_lesson("shape-scaffold");
    let mut agent = LearnableAgent::new("scaffold-protocol");

    let report = ScaffoldRunner::new("skill.shape.classifier").run(&mut agent, &lesson);

    assert!(report.teacher_off_clean());
    assert_eq!(report.teacher_off_accuracy(), 1.0);
    assert_eq!(report.cold_retest_accuracy(), 1.0);
    assert!(
        report
            .phases
            .iter()
            .find(|phase| phase.phase_id == ScaffoldPhaseId::TeacherOff)
            .unwrap()
            .attempts
            .iter()
            .all(|attempt| !attempt.memory_write_enabled)
    );
}
