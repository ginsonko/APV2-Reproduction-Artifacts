use artificial_psyarch::ap::{Feedback, TeacherMode};
use artificial_psyarch::count_loop::{
    CountLoopLearner, CountLoopWorld, DeltaSign, run_count_phase, train_count_loop,
};

#[test]
fn count_loop_learns_add_remove_and_transfers_to_unseen_counts() {
    let world = CountLoopWorld::canonical();
    let mut learner = CountLoopLearner::default();

    let pretest = run_count_phase(
        world.holdout_states(),
        &world,
        &mut learner,
        TeacherMode::TeacherOff,
    );
    assert!(pretest.accuracy < 1.0);
    assert_eq!(learner.memory_rows(), 0);

    let train = train_count_loop(&world, &mut learner, 4);
    assert_eq!(train.last().unwrap().accuracy, 1.0);
    assert!(learner.memory_rows() > 0);

    let memory_before_holdout = learner.memory_rows();
    let holdout = run_count_phase(
        world.holdout_states(),
        &world,
        &mut learner,
        TeacherMode::TeacherOff,
    );

    assert_eq!(holdout.accuracy, 1.0);
    assert_eq!(learner.memory_rows(), memory_before_holdout);
    assert!(holdout.traces.iter().all(|trace| {
        !trace.feedback_visible_to_learner
            && !trace.memory_write_enabled
            && trace.examiner_private_scoring
            && !trace.answer_visible_to_learner
    }));
}

#[test]
fn count_loop_uses_delta_sign_instead_of_state_id_lookup() {
    let world = CountLoopWorld::canonical();
    let mut learner = CountLoopLearner::default();
    train_count_loop(&world, &mut learner, 4);

    for state in world.holdout_states() {
        let selected = learner.select_action(state);
        assert_eq!(world.commit_action(state, selected), Feedback::Reward);
        assert!(matches!(
            state.delta_sign(),
            DeltaSign::NeedMore | DeltaSign::NeedFewer
        ));
    }
}
