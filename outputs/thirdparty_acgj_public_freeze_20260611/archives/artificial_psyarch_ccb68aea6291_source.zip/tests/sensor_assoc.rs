use artificial_psyarch::ap::{Feedback, TeacherMode};
use artificial_psyarch::sensor_assoc::{
    SensorAssocLearner, SensorAssocWorld, SensorLabel, run_sensor_assoc_phase, train_sensor_assoc,
};

#[test]
fn sensor_assoc_learns_raw_byte_label_associations() {
    let world = SensorAssocWorld::canonical();
    let mut learner = SensorAssocLearner::default();

    let pretest = run_sensor_assoc_phase(
        world.holdout_samples(),
        &world,
        &mut learner,
        TeacherMode::TeacherOff,
    );
    assert!(pretest.accuracy < 1.0);
    assert_eq!(learner.memory_rows(), 0);

    let train = train_sensor_assoc(&world, &mut learner, 4);
    assert_eq!(train.last().unwrap().accuracy, 1.0);
    assert!(learner.prototype_count(SensorLabel::Alpha) > 0);
    assert!(learner.prototype_count(SensorLabel::Beta) > 0);
    assert!(learner.prototype_count(SensorLabel::Gamma) > 0);

    let memory_before_holdout = learner.memory_rows();
    let holdout = run_sensor_assoc_phase(
        world.holdout_samples(),
        &world,
        &mut learner,
        TeacherMode::TeacherOff,
    );

    assert_eq!(holdout.accuracy, 1.0);
    assert_eq!(learner.memory_rows(), memory_before_holdout);
    assert!(holdout.traces.iter().all(|trace| {
        !trace.feedback_visible_to_learner
            && !trace.memory_write_enabled
            && trace.examiner_private_scoring
            && !trace.answer_visible_to_learner
    }));
}

#[test]
fn sensor_assoc_recalls_from_bytes_not_sample_ids() {
    let world = SensorAssocWorld::canonical();
    let mut learner = SensorAssocLearner::default();
    train_sensor_assoc(&world, &mut learner, 4);

    for sample in world.holdout_samples() {
        let selected = learner.select_label(sample);
        assert_eq!(world.commit_label(sample, selected), Feedback::Reward);
        assert!(
            !world
                .train_samples()
                .iter()
                .any(|train| train.id == sample.id)
        );
    }
}
