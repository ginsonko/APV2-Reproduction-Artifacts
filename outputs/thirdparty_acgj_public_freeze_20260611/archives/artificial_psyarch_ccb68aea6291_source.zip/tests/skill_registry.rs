use artificial_psyarch::ap::TeacherMode;
use artificial_psyarch::repeat_map::{RepeatMapLearner, RepeatMapWorld, run_phase, train_repeats};
use artificial_psyarch::skill_registry::{
    EvidenceGate, SkillBoundary, SkillContext, SkillDependency, SkillEvidence, SkillManifest,
    SkillRegistry, SkillRegistryError,
};

#[test]
fn skill_registry_gates_reload_by_evidence_and_boundary() {
    let world = RepeatMapWorld::new("alpha", 6101, 12);
    let mut learner = RepeatMapLearner::default();
    train_repeats(&world, &mut learner, 4);
    let holdout = run_phase(&world, &mut learner, TeacherMode::TeacherOff);

    let package = learner.export_skill_package("repeat-map-alpha");
    let manifest = package.manifest(
        "repeat_map",
        SkillEvidence {
            train_accuracy: 1.0,
            holdout_accuracy: holdout.accuracy,
            sample_count: learner.memory_len(),
        },
        SkillBoundary::new("alpha", 12, 12),
    );

    let mut registry = SkillRegistry::default();
    registry.register(manifest).unwrap();

    assert_eq!(registry.len(), 1);
    assert!(
        registry
            .can_reload(
                "repeat-map-alpha",
                &SkillContext::new("alpha", 12),
                EvidenceGate::default()
            )
            .is_ok()
    );
    assert_eq!(
        registry.can_reload(
            "repeat-map-alpha",
            &SkillContext::new("beta", 12),
            EvidenceGate::default()
        ),
        Err(SkillRegistryError::BoundaryMismatch(
            "repeat-map-alpha".to_owned()
        ))
    );
}

#[test]
fn registry_rejects_missing_required_dependencies() {
    let mut registry = SkillRegistry::default();
    let manifest = SkillManifest::new(
        "dependent",
        "test",
        SkillEvidence {
            train_accuracy: 1.0,
            holdout_accuracy: 1.0,
            sample_count: 8,
        },
        SkillBoundary::new("alpha", 1, 16),
    )
    .with_dependency(SkillDependency::required("base"));

    assert_eq!(
        registry.register(manifest),
        Err(SkillRegistryError::MissingRequiredDependencies {
            skill_id: "dependent".to_owned(),
            missing: vec!["base".to_owned()],
        })
    );
}

#[test]
fn reloadable_returns_only_skills_that_pass_gate() {
    let mut registry = SkillRegistry::default();
    registry
        .register(SkillManifest::new(
            "strong",
            "test",
            SkillEvidence {
                train_accuracy: 1.0,
                holdout_accuracy: 1.0,
                sample_count: 10,
            },
            SkillBoundary::new("alpha", 1, 16),
        ))
        .unwrap();
    registry
        .register(SkillManifest::new(
            "weak",
            "test",
            SkillEvidence {
                train_accuracy: 1.0,
                holdout_accuracy: 0.5,
                sample_count: 10,
            },
            SkillBoundary::new("alpha", 1, 16),
        ))
        .unwrap();

    let reloadable = registry.reloadable(&SkillContext::new("alpha", 12), EvidenceGate::default());
    let ids: Vec<_> = reloadable
        .iter()
        .map(|manifest| manifest.skill_id.as_str())
        .collect();

    assert_eq!(ids, vec!["strong"]);
}
