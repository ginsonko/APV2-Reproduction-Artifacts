use artificial_psyarch::ap::TeacherMode;
use artificial_psyarch::feature_combo::{
    FeatureComboLearner, FeatureComboWorld, run_combo_phase, train_feature_combo,
};

#[test]
fn feature_contribution_learning_generalizes_to_unseen_combinations() {
    let world = FeatureComboWorld::canonical();
    let mut learner = FeatureComboLearner::default();

    let pretest = run_combo_phase(
        world.holdout_states(),
        &world,
        &mut learner,
        TeacherMode::TeacherOff,
    );
    assert!(pretest.accuracy < 1.0);
    assert_eq!(learner.memory_rows(), 0);

    let train = train_feature_combo(&world, &mut learner, 6);
    assert_eq!(train.last().unwrap().accuracy, 1.0);
    assert!(learner.memory_rows() > 0);

    let memory_before_holdout = learner.memory_rows();
    let holdout = run_combo_phase(
        world.holdout_states(),
        &world,
        &mut learner,
        TeacherMode::TeacherOff,
    );

    assert_eq!(holdout.accuracy, 1.0);
    assert_eq!(learner.memory_rows(), memory_before_holdout);
    assert!(holdout.traces.iter().all(|trace| {
        !trace.feedback_visible_to_learner
            && !trace.memory_write_enabled
            && trace.examiner_private_scoring
            && !trace.answer_visible_to_learner
    }));
}

#[test]
fn feature_combo_does_not_need_state_id_lookup_for_holdout() {
    let world = FeatureComboWorld::canonical();
    let mut learner = FeatureComboLearner::default();
    train_feature_combo(&world, &mut learner, 6);

    for state in world.holdout_states() {
        let selected = learner.select_action(state);
        assert_eq!(
            world.commit_action(state, selected),
            artificial_psyarch::ap::Feedback::Reward
        );
    }
}
