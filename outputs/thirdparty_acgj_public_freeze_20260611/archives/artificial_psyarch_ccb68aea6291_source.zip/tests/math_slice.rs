use artificial_psyarch::ap::{Feedback, TeacherMode};
use artificial_psyarch::math_slice::{
    MathDirection, MathOp, MathProcess, NoSolverMathLearner, NoSolverMathSuite, NoSolverMathWorld,
    run_no_solver_math_phase, train_no_solver_math,
};

#[test]
fn no_solver_math_learns_slices_and_transfers_to_unseen_questions() {
    let world = NoSolverMathWorld::for_suite(NoSolverMathSuite::AddSub);
    let mut learner = NoSolverMathLearner::default();

    let pretest = run_no_solver_math_phase(
        world.holdout_questions(),
        &world,
        &mut learner,
        TeacherMode::TeacherOff,
    );
    assert!(pretest.accuracy < 1.0);
    assert_eq!(learner.memory_rows(), 0);

    let train = train_no_solver_math(&world, &mut learner, 8);
    assert_eq!(train.last().unwrap().accuracy, 1.0);
    assert_eq!(
        learner.learned_slice(MathOp::Add, 2).unwrap().direction,
        MathDirection::Forward
    );
    assert_eq!(
        learner.learned_slice(MathOp::Sub, 2).unwrap().direction,
        MathDirection::Backward
    );

    let memory_before_holdout = learner.memory_rows();
    let holdout = run_no_solver_math_phase(
        world.holdout_questions(),
        &world,
        &mut learner,
        TeacherMode::TeacherOff,
    );

    assert_eq!(holdout.accuracy, 1.0);
    assert_eq!(learner.memory_rows(), memory_before_holdout);
    assert!(holdout.traces.iter().all(|trace| {
        !trace.feedback_visible_to_learner
            && !trace.memory_write_enabled
            && trace.examiner_private_scoring
            && !trace.answer_visible_to_learner
    }));
}

#[test]
fn no_solver_math_uses_operation_slices_not_question_id_lookup() {
    let world = NoSolverMathWorld::for_suite(NoSolverMathSuite::AddSub);
    let mut learner = NoSolverMathLearner::default();
    train_no_solver_math(&world, &mut learner, 8);

    for question in world.holdout_questions() {
        let selected = learner.select_answer(question);
        assert_eq!(world.commit_answer(question, selected), Feedback::Reward);
        assert!(world.train_questions().iter().all(|train| {
            train.id != question.id
                && (train.left, train.op, train.right)
                    != (question.left, question.op, question.right)
        }));
    }
}

#[test]
fn no_solver_math_runs_all_paper_process_slices() {
    for world in NoSolverMathWorld::canonical_suites() {
        let mut learner = NoSolverMathLearner::default();
        let pretest = run_no_solver_math_phase(
            world.holdout_questions(),
            &world,
            &mut learner,
            TeacherMode::TeacherOff,
        );
        assert!(
            pretest.accuracy < 1.0,
            "{:?} should not start solved",
            world.suite()
        );

        let train = train_no_solver_math(&world, &mut learner, 8);
        assert_eq!(train.last().unwrap().accuracy, 1.0, "{:?}", world.suite());

        let holdout = run_no_solver_math_phase(
            world.holdout_questions(),
            &world,
            &mut learner,
            TeacherMode::TeacherOff,
        );
        assert_eq!(holdout.accuracy, 1.0, "{:?}", world.suite());
        assert!(holdout.traces.iter().all(|trace| {
            !trace.feedback_visible_to_learner
                && !trace.memory_write_enabled
                && trace.examiner_private_scoring
                && !trace.answer_visible_to_learner
        }));
    }
}

#[test]
fn no_solver_mul_div_and_vertical_slices_store_processes() {
    let mut mul_div = NoSolverMathLearner::default();
    let mul_div_world = NoSolverMathWorld::for_suite(NoSolverMathSuite::MulDiv);
    train_no_solver_math(&mul_div_world, &mut mul_div, 8);
    assert_eq!(
        mul_div.learned_process(MathOp::Mul, 2),
        Some(MathProcess::Scale { factor: 2 })
    );
    assert_eq!(
        mul_div.learned_process(MathOp::Div, 3),
        Some(MathProcess::Divide { divisor: 3 })
    );

    let mut vertical = NoSolverMathLearner::default();
    let vertical_world = NoSolverMathWorld::for_suite(NoSolverMathSuite::VerticalMultiply);
    train_no_solver_math(&vertical_world, &mut vertical, 8);
    assert_eq!(
        vertical.learned_process(MathOp::VerticalMul, 2),
        Some(MathProcess::Scale { factor: 2 })
    );
}
