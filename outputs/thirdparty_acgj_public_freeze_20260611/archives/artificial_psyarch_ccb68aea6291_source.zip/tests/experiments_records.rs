use artificial_psyarch::experiments::local_runner::{
    ExperimentRunConfig, run_all_experiment_records,
};
use artificial_psyarch::experiments::registry::registered_experiments;

#[test]
fn experiment_registry_entries_are_self_describing_plugins() {
    let plugin_ids: Vec<_> = registered_experiments()
        .into_iter()
        .map(|entry| entry.plugin_id)
        .collect();

    assert_eq!(
        plugin_ids,
        vec![
            "count_loop",
            "feature_combo",
            "sensor_assoc",
            "math_slice",
            "math_fullchain",
            "long_run",
            "canvas_geometry",
            "multimodal_revision",
            "desktop_control",
            "language_grounding",
        ]
    );
}

#[test]
fn local_experiment_records_cover_all_core_experiments() {
    let records = run_all_experiment_records(ExperimentRunConfig { train_repeats: 8 });

    assert_eq!(records.schema_id, "experiments_local/v0.1");
    let ids: Vec<_> = records
        .experiments
        .iter()
        .map(|run| run.experiment_id)
        .collect();
    assert_eq!(
        ids,
        vec![
            "count_loop",
            "feature_combo",
            "sensor_assoc",
            "math_slice_add_sub",
            "math_slice_mul_div",
            "math_slice_vertical_add_sub",
            "math_slice_vertical_multiply",
            "math_slice_vertical_division",
            "math_fullchain",
            "long_run_stability",
            "canvas_geometry",
            "multimodal_revision",
            "desktop_control_safety",
            "language_grounding",
        ]
    );
    assert!(records.validation_errors.is_empty());
    assert!(records.summary.all_holdouts_passed);
    assert_eq!(records.summary.experiment_count, ids.len());
    assert!(records.summary.event_count > 0);
}

#[test]
fn long_run_records_sleep_wake_rehab_before_final_holdout() {
    let records = run_all_experiment_records(ExperimentRunConfig { train_repeats: 8 });
    let long_run = records
        .experiments
        .iter()
        .find(|run| run.experiment_id == "long_run_stability")
        .unwrap();
    let phase_names: Vec<_> = long_run.phases.iter().map(|phase| phase.phase).collect();

    assert_eq!(
        phase_names,
        vec![
            "pretest",
            "train",
            "sleep",
            "wake_probe",
            "rehab",
            "holdout"
        ]
    );
    assert_eq!(long_run.summary.holdout_accuracy, 1.0);
    assert!(long_run.summary.memory_rows_final > 0);
}

#[test]
fn teacher_off_phases_do_not_leak_feedback_or_write_memory() {
    let records = run_all_experiment_records(ExperimentRunConfig { train_repeats: 8 });

    for run in &records.experiments {
        for phase in run
            .phases
            .iter()
            .filter(|phase| phase.phase == "pretest" || phase.phase == "holdout")
        {
            assert!(phase.events.iter().all(|event| {
                event.feedback_to_learner.is_none()
                    && !event.learning_enabled
                    && !event.trace.memory_write_enabled
                    && !event.trace.answer_visible_to_learner
            }));
        }
    }
}
