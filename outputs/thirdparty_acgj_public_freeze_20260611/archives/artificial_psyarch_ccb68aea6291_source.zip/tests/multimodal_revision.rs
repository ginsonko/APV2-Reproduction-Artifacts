use artificial_psyarch::ap::{Feedback, TeacherMode};
use artificial_psyarch::multimodal_revision::{
    MultimodalRevisionLearner, MultimodalRevisionWorld, RevisionLabel,
    run_multimodal_revision_phase, train_multimodal_revision,
};

#[test]
fn multimodal_revision_learns_to_refocus_visual_signal_and_hold_teacher_off() {
    let world = MultimodalRevisionWorld::canonical();
    let mut learner = MultimodalRevisionLearner::default();

    let pretest = run_multimodal_revision_phase(
        world.holdout_prompts(),
        &world,
        &mut learner,
        TeacherMode::TeacherOff,
    );
    assert!(pretest.accuracy < 1.0);

    let train = train_multimodal_revision(&world, &mut learner, 8);
    assert_eq!(train.last().unwrap().accuracy, 1.0);
    assert!(learner.prototype_count(RevisionLabel::Red) > 0);
    assert!(learner.prototype_count(RevisionLabel::Blue) > 0);
    assert!(learner.prototype_count(RevisionLabel::Green) > 0);

    let memory_before_holdout = learner.memory_rows();
    let holdout = run_multimodal_revision_phase(
        world.holdout_prompts(),
        &world,
        &mut learner,
        TeacherMode::TeacherOff,
    );
    assert_eq!(holdout.accuracy, 1.0);
    assert_eq!(learner.memory_rows(), memory_before_holdout);
    assert!(holdout.traces.iter().all(|trace| {
        !trace.feedback_visible_to_learner
            && !trace.memory_write_enabled
            && trace.examiner_private_scoring
            && !trace.answer_visible_to_learner
    }));
}

#[test]
fn multimodal_revision_marks_conflict_as_revision_not_text_hint_copy() {
    let world = MultimodalRevisionWorld::canonical();
    let mut learner = MultimodalRevisionLearner::default();
    train_multimodal_revision(&world, &mut learner, 8);

    for prompt in world.holdout_prompts() {
        assert!(learner.revision_needed(prompt));
        let selected = learner.select_label(prompt);
        assert_eq!(world.commit_label(prompt, selected), Feedback::Reward);
        assert!(
            !world
                .train_prompts()
                .iter()
                .any(|train| train.id == prompt.id)
        );
    }
}
