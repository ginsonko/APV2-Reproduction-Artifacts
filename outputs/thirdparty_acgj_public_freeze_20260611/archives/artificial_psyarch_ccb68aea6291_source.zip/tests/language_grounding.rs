use artificial_psyarch::ap::{Feedback, TeacherMode};
use artificial_psyarch::language_core::{
    DialogAct, LanguageFrame, LanguageGroundingLearner, LanguageGroundingWorld, ResponsePolicy,
    ResponsePolicyLearner, language_world_from_json_text, response_policy_world_from_json_text,
    run_language_grounding_phase, run_response_policy_phase, train_language_grounding,
    train_response_policy, understand_dialog,
};

#[test]
fn language_grounding_learns_state_frames_and_holds_teacher_off() {
    let world = LanguageGroundingWorld::canonical();
    let mut learner = LanguageGroundingLearner::default();

    let pretest = run_language_grounding_phase(
        world.holdout_items(),
        &world,
        &mut learner,
        TeacherMode::TeacherOff,
    );
    assert!(pretest.accuracy < 1.0);

    let train = train_language_grounding(&world, &mut learner, 5);
    assert_eq!(train.last().unwrap().accuracy, 1.0);
    assert!(learner.memory_rows() > 0);

    let memory_before_holdout = learner.memory_rows();
    let holdout = run_language_grounding_phase(
        world.holdout_items(),
        &world,
        &mut learner,
        TeacherMode::TeacherOff,
    );

    assert_eq!(holdout.accuracy, 1.0);
    assert_eq!(learner.memory_rows(), memory_before_holdout);
    assert!(holdout.traces.iter().all(|trace| {
        !trace.feedback_visible_to_learner
            && !trace.memory_write_enabled
            && !trace.answer_visible_to_learner
    }));
}

#[test]
fn language_grounding_uses_context_cues_not_stimulus_id_lookup() {
    let world = LanguageGroundingWorld::canonical();
    let mut learner = LanguageGroundingLearner::default();
    train_language_grounding(&world, &mut learner, 5);

    let regret = &world.holdout_items()[2];
    assert_eq!(learner.predict_frame(regret), LanguageFrame::REGRET);
    assert_eq!(
        world.commit_frame(regret, learner.predict_frame(regret)),
        Feedback::Reward
    );

    let fear = &world.holdout_items()[4];
    assert_eq!(learner.predict_frame(fear), LanguageFrame::FEAR);
    assert_eq!(
        world.commit_frame(fear, learner.predict_frame(fear)),
        Feedback::Reward
    );
}

#[test]
fn language_grounding_expands_to_dialog_intent_frames() {
    let world = LanguageGroundingWorld::canonical();
    let mut learner = LanguageGroundingLearner::default();
    train_language_grounding(&world, &mut learner, 5);

    assert_dialog_act(
        &learner,
        "帮我检查一下",
        "请求执行当前任务",
        DialogAct::ServeRequest,
    );
    assert_dialog_act(
        &learner,
        "说明一下原因",
        "需要依据",
        DialogAct::ExplainReason,
    );
    assert_dialog_act(
        &learner,
        "不是这个意思，修正",
        "用户纠错",
        DialogAct::AlignCorrection,
    );
    assert_dialog_act(
        &learner,
        "继续写还是先测试",
        "多个方案取舍",
        DialogAct::CompareOptions,
    );
    assert_dialog_act(
        &learner,
        "我想先完成语言训练",
        "用户目标",
        DialogAct::TrackGoal,
    );
    assert_dialog_act(
        &learner,
        "太慢了，不满意",
        "用户评价",
        DialogAct::RecordEvaluation,
    );
    assert_dialog_act(
        &learner,
        "我可能没明白",
        "存在未知",
        DialogAct::AskClarification,
    );
}

fn assert_dialog_act(
    learner: &LanguageGroundingLearner,
    text: &str,
    context: &str,
    expected: DialogAct,
) {
    let understanding = understand_dialog(learner, text, context);

    assert_eq!(understanding.act, expected);
}

#[test]
fn language_grounding_imports_jsonl_training_records() {
    let dataset = r#"
{"id":"L0","text":"请你帮我处理","context":"用户请求帮助","expected_frame":"frame:request/service/help","split":"train"}
{"id":"L1","text":"说明一下依据","context":"需要解释","expected_frame":"frame:question/reason/explain","split":"holdout"}
"#;

    let world = language_world_from_json_text(dataset).unwrap();

    assert_eq!(world.train_items().len(), 1);
    assert_eq!(world.holdout_items().len(), 1);
    assert_eq!(
        world.train_items()[0].expected_frame,
        LanguageFrame::REQUEST
    );
    assert_eq!(
        world.holdout_items()[0].expected_frame,
        LanguageFrame::EXPLAIN
    );
}

#[test]
fn language_grounding_imports_split_json_dataset() {
    let dataset = r#"{
  "train": [
    {"text":"我不知道怎么做","context":"需要澄清","expected_frame":"frame:uncertain/gap/clarify"}
  ],
  "holdout": [
    {"text":"这个结果很好","context":"用户评价","expected_frame":"frame:evaluation/feedback/evaluate"}
  ]
}"#;

    let world = language_world_from_json_text(dataset).unwrap();

    assert_eq!(
        world.train_items()[0].expected_frame,
        LanguageFrame::UNCERTAIN
    );
    assert_eq!(
        world.holdout_items()[0].expected_frame,
        LanguageFrame::EVALUATE
    );
}

#[test]
fn response_policy_learns_strategy_without_hardcoded_reply_text() {
    let grounding_world = LanguageGroundingWorld::canonical();
    let mut grounding = LanguageGroundingLearner::default();
    train_language_grounding(&grounding_world, &mut grounding, 5);
    let policy = ResponsePolicyLearner::canonical_trained();
    let understanding = understand_dialog(&grounding, "请你帮我检查", "请求执行任务");

    let decision = policy.predict(&understanding, "请你帮我检查", "请求执行任务");

    assert_eq!(decision.policy, ResponsePolicy::TaskPlan);
    assert_eq!(decision.policy_label, "response:task-plan");
}

#[test]
fn response_policy_imports_external_jsonl_dataset() {
    let dataset = r#"
{"id":"p0","text":"先比较两个办法","context":"用户需要分支取舍","expected_policy":"response:compare-tradeoffs","split":"train"}
{"id":"p1","text":"继续写还是先跑测试","context":"两个方案需要选择","expected_policy":"response:compare-tradeoffs","split":"holdout"}
"#;
    let world = response_policy_world_from_json_text(dataset).unwrap();
    let mut learner = ResponsePolicyLearner::default();

    train_response_policy(&world, &mut learner, 3);
    let holdout = run_response_policy_phase(
        world.holdout_items(),
        &world,
        &mut learner,
        TeacherMode::TeacherOff,
    );

    assert_eq!(world.train_items().len(), 1);
    assert_eq!(holdout.accuracy, 1.0);
}
