use artificial_psyarch::ap::{Feedback, TeacherMode};
use artificial_psyarch::canvas_geometry::{
    CanvasGeometryLearner, CanvasGeometryWorld, run_canvas_geometry_phase, train_canvas_geometry,
};

#[test]
fn canvas_geometry_learns_coordinate_relations_and_holds_teacher_off() {
    let world = CanvasGeometryWorld::canonical();
    let mut learner = CanvasGeometryLearner::default();

    let pretest = run_canvas_geometry_phase(
        world.holdout_tasks(),
        &world,
        &mut learner,
        TeacherMode::TeacherOff,
    );
    assert!(pretest.accuracy < 1.0);

    let train = train_canvas_geometry(&world, &mut learner, 8);
    assert_eq!(train.last().unwrap().accuracy, 1.0);

    let memory_before_holdout = learner.memory_rows();
    let holdout = run_canvas_geometry_phase(
        world.holdout_tasks(),
        &world,
        &mut learner,
        TeacherMode::TeacherOff,
    );
    assert_eq!(holdout.accuracy, 1.0);
    assert_eq!(learner.memory_rows(), memory_before_holdout);
    assert!(holdout.traces.iter().all(|trace| {
        !trace.feedback_visible_to_learner
            && !trace.memory_write_enabled
            && trace.examiner_private_scoring
            && !trace.answer_visible_to_learner
    }));
}

#[test]
fn canvas_geometry_uses_relations_not_task_ids() {
    let world = CanvasGeometryWorld::canonical();
    let mut learner = CanvasGeometryLearner::default();
    train_canvas_geometry(&world, &mut learner, 8);

    for task in world.holdout_tasks() {
        let selected = learner.select_action(task);
        assert_eq!(world.commit_action(task, selected), Feedback::Reward);
        assert!(!world.train_tasks().iter().any(|train| train.id == task.id));
    }
}
