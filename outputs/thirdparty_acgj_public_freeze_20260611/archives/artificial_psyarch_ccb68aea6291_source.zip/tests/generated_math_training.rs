use artificial_psyarch::learning::{
    LearnableAgent, LearningSession, LessonRunner, MathDifficulty, expression_probe_lesson,
    generated_generalization_probe, generated_math_lesson, generated_math_lesson_for_level,
    no_division_math_lesson, probe_answers, probe_lesson, read_skill_package,
};

#[test]
fn generated_basic_math_curriculum_trains_teacher_off_recall() {
    let lesson = generated_math_lesson("generated-math-train", 0..=4);
    let mut agent = LearnableAgent::new("generated_math");
    let report = LessonRunner::new("generated_math").run_with_agent(&mut agent, &lesson);

    assert_eq!(report.train_attempts.len(), lesson.task_count());
    assert_eq!(report.holdout_attempts.len(), lesson.task_count());
    assert_eq!(report.skill_report.train_accuracy(), 1.0);
    assert_eq!(report.skill_report.holdout_accuracy(), 1.0);
    assert_eq!(agent.memory_rows(), lesson.task_count());
    assert!(report.taint_audit.passed());
    assert!(
        report
            .holdout_attempts
            .iter()
            .all(|attempt| !attempt.memory_write_enabled)
    );
}

#[test]
fn generated_math_skill_package_reloads_for_exact_teacher_off_probe() {
    let lesson = generated_math_lesson("generated-math-package", 0..=3);
    let package_path = unique_target_path("generated-math-skill");
    let mut session = LearningSession::new("generated_math");

    let reports = session.run_lessons(std::slice::from_ref(&lesson));
    session
        .save_skill_package(
            &package_path,
            "skill.generated.basic_math",
            &lesson.lesson_id,
        )
        .unwrap();
    let mut reloaded =
        LearnableAgent::from_skill_package(read_skill_package(&package_path).unwrap());
    let probe = probe_lesson(
        "generated-math-probe",
        [(9, "+", 4), (9, "-", 7), (9, "*", 2)],
    );
    let probe_report =
        LessonRunner::new("generated_math").run_probe_with_agent(&mut reloaded, &probe);

    assert_eq!(reports[0].skill_report.holdout_accuracy(), 1.0);
    assert_eq!(probe_answers(&probe_report), vec!["13", "2", "18"]);
    assert_eq!(probe_report.skill_report.holdout_accuracy(), 1.0);
}

#[test]
fn generated_math_generalizes_to_unseen_questions_for_learned_ops() {
    let train = generated_math_lesson_for_level("generated-math-mixed", MathDifficulty::Mixed);
    let mut agent = LearnableAgent::new("generated_math");
    LessonRunner::new("generated_math").run_with_agent(&mut agent, &train);
    let unseen_probe = generated_generalization_probe("generated-math-unseen");

    let report =
        LessonRunner::new("generated_math").run_probe_with_agent(&mut agent, &unseen_probe);

    assert_eq!(
        probe_answers(&report),
        vec!["13", "2", "18", "4", "14", "20"]
    );
    assert_eq!(report.skill_report.holdout_accuracy(), 1.0);
    assert!(report.taint_audit.passed());
}

#[test]
fn generated_math_generalizes_parentheses_and_precedence() {
    let train =
        generated_math_lesson_for_level("generated-math-parentheses", MathDifficulty::Mixed);
    let mut agent = LearnableAgent::new("generated_math");
    LessonRunner::new("generated_math").run_with_agent(&mut agent, &train);
    let probe = expression_probe_lesson(
        "generated-math-expression-probe",
        ["2 + 3 * 5", "(2 + 3) * 5", "18 / 3 + 7", "18 / (3 + 3)"],
    );

    let report = LessonRunner::new("generated_math").run_probe_with_agent(&mut agent, &probe);

    assert_eq!(probe_answers(&report), vec!["17", "25", "13", "3"]);
    assert_eq!(report.skill_report.holdout_accuracy(), 1.0);
}

#[test]
fn generated_math_does_not_generalize_untrained_ops() {
    let train = no_division_math_lesson("generated-math-no-division", 1, 2);
    let mut agent = LearnableAgent::new("generated_math");
    LessonRunner::new("generated_math").run_with_agent(&mut agent, &train);
    let division_probe = probe_lesson("generated-math-untrained-div", [(8, "/", 2)]);

    let report =
        LessonRunner::new("generated_math").run_probe_with_agent(&mut agent, &division_probe);

    assert_eq!(probe_answers(&report), vec!["ObserveText"]);
    assert_eq!(report.skill_report.holdout_accuracy(), 0.0);
    assert!(report.taint_audit.passed());
}

#[test]
fn generated_math_does_not_answer_expression_with_untrained_op() {
    let train = no_division_math_lesson("generated-math-expression-no-division", 1, 2);
    let mut agent = LearnableAgent::new("generated_math");
    LessonRunner::new("generated_math").run_with_agent(&mut agent, &train);
    let probe = expression_probe_lesson("generated-math-expression-untrained", ["8 / 2 + 1"]);

    let report = LessonRunner::new("generated_math").run_probe_with_agent(&mut agent, &probe);

    assert_eq!(probe_answers(&report), vec!["ObserveText"]);
    assert_eq!(report.skill_report.holdout_accuracy(), 0.0);
}

fn unique_target_path(name: &str) -> String {
    format!("target/{name}-{}.json", std::process::id())
}
