use artificial_psyarch::ap::{AuditTrace, TeacherMode};
use artificial_psyarch::repeat_map::{RepeatMapLearner, RepeatMapWorld, run_phase};

#[test]
fn teacher_mode_audit_contracts_are_explicit() {
    assert_eq!(
        AuditTrace::for_mode(TeacherMode::TeacherOn),
        AuditTrace {
            feedback_visible_to_learner: true,
            memory_write_enabled: true,
            examiner_private_scoring: true,
            answer_visible_to_learner: true,
        }
    );
    assert_eq!(AuditTrace::for_mode(TeacherMode::Fade), AuditTrace::fade());
    assert_eq!(
        AuditTrace::for_mode(TeacherMode::NoAnswerFeedback),
        AuditTrace::no_answer_feedback()
    );
    assert_eq!(
        AuditTrace::for_mode(TeacherMode::TeacherOff),
        AuditTrace::teacher_off()
    );
}

#[test]
fn teacher_on_demonstrates_answers_and_writes_memory() {
    let world = RepeatMapWorld::new("teacher-on", 5101, 12);
    let mut learner = RepeatMapLearner::default();

    let phase = run_phase(&world, &mut learner, TeacherMode::TeacherOn);

    assert_eq!(phase.accuracy, 1.0);
    assert_eq!(learner.memory_len(), world.states().len());
    assert!(phase.traces.iter().all(|trace| {
        trace.feedback_visible_to_learner
            && trace.memory_write_enabled
            && trace.examiner_private_scoring
            && trace.answer_visible_to_learner
    }));
}

#[test]
fn no_answer_feedback_exposes_feedback_without_memory_writes() {
    let world = RepeatMapWorld::new("no-answer-feedback", 5101, 12);
    let mut learner = RepeatMapLearner::default();

    let phase = run_phase(&world, &mut learner, TeacherMode::NoAnswerFeedback);

    assert!(phase.accuracy < 1.0);
    assert_eq!(learner.memory_len(), 0);
    assert!(phase.traces.iter().all(|trace| {
        trace.feedback_visible_to_learner
            && !trace.memory_write_enabled
            && trace.examiner_private_scoring
            && !trace.answer_visible_to_learner
    }));
}

#[test]
fn fade_keeps_feedback_learning_but_hides_direct_answers() {
    let world = RepeatMapWorld::new("fade", 5101, 12);
    let mut learner = RepeatMapLearner::default();

    let first = run_phase(&world, &mut learner, TeacherMode::Fade);
    let memory_after_first = learner.memory_len();

    assert!(first.accuracy < 1.0);
    assert!(memory_after_first > 0);
    assert!(first.traces.iter().all(|trace| {
        trace.feedback_visible_to_learner
            && trace.memory_write_enabled
            && trace.examiner_private_scoring
            && !trace.answer_visible_to_learner
    }));
}
