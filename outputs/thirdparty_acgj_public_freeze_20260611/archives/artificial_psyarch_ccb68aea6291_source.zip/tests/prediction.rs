use artificial_psyarch::ap::{AtomKind, DualEnergyStatePool, StateAtom};
use artificial_psyarch::prediction::{
    ActionConsequenceEvaluator, CognitiveFeelingFactory, CognitiveFeelingKind, ExperienceFrame,
    PredictionConfig, SuccessorMemory,
};

#[test]
fn successor_memory_recalls_bn_and_builds_cstar_prediction() {
    let mut memory = SuccessorMemory::default();
    memory.write(ExperienceFrame::new(
        ["context::alpha", "state::U00", "action::A"],
        ["feedback::Punishment", "feeling::mismatch"],
    ));
    memory.write(ExperienceFrame::new(
        ["context::alpha", "state::U00", "action::B"],
        ["feedback::Reward", "feeling::grasp"],
    ));
    memory.write(ExperienceFrame::new(
        ["context::beta", "state::U00", "action::B"],
        ["feedback::Punishment"],
    ));

    let current = vec![
        "context::alpha".to_owned(),
        "state::U00".to_owned(),
        "action::B".to_owned(),
    ];
    let package = memory.predict_cstar(
        &current,
        PredictionConfig {
            bn_limit: 2,
            cstar_budget: 2,
        },
    );

    assert_eq!(package.recalls.len(), 2);
    assert_eq!(package.recalls[0].matched_keys, 3);
    assert_eq!(package.strongest().unwrap().key, "feedback::Reward");
    assert_eq!(package.candidates.len(), 2);
}

#[test]
fn prediction_package_injects_virtual_energy_into_state_pool() {
    let mut memory = SuccessorMemory::default();
    memory.write(ExperienceFrame::new(
        ["state::door", "action::push"],
        ["state::open"],
    ));

    let current = vec!["state::door".to_owned(), "action::push".to_owned()];
    let package = memory.predict_cstar(&current, PredictionConfig::default());
    let mut pool = DualEnergyStatePool::default();
    package.inject_virtual_energy(&mut pool);

    let predicted = pool.get("state::open").unwrap();
    assert_eq!(predicted.real_energy, 0.0);
    assert!(predicted.virtual_energy > 0.0);
    assert_eq!(predicted.cognitive_pressure, predicted.virtual_energy);
}

#[test]
fn state_pool_decays_attention_and_accumulates_fatigue_across_ticks() {
    let mut pool = DualEnergyStatePool::default();
    pool.observe("state::door");
    pool.upsert(StateAtom::new("state::door", AtomKind::Control).with_attention_gain(0.8));
    let touched = pool.get("state::door").unwrap();
    assert!(touched.attention_gain > 0.0);
    assert!(touched.fatigue > 0.0);

    let real_before = touched.real_energy;
    let attention_before = touched.attention_gain;
    pool.begin_tick();

    let decayed = pool.get("state::door").unwrap();
    assert!(decayed.real_energy < real_before);
    assert!(decayed.attention_gain < attention_before);
    assert_eq!(pool.tick_index(), 1);
}

#[test]
fn action_control_target_changes_attention_without_concept_energy() {
    let mut pool = DualEnergyStatePool::default();
    pool.control_attention("state::door", 0.9);

    let controlled = pool.get("state::door").unwrap();
    assert_eq!(controlled.real_energy, 0.0);
    assert_eq!(controlled.virtual_energy, 0.0);
    assert!(controlled.attention_gain > 0.0);
}

#[test]
fn cognitive_feeling_factory_reports_grasp_mismatch_and_gap() {
    let mut memory = SuccessorMemory::default();
    memory.write(ExperienceFrame::new(
        ["state::door", "action::push"],
        ["state::open"],
    ));

    let current = vec!["state::door".to_owned(), "action::push".to_owned()];
    let package = memory.predict_cstar(&current, PredictionConfig::default());

    let grasp = CognitiveFeelingFactory::from_prediction(&package, Some("state::open"));
    assert_eq!(grasp.kind, CognitiveFeelingKind::Grasp);

    let mismatch = CognitiveFeelingFactory::from_prediction(&package, Some("state::closed"));
    assert_eq!(mismatch.kind, CognitiveFeelingKind::Mismatch);

    let gap_package =
        SuccessorMemory::default().predict_cstar(&current, PredictionConfig::default());
    let gap = CognitiveFeelingFactory::from_prediction(&gap_package, None);
    assert_eq!(gap.kind, CognitiveFeelingKind::EvidenceGap);
}

#[test]
fn action_consequence_evaluator_turns_predicted_feedback_into_drive() {
    let mut memory = SuccessorMemory::default();
    memory.write(ExperienceFrame::new(
        ["state::door", "action::push"],
        ["feedback::Reward"],
    ));
    memory.write(ExperienceFrame::new(
        ["state::door", "action::pull"],
        ["feedback::Punishment"],
    ));

    let push = vec!["state::door".to_owned(), "action::push".to_owned()];
    let push_prediction = memory.predict_cstar(&push, PredictionConfig::default());
    let push_consequence = ActionConsequenceEvaluator::evaluate(&push_prediction);
    assert!(push_consequence.drive > 0.0);
    assert!(push_consequence.expected_reward > push_consequence.expected_punishment);

    let pull = vec!["state::door".to_owned(), "action::pull".to_owned()];
    let pull_prediction = memory.predict_cstar(&pull, PredictionConfig::default());
    let pull_consequence = ActionConsequenceEvaluator::evaluate(&pull_prediction);
    assert!(pull_consequence.drive < 0.0);
    assert!(pull_consequence.expected_punishment > pull_consequence.expected_reward);
}

#[test]
fn cstar_prediction_can_require_temporally_applicable_action_key() {
    let mut memory = SuccessorMemory::default();
    memory.write(ExperienceFrame::new(
        ["state::door", "action::push"],
        ["feedback::Reward"],
    ));
    memory.write(ExperienceFrame::new(
        ["state::door", "action::pull"],
        ["feedback::Punishment"],
    ));

    let current = vec!["state::door".to_owned(), "action::push".to_owned()];
    let required = vec!["action::push".to_owned()];
    let package =
        memory.predict_cstar_with_required_keys(&current, &required, PredictionConfig::default());

    assert_eq!(package.energy_for("feedback::Reward"), 1.0);
    assert_eq!(package.energy_for("feedback::Punishment"), 0.0);
}
