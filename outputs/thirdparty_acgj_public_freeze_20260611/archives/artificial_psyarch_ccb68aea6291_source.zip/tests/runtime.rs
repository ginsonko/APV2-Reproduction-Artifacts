use artificial_psyarch::ap::{Feedback, TeacherMode};
use artificial_psyarch::prediction::CognitiveFeelingKind;
use artificial_psyarch::runtime::{
    APV21Runtime, ActionFeedback, AnchorVerifierStatus, RuntimeConfig, RuntimeObservation,
    RuntimeTickInput, RuntimeTraceLog, TeacherSignal,
};

#[test]
fn runtime_learns_action_feedback_and_uses_it_teacher_off() {
    let mut runtime = APV21Runtime::default();
    let observation = RuntimeObservation::new("door", "closed", ["sensor::handle"]);

    let train = runtime.train_feedback(observation.clone(), "push", Feedback::Reward);
    assert!(train.memory_frame_written);
    assert!(train.memory_snapshot.is_some());
    assert_eq!(runtime.memory().frames().len(), 1);
    assert_eq!(runtime.memory().snapshots().len(), 1);
    assert!(
        runtime.memory().snapshots()[0]
            .state_field_items
            .contains(&"action::push".to_owned())
    );

    let probe = runtime.tick(RuntimeTickInput {
        observation,
        actions: vec!["pull".to_owned(), "push".to_owned()],
        teacher: TeacherSignal::new(TeacherMode::TeacherOff),
        feedback: None,
        actual_successor: None,
    });

    assert_eq!(probe.selected_action.as_deref(), Some("push"));
    assert!(!probe.memory_frame_written);
    assert!(!probe.teacher_audit.feedback_visible_to_learner);
    assert!(!probe.teacher_audit.memory_write_enabled);
    assert!(probe.prediction.package.energy_for("feedback::Reward") > 0.0);
    assert_eq!(probe.prediction.bn_trace.recall_count, 1);
    assert_eq!(
        probe.prediction.cstar_trace.strongest_key.as_deref(),
        Some("feedback::Reward")
    );
    assert!(
        probe
            .r_state
            .heads
            .iter()
            .any(|head| head.head == "high_real")
    );
    assert!(
        probe
            .r_state
            .heads
            .iter()
            .any(|head| head.head == "high_virtual")
    );
    assert!(
        probe
            .r_state
            .selected_keys
            .contains(&"state::closed".to_owned())
    );
    assert!(probe.prediction_validation.actual.is_none());
    assert!(matches!(
        probe.feeling.kind,
        CognitiveFeelingKind::Closure | CognitiveFeelingKind::Uncertainty
    ));
}

#[test]
fn runtime_teacher_off_feedback_does_not_write_memory() {
    let mut runtime = APV21Runtime::default();
    let observation = RuntimeObservation::new("door", "closed", ["sensor::handle"]);

    let trace = runtime.tick(RuntimeTickInput {
        observation,
        actions: vec!["push".to_owned()],
        teacher: TeacherSignal::new(TeacherMode::TeacherOff),
        feedback: Some(ActionFeedback::reward("push")),
        actual_successor: Some("feedback::Reward".to_owned()),
    });

    assert!(trace.feedback_written);
    assert!(!trace.memory_frame_written);
    assert!(trace.memory_snapshot.is_none());
    assert_eq!(
        trace.prediction_validation.unexpected,
        vec!["feedback::Reward".to_owned()]
    );
    assert!(runtime.memory().frames().is_empty());
}

#[test]
fn runtime_prediction_validation_reports_matched_successor() {
    let mut runtime = APV21Runtime::default();
    let observation = RuntimeObservation::new("door", "closed", ["sensor::handle"]);
    runtime.train_feedback(observation.clone(), "push", Feedback::Reward);

    let trace = runtime.tick(RuntimeTickInput {
        observation,
        actions: vec!["push".to_owned()],
        teacher: TeacherSignal::new(TeacherMode::TeacherOff),
        feedback: None,
        actual_successor: Some("feedback::Reward".to_owned()),
    });

    assert_eq!(
        trace.prediction_validation.matched,
        vec!["feedback::Reward".to_owned()]
    );
    assert!(trace.prediction_validation.mismatch_ratio < 1.0);
}

#[test]
fn runtime_feeling_trace_exposes_auditable_channels() {
    let mut runtime = APV21Runtime::default();
    let observation = RuntimeObservation::new("math", "count", ["quantity::n=3"]);
    runtime.train_feedback(observation.clone(), "answer_three", Feedback::Reward);

    let trace = runtime.tick(RuntimeTickInput {
        observation,
        actions: vec!["answer_three".to_owned()],
        teacher: TeacherSignal::new(TeacherMode::TeacherOff),
        feedback: None,
        actual_successor: Some("feedback::Reward".to_owned()),
    });

    assert_eq!(trace.feeling_trace.channels.quantity_grasp, 1.0);
    assert!(trace.feeling_trace.expectation.satisfaction > 0.0);
    assert!(trace.feeling_trace.task.fulfillment > 0.0);
    assert!(
        trace
            .feeling_trace
            .positive_components
            .iter()
            .any(|component| component.name == "expectation_satisfaction")
    );
    assert!(
        trace
            .feeling_trace
            .negative_components
            .iter()
            .any(|component| component.name == "computation_pressure")
    );
}

#[test]
fn runtime_modulation_affects_action_estimates_and_attention() {
    let mut runtime = APV21Runtime::default();
    let observation = RuntimeObservation::new(
        "task",
        "known",
        ["anchor::goal", "expect::feedback::Reward"],
    );
    runtime.train_feedback(observation.clone(), "solve", Feedback::Reward);

    let trace = runtime.tick(RuntimeTickInput {
        observation,
        actions: vec!["wait".to_owned(), "solve".to_owned()],
        teacher: TeacherSignal::new(TeacherMode::TeacherOff),
        feedback: None,
        actual_successor: Some("feedback::Reward".to_owned()),
    });

    assert!(trace.modulation_trace.dopamine_proxy > 0.0);
    assert!(trace.modulation_trace.attention_gain > 0.0);
    assert!(
        trace
            .action_estimates
            .iter()
            .any(|estimate| estimate.action == "solve" && estimate.drive > 0.0)
    );
    assert_eq!(trace.anchor_trace.status, AnchorVerifierStatus::Validated);
}

#[test]
fn runtime_anchor_verifier_reports_missed_expectation() {
    let mut runtime = APV21Runtime::default();

    let trace = runtime.tick(RuntimeTickInput {
        observation: RuntimeObservation::new(
            "task",
            "miss",
            ["anchor::goal", "expect::feedback::Reward"],
        ),
        actions: vec!["solve".to_owned()],
        teacher: TeacherSignal::new(TeacherMode::TeacherOff),
        feedback: None,
        actual_successor: Some("feedback::Punishment".to_owned()),
    });

    assert_eq!(trace.anchor_trace.status, AnchorVerifierStatus::Missed);
    assert!(trace.anchor_trace.is_miss());
    assert!(trace.anchor_trace.miss_count > 0);
}

#[test]
fn runtime_teacher_action_bias_is_stripped_outside_teacher_on() {
    let observation = RuntimeObservation::new("door", "closed", ["sensor::handle"]);
    let actions = vec!["pull".to_owned(), "push".to_owned()];

    let mut fade_runtime = APV21Runtime::default();
    let fade = fade_runtime.tick(RuntimeTickInput {
        observation: observation.clone(),
        actions: actions.clone(),
        teacher: TeacherSignal::new(TeacherMode::Fade).with_suggested_action("push"),
        feedback: None,
        actual_successor: None,
    });
    assert_eq!(fade.selected_action.as_deref(), Some("pull"));

    let mut explicit_fade_runtime = APV21Runtime::default();
    let explicit_fade = explicit_fade_runtime.tick(RuntimeTickInput {
        observation: observation.clone(),
        actions: actions.clone(),
        teacher: TeacherSignal::new(TeacherMode::Fade).with_action_bias("push", 0.75),
        feedback: None,
        actual_successor: None,
    });
    assert_eq!(explicit_fade.selected_action.as_deref(), Some("push"));
    assert!(
        explicit_fade
            .action_estimates
            .iter()
            .any(|estimate| estimate.action == "push" && estimate.teacher_bias_strength == 0.75)
    );

    let mut off_runtime = APV21Runtime::default();
    let teacher_off = off_runtime.tick(RuntimeTickInput {
        observation: observation.clone(),
        actions: actions.clone(),
        teacher: TeacherSignal::new(TeacherMode::TeacherOff).with_action_bias("push", 1.0),
        feedback: None,
        actual_successor: None,
    });
    assert_eq!(teacher_off.selected_action.as_deref(), Some("pull"));

    let mut teacher_on_runtime = APV21Runtime::default();
    let teacher_on = teacher_on_runtime.tick(RuntimeTickInput {
        observation,
        actions,
        teacher: TeacherSignal::new(TeacherMode::TeacherOn).with_suggested_action("push"),
        feedback: None,
        actual_successor: None,
    });
    assert_eq!(teacher_on.selected_action.as_deref(), Some("push"));
}

#[test]
fn runtime_memory_uses_recent_fallback_when_query_has_no_exact_overlap() {
    let mut runtime = APV21Runtime::default();
    runtime.train_feedback(
        RuntimeObservation::new("shape", "red", ["feature::round"]),
        "name_circle",
        Feedback::Reward,
    );

    let trace = runtime.tick(RuntimeTickInput {
        observation: RuntimeObservation::new("unseen", "blue", ["feature::square"]),
        actions: vec!["name_square".to_owned()],
        teacher: TeacherSignal::new(TeacherMode::TeacherOff),
        feedback: None,
        actual_successor: None,
    });

    assert!(trace.prediction.bn_trace.recall_count > 0);
    assert!(trace.prediction.bn_trace.recalls.iter().any(|recall| {
        recall
            .candidate_sources
            .contains(&"recent_fallback".to_owned())
    }));
}

#[test]
fn runtime_memory_recalls_near_numeric_feature_bucket() {
    let mut runtime = APV21Runtime::default();
    runtime.train_feedback(
        RuntimeObservation::new("sensor", "range", ["feature::distance=10.14"]),
        "approach",
        Feedback::Reward,
    );

    let trace = runtime.tick(RuntimeTickInput {
        observation: RuntimeObservation::new("sensor", "other", ["feature::distance=10.15"]),
        actions: vec!["wait".to_owned()],
        teacher: TeacherSignal::new(TeacherMode::TeacherOff),
        feedback: None,
        actual_successor: None,
    });

    assert!(trace.prediction.bn_trace.recalls.iter().any(|recall| {
        recall
            .candidate_sources
            .contains(&"numeric_feature".to_owned())
    }));
}

#[test]
fn runtime_prediction_trace_exposes_temporal_applicability() {
    let mut runtime = APV21Runtime::default();
    let observation = RuntimeObservation::new("door", "closed", ["sensor::handle"]);
    runtime.train_feedback(observation.clone(), "push", Feedback::Reward);

    let early = runtime.memory().predict_cstar_at_tick(
        &[
            "context::door".to_owned(),
            "state::closed".to_owned(),
            "action::push".to_owned(),
        ],
        &["action::push".to_owned()],
        Default::default(),
        2,
    );
    let late = runtime.memory().predict_cstar_at_tick(
        &[
            "context::door".to_owned(),
            "state::closed".to_owned(),
            "action::push".to_owned(),
        ],
        &["action::push".to_owned()],
        Default::default(),
        200,
    );

    let early_factor = early.prediction_first_temporal_factor();
    let late_factor = late.prediction_first_temporal_factor();
    assert!(early_factor > late_factor);
    assert!(late_factor >= 0.20);
}

#[test]
fn runtime_cstar_uses_fixed_virtual_energy_budget() {
    let mut runtime = APV21Runtime::default();
    let observation = RuntimeObservation::new("door", "closed", ["sensor::handle"]);
    runtime.train_feedback(observation.clone(), "push", Feedback::Reward);
    runtime.train_feedback(observation.clone(), "push", Feedback::Punishment);

    let trace = runtime.tick(RuntimeTickInput {
        observation,
        actions: vec!["push".to_owned()],
        teacher: TeacherSignal::new(TeacherMode::TeacherOff),
        feedback: None,
        actual_successor: None,
    });

    let total_energy = trace
        .prediction
        .cstar_trace
        .candidates
        .iter()
        .map(|candidate| candidate.virtual_energy)
        .sum::<f32>();
    assert!(total_energy <= 1.0 + f32::EPSILON);
    assert!(
        trace
            .prediction
            .cstar_trace
            .energy_budget_semantics
            .contains("fixed_virtual_energy_budget")
    );
}

#[test]
fn runtime_trace_log_exports_and_replays_tick_inputs() {
    let mut runtime = APV21Runtime::default();
    let input = RuntimeTickInput {
        observation: RuntimeObservation::new("door", "closed", ["sensor::handle"]),
        actions: vec!["push".to_owned()],
        teacher: TeacherSignal::new(TeacherMode::FeedbackOnly).with_feedback(Feedback::Reward),
        feedback: Some(ActionFeedback::reward("push")),
        actual_successor: Some("feedback::Reward".to_owned()),
    };
    runtime.tick(input.clone());

    let json = runtime.export_trace_log_json().unwrap();
    assert!(json.contains("feedback::Reward"));
    assert_eq!(runtime.trace_log().entries().len(), 1);

    let replay = RuntimeTraceLog::replay(RuntimeConfig::default(), [input]);
    assert_eq!(
        replay.entries()[0].trace.memory_snapshot,
        runtime.trace_log().entries()[0].trace.memory_snapshot
    );
}

trait RuntimePredictionTraceExt {
    fn prediction_first_temporal_factor(&self) -> f32;
}

impl RuntimePredictionTraceExt for artificial_psyarch::runtime::RuntimePredictionTrace {
    fn prediction_first_temporal_factor(&self) -> f32 {
        self.bn_trace.recalls[0].temporal_factor
    }
}
