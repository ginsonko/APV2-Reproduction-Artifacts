use artificial_psyarch::ap::TeacherMode;
use artificial_psyarch::prediction::CognitiveFeelingKind;
use artificial_psyarch::repeat_map::local_runner::{LocalRunConfig, run_local_records};
use artificial_psyarch::repeat_map::{
    ACTIONS, RepeatMapLearner, RepeatMapWorld, run_phase, train_repeats,
};

#[test]
fn feedback_memory_learns_and_holds_under_teacher_off() {
    let world = RepeatMapWorld::new("alpha", 1103, 12);
    let mut learner = RepeatMapLearner::default();

    let pretest = run_phase(&world, &mut learner, TeacherMode::TeacherOff);
    assert_eq!(pretest.total, 12);
    assert!(pretest.accuracy < 1.0);
    assert_eq!(learner.memory_len(), 0);
    assert!(pretest.traces.iter().all(|trace| {
        !trace.feedback_visible_to_learner
            && !trace.memory_write_enabled
            && trace.examiner_private_scoring
            && !trace.answer_visible_to_learner
    }));

    let train = train_repeats(&world, &mut learner, 4);
    assert_eq!(train.len(), 4);
    assert_eq!(train.last().unwrap().accuracy, 1.0);
    assert!(learner.memory_len() > 0);

    let holdout = run_phase(&world, &mut learner, TeacherMode::TeacherOff);
    assert_eq!(holdout.accuracy, 1.0);
    assert!(holdout.traces.iter().all(|trace| {
        !trace.feedback_visible_to_learner
            && !trace.memory_write_enabled
            && trace.examiner_private_scoring
            && !trace.answer_visible_to_learner
    }));
}

#[test]
fn skill_package_reload_preserves_acquired_mapping() {
    let world = RepeatMapWorld::new("alpha", 2207, 12);
    let mut learner = RepeatMapLearner::default();
    train_repeats(&world, &mut learner, 4);

    let package = learner.export_skill_package("repeat-map-alpha");
    let mut reloaded = RepeatMapLearner::from_skill_package(package);
    let reload_holdout = run_phase(&world, &mut reloaded, TeacherMode::TeacherOff);

    assert_eq!(reload_holdout.accuracy, 1.0);
}

#[test]
fn strict_core_records_successor_predictions_and_feelings() {
    let world = RepeatMapWorld::new("alpha", 1103, 12);
    let state = &world.states()[0];
    let mut learner = RepeatMapLearner::default();

    for action in ACTIONS {
        let feedback = world.commit_action(state, action);
        learner.receive_feedback(
            world.context(),
            state,
            action,
            feedback,
            TeacherMode::FeedbackOnly,
        );
    }

    assert_eq!(learner.memory_len(), ACTIONS.len());
    assert_eq!(learner.successor_memory_len(), ACTIONS.len());

    let selected = learner.select_action(world.context(), state);
    let feedback = world.commit_action(state, selected);
    let expected_successor = format!("feedback::{feedback:?}");
    assert!(
        learner
            .last_prediction()
            .unwrap()
            .candidates
            .iter()
            .any(|candidate| candidate.key == expected_successor)
    );
    assert!(matches!(
        learner.last_feeling().unwrap().kind,
        CognitiveFeelingKind::Closure | CognitiveFeelingKind::Uncertainty
    ));

    let package = learner.export_skill_package("repeat-map-alpha");
    let mut reloaded = RepeatMapLearner::from_skill_package(package);
    reloaded.select_action(world.context(), state);
    assert!(reloaded.last_prediction().unwrap().strongest().is_some());
}

#[test]
fn strict_core_action_choice_uses_predicted_consequence_drive() {
    let world = RepeatMapWorld::new("alpha", 1103, 12);
    let state = &world.states()[0];
    let mut learner = RepeatMapLearner::default();

    for action in ACTIONS {
        let feedback = world.commit_action(state, action);
        learner.receive_feedback(
            world.context(),
            state,
            action,
            feedback,
            TeacherMode::FeedbackOnly,
        );
    }

    let selected = learner.select_action(world.context(), state);
    assert_eq!(
        world.commit_action(state, selected),
        artificial_psyarch::ap::Feedback::Reward
    );
    let consequence = learner.last_consequence().unwrap();
    assert!(consequence.drive > 0.0);
    assert!(consequence.expected_reward > consequence.expected_punishment);
}

#[test]
fn beta_context_relearning_does_not_need_hidden_answers() {
    let alpha = RepeatMapWorld::new("alpha", 3301, 12);
    let beta = RepeatMapWorld::new("beta", 3301, 12);
    let mut learner = RepeatMapLearner::default();

    train_repeats(&alpha, &mut learner, 4);
    let alpha_holdout = run_phase(&alpha, &mut learner, TeacherMode::TeacherOff);
    assert_eq!(alpha_holdout.accuracy, 1.0);

    let beta_first = run_phase(&beta, &mut learner, TeacherMode::FeedbackOnly);
    assert!(beta_first.accuracy < 1.0);

    let beta_train = train_repeats(&beta, &mut learner, 3);
    assert_eq!(beta_train.last().unwrap().accuracy, 1.0);

    let beta_holdout = run_phase(&beta, &mut learner, TeacherMode::TeacherOff);
    assert_eq!(beta_holdout.accuracy, 1.0);
}

#[test]
fn local_records_cover_three_non_api_groups_without_teacher_leakage() {
    let records = run_local_records(&LocalRunConfig {
        seeds: vec![1103, 2207],
        state_count: 12,
        train_repeats: 4,
    });

    assert_eq!(records.seed_count, 2);
    assert_eq!(records.participant_identity.len(), 3);
    assert!(records.summary.validation_passed);
    assert_eq!(records.summary.error_count, 0);
    assert!(records.validation_errors.is_empty());

    let group_ids: Vec<_> = records
        .participant_identity
        .iter()
        .map(|id| id.route_id)
        .collect();
    assert_eq!(
        group_ids,
        vec![
            "G1A_RM_AP_STYLE",
            "G1B_RM_STRICT_CORE_BRIDGE",
            "G2_RM_FIXED_HEURISTIC"
        ]
    );

    for seed_run in &records.seed_runs {
        assert_eq!(seed_run.groups.len(), 3);
        for group in &seed_run.groups {
            if group.group_id == "G1A_RM_AP_STYLE" || group.group_id == "G1B_RM_STRICT_CORE_BRIDGE"
            {
                assert_eq!(group.summary.alpha_holdout_accuracy, 1.0);
                assert_eq!(group.summary.package_reload_accuracy, 1.0);
                assert_eq!(group.summary.beta_holdout_accuracy, 1.0);
            }

            for phase_name in [
                "pretest_alpha",
                "alpha_holdout",
                "package_reload",
                "beta_holdout",
            ] {
                assert!(group.phases[phase_name].iter().all(|event| {
                    event.feedback_to_learner.is_none()
                        && !event.learning_enabled
                        && !event.trace.audit.memory_write_enabled
                        && !event.trace.audit.answer_visible_to_learner
                }));
            }
        }
    }
}
