use artificial_psyarch::ap::{Feedback, TeacherMode};
use artificial_psyarch::long_run::{
    LongRunLabel, LongRunLearner, LongRunWorld, run_long_run_phase, train_long_run,
};

#[test]
fn long_run_stability_survives_sleep_and_rehab_under_teacher_off_holdout() {
    let world = LongRunWorld::canonical();
    let mut learner = LongRunLearner::default();

    let pretest = run_long_run_phase(
        world.holdout_stimuli(),
        &world,
        &mut learner,
        TeacherMode::TeacherOff,
    );
    assert!(pretest.accuracy < 1.0);

    let train = train_long_run(&world, &mut learner, 8);
    assert_eq!(train.last().unwrap().accuracy, 1.0);
    assert!(learner.prototype_count(LongRunLabel::Alpha) > 0);
    assert!(learner.prototype_count(LongRunLabel::Beta) > 0);
    assert!(learner.prototype_count(LongRunLabel::Gamma) > 0);

    let memory_after_train = learner.memory_rows();
    let strength_after_train = learner.total_memory_strength();
    let sleep = run_long_run_phase(
        world.sleep_ticks(),
        &world,
        &mut learner,
        TeacherMode::NoAnswerFeedback,
    );
    assert_eq!(sleep.accuracy, 1.0);
    assert_eq!(learner.memory_rows(), memory_after_train);
    assert!(learner.sleep_cycles() > 0);
    assert!(learner.total_memory_strength() < strength_after_train);

    let wake_probe = run_long_run_phase(
        world.holdout_stimuli(),
        &world,
        &mut learner,
        TeacherMode::TeacherOff,
    );
    assert_eq!(wake_probe.accuracy, 1.0);

    let rehab = run_long_run_phase(
        world.rehab_stimuli(),
        &world,
        &mut learner,
        TeacherMode::FeedbackOnly,
    );
    assert_eq!(rehab.accuracy, 1.0);

    let memory_before_holdout = learner.memory_rows();
    let holdout = run_long_run_phase(
        world.holdout_stimuli(),
        &world,
        &mut learner,
        TeacherMode::TeacherOff,
    );
    assert_eq!(holdout.accuracy, 1.0);
    assert_eq!(learner.memory_rows(), memory_before_holdout);
    assert!(holdout.traces.iter().all(|trace| {
        !trace.feedback_visible_to_learner
            && !trace.memory_write_enabled
            && trace.examiner_private_scoring
            && !trace.answer_visible_to_learner
    }));
}

#[test]
fn long_run_recalls_from_sensor_pattern_not_holdout_id() {
    let world = LongRunWorld::canonical();
    let mut learner = LongRunLearner::default();
    train_long_run(&world, &mut learner, 8);
    run_long_run_phase(
        world.sleep_ticks(),
        &world,
        &mut learner,
        TeacherMode::NoAnswerFeedback,
    );

    for stimulus in world.holdout_stimuli() {
        let selected = learner.select_action(stimulus);
        assert_eq!(world.commit_action(stimulus, selected), Feedback::Reward);
        assert!(
            !world
                .train_stimuli()
                .iter()
                .any(|train| train.id() == stimulus.id())
        );
    }
}
