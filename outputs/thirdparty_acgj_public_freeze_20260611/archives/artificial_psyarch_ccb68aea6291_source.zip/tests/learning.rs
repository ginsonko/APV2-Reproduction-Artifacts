use artificial_psyarch::ap::{Feedback, TeacherMode};
use artificial_psyarch::learning::{
    AgentLearningRequest, ArtifactKind, ArtifactRef, FeedbackPolicy, HoldoutSplit, LearnableAgent,
    LearningInput, LearningIntent, LearningMaterial, LearningSession, LearningSource, LessonRunner,
    LessonTask, LlmAdapter, LlmBridge, MaterialStimulus, MediaOutput, PlannedLesson, SkillReport,
    SkillReportStatus, ToolTranslationRequest, read_learning_request, read_learning_request_text,
    read_skill_package, write_lesson_bundle, write_skill_package,
};
use artificial_psyarch::skill_registry::SkillBoundary;

#[test]
fn learning_input_from_llm_can_be_converted_to_trainable_lesson() {
    let input = LearningInput::new(
        LearningSource::Llm {
            provider: "local".to_owned(),
            model: "teacher".to_owned(),
        },
        LearningMaterial::TaskSet(vec![
            LessonTask::new(
                "shape-0",
                MaterialStimulus::Text("draw horizontal".to_owned()),
            )
            .with_expected_action("DrawHorizontal")
            .with_rubric("reward only if the action follows the relation"),
        ]),
        "learn coordinate relation actions",
        TeacherMode::FeedbackOnly,
        FeedbackPolicy::LlmScored,
    );

    let lesson = input.into_lesson("lesson-geometry-0");

    assert_eq!(lesson.lesson_id, "lesson-geometry-0");
    assert_eq!(lesson.task_count(), 1);
    assert!(lesson.is_trainable());
    assert!(lesson.allow_memory_write);
}

#[test]
fn teacher_off_learning_input_is_not_trainable() {
    let input = LearningInput::new(
        LearningSource::User,
        LearningMaterial::text("probe without feedback"),
        "probe AP without writing memory",
        TeacherMode::TeacherOff,
        FeedbackPolicy::NoFeedback,
    );

    let lesson = input.into_lesson("lesson-probe-0");

    assert!(!lesson.is_trainable());
    assert!(!lesson.allow_memory_write);
}

#[test]
fn skill_report_exports_manifest_only_after_verified_holdout() {
    let mut report = SkillReport::new(
        "skill.demo",
        "lesson-demo",
        SkillBoundary::new("demo", 1, 8),
    );
    report.record_train_attempt(Feedback::Reward);
    report.record_holdout_attempt(Feedback::Reward);

    let report = report.finalize();
    let manifest = report.to_manifest("demo").unwrap();

    assert_eq!(report.status, SkillReportStatus::Verified);
    assert_eq!(manifest.skill_id, "skill.demo");
    assert_eq!(manifest.evidence.train_accuracy, 1.0);
    assert_eq!(manifest.evidence.holdout_accuracy, 1.0);
    assert_eq!(manifest.evidence.sample_count, 2);
}

#[test]
fn artifact_refs_cover_image_and_audio_outputs() {
    let image = ArtifactRef::new("img-0", ArtifactKind::Image, "file:///tmp/result.png")
        .with_mime_type("image/png");
    let audio = ArtifactRef::new("aud-0", ArtifactKind::Audio, "file:///tmp/result.wav")
        .with_mime_type("audio/wav");

    assert_eq!(image.kind, ArtifactKind::Image);
    assert_eq!(image.mime_type.as_deref(), Some("image/png"));
    assert_eq!(audio.kind, ArtifactKind::Audio);
    assert_eq!(audio.mime_type.as_deref(), Some("audio/wav"));
}

#[test]
fn external_agent_request_plans_and_runs_lesson() {
    let task = LessonTask::new(
        "agent-task-0",
        MaterialStimulus::Text("red circle".to_owned()),
    )
    .with_expected_action("ClassifyRedCircle");
    let mut request = AgentLearningRequest::user_text("agent-0", "learn text observation");
    request.material = LearningMaterial::TaskSet(vec![task]);
    request.desired_outputs.push(MediaOutput::Trace);

    let response = PlannedLesson.plan_lesson(request);
    let report = LessonRunner::new("agent").run(&response.lesson);

    assert_eq!(response.request_id, "agent-0");
    assert_eq!(response.lesson.task_count(), 1);
    assert_eq!(report.train_attempts.len(), 1);
    assert_eq!(report.holdout_attempts.len(), 1);
    assert_eq!(report.skill_report.holdout_accuracy(), 1.0);
    assert_eq!(report.holdout_attempts[0].response, "ClassifyRedCircle");
}

#[test]
fn llm_adapter_generates_curriculum_with_safety_notes() {
    let request = AgentLearningRequest::user_text("llm-safe", "learn relation words");
    let response = PlannedLesson.generate_curriculum(request);

    assert_eq!(response.request_id, "llm-safe");
    assert!(response.lesson.is_trainable());
    assert!(
        response
            .notes
            .iter()
            .any(|note| note.contains("curriculum"))
    );
}

#[test]
fn llm_adapter_rejects_teacher_off_memory_write() {
    let mut request = AgentLearningRequest::user_text("llm-unsafe", "leak answer");
    request.teacher_mode = TeacherMode::TeacherOff;

    let review = PlannedLesson.review_safety(&request);
    let response = PlannedLesson.generate_curriculum(request);

    assert!(!review.approved);
    assert!(review.teacher_off_answer_leak_risk);
    assert!(!response.lesson.is_trainable());
}

#[test]
fn llm_adapter_translates_tool_request_with_confirmation() {
    let plan = PlannedLesson.translate_tool_request(ToolTranslationRequest {
        request_id: "tool-0".to_owned(),
        user_text: "export runtime trace".to_owned(),
        allowed_tools: vec!["export_trace".to_owned()],
    });

    assert_eq!(plan.tool_name.as_deref(), Some("export_trace"));
    assert!(plan.requires_confirmation);
    assert_eq!(plan.arguments_json["text"], "export runtime trace");
}

#[test]
fn lesson_runner_uses_persistent_agent_memory_for_holdout() {
    let lesson = LearningInput::new(
        LearningSource::User,
        LearningMaterial::TaskSet(vec![
            LessonTask::new("shape-0", MaterialStimulus::Text("red circle".to_owned()))
                .with_expected_action("ClassifyRedCircle"),
        ]),
        "learn shape classification",
        TeacherMode::FeedbackOnly,
        FeedbackPolicy::AutomaticExaminer,
    )
    .into_lesson("lesson-shape");
    let mut agent = LearnableAgent::new("agent");
    let runner = LessonRunner::new("agent");

    let report = runner.run_with_agent(&mut agent, &lesson);

    assert_eq!(report.train_attempts[0].response, "ClassifyRedCircle");
    assert_eq!(report.holdout_attempts[0].response, "ClassifyRedCircle");
    assert_eq!(agent.memory_rows(), 1);
    assert!(report.taint_audit.passed());
    assert_eq!(report.skill_report.holdout_accuracy(), 1.0);
    assert_eq!(
        report.skill_report.artifacts[0].kind,
        ArtifactKind::SkillPackage
    );
}

#[test]
fn teacher_off_lesson_does_not_train_agent_memory() {
    let lesson = LearningInput::new(
        LearningSource::User,
        LearningMaterial::TaskSet(vec![
            LessonTask::new("shape-0", MaterialStimulus::Text("red circle".to_owned()))
                .with_expected_action("ClassifyRedCircle"),
        ]),
        "probe only",
        TeacherMode::TeacherOff,
        FeedbackPolicy::NoFeedback,
    )
    .into_lesson("lesson-probe");
    let mut agent = LearnableAgent::new("agent");
    let runner = LessonRunner::new("agent");

    let report = runner.run_with_agent(&mut agent, &lesson);

    assert_eq!(agent.memory_rows(), 0);
    assert_eq!(report.train_attempts[0].response, "ObserveText");
    assert_eq!(report.holdout_attempts[0].response, "ObserveText");
    assert_eq!(report.skill_report.holdout_accuracy(), 0.0);
}

#[test]
fn trained_agent_can_answer_later_teacher_off_probe() {
    let train_lesson = LearningInput::new(
        LearningSource::User,
        LearningMaterial::TaskSet(vec![
            LessonTask::new(
                "shape-train",
                MaterialStimulus::Text("red circle".to_owned()),
            )
            .with_expected_action("ClassifyRedCircle"),
        ]),
        "train shape",
        TeacherMode::FeedbackOnly,
        FeedbackPolicy::AutomaticExaminer,
    )
    .into_lesson("lesson-train");
    let probe_lesson = LearningInput::new(
        LearningSource::User,
        LearningMaterial::TaskSet(vec![
            LessonTask::new(
                "shape-probe",
                MaterialStimulus::Text("red circle".to_owned()),
            )
            .with_expected_action("ClassifyRedCircle"),
        ]),
        "probe shape",
        TeacherMode::TeacherOff,
        FeedbackPolicy::NoFeedback,
    )
    .into_lesson("lesson-probe");
    let mut agent = LearnableAgent::new("agent");
    let runner = LessonRunner::new("agent");

    runner.run_with_agent(&mut agent, &train_lesson);
    let memory_after_train = agent.memory_rows();
    let report = runner.run_with_agent(&mut agent, &probe_lesson);

    assert_eq!(report.train_attempts[0].response, "ClassifyRedCircle");
    assert_eq!(report.holdout_attempts[0].response, "ClassifyRedCircle");
    assert_eq!(agent.memory_rows(), memory_after_train);
    assert_eq!(report.skill_report.holdout_accuracy(), 1.0);
}

#[test]
fn skill_package_round_trip_preserves_teacher_off_recall() {
    let package_path = "target/test-learned-skill-package.json";
    let train_lesson = shape_lesson("lesson-train", TeacherMode::FeedbackOnly);
    let probe_lesson = shape_lesson("lesson-probe", TeacherMode::TeacherOff);
    let mut agent = LearnableAgent::new("agent");
    let runner = LessonRunner::new("agent");

    runner.run_with_agent(&mut agent, &train_lesson);
    write_skill_package(
        package_path,
        &agent.export_skill_package("shape-skill", "lesson-train"),
    )
    .unwrap();

    let loaded = LearnableAgent::from_skill_package(read_skill_package(package_path).unwrap());
    let mut loaded = loaded;
    let report = runner.run_probe_with_agent(&mut loaded, &probe_lesson);

    assert_eq!(report.holdout_attempts[0].response, "ClassifyRedCircle");
    assert_eq!(loaded.memory_rows(), 1);
}

#[test]
fn skill_package_round_trip_supports_bincode_internal_codec() {
    let package_path = "target/test-learned-skill-package.apbin";
    let train_lesson = shape_lesson("lesson-train-bincode", TeacherMode::FeedbackOnly);
    let probe_lesson = shape_lesson("lesson-probe-bincode", TeacherMode::TeacherOff);
    let mut agent = LearnableAgent::new("agent");
    let runner = LessonRunner::new("agent");

    runner.run_with_agent(&mut agent, &train_lesson);
    write_skill_package(
        package_path,
        &agent.export_skill_package("shape-skill", "lesson-train-bincode"),
    )
    .unwrap();
    let mut loaded = LearnableAgent::from_skill_package(read_skill_package(package_path).unwrap());
    let report = runner.run_probe_with_agent(&mut loaded, &probe_lesson);

    assert_eq!(report.holdout_attempts[0].response, "ClassifyRedCircle");
    assert_eq!(loaded.memory_rows(), 1);
}

#[test]
fn learning_session_probe_does_not_write_memory() {
    let train_lesson = shape_lesson("lesson-train", TeacherMode::FeedbackOnly);
    let probe_lesson = shape_lesson("lesson-probe", TeacherMode::TeacherOff);
    let mut session = LearningSession::new("agent");

    session.run_lessons(std::slice::from_ref(&train_lesson));
    let memory_after_train = session.agent().memory_rows();
    let message = session.reply_to_lesson(&probe_lesson, LearningIntent::Probe);

    assert_eq!(message.text, "ClassifyRedCircle");
    assert_eq!(session.agent().memory_rows(), memory_after_train);
    assert_eq!(session.reports().len(), 2);
}

#[test]
fn learning_session_persists_and_reloads_skill_package() {
    let package_path = "target/test-session-skill-package.apbin";
    let train_lesson = shape_lesson("lesson-train", TeacherMode::FeedbackOnly);
    let probe_lesson = shape_lesson("lesson-probe", TeacherMode::TeacherOff);
    let mut session = LearningSession::new("agent");

    session.run_lessons(std::slice::from_ref(&train_lesson));
    session
        .save_skill_package(package_path, "shape-skill", "lesson-train")
        .unwrap();
    let mut reloaded = LearningSession::load_or_new("agent", package_path).unwrap();
    let message = reloaded.reply_to_lesson(&probe_lesson, LearningIntent::Probe);

    assert_eq!(message.text, "ClassifyRedCircle");
    assert_eq!(reloaded.agent().memory_rows(), 1);
}

#[test]
fn probe_request_contract_is_teacher_off_only() {
    let request = AgentLearningRequest::probe_text("probe-0", "red circle");
    let response = PlannedLesson.plan_lesson(request.clone());

    assert_eq!(request.intent, LearningIntent::Probe);
    assert_eq!(request.teacher_mode, TeacherMode::TeacherOff);
    assert_eq!(request.feedback_policy, FeedbackPolicy::NoFeedback);
    assert_eq!(request.holdout.split, HoldoutSplit::AllProbe);
    assert!(!response.lesson.is_trainable());
}

#[test]
fn learning_request_json_can_be_imported_and_bundle_exported() {
    let request_path = "target/test-learning-request.json";
    let bundle_path = "target/test-learning-bundle.json";
    let request = AgentLearningRequest::user_text("agent-file-0", "prepare file lesson");

    write_lesson_bundle(request_path, &request).unwrap();
    let imported = read_learning_request(request_path).unwrap();
    let response = PlannedLesson.plan_lesson(imported);
    let report = LessonRunner::new("file").run(&response.lesson);

    write_lesson_bundle(bundle_path, &report).unwrap();
    assert!(std::fs::metadata(bundle_path).unwrap().is_file());
}

#[test]
fn external_agent_can_submit_learning_request_as_json_text() {
    let request = AgentLearningRequest::user_text("agent-stdio-0", "learn from stdin json");
    let json = serde_json::to_string(&request).unwrap();

    let imported = read_learning_request_text(&json).unwrap();
    let response = PlannedLesson.plan_lesson(imported);

    assert_eq!(response.request_id, "agent-stdio-0");
    assert!(response.lesson.is_trainable());
}

fn shape_lesson(id: &str, mode: TeacherMode) -> artificial_psyarch::learning::Lesson {
    LearningInput::new(
        LearningSource::User,
        LearningMaterial::TaskSet(vec![
            LessonTask::new("shape", MaterialStimulus::Text("red circle".to_owned()))
                .with_expected_action("ClassifyRedCircle"),
        ]),
        "shape",
        mode,
        feedback_policy_for_mode(mode),
    )
    .into_lesson(id)
}

fn feedback_policy_for_mode(mode: TeacherMode) -> FeedbackPolicy {
    match mode {
        TeacherMode::TeacherOff => FeedbackPolicy::NoFeedback,
        _ => FeedbackPolicy::AutomaticExaminer,
    }
}
