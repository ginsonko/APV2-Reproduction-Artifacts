use std::fs;

use artificial_psyarch::experiments::local_runner::{
    ExperimentRunConfig, run_all_experiment_records,
};
use artificial_psyarch::key_suite::{build_key_suite_bundle, write_key_suite_bundle};
use artificial_psyarch::repeat_map::local_runner::{LocalRunConfig, run_local_records};

#[test]
fn key_suite_maps_local_runs_to_eight_suites() {
    let experiments = run_all_experiment_records(ExperimentRunConfig { train_repeats: 8 });
    let repeat_map = run_local_records(&LocalRunConfig::default());
    let bundle = build_key_suite_bundle(&experiments, &repeat_map);

    assert_eq!(bundle.results.schema_id, "canonical_key_suite_local/v0.1");
    assert_eq!(bundle.results.status, "PASS");
    assert_eq!(bundle.results.suite_count, 8);
    assert_eq!(bundle.results.passed_count, 8);
    assert_eq!(bundle.claim_matrix.claims.len(), 8);
    assert_eq!(bundle.taint_audit.status, "PASS");
    assert!(bundle.taint_audit.summary.passed());
    assert_eq!(bundle.case_snapshots.snapshots.len(), 8);
    assert_eq!(
        bundle.reproduction.validation_command,
        "cargo run --bin paper_key_suite -- --out-dir .ap/reports/key_suite/paper_key_suite_local"
    );
    assert_eq!(bundle.reproduction.artifact_paths.len(), 7);
    assert!(
        bundle
            .case_snapshots
            .snapshots
            .iter()
            .all(|snapshot| snapshot.taint_audit.passed())
    );
    assert!(
        bundle
            .results
            .suites
            .iter()
            .all(|suite| suite.status == "PASS" && !suite.evidence.is_empty())
    );
}

#[test]
fn key_suite_writer_emits_report_claims_results_and_manifest() {
    let experiments = run_all_experiment_records(ExperimentRunConfig { train_repeats: 8 });
    let repeat_map = run_local_records(&LocalRunConfig::default());
    let bundle = build_key_suite_bundle(&experiments, &repeat_map);
    let out_dir = std::env::temp_dir().join(format!(
        "artificial_psyarch_key_suite_{}",
        std::process::id()
    ));
    let _ = fs::remove_dir_all(&out_dir);

    let written = write_key_suite_bundle(&out_dir, &bundle).unwrap();

    assert_eq!(written.manifest.files.len(), 7);
    for file_name in [
        "KEY_SUITE_RESULTS.json",
        "CLAIM_MATRIX.json",
        "TAINT_AUDIT_SUMMARY.json",
        "CASE_SNAPSHOTS.json",
        "REPRODUCTION_RECORD.json",
        "PROVENANCE.json",
        "KEY_SUITE_REPORT.md",
        "MANIFEST_SHA256.json",
    ] {
        assert!(out_dir.join(file_name).exists(), "{file_name} missing");
    }

    let report = fs::read_to_string(out_dir.join("KEY_SUITE_REPORT.md")).unwrap();
    assert!(report.contains("KS-006 PASS ElementaryMath NoSolver 0-4"));
    assert!(report.contains("KS-008 PASS AP learned skill registry"));
    assert!(report.contains("taint_audit: PASS"));
    assert!(report.contains("case_snapshots: 8"));
    assert!(report.contains("validation_command: cargo run --bin paper_key_suite"));

    fs::remove_dir_all(out_dir).unwrap();
}
