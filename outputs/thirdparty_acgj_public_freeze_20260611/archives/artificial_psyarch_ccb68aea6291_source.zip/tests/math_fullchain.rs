use artificial_psyarch::ap::TeacherMode;
use artificial_psyarch::math_fullchain::{
    MathFullChainLearner, MathFullChainWorld, run_math_fullchain_phase, train_math_fullchain,
};
use artificial_psyarch::skill_registry::{EvidenceGate, SkillContext, SkillEvidence};

#[test]
fn math_fullchain_learns_template_chain_and_holds_teacher_off() {
    let world = MathFullChainWorld::canonical();
    let mut learner = MathFullChainLearner::with_foundation_skills();

    let pretest = run_math_fullchain_phase(
        world.holdout_problems(),
        &world,
        &mut learner,
        TeacherMode::TeacherOff,
    );
    assert_eq!(pretest.accuracy, 0.0);

    let train = train_math_fullchain(&world, &mut learner, 8);
    assert_eq!(train.last().unwrap().accuracy, 1.0);

    let memory_before_holdout = learner.memory_rows();
    let holdout = run_math_fullchain_phase(
        world.holdout_problems(),
        &world,
        &mut learner,
        TeacherMode::TeacherOff,
    );

    assert_eq!(holdout.accuracy, 1.0);
    assert_eq!(learner.memory_rows(), memory_before_holdout);
    assert!(holdout.traces.iter().all(|trace| {
        !trace.feedback_visible_to_learner
            && !trace.memory_write_enabled
            && trace.examiner_private_scoring
            && !trace.answer_visible_to_learner
    }));
}

#[test]
fn math_fullchain_trace_exposes_equation_steps_not_whole_problem_lookup() {
    let world = MathFullChainWorld::canonical();
    let mut learner = MathFullChainLearner::with_foundation_skills();
    train_math_fullchain(&world, &mut learner, 8);

    let trace = learner
        .chain_trace(&world.holdout_problems()[0])
        .expect("trained template should produce chain trace");

    assert_eq!(
        trace,
        vec![
            "3x+5=26",
            "26-5=21",
            "21 repeated subtract 3 -> 7 groups",
            "3*7+5=26",
            "submit 7"
        ]
    );
    assert!(world.train_problems().iter().all(|problem| {
        problem.id != world.holdout_problems()[0].id
            && problem.total != world.holdout_problems()[0].total
    }));
}

#[test]
fn math_fullchain_exports_dependency_declared_skill_manifest() {
    let world = MathFullChainWorld::canonical();
    let mut learner = MathFullChainLearner::with_foundation_skills();
    train_math_fullchain(&world, &mut learner, 8);

    let registry = learner
        .register_with_foundation(SkillEvidence {
            train_accuracy: 1.0,
            holdout_accuracy: 1.0,
            sample_count: learner.memory_rows(),
        })
        .unwrap();

    assert!(
        registry
            .can_reload(
                "skill.math.linear_equation_word_problem.v1",
                &SkillContext::new("math_fullchain.linear_word_problem.controlled", 3),
                EvidenceGate::default(),
            )
            .is_ok()
    );
    let manifest = registry
        .get("skill.math.linear_equation_word_problem.v1")
        .unwrap();
    assert_eq!(manifest.dependencies.len(), 4);
}
