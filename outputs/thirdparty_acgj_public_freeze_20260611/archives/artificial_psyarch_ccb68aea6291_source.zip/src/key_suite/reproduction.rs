use serde::Serialize;

use crate::experiments::records::ExperimentRecords;
use crate::key_suite::ArtifactProvenance;
use crate::repeat_map::records::Records as RepeatMapRecords;

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct ReproductionRecord {
    pub schema_id: &'static str,
    pub route: &'static str,
    pub validation_command: &'static str,
    pub smoke_commands: Vec<&'static str>,
    pub rust_toolchain: String,
    pub protocol_version: &'static str,
    pub experiment_train_repeats: usize,
    pub repeatmap_train_repeats: usize,
    pub repeatmap_seeds: Vec<u64>,
    pub artifact_paths: Vec<&'static str>,
    pub report_paths: Vec<&'static str>,
    pub input_boundary: BoundaryRecord,
    pub teacher_off_boundary: BoundaryRecord,
    pub solver_boundary: BoundaryRecord,
    pub controls_summary: Vec<&'static str>,
    pub repository_status: RepositoryStatus,
    pub allowed_claim: &'static str,
    pub forbidden_claim: &'static str,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct BoundaryRecord {
    pub status: &'static str,
    pub summary: &'static str,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct RepositoryStatus {
    pub status: &'static str,
    pub git_commit: Option<String>,
    pub git_dirty: Option<bool>,
    pub archive_sha256: Option<String>,
}

impl ReproductionRecord {
    pub fn from_inputs(
        experiments: &ExperimentRecords,
        repeat_map: &RepeatMapRecords,
        provenance: &ArtifactProvenance,
    ) -> Self {
        Self {
            schema_id: "apv21_reproduction_record/v0.1",
            route: "AP-Core clean-room local",
            validation_command: "cargo run --bin paper_key_suite -- --out-dir .ap/reports/key_suite/paper_key_suite_local",
            smoke_commands: vec![
                "cargo test",
                "cargo clippy --all-targets --all-features -- -D warnings",
                "cargo crap",
            ],
            rust_toolchain: rust_toolchain(),
            protocol_version: experiments.schema_id,
            experiment_train_repeats: experiment_train_repeats(experiments),
            repeatmap_train_repeats: repeat_map.train_repeats,
            repeatmap_seeds: repeat_map.seeds.clone(),
            artifact_paths: artifact_path_list(),
            report_paths: vec!["KEY_SUITE_REPORT.md"],
            input_boundary: clean_boundary("synthetic AP-Core inputs; no hidden answer fields"),
            teacher_off_boundary: clean_boundary(
                "teacher-off phases expose no feedback, no answer, and no memory writes",
            ),
            solver_boundary: clean_boundary(
                "learner records use private examiner scoring and no visible solver path",
            ),
            controls_summary: controls_summary(),
            repository_status: RepositoryStatus::from_provenance(provenance),
            allowed_claim: "AP-Core local evidence supports bounded white-box process skills under audited teacher-off/no-leakage conditions.",
            forbidden_claim: "Does not prove complete AGI, human-equivalent consciousness, open-world perception, or unrestricted mathematics.",
        }
    }
}

impl RepositoryStatus {
    fn from_provenance(provenance: &ArtifactProvenance) -> Self {
        Self {
            status: repository_status(provenance),
            git_commit: provenance.git_commit.clone(),
            git_dirty: provenance.git_dirty,
            archive_sha256: provenance.archive_sha256.clone(),
        }
    }
}

fn clean_boundary(summary: &'static str) -> BoundaryRecord {
    BoundaryRecord {
        status: "clean",
        summary,
    }
}

fn repository_status(provenance: &ArtifactProvenance) -> &'static str {
    match (provenance.git_commit.as_ref(), provenance.git_dirty) {
        (Some(_), Some(false)) => "git_clean",
        (Some(_), Some(true)) => "git_dirty",
        (Some(_), None) => "git_unknown_dirty_status",
        (None, _) => "not_git_repository",
    }
}

fn rust_toolchain() -> String {
    option_env!("RUSTC_VERSION")
        .unwrap_or("captured_by_cargo_toolchain")
        .to_owned()
}

fn experiment_train_repeats(experiments: &ExperimentRecords) -> usize {
    experiments
        .experiments
        .iter()
        .map(|run| run.train_repeats)
        .max()
        .unwrap_or_default()
}

fn artifact_path_list() -> Vec<&'static str> {
    vec![
        "KEY_SUITE_RESULTS.json",
        "CLAIM_MATRIX.json",
        "TAINT_AUDIT_SUMMARY.json",
        "CASE_SNAPSHOTS.json",
        "REPRODUCTION_RECORD.json",
        "PROVENANCE.json",
        "MANIFEST_SHA256.json",
    ]
}

fn controls_summary() -> Vec<&'static str> {
    vec![
        "RepeatMap fixed heuristic control remains separate from AP-style learner",
        "pretest phases run teacher-off before training",
        "package reload holdout verifies skill persistence boundary",
    ]
}
