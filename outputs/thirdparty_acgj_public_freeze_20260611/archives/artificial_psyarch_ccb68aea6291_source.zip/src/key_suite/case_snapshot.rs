use linkme::distributed_slice;
use serde::Serialize;

use crate::core::ap::{AuditTrace, TaintAuditSummary};
use crate::experiments::records::{ExperimentEvent, ExperimentRecords, ExperimentRun, PhaseRecord};
use crate::repeat_map::records::{
    EventRecord as RepeatMapEvent, GroupRun, Records as RepeatMapRecords,
};

#[derive(Debug, Clone, PartialEq, Serialize)]
pub struct CaseSnapshotBundle {
    pub schema_id: &'static str,
    pub route: &'static str,
    pub snapshots: Vec<CaseSnapshot>,
}

#[derive(Debug, Clone, PartialEq, Serialize)]
pub struct CaseSnapshot {
    pub schema_id: &'static str,
    pub claim_id: &'static str,
    pub route: &'static str,
    pub phase: String,
    pub case_id: String,
    pub visible_observation: Vec<String>,
    pub state_pool_snapshot_ref: String,
    pub memory_recall_rows: Vec<String>,
    pub action_candidates: Vec<String>,
    pub selected_action: String,
    pub actuator_event: ActuatorEvent,
    pub examiner_private_result: ExaminerPrivateResult,
    pub feedback_to_learner: Option<String>,
    pub memory_write_after_test_action: usize,
    pub teacher_off_signal: TeacherOffSignal,
    pub taint_audit: TaintAuditSummary,
    pub component_trace: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct ActuatorEvent {
    pub execution_result: &'static str,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct ExaminerPrivateResult {
    pub stored_for_report_only: bool,
    pub matched: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct TeacherOffSignal {
    pub state_items: Vec<String>,
    pub action_biases: Vec<String>,
    pub feedback: Vec<String>,
}

pub fn build_case_snapshot_bundle(
    experiments: &ExperimentRecords,
    repeat_map: &RepeatMapRecords,
) -> CaseSnapshotBundle {
    CaseSnapshotBundle {
        schema_id: "apv21_case_snapshot_bundle/v0.1",
        route: "AP-Core clean-room local",
        snapshots: representative_snapshots(experiments, repeat_map),
    }
}

fn representative_snapshots(
    experiments: &ExperimentRecords,
    repeat_map: &RepeatMapRecords,
) -> Vec<CaseSnapshot> {
    sorted_snapshot_registry()
        .iter()
        .filter_map(|spec| build_snapshot(spec, experiments, repeat_map))
        .collect()
}

fn sorted_snapshot_registry() -> Vec<&'static SnapshotSpec> {
    let mut registry = SNAPSHOT_REGISTRY.iter().collect::<Vec<_>>();
    registry.sort_by_key(|spec| spec.claim_id);
    registry
}

fn build_snapshot(
    spec: &SnapshotSpec,
    experiments: &ExperimentRecords,
    repeat_map: &RepeatMapRecords,
) -> Option<CaseSnapshot> {
    match spec.source {
        SnapshotSource::Experiment { experiment_id } => {
            experiment_snapshot(spec.claim_id, experiments, experiment_id)
        }
        SnapshotSource::RepeatMap { group_id, phase } => {
            repeat_map_snapshot(spec.claim_id, repeat_map, group_id, phase)
        }
    }
}

fn experiment_snapshot(
    claim_id: &'static str,
    records: &ExperimentRecords,
    experiment_id: &'static str,
) -> Option<CaseSnapshot> {
    let run = records
        .experiments
        .iter()
        .find(|run| run.experiment_id == experiment_id)?;
    let (phase, event) = first_event_in_phase(run, "holdout")?;
    Some(snapshot_from_experiment(claim_id, run, phase, event))
}

fn repeat_map_snapshot(
    claim_id: &'static str,
    records: &RepeatMapRecords,
    group_id: &'static str,
    phase_name: &'static str,
) -> Option<CaseSnapshot> {
    let group = records
        .seed_runs
        .iter()
        .flat_map(|run| run.groups.iter())
        .find(|group| group.group_id == group_id)?;
    let event = group.phases.get(phase_name)?.first()?;
    Some(snapshot_from_repeat_map(claim_id, group, phase_name, event))
}

fn first_event_in_phase<'a>(
    run: &'a ExperimentRun,
    phase_name: &str,
) -> Option<(&'a PhaseRecord, &'a ExperimentEvent)> {
    let phase = run.phases.iter().find(|phase| phase.phase == phase_name)?;
    phase.events.first().map(|event| (phase, event))
}

fn snapshot_from_experiment(
    claim_id: &'static str,
    run: &ExperimentRun,
    phase: &PhaseRecord,
    event: &ExperimentEvent,
) -> CaseSnapshot {
    let selected_action = event.response.clone();
    let visible_observation = vec![format!("stimulus_id={}", event.stimulus_id)];
    CaseSnapshot {
        schema_id: "apv21_case_snapshot/v1",
        claim_id,
        route: "AP-Core",
        phase: phase.phase.to_owned(),
        case_id: format!(
            "{}::{}::{}",
            run.experiment_id, phase.phase, event.event_index
        ),
        state_pool_snapshot_ref: format!(
            "experiment://{}/{}/{}",
            run.experiment_id, phase.phase, event.event_index
        ),
        memory_recall_rows: Vec::new(),
        action_candidates: vec![selected_action.clone()],
        selected_action: selected_action.clone(),
        actuator_event: ActuatorEvent {
            execution_result: "committed",
        },
        examiner_private_result: ExaminerPrivateResult {
            stored_for_report_only: true,
            matched: event.matched,
        },
        feedback_to_learner: event
            .feedback_to_learner
            .map(|feedback| format!("{feedback:?}")),
        memory_write_after_test_action: usize::from(event.learning_enabled),
        teacher_off_signal: teacher_off_signal(&visible_observation, &selected_action),
        taint_audit: trace_taint_audit(&event.trace),
        component_trace: experiment_component_trace(event),
        visible_observation,
    }
}

fn snapshot_from_repeat_map(
    claim_id: &'static str,
    group: &GroupRun,
    phase: &'static str,
    event: &RepeatMapEvent,
) -> CaseSnapshot {
    let selected_action = format!("{:?}", event.selected_action);
    let visible_observation = repeat_map_observation(event);
    CaseSnapshot {
        schema_id: "apv21_case_snapshot/v1",
        claim_id,
        route: "AP-Core",
        phase: phase.to_owned(),
        case_id: format!(
            "{}::seed{}::{}::{}",
            group.group_id, event.seed, phase, event.event_index
        ),
        state_pool_snapshot_ref: format!(
            "repeatmap://{}/seed/{}/{}/{}",
            group.group_id, event.seed, phase, event.event_index
        ),
        memory_recall_rows: vec![format!("memory_rows={}", event.trace.memory_rows)],
        action_candidates: event
            .trace
            .action_scores
            .keys()
            .map(|action| format!("{action:?}"))
            .collect(),
        selected_action: selected_action.clone(),
        actuator_event: ActuatorEvent {
            execution_result: "committed",
        },
        examiner_private_result: ExaminerPrivateResult {
            stored_for_report_only: event.scorer_after_commit,
            matched: event.matched,
        },
        feedback_to_learner: event
            .feedback_to_learner
            .map(|feedback| format!("{feedback:?}")),
        memory_write_after_test_action: usize::from(event.learning_enabled),
        teacher_off_signal: teacher_off_signal(&visible_observation, &selected_action),
        taint_audit: trace_taint_audit(&event.trace.audit),
        component_trace: repeat_map_component_trace(event),
        visible_observation,
    }
}

fn repeat_map_observation(event: &RepeatMapEvent) -> Vec<String> {
    vec![
        format!("state_id={}", event.state_id),
        format!("shape={}", event.features.shape),
        format!("color={}", event.features.color),
        format!("mark={}", event.features.mark),
        format!("slot={}", event.features.slot),
    ]
}

fn teacher_off_signal(visible_observation: &[String], selected_action: &str) -> TeacherOffSignal {
    TeacherOffSignal {
        state_items: visible_observation.to_vec(),
        action_biases: vec![selected_action.to_owned()],
        feedback: Vec::new(),
    }
}

fn trace_taint_audit(trace: &AuditTrace) -> TaintAuditSummary {
    TaintAuditSummary::from_teacher_off_traces([trace])
}

fn experiment_component_trace(event: &ExperimentEvent) -> Vec<String> {
    vec![
        format!("response={}", event.response),
        format!("matched={}", event.matched),
        format!("audit={:?}", event.trace),
    ]
}

fn repeat_map_component_trace(event: &RepeatMapEvent) -> Vec<String> {
    vec![
        format!("reason={}", event.trace.reason),
        format!("valid_action={}", event.valid_action),
        format!("matched={}", event.matched),
        format!("audit={:?}", event.trace.audit),
    ]
}

#[derive(Debug, Clone, Copy)]
struct SnapshotSpec {
    claim_id: &'static str,
    source: SnapshotSource,
}

#[derive(Debug, Clone, Copy)]
enum SnapshotSource {
    Experiment {
        experiment_id: &'static str,
    },
    RepeatMap {
        group_id: &'static str,
        phase: &'static str,
    },
}

#[distributed_slice]
static SNAPSHOT_REGISTRY: [SnapshotSpec] = [..];

#[distributed_slice(SNAPSHOT_REGISTRY)]
static CORE_001_SNAPSHOT: SnapshotSpec =
    repeat_map_snapshot_spec("CORE-001", "G1B_RM_STRICT_CORE_BRIDGE", "package_reload");

#[distributed_slice(SNAPSHOT_REGISTRY)]
static CORE_002_SNAPSHOT: SnapshotSpec =
    repeat_map_snapshot_spec("CORE-002", "G1A_RM_AP_STYLE", "alpha_holdout");

#[distributed_slice(SNAPSHOT_REGISTRY)]
static CORE_003_SNAPSHOT: SnapshotSpec = experiment_snapshot_spec("CORE-003", "feature_combo");

#[distributed_slice(SNAPSHOT_REGISTRY)]
static CORE_004_SNAPSHOT: SnapshotSpec = experiment_snapshot_spec("CORE-004", "count_loop");

#[distributed_slice(SNAPSHOT_REGISTRY)]
static CORE_005_SNAPSHOT: SnapshotSpec = experiment_snapshot_spec("CORE-005", "sensor_assoc");

#[distributed_slice(SNAPSHOT_REGISTRY)]
static CORE_006_SNAPSHOT: SnapshotSpec =
    experiment_snapshot_spec("CORE-006", "math_slice_vertical_division");

#[distributed_slice(SNAPSHOT_REGISTRY)]
static CORE_007_SNAPSHOT: SnapshotSpec = experiment_snapshot_spec("CORE-007", "math_fullchain");

#[distributed_slice(SNAPSHOT_REGISTRY)]
static CORE_008_SNAPSHOT: SnapshotSpec =
    repeat_map_snapshot_spec("CORE-008", "G1B_RM_STRICT_CORE_BRIDGE", "package_reload");

const fn experiment_snapshot_spec(
    claim_id: &'static str,
    experiment_id: &'static str,
) -> SnapshotSpec {
    SnapshotSpec {
        claim_id,
        source: SnapshotSource::Experiment { experiment_id },
    }
}

const fn repeat_map_snapshot_spec(
    claim_id: &'static str,
    group_id: &'static str,
    phase: &'static str,
) -> SnapshotSpec {
    SnapshotSpec {
        claim_id,
        source: SnapshotSource::RepeatMap { group_id, phase },
    }
}
