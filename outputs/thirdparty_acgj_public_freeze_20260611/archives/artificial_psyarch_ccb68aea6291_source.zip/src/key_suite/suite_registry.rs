use std::collections::BTreeMap;

use linkme::distributed_slice;

use crate::experiments::records::{ExperimentRecords, ExperimentRun};
use crate::repeat_map::records::{Records as RepeatMapRecords, SeedSummary};

use super::KeySuiteResult;

#[derive(Debug, Clone, Copy)]
pub(super) struct ClaimSpec {
    pub suite_id: &'static str,
    pub claim_id: &'static str,
    pub title: &'static str,
    pub supports: &'static str,
    pub does_not_support: &'static str,
}

#[derive(Debug, Clone, Copy)]
pub(super) struct KeySuiteRegistration {
    pub spec: ClaimSpec,
    build: KeySuiteBuilder,
}

type ExperimentIndex<'a> = BTreeMap<&'static str, &'a ExperimentRun>;
type KeySuiteBuilder = fn(&ExperimentIndex<'_>, &RepeatMapRecords) -> KeySuiteResult;

#[distributed_slice]
static KEY_SUITE_REGISTRY: [KeySuiteRegistration] = [..];

#[distributed_slice(KEY_SUITE_REGISTRY)]
static KS_001_STRICT_CORE: KeySuiteRegistration = KeySuiteRegistration {
    spec: ClaimSpec {
        suite_id: "KS-001",
        claim_id: "CORE-001",
        title: "StrictCore-0 foundation boundary suite",
        supports: "minimal action-feedback-memory and reload boundary",
        does_not_support: "open-world general learning",
    },
    build: build_ks001_strict_core,
};

#[distributed_slice(KEY_SUITE_REGISTRY)]
static KS_002_LOOP_LEARN: KeySuiteRegistration = KeySuiteRegistration {
    spec: ClaimSpec {
        suite_id: "KS-002",
        claim_id: "CORE-002",
        title: "LoopLearn-1 blind action-feedback closed loop",
        supports: "action consequences can bias later choices",
        does_not_support: "blind learning for arbitrary tasks",
    },
    build: build_ks002_loop_learn,
};

#[distributed_slice(KEY_SUITE_REGISTRY)]
static KS_003_FEATURE_COMBO: KeySuiteRegistration = experiment_suite_registration(
    "KS-003",
    "CORE-003",
    "LoopLearn-2 compositional feature generalization",
    "local numeric feature contribution composition",
    "complete semantic representation",
    build_ks003_feature_combo,
);

#[distributed_slice(KEY_SUITE_REGISTRY)]
static KS_004_COUNT_LOOP: KeySuiteRegistration = experiment_suite_registration(
    "KS-004",
    "CORE-004",
    "CountLoop-0 object quantity and add/remove acquisition",
    "small controlled quantity and add/remove transfer",
    "unbounded natural number concept",
    build_ks004_count_loop,
);

#[distributed_slice(KEY_SUITE_REGISTRY)]
static KS_005_SENSOR_ASSOC: KeySuiteRegistration = experiment_suite_registration(
    "KS-005",
    "CORE-005",
    "Multimodal NoInject0 raw sensor feature association",
    "raw byte feature to label association under teacher-off query",
    "open-world OCR, ASR, or object recognition",
    build_ks005_sensor_assoc,
);

#[distributed_slice(KEY_SUITE_REGISTRY)]
static KS_006_NO_SOLVER_MATH: KeySuiteRegistration = experiment_suite_registration(
    "KS-006",
    "CORE-006",
    "ElementaryMath NoSolver 0-4",
    "controlled no-solver arithmetic process slices",
    "complete elementary mathematics",
    build_ks006_no_solver_math,
);

#[distributed_slice(KEY_SUITE_REGISTRY)]
static KS_007_MATH_FULLCHAIN: KeySuiteRegistration = experiment_suite_registration(
    "KS-007",
    "CORE-007",
    "Math-FullChain0/1 equation word problem chain",
    "controlled linear equation word-problem process chain",
    "arbitrary natural-language algebra word problems",
    build_ks007_math_fullchain,
);

#[distributed_slice(KEY_SUITE_REGISTRY)]
static KS_008_SKILL_REGISTRY: KeySuiteRegistration = KeySuiteRegistration {
    spec: ClaimSpec {
        suite_id: "KS-008",
        claim_id: "CORE-008",
        title: "AP learned skill registry",
        supports: "validated skill dependency declaration and reload boundary",
        does_not_support: "universal solver or answer table",
    },
    build: build_ks008_skill_registry,
};

pub(super) fn build_key_suite_results(
    experiments: &ExperimentRecords,
    repeat_map: &RepeatMapRecords,
) -> Vec<KeySuiteResult> {
    let experiment_index = index_experiments(experiments);
    sorted_key_suite_registry()
        .iter()
        .map(|entry| (entry.build)(&experiment_index, repeat_map))
        .collect()
}

pub(super) fn sorted_key_suite_registry() -> Vec<&'static KeySuiteRegistration> {
    let mut registry = KEY_SUITE_REGISTRY.iter().collect::<Vec<_>>();
    registry.sort_by_key(|entry| entry.spec.suite_id);
    registry
}

const fn experiment_suite_registration(
    suite_id: &'static str,
    claim_id: &'static str,
    title: &'static str,
    supports: &'static str,
    does_not_support: &'static str,
    build: KeySuiteBuilder,
) -> KeySuiteRegistration {
    KeySuiteRegistration {
        spec: ClaimSpec {
            suite_id,
            claim_id,
            title,
            supports,
            does_not_support,
        },
        build,
    }
}

fn build_ks001_strict_core(
    _index: &ExperimentIndex<'_>,
    repeat_map: &RepeatMapRecords,
) -> KeySuiteResult {
    suite_result(
        KS_001_STRICT_CORE.spec,
        repeat_map.validation_errors.is_empty() && strict_core_reload_passes(repeat_map),
        strict_core_evidence(repeat_map),
    )
}

fn build_ks002_loop_learn(
    _index: &ExperimentIndex<'_>,
    repeat_map: &RepeatMapRecords,
) -> KeySuiteResult {
    suite_result(
        KS_002_LOOP_LEARN.spec,
        repeat_map.validation_errors.is_empty() && loop_learn_passes(repeat_map),
        loop_learn_evidence(repeat_map),
    )
}

fn build_ks003_feature_combo(
    index: &ExperimentIndex<'_>,
    _repeat_map: &RepeatMapRecords,
) -> KeySuiteResult {
    experiment_suite_result(KS_003_FEATURE_COMBO.spec, index, &["feature_combo"])
}

fn build_ks004_count_loop(
    index: &ExperimentIndex<'_>,
    _repeat_map: &RepeatMapRecords,
) -> KeySuiteResult {
    experiment_suite_result(KS_004_COUNT_LOOP.spec, index, &["count_loop"])
}

fn build_ks005_sensor_assoc(
    index: &ExperimentIndex<'_>,
    _repeat_map: &RepeatMapRecords,
) -> KeySuiteResult {
    experiment_suite_result(KS_005_SENSOR_ASSOC.spec, index, &["sensor_assoc"])
}

fn build_ks006_no_solver_math(
    index: &ExperimentIndex<'_>,
    _repeat_map: &RepeatMapRecords,
) -> KeySuiteResult {
    experiment_suite_result(
        KS_006_NO_SOLVER_MATH.spec,
        index,
        &[
            "math_slice_add_sub",
            "math_slice_mul_div",
            "math_slice_vertical_add_sub",
            "math_slice_vertical_multiply",
            "math_slice_vertical_division",
        ],
    )
}

fn build_ks007_math_fullchain(
    index: &ExperimentIndex<'_>,
    _repeat_map: &RepeatMapRecords,
) -> KeySuiteResult {
    experiment_suite_result(KS_007_MATH_FULLCHAIN.spec, index, &["math_fullchain"])
}

fn build_ks008_skill_registry(
    index: &ExperimentIndex<'_>,
    repeat_map: &RepeatMapRecords,
) -> KeySuiteResult {
    suite_result(
        KS_008_SKILL_REGISTRY.spec,
        experiment_passes(index, "math_fullchain") && repeat_map.validation_errors.is_empty(),
        vec![
            "math_fullchain exports dependency-declared skill manifest".to_owned(),
            "repeat_map validates package reload under teacher-off".to_owned(),
        ],
    )
}

fn suite_result(spec: ClaimSpec, passed: bool, evidence: Vec<String>) -> KeySuiteResult {
    KeySuiteResult {
        id: spec.suite_id,
        claim_id: spec.claim_id,
        title: spec.title,
        status: if passed { "PASS" } else { "FAIL" },
        evidence,
    }
}

fn experiment_suite_result(
    spec: ClaimSpec,
    index: &ExperimentIndex<'_>,
    required_ids: &[&'static str],
) -> KeySuiteResult {
    let evidence = required_ids
        .iter()
        .map(|id| experiment_evidence(index, id))
        .collect::<Vec<_>>();
    let passed = required_ids.iter().all(|id| experiment_passes(index, id));
    suite_result(spec, passed, evidence)
}

fn index_experiments(records: &ExperimentRecords) -> ExperimentIndex<'_> {
    records
        .experiments
        .iter()
        .map(|run| (run.experiment_id, run))
        .collect()
}

fn experiment_passes(index: &ExperimentIndex<'_>, id: &str) -> bool {
    index
        .get(id)
        .map(|run| {
            run.summary.train_last_round_accuracy == 1.0 && run.summary.holdout_accuracy == 1.0
        })
        .unwrap_or(false)
}

fn experiment_evidence(index: &ExperimentIndex<'_>, id: &str) -> String {
    match index.get(id) {
        Some(run) => format!(
            "{id}: train_last={:.3}, holdout={:.3}, memory_rows={}",
            run.summary.train_last_round_accuracy,
            run.summary.holdout_accuracy,
            run.summary.memory_rows_final
        ),
        None => format!("{id}: missing"),
    }
}

fn strict_core_reload_passes(records: &RepeatMapRecords) -> bool {
    summaries_for_group(records, "G1B_RM_STRICT_CORE_BRIDGE").all(|summary| {
        summary.alpha_holdout_accuracy == 1.0 && summary.package_reload_accuracy == 1.0
    })
}

fn loop_learn_passes(records: &RepeatMapRecords) -> bool {
    ["G1A_RM_AP_STYLE", "G1B_RM_STRICT_CORE_BRIDGE"]
        .into_iter()
        .flat_map(|group_id| summaries_for_group(records, group_id))
        .all(|summary| {
            summary.alpha_holdout_accuracy == 1.0 && summary.beta_holdout_accuracy == 1.0
        })
}

fn strict_core_evidence(records: &RepeatMapRecords) -> Vec<String> {
    summaries_for_group(records, "G1B_RM_STRICT_CORE_BRIDGE")
        .map(|summary| {
            format!(
                "seed {} strict_core alpha_holdout={:.3}, reload={:.3}",
                summary.seed, summary.alpha_holdout_accuracy, summary.package_reload_accuracy
            )
        })
        .collect()
}

fn loop_learn_evidence(records: &RepeatMapRecords) -> Vec<String> {
    ["G1A_RM_AP_STYLE", "G1B_RM_STRICT_CORE_BRIDGE"]
        .into_iter()
        .flat_map(|group_id| summaries_for_group(records, group_id))
        .map(|summary| {
            format!(
                "{} seed {} alpha_holdout={:.3}, beta_holdout={:.3}",
                summary.group_id,
                summary.seed,
                summary.alpha_holdout_accuracy,
                summary.beta_holdout_accuracy
            )
        })
        .collect()
}

fn summaries_for_group<'a>(
    records: &'a RepeatMapRecords,
    group_id: &'static str,
) -> impl Iterator<Item = &'a SeedSummary> {
    records
        .summary
        .seed_summaries
        .iter()
        .filter(move |summary| summary.group_id == group_id)
}
