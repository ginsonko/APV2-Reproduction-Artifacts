use serde::{Deserialize, Serialize};

use crate::learning::{ArtifactKind, ArtifactRef, MediaOutput};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct MediaRenderPlan {
    pub channel: MediaOutput,
    pub artifact: ArtifactRef,
    pub terminal_uri: String,
    pub inline_capable: bool,
}

pub trait MediaRenderer {
    fn plan_render(&self, artifact: ArtifactRef) -> Option<MediaRenderPlan>;
}

#[derive(Debug, Default, Clone, Copy)]
pub struct TermwizMediaRenderer;

impl MediaRenderer for TermwizMediaRenderer {
    fn plan_render(&self, artifact: ArtifactRef) -> Option<MediaRenderPlan> {
        let channel = artifact_channel(artifact.kind)?;
        Some(MediaRenderPlan {
            terminal_uri: format!("termwiz://{}", artifact.uri),
            inline_capable: true,
            artifact,
            channel,
        })
    }
}

fn artifact_channel(kind: ArtifactKind) -> Option<MediaOutput> {
    ARTIFACT_CHANNELS
        .iter()
        .find_map(|(artifact_kind, output)| (*artifact_kind == kind).then_some(*output))
}

const ARTIFACT_CHANNELS: [(ArtifactKind, MediaOutput); 4] = [
    (ArtifactKind::Image, MediaOutput::Image),
    (ArtifactKind::Audio, MediaOutput::Audio),
    (ArtifactKind::Text, MediaOutput::Text),
    (ArtifactKind::Trace, MediaOutput::Trace),
];
