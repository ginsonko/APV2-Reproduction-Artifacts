use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum GlPermission {
    LearnMemory,
    ProbeRuntime,
    ExportTrace,
    RenderMedia,
    UseTool,
    ExecuteAction,
    ImportSkill,
    ShareSkill,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PermissionSet {
    granted: Vec<GlPermission>,
}

impl PermissionSet {
    pub fn new(granted: impl IntoIterator<Item = GlPermission>) -> Self {
        let mut granted = granted.into_iter().collect::<Vec<_>>();
        granted.sort_by_key(|permission| *permission as u8);
        granted.dedup();
        Self { granted }
    }

    pub fn interactive_default() -> Self {
        Self::new([
            GlPermission::LearnMemory,
            GlPermission::ProbeRuntime,
            GlPermission::ExportTrace,
            GlPermission::RenderMedia,
            GlPermission::UseTool,
        ])
    }

    pub fn contains(&self, permission: GlPermission) -> bool {
        self.granted.contains(&permission)
    }

    pub fn decide(&self, permission: GlPermission) -> PermissionDecision {
        if self.contains(permission) {
            PermissionDecision::Allowed
        } else {
            PermissionDecision::Denied { permission }
        }
    }
}

impl Default for PermissionSet {
    fn default() -> Self {
        Self::interactive_default()
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum PermissionDecision {
    Allowed,
    Denied { permission: GlPermission },
}

impl PermissionDecision {
    pub fn allowed(self) -> bool {
        matches!(self, Self::Allowed)
    }
}
