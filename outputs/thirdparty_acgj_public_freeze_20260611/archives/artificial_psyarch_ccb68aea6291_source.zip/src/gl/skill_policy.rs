use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

use crate::skill_registry::{EvidenceGate, SkillContext, SkillManifest};

use super::permissions::{GlPermission, PermissionDecision, PermissionSet};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SignedSkillPackage {
    pub manifest: SkillManifest,
    pub signature: String,
}

impl SignedSkillPackage {
    pub fn sign(manifest: SkillManifest, signer: &str) -> Self {
        let signature = signature_for(&manifest, signer);
        Self {
            manifest,
            signature,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SkillPackagePolicy {
    pub signer: String,
    pub require_signature: bool,
    pub gate: EvidenceGate,
}

impl SkillPackagePolicy {
    pub fn new(signer: impl Into<String>, gate: EvidenceGate) -> Self {
        Self {
            signer: signer.into(),
            require_signature: true,
            gate,
        }
    }

    pub fn review_import(
        &self,
        package: &SignedSkillPackage,
        context: &SkillContext,
        permissions: &PermissionSet,
    ) -> Result<SkillPolicyDecision, SkillPolicyError> {
        if let Some(decision) = import_permission_denial(permissions) {
            return Ok(decision);
        }
        self.verify_signature(package)?;
        self.verify_evidence(package)?;
        verify_boundary(package, context)?;
        Ok(SkillPolicyDecision::Allowed)
    }

    fn verify_signature(&self, package: &SignedSkillPackage) -> Result<(), SkillPolicyError> {
        let invalid = self.require_signature
            && package.signature != signature_for(&package.manifest, &self.signer);
        (!invalid)
            .then_some(())
            .ok_or(SkillPolicyError::InvalidSignature)
    }

    fn verify_evidence(&self, package: &SignedSkillPackage) -> Result<(), SkillPolicyError> {
        package
            .manifest
            .evidence
            .meets(self.gate)
            .then_some(())
            .ok_or(SkillPolicyError::InsufficientEvidence)
    }

    pub fn review_share(&self, permissions: &PermissionSet) -> SkillPolicyDecision {
        match permissions.decide(GlPermission::ShareSkill) {
            PermissionDecision::Allowed => SkillPolicyDecision::Allowed,
            denied => SkillPolicyDecision::Denied { permission: denied },
        }
    }
}

fn import_permission_denial(permissions: &PermissionSet) -> Option<SkillPolicyDecision> {
    match permissions.decide(GlPermission::ImportSkill) {
        PermissionDecision::Allowed => None,
        permission => Some(SkillPolicyDecision::Denied { permission }),
    }
}

fn verify_boundary(
    package: &SignedSkillPackage,
    context: &SkillContext,
) -> Result<(), SkillPolicyError> {
    package
        .manifest
        .boundary
        .contains(context)
        .then_some(())
        .ok_or(SkillPolicyError::BoundaryMismatch)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum SkillPolicyDecision {
    Allowed,
    Denied { permission: PermissionDecision },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SkillPolicyError {
    InvalidSignature,
    InsufficientEvidence,
    BoundaryMismatch,
}

fn signature_for(manifest: &SkillManifest, signer: &str) -> String {
    let mut hasher = Sha256::new();
    hasher.update(signer.as_bytes());
    hasher.update(manifest.skill_id.as_bytes());
    hasher.update(manifest.domain.as_bytes());
    hasher.update(format!("{:.3}", manifest.evidence.train_accuracy));
    hasher.update(format!("{:.3}", manifest.evidence.holdout_accuracy));
    hasher.update(manifest.evidence.sample_count.to_string());
    format!("{:x}", hasher.finalize())
}
