use std::collections::HashMap;

use serde::{Deserialize, Serialize};

use super::permissions::{GlPermission, PermissionDecision, PermissionSet};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ToolRegistration {
    pub name: String,
    pub required_permission: GlPermission,
    pub description: String,
}

impl ToolRegistration {
    pub fn new(
        name: impl Into<String>,
        required_permission: GlPermission,
        description: impl Into<String>,
    ) -> Self {
        Self {
            name: name.into(),
            required_permission,
            description: description.into(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ActionRegistration {
    pub name: String,
    pub required_permission: GlPermission,
    pub description: String,
}

impl ActionRegistration {
    pub fn new(
        name: impl Into<String>,
        required_permission: GlPermission,
        description: impl Into<String>,
    ) -> Self {
        Self {
            name: name.into(),
            required_permission,
            description: description.into(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ToolInvocation {
    pub tool_name: String,
    pub arguments_json: serde_json::Value,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ActionInvocation {
    pub action_name: String,
    pub target: String,
}

#[derive(Debug, Default, Clone)]
pub struct GlRegistry {
    tools: HashMap<String, ToolRegistration>,
    actions: HashMap<String, ActionRegistration>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum GlRegistryEntry {
    Tool(ToolRegistration),
    Action(ActionRegistration),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct GlRegistryDescriptor {
    pub order: u16,
    pub kind: GlRegistryDescriptorKind,
    pub name: &'static str,
    pub required_permission: GlPermission,
    pub description: &'static str,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum GlRegistryDescriptorKind {
    Tool,
    Action,
}

impl GlRegistryDescriptor {
    pub const fn tool(
        order: u16,
        name: &'static str,
        required_permission: GlPermission,
        description: &'static str,
    ) -> Self {
        Self {
            order,
            kind: GlRegistryDescriptorKind::Tool,
            name,
            required_permission,
            description,
        }
    }

    pub const fn action(
        order: u16,
        name: &'static str,
        required_permission: GlPermission,
        description: &'static str,
    ) -> Self {
        Self {
            order,
            kind: GlRegistryDescriptorKind::Action,
            name,
            required_permission,
            description,
        }
    }

    fn entry(self) -> GlRegistryEntry {
        match self.kind {
            GlRegistryDescriptorKind::Tool => GlRegistryEntry::Tool(ToolRegistration::new(
                self.name,
                self.required_permission,
                self.description,
            )),
            GlRegistryDescriptorKind::Action => GlRegistryEntry::Action(ActionRegistration::new(
                self.name,
                self.required_permission,
                self.description,
            )),
        }
    }
}

impl GlRegistryEntry {
    fn register(self, registry: &mut GlRegistry) {
        match self {
            Self::Tool(tool) => registry.register_tool(tool),
            Self::Action(action) => registry.register_action(action),
        }
    }
}

impl GlRegistry {
    pub fn with_default_interactive_tools() -> Self {
        let mut registry = Self::default();
        default_interactive_entries()
            .into_iter()
            .for_each(|entry| entry.register(&mut registry));
        registry
    }

    pub fn register_tool(&mut self, tool: ToolRegistration) {
        self.tools.insert(tool.name.clone(), tool);
    }

    pub fn register_action(&mut self, action: ActionRegistration) {
        self.actions.insert(action.name.clone(), action);
    }

    pub fn tool_names(&self) -> Vec<String> {
        sorted_keys(&self.tools)
    }

    pub fn action_names(&self) -> Vec<String> {
        sorted_keys(&self.actions)
    }

    pub fn authorize_tool(
        &self,
        invocation: &ToolInvocation,
        permissions: &PermissionSet,
    ) -> Result<PermissionDecision, RegistryError> {
        let registration = self
            .tools
            .get(&invocation.tool_name)
            .ok_or_else(|| RegistryError::UnknownTool(invocation.tool_name.clone()))?;
        Ok(permissions.decide(registration.required_permission))
    }

    pub fn authorize_action(
        &self,
        invocation: &ActionInvocation,
        permissions: &PermissionSet,
    ) -> Result<PermissionDecision, RegistryError> {
        let registration = self
            .actions
            .get(&invocation.action_name)
            .ok_or_else(|| RegistryError::UnknownAction(invocation.action_name.clone()))?;
        Ok(permissions.decide(registration.required_permission))
    }
}

pub fn default_interactive_entries() -> Vec<GlRegistryEntry> {
    let mut descriptors = inventory::iter::<GlRegistryDescriptor>
        .into_iter()
        .copied()
        .collect::<Vec<_>>();
    descriptors.sort_by_key(|descriptor| (descriptor.order, descriptor.name));
    descriptors
        .into_iter()
        .map(GlRegistryDescriptor::entry)
        .collect()
}

inventory::collect!(GlRegistryDescriptor);

inventory::submit! {
    GlRegistryDescriptor::tool(
        10,
        "export_trace",
        GlPermission::ExportTrace,
        "export AP runtime trace log",
    )
}

inventory::submit! {
    GlRegistryDescriptor::tool(
        20,
        "render_media",
        GlPermission::RenderMedia,
        "render image/audio artifact references",
    )
}

inventory::submit! {
    GlRegistryDescriptor::action(
        30,
        "ap_runtime_tick",
        GlPermission::ProbeRuntime,
        "run APV21 runtime probe tick",
    )
}

inventory::submit! {
    GlRegistryDescriptor::action(
        40,
        "ap_train_feedback",
        GlPermission::LearnMemory,
        "write controlled feedback memory into AP runtime",
    )
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RegistryError {
    UnknownTool(String),
    UnknownAction(String),
}

fn sorted_keys<T>(map: &HashMap<String, T>) -> Vec<String> {
    let mut keys = map.keys().cloned().collect::<Vec<_>>();
    keys.sort();
    keys
}
