use serde::{Deserialize, Serialize};

use crate::learning::{
    AgentLearningRequest, AgentLearningResponse, AgentMessage, ArtifactRef, LlmAdapter,
    MediaOutput, PlannedLesson, ToolTranslationRequest,
};
use crate::runtime::{APV21Runtime, RuntimeObservation, RuntimeTickInput, RuntimeTickTrace};

use super::media::{MediaRenderPlan, MediaRenderer, TermwizMediaRenderer};
use super::permissions::{GlPermission, PermissionDecision, PermissionSet};
use super::registry::{ActionInvocation, GlRegistry, RegistryError, ToolInvocation};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct GlRequest {
    pub request_id: String,
    pub kind: GlRequestKind,
    pub text: String,
    pub desired_outputs: Vec<MediaOutput>,
    pub artifacts: Vec<ArtifactRef>,
}

impl GlRequest {
    pub fn chat(request_id: impl Into<String>, text: impl Into<String>) -> Self {
        Self {
            request_id: request_id.into(),
            kind: GlRequestKind::Chat,
            text: text.into(),
            desired_outputs: vec![MediaOutput::Text],
            artifacts: Vec::new(),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum GlRequestKind {
    Chat,
    Learn,
    Probe,
    ExportTrace,
    RenderMedia,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct GlPlan {
    pub request_id: String,
    pub steps: Vec<GlStep>,
    pub requires_confirmation: bool,
    pub notes: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum GlStep {
    Lesson(AgentLearningRequest),
    RuntimeProbe(RuntimeTickInput),
    Tool(ToolInvocation),
    Action(ActionInvocation),
    RenderMedia(ArtifactRef),
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct GlExecutionResult {
    pub request_id: String,
    pub outcomes: Vec<GlStepOutcome>,
    pub message: AgentMessage,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum GlStepOutcome {
    LessonPlanned(AgentLearningResponse),
    RuntimeTick(Box<RuntimeTickTrace>),
    ToolAuthorized(String),
    ActionAuthorized(String),
    MediaPlanned(MediaRenderPlan),
    Denied(PermissionDecision),
    RegistryError(String),
}

#[derive(Debug, Clone)]
pub struct GlOrchestrator<A = PlannedLesson, R = TermwizMediaRenderer> {
    pub permissions: PermissionSet,
    pub registry: GlRegistry,
    pub llm_adapter: A,
    pub media_renderer: R,
}

impl Default for GlOrchestrator {
    fn default() -> Self {
        Self {
            permissions: PermissionSet::default(),
            registry: GlRegistry::with_default_interactive_tools(),
            llm_adapter: PlannedLesson,
            media_renderer: TermwizMediaRenderer,
        }
    }
}

impl<A, R> GlOrchestrator<A, R>
where
    A: LlmAdapter,
    R: MediaRenderer,
{
    pub fn plan(&self, request: GlRequest) -> GlPlan {
        let mut steps = request_steps(&request);
        steps.extend(render_steps(request.artifacts));
        GlPlan {
            request_id: request.request_id,
            steps,
            requires_confirmation: request.kind != GlRequestKind::Chat,
            notes: vec!["GL plan keeps tools/media outside AP-Core proof path".to_owned()],
        }
    }

    pub fn execute(&self, runtime: &mut APV21Runtime, plan: GlPlan) -> GlExecutionResult {
        let outcomes = plan
            .steps
            .into_iter()
            .map(|step| self.execute_step(runtime, step))
            .collect::<Vec<_>>();
        let message = result_message(&outcomes);
        GlExecutionResult {
            request_id: plan.request_id,
            outcomes,
            message,
        }
    }

    fn execute_step(&self, runtime: &mut APV21Runtime, step: GlStep) -> GlStepOutcome {
        match step {
            GlStep::Lesson(request) => self.execute_lesson(request),
            GlStep::RuntimeProbe(input) => self.execute_runtime_probe(runtime, input),
            external => self.execute_external_step(external),
        }
    }

    fn execute_external_step(&self, step: GlStep) -> GlStepOutcome {
        match step {
            GlStep::Tool(invocation) => self.execute_tool(invocation),
            GlStep::Action(invocation) => self.execute_action(invocation),
            GlStep::RenderMedia(artifact) => self.execute_media(artifact),
            GlStep::Lesson(_) | GlStep::RuntimeProbe(_) => {
                GlStepOutcome::RegistryError("invalid external GL step".to_owned())
            }
        }
    }

    fn execute_lesson(&self, request: AgentLearningRequest) -> GlStepOutcome {
        GlStepOutcome::LessonPlanned(self.llm_adapter.generate_curriculum(request))
    }

    fn execute_runtime_probe(
        &self,
        runtime: &mut APV21Runtime,
        input: RuntimeTickInput,
    ) -> GlStepOutcome {
        permission_outcome(self.permissions.decide(GlPermission::ProbeRuntime), || {
            GlStepOutcome::RuntimeTick(Box::new(runtime.tick(input)))
        })
    }

    fn execute_tool(&self, invocation: ToolInvocation) -> GlStepOutcome {
        match self.registry.authorize_tool(&invocation, &self.permissions) {
            Ok(PermissionDecision::Allowed) => GlStepOutcome::ToolAuthorized(invocation.tool_name),
            Ok(denied) => GlStepOutcome::Denied(denied),
            Err(error) => GlStepOutcome::RegistryError(registry_error_text(error)),
        }
    }

    fn execute_action(&self, invocation: ActionInvocation) -> GlStepOutcome {
        match self
            .registry
            .authorize_action(&invocation, &self.permissions)
        {
            Ok(PermissionDecision::Allowed) => {
                GlStepOutcome::ActionAuthorized(invocation.action_name)
            }
            Ok(denied) => GlStepOutcome::Denied(denied),
            Err(error) => GlStepOutcome::RegistryError(registry_error_text(error)),
        }
    }

    fn execute_media(&self, artifact: ArtifactRef) -> GlStepOutcome {
        permission_outcome(self.permissions.decide(GlPermission::RenderMedia), || {
            self.media_renderer
                .plan_render(artifact)
                .map(GlStepOutcome::MediaPlanned)
                .unwrap_or_else(unsupported_media_outcome)
        })
    }

    pub fn translate_tool_text(&self, request_id: String, user_text: String) -> GlPlan {
        let translation = self
            .llm_adapter
            .translate_tool_request(ToolTranslationRequest {
                request_id: request_id.clone(),
                user_text,
                allowed_tools: self.registry.tool_names(),
            });
        let steps = translation
            .tool_name
            .map(|tool_name| {
                vec![GlStep::Tool(ToolInvocation {
                    tool_name,
                    arguments_json: translation.arguments_json,
                })]
            })
            .unwrap_or_default();
        GlPlan {
            request_id,
            steps,
            requires_confirmation: translation.requires_confirmation,
            notes: translation.notes,
        }
    }
}

fn request_steps(request: &GlRequest) -> Vec<GlStep> {
    request_step(request).into_iter().collect()
}

fn request_step(request: &GlRequest) -> Option<GlStep> {
    match request.kind {
        GlRequestKind::Learn => Some(learn_step(request)),
        GlRequestKind::Probe => Some(probe_step(request)),
        GlRequestKind::ExportTrace => Some(export_trace_step(&request.text)),
        GlRequestKind::Chat | GlRequestKind::RenderMedia => None,
    }
}

fn learn_step(request: &GlRequest) -> GlStep {
    GlStep::Lesson(AgentLearningRequest::user_text(
        request.request_id.clone(),
        request.text.clone(),
    ))
}

fn probe_step(request: &GlRequest) -> GlStep {
    GlStep::RuntimeProbe(RuntimeTickInput::new(
        RuntimeObservation::new(
            "tui",
            request.text.clone(),
            [format!("text::{}", request.text)],
        ),
        ["answer".to_owned(), "ask_clarify".to_owned()],
    ))
}

fn export_trace_step(text: &str) -> GlStep {
    GlStep::Tool(ToolInvocation {
        tool_name: "export_trace".to_owned(),
        arguments_json: serde_json::json!({ "text": text }),
    })
}

fn render_steps(artifacts: Vec<ArtifactRef>) -> Vec<GlStep> {
    artifacts.into_iter().map(GlStep::RenderMedia).collect()
}

fn permission_outcome(
    decision: PermissionDecision,
    allowed: impl FnOnce() -> GlStepOutcome,
) -> GlStepOutcome {
    match decision {
        PermissionDecision::Allowed => allowed(),
        denied => GlStepOutcome::Denied(denied),
    }
}

fn result_message(outcomes: &[GlStepOutcome]) -> AgentMessage {
    let mut message = AgentMessage::text(format!("GL completed {} step(s)", outcomes.len()));
    message.channels.extend(outcome_channels(outcomes));
    message.artifacts.extend(outcome_artifacts(outcomes));
    message
}

fn outcome_channels(outcomes: &[GlStepOutcome]) -> Vec<MediaOutput> {
    outcomes
        .iter()
        .filter_map(|outcome| match outcome {
            GlStepOutcome::MediaPlanned(plan) => Some(plan.channel),
            GlStepOutcome::RuntimeTick(_) => Some(MediaOutput::Trace),
            _ => None,
        })
        .collect()
}

fn outcome_artifacts(outcomes: &[GlStepOutcome]) -> Vec<ArtifactRef> {
    outcomes
        .iter()
        .filter_map(|outcome| match outcome {
            GlStepOutcome::MediaPlanned(plan) => Some(plan.artifact.clone()),
            _ => None,
        })
        .collect()
}

fn registry_error_text(error: RegistryError) -> String {
    match error {
        RegistryError::UnknownTool(tool) => format!("unknown tool: {tool}"),
        RegistryError::UnknownAction(action) => format!("unknown action: {action}"),
    }
}

fn unsupported_media_outcome() -> GlStepOutcome {
    GlStepOutcome::RegistryError("unsupported media artifact".to_owned())
}
