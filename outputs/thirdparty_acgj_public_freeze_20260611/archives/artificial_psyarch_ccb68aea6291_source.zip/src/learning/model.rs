use serde::{Deserialize, Serialize};

use crate::core::ap::{Feedback, TeacherMode};
use crate::core::skill_registry::{SkillBoundary, SkillEvidence, SkillManifest};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum LearningSource {
    User,
    Llm { provider: String, model: String },
    File { path: String },
    Script { name: String },
    Experiment { experiment_id: String },
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum LearningMaterial {
    Stimulus(MaterialStimulus),
    TaskSet(Vec<LessonTask>),
}

impl LearningMaterial {
    pub fn text(text: impl Into<String>) -> Self {
        Self::Stimulus(MaterialStimulus::Text(text.into()))
    }

    pub fn json(value: serde_json::Value) -> Self {
        Self::Stimulus(MaterialStimulus::Json(value))
    }

    pub fn image_ref(image: ArtifactRef) -> Self {
        Self::Stimulus(MaterialStimulus::ImageRef(image))
    }

    pub fn audio_ref(audio: ArtifactRef) -> Self {
        Self::Stimulus(MaterialStimulus::AudioRef(audio))
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct LearningInput {
    pub source: LearningSource,
    pub material: LearningMaterial,
    pub goal: String,
    pub teacher_mode: TeacherMode,
    pub feedback_policy: FeedbackPolicy,
    pub allow_memory_write: bool,
}

impl LearningInput {
    pub fn new(
        source: LearningSource,
        material: LearningMaterial,
        goal: impl Into<String>,
        teacher_mode: TeacherMode,
        feedback_policy: FeedbackPolicy,
    ) -> Self {
        Self {
            source,
            material,
            goal: goal.into(),
            teacher_mode,
            feedback_policy,
            allow_memory_write: teacher_mode.memory_write_enabled(),
        }
    }

    pub fn into_lesson(self, lesson_id: impl Into<String>) -> Lesson {
        Lesson::from_input(lesson_id, self)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum FeedbackPolicy {
    UserScored,
    LlmScored,
    AutomaticExaminer,
    NoFeedback,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Lesson {
    pub lesson_id: String,
    pub source: LearningSource,
    pub goal: String,
    pub teacher_mode: TeacherMode,
    pub feedback_policy: FeedbackPolicy,
    pub allow_memory_write: bool,
    pub tasks: Vec<LessonTask>,
}

impl Lesson {
    pub fn from_input(lesson_id: impl Into<String>, input: LearningInput) -> Self {
        let tasks = lesson_tasks_from_material(input.material);
        Self {
            lesson_id: lesson_id.into(),
            source: input.source,
            goal: input.goal,
            teacher_mode: input.teacher_mode,
            feedback_policy: input.feedback_policy,
            allow_memory_write: input.allow_memory_write,
            tasks,
        }
    }

    pub fn task_count(&self) -> usize {
        self.tasks.len()
    }

    pub fn is_trainable(&self) -> bool {
        self.allow_memory_write
            && self.teacher_mode.memory_write_enabled()
            && !self.tasks.is_empty()
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct LessonTask {
    pub task_id: String,
    pub stimulus: MaterialStimulus,
    pub expected_action: Option<String>,
    pub rubric: Option<String>,
}

impl LessonTask {
    pub fn new(task_id: impl Into<String>, stimulus: MaterialStimulus) -> Self {
        Self {
            task_id: task_id.into(),
            stimulus,
            expected_action: None,
            rubric: None,
        }
    }

    pub fn with_expected_action(mut self, expected_action: impl Into<String>) -> Self {
        self.expected_action = Some(expected_action.into());
        self
    }

    pub fn with_rubric(mut self, rubric: impl Into<String>) -> Self {
        self.rubric = Some(rubric.into());
        self
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum MaterialStimulus {
    Text(String),
    Json(serde_json::Value),
    ImageRef(ArtifactRef),
    AudioRef(ArtifactRef),
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct LessonAttempt {
    pub task_id: String,
    pub response: String,
    pub feedback: Option<Feedback>,
    pub teacher_mode: TeacherMode,
    pub memory_write_enabled: bool,
}

impl LessonAttempt {
    pub fn new(
        task_id: impl Into<String>,
        response: impl Into<String>,
        feedback: Option<Feedback>,
        teacher_mode: TeacherMode,
    ) -> Self {
        Self {
            task_id: task_id.into(),
            response: response.into(),
            feedback,
            teacher_mode,
            memory_write_enabled: teacher_mode.memory_write_enabled(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SkillReport {
    pub skill_id: String,
    pub lesson_id: String,
    pub status: SkillReportStatus,
    pub train_attempts: usize,
    pub holdout_attempts: usize,
    pub train_rewards: usize,
    pub holdout_rewards: usize,
    pub artifacts: Vec<ArtifactRef>,
    pub boundary: SkillBoundary,
}

impl SkillReport {
    pub fn new(
        skill_id: impl Into<String>,
        lesson_id: impl Into<String>,
        boundary: SkillBoundary,
    ) -> Self {
        Self {
            skill_id: skill_id.into(),
            lesson_id: lesson_id.into(),
            status: SkillReportStatus::Draft,
            train_attempts: 0,
            holdout_attempts: 0,
            train_rewards: 0,
            holdout_rewards: 0,
            artifacts: Vec::new(),
            boundary,
        }
    }

    pub fn record_train_attempt(&mut self, feedback: Feedback) {
        self.train_attempts += 1;
        self.train_rewards += usize::from(feedback == Feedback::Reward);
    }

    pub fn record_holdout_attempt(&mut self, feedback: Feedback) {
        self.holdout_attempts += 1;
        self.holdout_rewards += usize::from(feedback == Feedback::Reward);
    }

    pub fn finalize(mut self) -> Self {
        self.status = if self.train_accuracy() == 1.0 && self.holdout_accuracy() == 1.0 {
            SkillReportStatus::Verified
        } else {
            SkillReportStatus::NeedsMoreEvidence
        };
        self
    }

    pub fn train_accuracy(&self) -> f32 {
        accuracy(self.train_rewards, self.train_attempts)
    }

    pub fn holdout_accuracy(&self) -> f32 {
        accuracy(self.holdout_rewards, self.holdout_attempts)
    }

    pub fn to_manifest(&self, domain: impl Into<String>) -> Option<SkillManifest> {
        (self.status == SkillReportStatus::Verified).then(|| {
            SkillManifest::new(
                self.skill_id.clone(),
                domain,
                SkillEvidence {
                    train_accuracy: self.train_accuracy(),
                    holdout_accuracy: self.holdout_accuracy(),
                    sample_count: self.train_attempts + self.holdout_attempts,
                },
                self.boundary.clone(),
            )
        })
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum SkillReportStatus {
    Draft,
    Verified,
    NeedsMoreEvidence,
    RejectedLeakageRisk,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ArtifactRef {
    pub artifact_id: String,
    pub kind: ArtifactKind,
    pub uri: String,
    pub mime_type: Option<String>,
}

impl ArtifactRef {
    pub fn new(artifact_id: impl Into<String>, kind: ArtifactKind, uri: impl Into<String>) -> Self {
        Self {
            artifact_id: artifact_id.into(),
            kind,
            uri: uri.into(),
            mime_type: None,
        }
    }

    pub fn with_mime_type(mut self, mime_type: impl Into<String>) -> Self {
        self.mime_type = Some(mime_type.into());
        self
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ArtifactKind {
    Text,
    Json,
    Image,
    Audio,
    Trace,
    SkillPackage,
}

fn lesson_tasks_from_material(material: LearningMaterial) -> Vec<LessonTask> {
    match material {
        LearningMaterial::Stimulus(stimulus) => single_material_task(stimulus),
        LearningMaterial::TaskSet(tasks) => tasks,
    }
}

fn single_material_task(stimulus: MaterialStimulus) -> Vec<LessonTask> {
    vec![LessonTask::new("task-000", stimulus)]
}

fn accuracy(rewards: usize, attempts: usize) -> f32 {
    if attempts == 0 {
        0.0
    } else {
        rewards as f32 / attempts as f32
    }
}
