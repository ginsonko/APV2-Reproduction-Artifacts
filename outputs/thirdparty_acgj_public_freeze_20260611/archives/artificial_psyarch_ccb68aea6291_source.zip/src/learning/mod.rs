pub mod agent;
pub mod io;
pub mod math;
pub mod math_curriculum;
pub mod model;
pub mod protocol;
pub mod relation_runtime;
pub mod relation_scene;
pub mod relation_words;
pub mod runner;
pub mod scaffold;
pub mod session;

pub use agent::{LearnableAgent, LearnedSkillPackage};
pub use io::{
    LearningIoError, read_learning_request, read_learning_request_text, read_scaffold_spec,
    read_scaffold_spec_text, read_skill_package, read_stdin, write_lesson_bundle,
    write_scaffold_bundle, write_skill_package, write_stdout,
};
pub use math::is_arithmetic_expression;
pub use math_curriculum::{
    MathDifficulty, expression_probe_lesson, generated_generalization_probe, generated_math_lesson,
    generated_math_lesson_for_level, no_division_math_lesson, probe_answers, probe_lesson,
};
pub use model::{
    ArtifactKind, ArtifactRef, FeedbackPolicy, LearningInput, LearningMaterial, LearningSource,
    Lesson, LessonAttempt, LessonTask, MaterialStimulus, SkillReport, SkillReportStatus,
};
pub use protocol::{
    AgentLearningRequest, AgentLearningResponse, AgentMessage, ConversationTurn, HoldoutSpec,
    HoldoutSplit, LearningIntent, LlmAdapter, LlmBridge, LlmSafetyReview, MediaOutput,
    PlannedLesson, ToolTranslationPlan, ToolTranslationRequest,
};
pub use relation_runtime::{
    RelationProbeError, RelationProbeReport, default_relation_skill_path, probe_relation_scene,
    probe_relation_scene_json,
};
pub use relation_scene::{
    RelationScene, RelationSceneError, SceneObject, SceneQuery, relation_scene_from_json,
    relation_scene_state_items,
};
pub use relation_words::{
    ControlProbeReport, DEFAULT_RELATION_BUNDLE, DEFAULT_RELATION_DOMAIN,
    DEFAULT_RELATION_HOLDOUT_SPEC, DEFAULT_RELATION_SKILL, DEFAULT_RELATION_SKILL_ID,
    DEFAULT_RELATION_SPEC, ProbeSummary, RelationWordAuditReport, RelationWordTrainingConfig,
    RelationWordTrainingReport, audit_relation_word_spec, run_control_probes,
    run_relation_word_holdout_probe, run_relation_word_training,
};
pub use runner::{LessonRunReport, LessonRunner};
pub use scaffold::{
    ActionBias, EducationIntervention, MasteryPolicy, ScaffoldAttempt, ScaffoldBuildingBlock,
    ScaffoldFeedback, ScaffoldMasterySummary, ScaffoldPhase, ScaffoldPhaseId, ScaffoldPhaseReport,
    ScaffoldRunReport, ScaffoldRunner, ScaffoldSpecRunBundle, ScaffoldSpecRunner, ScaffoldStep,
    SkillProtocolState, SkillScaffoldController, SkillScaffoldSpec, StepActionBias, StepFeedback,
    TeacherSignalPolicy,
};
pub use session::{LearningSession, lesson_task_response, reserved_media_artifacts};
