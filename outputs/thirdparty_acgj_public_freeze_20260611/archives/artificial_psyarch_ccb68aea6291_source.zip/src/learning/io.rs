use std::fmt::{Display, Formatter};
use std::fs;
use std::io::{self, Read};
use std::path::Path;

use serde::{Serialize, de::DeserializeOwned};

use crate::codec::{Codec, CodecError};
use crate::learning::agent::LearnedSkillPackage;
use crate::learning::protocol::AgentLearningRequest;
use crate::learning::scaffold::{ScaffoldSpecRunBundle, SkillScaffoldSpec};
use crate::workspace::ensure_parent;

#[derive(Debug)]
pub enum LearningIoError {
    Io(io::Error),
    Json(serde_json::Error),
    Codec(CodecError),
}

impl Display for LearningIoError {
    fn fmt(&self, formatter: &mut Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Io(error) => write!(formatter, "io error: {error}"),
            Self::Json(error) => write!(formatter, "json error: {error}"),
            Self::Codec(error) => write!(formatter, "codec error: {error}"),
        }
    }
}

impl std::error::Error for LearningIoError {}

impl From<io::Error> for LearningIoError {
    fn from(error: io::Error) -> Self {
        Self::Io(error)
    }
}

impl From<serde_json::Error> for LearningIoError {
    fn from(error: serde_json::Error) -> Self {
        Self::Json(error)
    }
}

impl From<CodecError> for LearningIoError {
    fn from(error: CodecError) -> Self {
        Self::Codec(error)
    }
}

pub fn read_learning_request(
    path: impl AsRef<Path>,
) -> Result<AgentLearningRequest, LearningIoError> {
    read_json(path)
}

pub fn read_learning_request_text(text: &str) -> Result<AgentLearningRequest, LearningIoError> {
    Ok(serde_json::from_str(text)?)
}

pub fn read_scaffold_spec(path: impl AsRef<Path>) -> Result<SkillScaffoldSpec, LearningIoError> {
    read_json(path)
}

pub fn read_scaffold_spec_text(text: &str) -> Result<SkillScaffoldSpec, LearningIoError> {
    Ok(serde_json::from_str(text)?)
}

pub fn write_lesson_bundle<T>(path: impl AsRef<Path>, bundle: &T) -> Result<(), LearningIoError>
where
    T: Serialize,
{
    write_json(path, bundle)
}

pub fn write_scaffold_bundle(
    path: impl AsRef<Path>,
    bundle: &ScaffoldSpecRunBundle,
) -> Result<(), LearningIoError> {
    write_json(path, bundle)
}

pub fn read_skill_package(path: impl AsRef<Path>) -> Result<LearnedSkillPackage, LearningIoError> {
    read_by_path_codec(path)
}

pub fn write_skill_package(
    path: impl AsRef<Path>,
    package: &LearnedSkillPackage,
) -> Result<(), LearningIoError> {
    write_by_path_codec(path, package)
}

pub fn read_stdin() -> Result<String, LearningIoError> {
    let mut text = String::new();
    io::stdin().read_to_string(&mut text)?;
    Ok(text)
}

pub fn write_stdout<T>(value: &T) -> Result<(), LearningIoError>
where
    T: Serialize,
{
    let text = serde_json::to_string_pretty(value)?;
    println!("{text}");
    Ok(())
}

fn read_json<T>(path: impl AsRef<Path>) -> Result<T, LearningIoError>
where
    T: DeserializeOwned,
{
    let text = fs::read_to_string(path)?;
    Ok(serde_json::from_str(&text)?)
}

fn write_json<T>(path: impl AsRef<Path>, value: &T) -> Result<(), LearningIoError>
where
    T: Serialize,
{
    ensure_parent(path.as_ref())?;
    let text = serde_json::to_string_pretty(value)?;
    fs::write(path, text)?;
    Ok(())
}

fn read_by_path_codec<T>(path: impl AsRef<Path>) -> Result<T, LearningIoError>
where
    T: DeserializeOwned,
{
    let bytes = fs::read(path.as_ref())?;
    Ok(codec_for_path(path.as_ref()).decode(&bytes)?)
}

fn write_by_path_codec<T>(path: impl AsRef<Path>, value: &T) -> Result<(), LearningIoError>
where
    T: Serialize,
{
    ensure_parent(path.as_ref())?;
    let bytes = codec_for_path(path.as_ref()).encode(value)?;
    fs::write(path, bytes)?;
    Ok(())
}

fn codec_for_path(path: &Path) -> Codec {
    match path.extension().and_then(|extension| extension.to_str()) {
        Some("apbin" | "bin" | "bincode") => Codec::Bincode,
        _ => Codec::JsonPretty,
    }
}
