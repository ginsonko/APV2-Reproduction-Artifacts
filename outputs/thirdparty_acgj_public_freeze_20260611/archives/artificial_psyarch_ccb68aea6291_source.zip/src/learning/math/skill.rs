use std::collections::{BTreeSet, HashMap};

use crate::core::ap::{Feedback, MemoryEvent};
use crate::learning::model::{LessonTask, MaterialStimulus};

use super::parser::{ArithmeticExpression, ArithmeticNode, ArithmeticOp};

#[derive(Debug, Default, Clone, PartialEq, Eq)]
pub struct ArithmeticSkill {
    operators: BTreeSet<ArithmeticOp>,
    successors: HashMap<i16, i16>,
    predecessors: HashMap<i16, i16>,
}

impl ArithmeticSkill {
    pub fn from_events(actions: &[String], events: &[MemoryEvent<usize>]) -> Self {
        events
            .iter()
            .filter(|event| event.feedback == Feedback::Reward)
            .filter_map(|event| rewarded_example(actions, event))
            .fold(Self::default(), |mut skill, example| {
                skill.learn_example(&example);
                skill
            })
    }

    pub fn answer(&self, task: &LessonTask) -> Option<String> {
        let expression = ArithmeticExpression::parse(task_text(task)?)?;
        self.evaluate_learned(&expression.node)
            .map(|value| value.to_string())
    }

    pub fn operator_count(&self) -> usize {
        self.operators.len()
    }

    fn learn_example(&mut self, example: &RewardedExample) {
        self.remember_expression_numbers(&example.expression.node);
        self.remember_span(0, example.answer);
        self.operators.extend(example.expression.operators.iter());
    }

    fn remember_expression_numbers(&mut self, node: &ArithmeticNode) {
        match node {
            ArithmeticNode::Number(value) => self.remember_span(0, *value),
            ArithmeticNode::Binary { left, right, .. } => {
                self.remember_expression_numbers(left);
                self.remember_expression_numbers(right);
            }
        }
    }

    fn remember_span(&mut self, from: i16, to: i16) {
        for value in from.min(to)..from.max(to) {
            self.successors.insert(value, value + 1);
            self.predecessors.insert(value + 1, value);
        }
    }

    fn evaluate_learned(&self, node: &ArithmeticNode) -> Option<i16> {
        match node {
            ArithmeticNode::Number(value) => Some(*value),
            ArithmeticNode::Binary { left, op, right } => self.apply_learned_op(
                self.evaluate_learned(left)?,
                *op,
                self.evaluate_learned(right)?,
            ),
        }
    }

    fn apply_learned_op(&self, left: i16, op: ArithmeticOp, right: i16) -> Option<i16> {
        self.operators.contains(&op).then(|| match op {
            ArithmeticOp::Add => self.advance_forward(left, right),
            ArithmeticOp::Sub => self.advance_backward(left, right),
            ArithmeticOp::Mul => self.multiply_by_repeated_add(left, right),
            ArithmeticOp::Div => self.divide_by_repeated_subtract(left, right),
        })?
    }

    fn multiply_by_repeated_add(&self, left: i16, right: i16) -> Option<i16> {
        let mut total = 0;
        for _ in 0..right {
            total = self.advance_forward(total, left)?;
        }
        Some(total)
    }

    fn divide_by_repeated_subtract(&self, left: i16, right: i16) -> Option<i16> {
        if right == 0 {
            return None;
        }
        let mut remainder = left;
        let mut groups = 0;
        while remainder >= right {
            remainder = self.advance_backward(remainder, right)?;
            groups = self.step_once(groups, StepDirection::Forward)?;
        }
        (remainder == 0).then_some(groups)
    }

    fn advance_forward(&self, start: i16, steps: i16) -> Option<i16> {
        self.advance(start, steps, StepDirection::Forward)
    }

    fn advance_backward(&self, start: i16, steps: i16) -> Option<i16> {
        self.advance(start, steps, StepDirection::Backward)
    }

    fn advance(&self, start: i16, steps: i16, direction: StepDirection) -> Option<i16> {
        let mut cursor = start;
        for _ in 0..steps {
            cursor = self.step_once(cursor, direction)?;
        }
        Some(cursor)
    }

    fn step_once(&self, cursor: i16, direction: StepDirection) -> Option<i16> {
        match direction {
            StepDirection::Forward => self.successors.get(&cursor).copied(),
            StepDirection::Backward => self.predecessors.get(&cursor).copied(),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum StepDirection {
    Forward,
    Backward,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct RewardedExample {
    expression: ArithmeticExpression,
    answer: i16,
}

fn rewarded_example(actions: &[String], event: &MemoryEvent<usize>) -> Option<RewardedExample> {
    let action = actions.get(event.action)?;
    Some(RewardedExample {
        expression: ArithmeticExpression::parse_text_state(&event.state_id)?,
        answer: action.parse().ok()?,
    })
}

fn task_text(task: &LessonTask) -> Option<&str> {
    match &task.stimulus {
        MaterialStimulus::Text(text) => Some(text),
        _ => None,
    }
}
