use std::collections::BTreeSet;

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct ArithmeticExpression {
    pub(crate) node: ArithmeticNode,
    pub(crate) operators: BTreeSet<ArithmeticOp>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum ArithmeticNode {
    Number(i16),
    Binary {
        left: Box<ArithmeticNode>,
        op: ArithmeticOp,
        right: Box<ArithmeticNode>,
    },
}

impl ArithmeticExpression {
    pub(crate) fn parse_text_state(state_id: &str) -> Option<Self> {
        Self::parse(state_id.strip_prefix("text:")?)
    }

    pub(crate) fn parse(text: &str) -> Option<Self> {
        let mut parser = ExpressionParser::new(lex_expression(text)?);
        let expression = parser.parse_expression()?;
        parser.is_finished().then_some(expression)
    }

    fn number(value: i16) -> Self {
        Self {
            node: ArithmeticNode::Number(value),
            operators: BTreeSet::new(),
        }
    }

    fn combine(self, op: ArithmeticOp, right: Self) -> Self {
        Self {
            node: ArithmeticNode::Binary {
                left: Box::new(self.node),
                op,
                right: Box::new(right.node),
            },
            operators: combined_operators(self.operators, op, right.operators),
        }
    }

    pub(crate) fn evaluate_builtin(&self) -> Option<i16> {
        evaluate_builtin_node(&self.node)
    }
}

fn evaluate_builtin_node(node: &ArithmeticNode) -> Option<i16> {
    match node {
        ArithmeticNode::Number(value) => Some(*value),
        ArithmeticNode::Binary { left, op, right } => {
            op.apply(evaluate_builtin_node(left)?, evaluate_builtin_node(right)?)
        }
    }
}

fn combined_operators(
    mut left: BTreeSet<ArithmeticOp>,
    op: ArithmeticOp,
    right: BTreeSet<ArithmeticOp>,
) -> BTreeSet<ArithmeticOp> {
    left.insert(op);
    left.extend(right);
    left
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub(crate) enum ArithmeticOp {
    Add,
    Sub,
    Mul,
    Div,
}

impl ArithmeticOp {
    fn parse_char(symbol: char) -> Option<Self> {
        ARITHMETIC_OPS
            .iter()
            .find(|candidate| candidate.symbol.starts_with(symbol))
            .map(|candidate| candidate.op)
    }

    fn apply(self, left: i16, right: i16) -> Option<i16> {
        ARITHMETIC_OPS
            .iter()
            .find(|candidate| candidate.op == self)
            .map(|candidate| (candidate.apply)(left, right))
            .expect("all arithmetic ops have an implementation")
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ExpressionLexeme {
    Number(i16),
    Op(ArithmeticOp),
    LeftParen,
    RightParen,
}

fn lex_expression(text: &str) -> Option<Vec<ExpressionLexeme>> {
    let mut chars = text.chars().peekable();
    let mut lexemes = Vec::new();
    while let Some(ch) = chars.peek().copied() {
        if let Some(lexeme) = read_lexeme(ch, &mut chars)? {
            lexemes.push(lexeme);
        }
    }
    (!lexemes.is_empty()).then_some(lexemes)
}

fn read_lexeme(
    ch: char,
    chars: &mut std::iter::Peekable<std::str::Chars<'_>>,
) -> Option<Option<ExpressionLexeme>> {
    if ch.is_ascii_digit() {
        return Some(Some(ExpressionLexeme::Number(read_number(chars)?)));
    }
    if ch.is_whitespace() {
        chars.next();
        return Some(None);
    }
    read_symbol_lexeme(ch, chars).map(Some)
}

fn read_symbol_lexeme(
    ch: char,
    chars: &mut std::iter::Peekable<std::str::Chars<'_>>,
) -> Option<ExpressionLexeme> {
    chars.next();
    match ch {
        '+' | '-' | '*' | '/' => ArithmeticOp::parse_char(ch).map(ExpressionLexeme::Op),
        '(' => Some(ExpressionLexeme::LeftParen),
        ')' => Some(ExpressionLexeme::RightParen),
        _ => None,
    }
}

fn read_number(chars: &mut std::iter::Peekable<std::str::Chars<'_>>) -> Option<i16> {
    let mut text = String::new();
    while let Some(ch) = chars.peek().filter(|ch| ch.is_ascii_digit()).copied() {
        text.push(ch);
        chars.next();
    }
    text.parse().ok()
}

#[derive(Debug, Clone)]
struct ExpressionParser {
    lexemes: Vec<ExpressionLexeme>,
    index: usize,
}

impl ExpressionParser {
    fn new(lexemes: Vec<ExpressionLexeme>) -> Self {
        Self { lexemes, index: 0 }
    }

    fn parse_expression(&mut self) -> Option<ArithmeticExpression> {
        self.parse_binary(Self::parse_term, &[ArithmeticOp::Add, ArithmeticOp::Sub])
    }

    fn parse_term(&mut self) -> Option<ArithmeticExpression> {
        self.parse_binary(Self::parse_factor, &[ArithmeticOp::Mul, ArithmeticOp::Div])
    }

    fn parse_factor(&mut self) -> Option<ArithmeticExpression> {
        match self.advance()? {
            ExpressionLexeme::Number(value) => Some(ArithmeticExpression::number(value)),
            ExpressionLexeme::LeftParen => self.parse_parenthesized(),
            _ => None,
        }
    }

    fn parse_parenthesized(&mut self) -> Option<ArithmeticExpression> {
        let expression = self.parse_expression()?;
        self.consume_right_paren().then_some(expression)
    }

    fn parse_binary(
        &mut self,
        next: fn(&mut Self) -> Option<ArithmeticExpression>,
        allowed: &[ArithmeticOp],
    ) -> Option<ArithmeticExpression> {
        let mut left = next(self)?;
        while let Some(op) = self.consume_allowed_op(allowed) {
            left = left.combine(op, next(self)?);
        }
        Some(left)
    }

    fn consume_allowed_op(&mut self, allowed: &[ArithmeticOp]) -> Option<ArithmeticOp> {
        match self.peek().copied()? {
            ExpressionLexeme::Op(op) if allowed.contains(&op) => {
                self.index += 1;
                Some(op)
            }
            _ => None,
        }
    }

    fn consume_right_paren(&mut self) -> bool {
        matches!(self.advance(), Some(ExpressionLexeme::RightParen))
    }

    fn advance(&mut self) -> Option<ExpressionLexeme> {
        let lexeme = self.lexemes.get(self.index).copied()?;
        self.index += 1;
        Some(lexeme)
    }

    fn peek(&self) -> Option<&ExpressionLexeme> {
        self.lexemes.get(self.index)
    }

    fn is_finished(&self) -> bool {
        self.index == self.lexemes.len()
    }
}

#[derive(Debug, Clone, Copy)]
struct ArithmeticOpSpec {
    symbol: &'static str,
    op: ArithmeticOp,
    apply: fn(i16, i16) -> Option<i16>,
}

const ARITHMETIC_OPS: [ArithmeticOpSpec; 4] = [
    ArithmeticOpSpec {
        symbol: "+",
        op: ArithmeticOp::Add,
        apply: |left, right| Some(left + right),
    },
    ArithmeticOpSpec {
        symbol: "-",
        op: ArithmeticOp::Sub,
        apply: |left, right| Some(left - right),
    },
    ArithmeticOpSpec {
        symbol: "*",
        op: ArithmeticOp::Mul,
        apply: |left, right| Some(left * right),
    },
    ArithmeticOpSpec {
        symbol: "/",
        op: ArithmeticOp::Div,
        apply: |left, right| (right != 0).then_some(left / right),
    },
];
