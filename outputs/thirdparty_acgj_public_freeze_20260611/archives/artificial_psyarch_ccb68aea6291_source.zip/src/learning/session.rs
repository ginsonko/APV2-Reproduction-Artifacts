use crate::core::ap::TeacherMode;
use crate::learning::agent::LearnableAgent;
use crate::learning::io::{LearningIoError, read_skill_package, write_skill_package};
use crate::learning::model::{ArtifactKind, ArtifactRef, Lesson, LessonTask};
use crate::learning::protocol::{AgentMessage, LearningIntent};
use crate::learning::runner::{LessonRunReport, LessonRunner};
use crate::learning::scaffold::{ScaffoldSpecRunBundle, ScaffoldSpecRunner, SkillScaffoldSpec};
use std::path::Path;

#[derive(Debug, Clone)]
pub struct LearningSession {
    domain: String,
    agent: LearnableAgent,
    reports: Vec<LessonRunReport>,
    artifacts: Vec<ArtifactRef>,
}

impl LearningSession {
    pub fn new(domain: impl Into<String>) -> Self {
        let domain = domain.into();
        Self {
            agent: LearnableAgent::new(domain.clone()),
            domain,
            reports: Vec::new(),
            artifacts: Vec::new(),
        }
    }

    pub fn load_or_new(
        domain: impl Into<String>,
        path: impl AsRef<Path>,
    ) -> Result<Self, LearningIoError> {
        let mut session = Self::new(domain);
        if path.as_ref().exists() {
            session.agent.merge_skill_package(read_skill_package(path)?);
        }
        Ok(session)
    }

    pub fn agent(&self) -> &LearnableAgent {
        &self.agent
    }

    pub fn agent_mut(&mut self) -> &mut LearnableAgent {
        &mut self.agent
    }

    pub fn reports(&self) -> &[LessonRunReport] {
        &self.reports
    }

    pub fn artifacts(&self) -> &[ArtifactRef] {
        &self.artifacts
    }

    pub fn save_skill_package(
        &self,
        path: impl AsRef<Path>,
        skill_id: impl Into<String>,
        lesson_id: impl Into<String>,
    ) -> Result<(), LearningIoError> {
        write_skill_package(
            path,
            &self
                .agent
                .export_skill_package(skill_id.into(), lesson_id.into()),
        )
    }

    pub fn run_lessons(&mut self, lessons: &[Lesson]) -> Vec<LessonRunReport> {
        let runner = LessonRunner::new(self.domain.clone());
        let reports = lessons
            .iter()
            .map(|lesson| self.run_one(&runner, lesson))
            .collect::<Vec<_>>();
        self.record_reports(&reports);
        reports
    }

    pub fn probe_lesson(&mut self, lesson: &Lesson) -> LessonRunReport {
        let runner = LessonRunner::new(self.domain.clone());
        let report = runner.run_probe_with_agent(&mut self.agent, lesson);
        self.record_reports(std::slice::from_ref(&report));
        report
    }

    pub fn run_scaffold_spec(&mut self, spec: &SkillScaffoldSpec) -> ScaffoldSpecRunBundle {
        ScaffoldSpecRunner::new(self.domain.clone()).run(&mut self.agent, spec)
    }

    pub fn reply_to_lesson(&mut self, lesson: &Lesson, intent: LearningIntent) -> AgentMessage {
        match intent {
            LearningIntent::Learn => self.learn_reply(lesson),
            _ => self.probe_reply(lesson),
        }
    }

    fn run_one(&mut self, runner: &LessonRunner, lesson: &Lesson) -> LessonRunReport {
        runner.run_with_agent(&mut self.agent, lesson)
    }

    fn learn_reply(&mut self, lesson: &Lesson) -> AgentMessage {
        let reports = self.run_lessons(std::slice::from_ref(lesson));
        AgentMessage::text(report_text(&reports[0], "learned"))
    }

    fn probe_reply(&mut self, lesson: &Lesson) -> AgentMessage {
        let report = self.probe_lesson(lesson);
        let text = report
            .holdout_attempts
            .first()
            .map(|attempt| attempt.response.clone())
            .unwrap_or_else(|| "NoAnswer".to_owned());
        AgentMessage::text(text)
    }

    fn record_reports(&mut self, reports: &[LessonRunReport]) {
        self.artifacts.extend(report_artifacts(reports));
        self.reports.extend(reports.iter().cloned());
    }
}

pub fn lesson_task_response(agent: &mut LearnableAgent, task: &LessonTask) -> String {
    agent.respond(task, TeacherMode::TeacherOff)
}

fn report_artifacts(reports: &[LessonRunReport]) -> Vec<ArtifactRef> {
    reports
        .iter()
        .flat_map(|report| report.skill_report.artifacts.iter().cloned())
        .collect()
}

fn report_text(report: &LessonRunReport, verb: &str) -> String {
    format!(
        "{verb} {} train={:.2} holdout={:.2}",
        report.lesson_id,
        report.skill_report.train_accuracy(),
        report.skill_report.holdout_accuracy()
    )
}

pub fn reserved_media_artifacts() -> Vec<ArtifactRef> {
    vec![
        ArtifactRef::new("artifact-text-0", ArtifactKind::Text, "inline://chat"),
        ArtifactRef::new(
            "artifact-image-slot",
            ArtifactKind::Image,
            "pending://termwiz-image",
        ),
        ArtifactRef::new(
            "artifact-audio-slot",
            ArtifactKind::Audio,
            "pending://audio-output",
        ),
    ]
}
