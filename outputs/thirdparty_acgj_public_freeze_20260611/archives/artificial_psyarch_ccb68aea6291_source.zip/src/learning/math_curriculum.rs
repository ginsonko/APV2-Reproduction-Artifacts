use crate::core::ap::TeacherMode;
use crate::learning::math::evaluate_arithmetic_expression;
use crate::learning::model::{
    FeedbackPolicy, LearningMaterial, Lesson, LessonTask, MaterialStimulus,
};
use crate::learning::protocol::{AgentLearningRequest, LlmBridge, PlannedLesson};
use crate::learning::runner::LessonRunReport;

const MIXED_COUNTING_LIMIT: u8 = 25;
const BASIC_COUNTING_LIMIT: u8 = 25;

pub fn generated_math_lesson(lesson_id: &str, values: impl IntoIterator<Item = u8>) -> Lesson {
    let values = values.into_iter().collect::<Vec<_>>();
    lesson_from_tasks(
        lesson_id,
        [
            count_scaffold_tasks(BASIC_COUNTING_LIMIT),
            math_tasks(&values),
        ]
        .into_iter()
        .flatten(),
    )
}

pub fn generated_math_lesson_for_level(lesson_id: &str, level: MathDifficulty) -> Lesson {
    lesson_from_tasks(lesson_id, level.tasks())
}

pub fn no_division_math_lesson(lesson_id: &str, left: u8, right: u8) -> Lesson {
    lesson_from_tasks(
        lesson_id,
        math_tasks_for_pair(left, right)
            .into_iter()
            .filter(|task| !task.task_id.starts_with("div-")),
    )
}

pub fn expression_probe_lesson(
    lesson_id: &str,
    expressions: impl IntoIterator<Item = impl Into<String>>,
) -> Lesson {
    let tasks: Vec<_> = expressions
        .into_iter()
        .enumerate()
        .filter_map(|(index, expression)| expression_task("expr-probe", index, expression.into()))
        .collect();
    probe_from_tasks(lesson_id, tasks)
}

pub fn probe_lesson(
    lesson_id: &str,
    questions: impl IntoIterator<Item = (u8, &'static str, u8)>,
) -> Lesson {
    probe_from_tasks(
        lesson_id,
        questions
            .into_iter()
            .map(|(left, op, right)| ArithmeticQuestion::new("probe", left, op, right).task()),
    )
}

pub fn generated_generalization_probe(lesson_id: &str) -> Lesson {
    expression_probe_lesson(
        lesson_id,
        [
            "9 + 4",
            "9 - 7",
            "9 * 2",
            "8 / 2",
            "2 + 3 * 4",
            "(2 + 3) * 4",
        ],
    )
}

fn probe_from_tasks(lesson_id: &str, tasks: impl IntoIterator<Item = LessonTask>) -> Lesson {
    let mut request = AgentLearningRequest::probe_text(lesson_id, "probe generated arithmetic");
    request.material = LearningMaterial::TaskSet(tasks.into_iter().collect());
    PlannedLesson.plan_lesson(request).lesson
}

pub fn probe_answers(report: &LessonRunReport) -> Vec<String> {
    report
        .holdout_attempts
        .iter()
        .map(|attempt| attempt.response.clone())
        .collect()
}

fn lesson_from_tasks(lesson_id: &str, tasks: impl IntoIterator<Item = LessonTask>) -> Lesson {
    let mut request = AgentLearningRequest::user_text(lesson_id, "generated basic arithmetic");
    request.material = LearningMaterial::TaskSet(tasks.into_iter().collect());
    request.teacher_mode = TeacherMode::TeacherOn;
    request.feedback_policy = FeedbackPolicy::AutomaticExaminer;
    PlannedLesson.plan_lesson(request).lesson
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MathDifficulty {
    Basic,
    MultiStep,
    Parentheses,
    Mixed,
}

impl MathDifficulty {
    fn tasks(self) -> Vec<LessonTask> {
        match self {
            Self::Basic => math_tasks(&[0, 1, 2, 3, 4]),
            Self::MultiStep => multi_step_tasks(),
            Self::Parentheses => parenthesized_tasks(),
            Self::Mixed => mixed_tasks(),
        }
    }
}

fn mixed_tasks() -> Vec<LessonTask> {
    [
        count_scaffold_tasks(MIXED_COUNTING_LIMIT),
        MathDifficulty::Basic.tasks(),
        MathDifficulty::MultiStep.tasks(),
        MathDifficulty::Parentheses.tasks(),
    ]
    .into_iter()
    .flatten()
    .collect()
}

fn count_scaffold_tasks(limit: u8) -> Vec<LessonTask> {
    (0..limit)
        .map(|left| ArithmeticQuestion::new("count", left, "+", 1).task())
        .collect()
}

fn math_tasks(values: &[u8]) -> Vec<LessonTask> {
    values
        .iter()
        .flat_map(|left| math_tasks_for_left(*left, values))
        .collect()
}

fn math_tasks_for_left(left: u8, values: &[u8]) -> Vec<LessonTask> {
    values
        .iter()
        .flat_map(|right| math_tasks_for_pair(left, *right))
        .collect()
}

fn math_tasks_for_pair(left: u8, right: u8) -> Vec<LessonTask> {
    arithmetic_questions(left, right)
        .into_iter()
        .map(|question| question.task())
        .collect()
}

fn arithmetic_questions(left: u8, right: u8) -> Vec<ArithmeticQuestion> {
    let mut questions = vec![
        ArithmeticQuestion::new("add", left, "+", right),
        ArithmeticQuestion::new("mul", left, "*", right),
    ];
    if left >= right {
        questions.push(ArithmeticQuestion::new("sub", left, "-", right));
    }
    if right != 0 && left.is_multiple_of(right) {
        questions.push(ArithmeticQuestion::new("div", left, "/", right));
    }
    questions
}

fn multi_step_tasks() -> Vec<LessonTask> {
    expression_tasks(
        "multi",
        [
            "1 + 2 * 3",
            "8 - 2 * 3",
            "9 / 3 + 4",
            "2 * 3 + 4",
            "12 / 3 * 2",
            "7 + 8 / 2",
        ],
    )
}

fn parenthesized_tasks() -> Vec<LessonTask> {
    expression_tasks(
        "paren",
        [
            "(1 + 2) * 3",
            "(8 - 2) / 3",
            "2 * (3 + 4)",
            "(12 / 3) + 5",
            "9 - (2 + 3)",
            "(6 + 2) / 4",
        ],
    )
}

fn expression_tasks(
    prefix: &'static str,
    expressions: impl IntoIterator<Item = impl Into<String>>,
) -> Vec<LessonTask> {
    expressions
        .into_iter()
        .enumerate()
        .filter_map(|(index, expression)| expression_task(prefix, index, expression.into()))
        .collect()
}

fn expression_task(prefix: &str, index: usize, expression: String) -> Option<LessonTask> {
    evaluate_arithmetic_expression(&expression).map(|answer| {
        LessonTask::new(
            format!("{prefix}-{index}"),
            MaterialStimulus::Text(expression),
        )
        .with_expected_action(answer.to_string())
    })
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct ArithmeticQuestion {
    prefix: &'static str,
    left: u8,
    op: &'static str,
    right: u8,
}

impl ArithmeticQuestion {
    fn new(prefix: &'static str, left: u8, op: &'static str, right: u8) -> Self {
        Self {
            prefix,
            left,
            op,
            right,
        }
    }

    fn task(self) -> LessonTask {
        LessonTask::new(self.task_id(), MaterialStimulus::Text(self.expression()))
            .with_expected_action(self.expected_answer())
    }

    fn task_id(self) -> String {
        format!("{}-{}-{}-{}", self.prefix, self.left, self.op, self.right)
    }

    fn expression(self) -> String {
        format!("{} {} {}", self.left, self.op, self.right)
    }

    fn expected_answer(self) -> String {
        arithmetic_op(self.op)(self.left, self.right).to_string()
    }
}

fn arithmetic_op(op: &'static str) -> fn(u8, u8) -> u8 {
    ARITHMETIC_OPS
        .iter()
        .find(|candidate| candidate.symbol == op)
        .map(|candidate| candidate.apply)
        .expect("generated curriculum only uses arithmetic operators")
}

#[derive(Clone, Copy)]
struct ArithmeticOp {
    symbol: &'static str,
    apply: fn(u8, u8) -> u8,
}

const ARITHMETIC_OPS: [ArithmeticOp; 4] = [
    ArithmeticOp {
        symbol: "+",
        apply: |left, right| left + right,
    },
    ArithmeticOp {
        symbol: "-",
        apply: |left, right| left - right,
    },
    ArithmeticOp {
        symbol: "*",
        apply: |left, right| left * right,
    },
    ArithmeticOp {
        symbol: "/",
        apply: |left, right| left / right,
    },
];
