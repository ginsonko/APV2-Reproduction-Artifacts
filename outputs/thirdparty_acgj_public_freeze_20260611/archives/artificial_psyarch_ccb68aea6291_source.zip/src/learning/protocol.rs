use serde::{Deserialize, Serialize};

use crate::core::ap::TeacherMode;
use crate::learning::model::{
    ArtifactRef, FeedbackPolicy, LearningInput, LearningMaterial, LearningSource, Lesson,
};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AgentLearningRequest {
    pub request_id: String,
    pub source: LearningSource,
    #[serde(default)]
    pub intent: LearningIntent,
    pub goal: String,
    pub material: LearningMaterial,
    pub teacher_mode: TeacherMode,
    pub feedback_policy: FeedbackPolicy,
    #[serde(default)]
    pub holdout: HoldoutSpec,
    pub desired_outputs: Vec<MediaOutput>,
    pub conversation: Vec<ConversationTurn>,
}

impl AgentLearningRequest {
    pub fn user_text(request_id: impl Into<String>, goal: impl Into<String>) -> Self {
        let goal = goal.into();
        Self {
            request_id: request_id.into(),
            source: LearningSource::User,
            intent: LearningIntent::Learn,
            material: LearningMaterial::text(goal.clone()),
            goal,
            teacher_mode: TeacherMode::FeedbackOnly,
            feedback_policy: FeedbackPolicy::UserScored,
            holdout: HoldoutSpec::default(),
            desired_outputs: vec![MediaOutput::Text],
            conversation: Vec::new(),
        }
    }

    pub fn into_learning_input(self) -> LearningInput {
        LearningInput::new(
            self.source,
            self.material,
            self.goal,
            self.teacher_mode,
            self.feedback_policy,
        )
    }

    pub fn probe_text(request_id: impl Into<String>, question: impl Into<String>) -> Self {
        let question = question.into();
        Self {
            request_id: request_id.into(),
            source: LearningSource::User,
            intent: LearningIntent::Probe,
            material: LearningMaterial::text(question.clone()),
            goal: question,
            teacher_mode: TeacherMode::TeacherOff,
            feedback_policy: FeedbackPolicy::NoFeedback,
            holdout: HoldoutSpec::teacher_off_only(),
            desired_outputs: vec![MediaOutput::Text],
            conversation: Vec::new(),
        }
    }
}

#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum LearningIntent {
    #[default]
    Learn,
    Probe,
    Chat,
    Export,
}

impl LearningIntent {
    pub fn writes_memory(self) -> bool {
        matches!(self, Self::Learn)
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct HoldoutSpec {
    pub teacher_off: bool,
    pub split: HoldoutSplit,
}

impl HoldoutSpec {
    pub fn teacher_off_only() -> Self {
        Self {
            teacher_off: true,
            split: HoldoutSplit::AllProbe,
        }
    }
}

impl Default for HoldoutSpec {
    fn default() -> Self {
        Self {
            teacher_off: true,
            split: HoldoutSplit::MirrorTasks,
        }
    }
}

#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum HoldoutSplit {
    #[default]
    MirrorTasks,
    AllProbe,
    Ratio {
        train_percent: u8,
    },
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ConversationTurn {
    pub role: ConversationRole,
    pub content: String,
    pub artifacts: Vec<ArtifactRef>,
}

impl ConversationTurn {
    pub fn user(content: impl Into<String>) -> Self {
        Self::new(ConversationRole::User, content)
    }

    pub fn assistant(content: impl Into<String>) -> Self {
        Self::new(ConversationRole::Assistant, content)
    }

    pub fn tool(content: impl Into<String>) -> Self {
        Self::new(ConversationRole::Tool, content)
    }

    fn new(role: ConversationRole, content: impl Into<String>) -> Self {
        Self {
            role,
            content: content.into(),
            artifacts: Vec::new(),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ConversationRole {
    User,
    Assistant,
    Tool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum MediaOutput {
    Text,
    Image,
    Audio,
    Trace,
    SkillPackage,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AgentMessage {
    pub text: String,
    pub artifacts: Vec<ArtifactRef>,
    pub channels: Vec<MediaOutput>,
}

impl AgentMessage {
    pub fn text(text: impl Into<String>) -> Self {
        Self {
            text: text.into(),
            artifacts: Vec::new(),
            channels: vec![MediaOutput::Text],
        }
    }
}

pub trait LlmBridge {
    fn plan_lesson(&self, request: AgentLearningRequest) -> AgentLearningResponse;
}

pub trait LlmAdapter {
    fn generate_curriculum(&self, request: AgentLearningRequest) -> AgentLearningResponse;

    fn review_safety(&self, request: &AgentLearningRequest) -> LlmSafetyReview;

    fn translate_tool_request(&self, request: ToolTranslationRequest) -> ToolTranslationPlan;
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct LlmSafetyReview {
    pub approved: bool,
    pub teacher_off_answer_leak_risk: bool,
    pub notes: Vec<String>,
}

impl LlmSafetyReview {
    pub fn approved(notes: impl IntoIterator<Item = impl Into<String>>) -> Self {
        Self {
            approved: true,
            teacher_off_answer_leak_risk: false,
            notes: notes.into_iter().map(Into::into).collect(),
        }
    }

    pub fn rejected_for_teacher_off_leak(note: impl Into<String>) -> Self {
        Self {
            approved: false,
            teacher_off_answer_leak_risk: true,
            notes: vec![note.into()],
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ToolTranslationRequest {
    pub request_id: String,
    pub user_text: String,
    pub allowed_tools: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ToolTranslationPlan {
    pub request_id: String,
    pub tool_name: Option<String>,
    pub arguments_json: serde_json::Value,
    pub requires_confirmation: bool,
    pub notes: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AgentLearningResponse {
    pub request_id: String,
    pub lesson: Lesson,
    pub notes: Vec<String>,
    pub artifacts: Vec<ArtifactRef>,
}

impl AgentLearningResponse {
    pub fn from_request(request: AgentLearningRequest, lesson_id: impl Into<String>) -> Self {
        let request_id = request.request_id.clone();
        Self {
            request_id,
            lesson: request.into_learning_input().into_lesson(lesson_id),
            notes: Vec::new(),
            artifacts: Vec::new(),
        }
    }
}

#[derive(Debug, Default, Clone, Copy)]
pub struct PlannedLesson;

impl LlmBridge for PlannedLesson {
    fn plan_lesson(&self, request: AgentLearningRequest) -> AgentLearningResponse {
        let lesson_id = format!("lesson-{}", request.request_id);
        AgentLearningResponse::from_request(request, lesson_id)
    }
}

impl LlmAdapter for PlannedLesson {
    fn generate_curriculum(&self, request: AgentLearningRequest) -> AgentLearningResponse {
        let safety = self.review_safety(&request);
        if safety.approved {
            let mut response = self.plan_lesson(request);
            response.notes.extend(safety.notes);
            response
        } else {
            rejected_lesson_response(request, safety.notes)
        }
    }

    fn review_safety(&self, request: &AgentLearningRequest) -> LlmSafetyReview {
        if request.teacher_mode == TeacherMode::TeacherOff && request.intent.writes_memory() {
            return LlmSafetyReview::rejected_for_teacher_off_leak(
                "teacher-off request must not write AP memory",
            );
        }
        LlmSafetyReview::approved([
            "llm output is curriculum/tool proposal only",
            "teacher-off answer path remains audited",
        ])
    }

    fn translate_tool_request(&self, request: ToolTranslationRequest) -> ToolTranslationPlan {
        ToolTranslationPlan {
            request_id: request.request_id,
            tool_name: request.allowed_tools.first().cloned(),
            arguments_json: serde_json::json!({ "text": request.user_text }),
            requires_confirmation: true,
            notes: vec!["mock adapter requires explicit confirmation".to_owned()],
        }
    }
}

fn rejected_lesson_response(
    request: AgentLearningRequest,
    notes: Vec<String>,
) -> AgentLearningResponse {
    AgentLearningResponse {
        request_id: request.request_id,
        lesson: LearningInput::new(
            LearningSource::Llm {
                provider: "adapter".to_owned(),
                model: "mock".to_owned(),
            },
            LearningMaterial::text("rejected unsafe teacher-off learning request"),
            "rejected",
            TeacherMode::TeacherOff,
            FeedbackPolicy::NoFeedback,
        )
        .into_lesson("lesson-rejected"),
        notes,
        artifacts: Vec::new(),
    }
}
