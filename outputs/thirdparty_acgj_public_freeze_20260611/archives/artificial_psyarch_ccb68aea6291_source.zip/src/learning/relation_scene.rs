use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct RelationScene {
    #[serde(default)]
    pub image: Option<String>,
    #[serde(default)]
    pub objects: Vec<SceneObject>,
    #[serde(default)]
    pub query: Option<SceneQuery>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SceneObject {
    pub id: String,
    #[serde(default)]
    pub kind: Option<String>,
    #[serde(default)]
    pub color: Option<String>,
    #[serde(default)]
    pub shape: Option<String>,
    #[serde(default)]
    pub center: Option<[f32; 2]>,
    #[serde(default)]
    pub bbox: Option<[f32; 4]>,
    #[serde(default)]
    pub endpoints: Option<[[f32; 2]; 2]>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SceneQuery {
    pub a: String,
    pub b: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RelationSceneError {
    Json(String),
    MissingQueryObjects,
    UnknownObject(String),
}

impl std::fmt::Display for RelationSceneError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Json(error) => write!(formatter, "invalid relation scene json: {error}"),
            Self::MissingQueryObjects => {
                write!(formatter, "relation scene needs at least two objects")
            }
            Self::UnknownObject(id) => write!(formatter, "unknown relation scene object: {id}"),
        }
    }
}

impl std::error::Error for RelationSceneError {}

pub fn relation_scene_from_json(text: &str) -> Result<RelationScene, RelationSceneError> {
    serde_json::from_str(text).map_err(|error| RelationSceneError::Json(error.to_string()))
}

pub fn relation_scene_state_items(
    scene: &RelationScene,
) -> Result<Vec<String>, RelationSceneError> {
    let pair = scene.object_pair()?;
    let mut items = Vec::new();
    items.extend(scene.image.iter().map(|image| format!("image::{image}")));
    items.extend(scene.objects.iter().flat_map(object_items));
    items.extend(axis_items(pair));
    items.extend(geometry_items(pair));
    Ok(items)
}

impl RelationScene {
    fn object_pair(&self) -> Result<(&SceneObject, &SceneObject), RelationSceneError> {
        match &self.query {
            Some(query) => Ok((self.object(&query.a)?, self.object(&query.b)?)),
            None => self
                .objects
                .first()
                .zip(self.objects.get(1))
                .ok_or(RelationSceneError::MissingQueryObjects),
        }
    }

    fn object(&self, id: &str) -> Result<&SceneObject, RelationSceneError> {
        self.objects
            .iter()
            .find(|object| object.id == id)
            .ok_or_else(|| RelationSceneError::UnknownObject(id.to_owned()))
    }
}

fn object_items(object: &SceneObject) -> Vec<String> {
    let mut items = vec![format!("object::{}{}", object.id, object_attrs(object))];
    items.extend(object.center_point().map(|point| {
        format!(
            "object::{} center=({},{})",
            object.id,
            fmt(point[0]),
            fmt(point[1])
        )
    }));
    items.extend(object.bbox.map(|bbox| {
        format!(
            "object::{} bbox=({},{},{},{})",
            object.id,
            fmt(bbox[0]),
            fmt(bbox[1]),
            fmt(bbox[2]),
            fmt(bbox[3])
        )
    }));
    items.extend(object.endpoints.map(|endpoints| {
        format!(
            "object::{} endpoints=({},{})-({},{})",
            object.id,
            fmt(endpoints[0][0]),
            fmt(endpoints[0][1]),
            fmt(endpoints[1][0]),
            fmt(endpoints[1][1])
        )
    }));
    items
}

fn object_attrs(object: &SceneObject) -> String {
    [
        attr("kind", object.kind.as_deref()),
        attr("color", object.color.as_deref()),
        attr("shape", object.shape.as_deref()),
    ]
    .into_iter()
    .flatten()
    .collect::<Vec<_>>()
    .join("")
}

fn attr(name: &str, value: Option<&str>) -> Option<String> {
    value.map(|value| format!(" {name}={value}"))
}

fn axis_items((a, b): (&SceneObject, &SceneObject)) -> Vec<String> {
    let Some((pa, pb)) = a.center_point().zip(b.center_point()) else {
        return Vec::new();
    };
    vec![
        delta_item("x", a, b, pa[0] - pb[0]),
        delta_item("y", a, b, pa[1] - pb[1]),
        pair_item("axis::abs_x_delta", a, b, (pa[0] - pb[0]).abs()),
        pair_item("axis::abs_y_delta", a, b, (pa[1] - pb[1]).abs()),
    ]
}

fn geometry_items((a, b): (&SceneObject, &SceneObject)) -> Vec<String> {
    let Some((va, vb)) = a.direction().zip(b.direction()) else {
        return Vec::new();
    };
    let slopes = a.slope().zip(b.slope()).map(|(sa, sb)| {
        vec![
            object_value("geometry::slope", a, sa),
            object_value("geometry::slope", b, sb),
            pair_item("geometry::slope_delta", a, b, slope_delta(sa, sb)),
        ]
    });
    let mut items = slopes.unwrap_or_default();
    items.push(pair_item("geometry::dot_direction", a, b, dot(va, vb)));
    items.push(pair_item("geometry::angle", a, b, angle_degrees(va, vb)));
    items
}

fn delta_item(axis: &str, a: &SceneObject, b: &SceneObject, value: f32) -> String {
    pair_item(&format!("axis::{axis}_delta"), a, b, value)
}

fn object_value(prefix: &str, object: &SceneObject, value: f32) -> String {
    format!("{prefix}({})={}", object.id, fmt(value))
}

fn pair_item(prefix: &str, a: &SceneObject, b: &SceneObject, value: f32) -> String {
    format!("{prefix}({},{})={}", a.id, b.id, fmt(value))
}

impl SceneObject {
    fn center_point(&self) -> Option<[f32; 2]> {
        self.center.or_else(|| self.bbox.map(bbox_center))
    }

    fn direction(&self) -> Option<[f32; 2]> {
        self.endpoints
            .map(|points| [points[1][0] - points[0][0], points[1][1] - points[0][1]])
    }

    fn slope(&self) -> Option<f32> {
        self.direction().map(|direction| {
            if direction[0] == 0.0 {
                f32::INFINITY
            } else {
                direction[1] / direction[0]
            }
        })
    }
}

fn bbox_center(bbox: [f32; 4]) -> [f32; 2] {
    [(bbox[0] + bbox[2]) / 2.0, (bbox[1] + bbox[3]) / 2.0]
}

fn slope_delta(left: f32, right: f32) -> f32 {
    if left.is_infinite() && right.is_infinite() {
        0.0
    } else {
        (left - right).abs()
    }
}

fn dot(left: [f32; 2], right: [f32; 2]) -> f32 {
    left[0] * right[0] + left[1] * right[1]
}

fn angle_degrees(left: [f32; 2], right: [f32; 2]) -> f32 {
    let norms = norm(left) * norm(right);
    if norms == 0.0 {
        return 0.0;
    }
    (dot(left, right) / norms)
        .clamp(-1.0, 1.0)
        .acos()
        .to_degrees()
        .round()
}

fn norm(vector: [f32; 2]) -> f32 {
    (vector[0].powi(2) + vector[1].powi(2)).sqrt()
}

fn fmt(value: f32) -> String {
    if value.is_infinite() {
        "infinity".to_owned()
    } else if value.fract() == 0.0 {
        format!("{value:.0}")
    } else {
        format!("{value:.3}")
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn scene_generates_axis_features_without_relation_label() {
        let scene = relation_scene_from_json(
            r#"{"objects":[{"id":"a","center":[20,50]},{"id":"b","center":[80,50]}]}"#,
        )
        .unwrap();

        let items = relation_scene_state_items(&scene).unwrap();

        assert!(items.iter().any(|item| item == "axis::x_delta(a,b)=-60"));
        assert!(items.iter().any(|item| item == "axis::abs_y_delta(a,b)=0"));
        assert!(!items.iter().any(|item| item.contains("RelationWord")));
    }

    #[test]
    fn scene_generates_line_geometry_features() {
        let scene = relation_scene_from_json(
            r#"{"objects":[{"id":"m","endpoints":[[10,20],[90,20]]},{"id":"n","endpoints":[[10,60],[90,60]]}]}"#,
        )
        .unwrap();

        let items = relation_scene_state_items(&scene).unwrap();

        assert!(
            items
                .iter()
                .any(|item| item == "geometry::slope_delta(m,n)=0")
        );
        assert!(items.iter().any(|item| item == "geometry::angle(m,n)=0"));
    }
}
