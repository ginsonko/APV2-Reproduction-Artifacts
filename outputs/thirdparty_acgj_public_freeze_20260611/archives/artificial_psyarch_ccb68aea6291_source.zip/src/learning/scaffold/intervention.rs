use serde::{Deserialize, Serialize};

use crate::core::ap::{Feedback, TeacherMode};
use crate::runtime::TeacherSignal;

use super::phase::TeacherSignalPolicy;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct EducationIntervention {
    pub state_items: Vec<String>,
    pub action_biases: Vec<ActionBias>,
    pub feedback: Option<ScaffoldFeedback>,
}

impl EducationIntervention {
    pub fn empty() -> Self {
        Self {
            state_items: Vec::new(),
            action_biases: Vec::new(),
            feedback: None,
        }
    }

    pub fn for_expected_action(expected_action: Option<&str>, strength: f32) -> Self {
        let Some(action) = expected_action else {
            return Self::empty();
        };
        Self {
            state_items: vec![format!("teacher.expected_action:{action}")],
            action_biases: vec![ActionBias {
                action: action.to_owned(),
                strength: strength.clamp(0.0, 1.0),
            }],
            feedback: None,
        }
    }

    pub fn apply_policy(self, policy: TeacherSignalPolicy) -> Self {
        Self {
            state_items: keep_when(policy.state_items, self.state_items),
            action_biases: keep_when(policy.action_biases, self.action_biases),
            feedback: policy.feedback.then_some(self.feedback).flatten(),
        }
    }

    pub fn is_empty(&self) -> bool {
        self.state_items.is_empty() && self.action_biases.is_empty() && self.feedback.is_none()
    }

    pub fn to_teacher_signal(&self, mode: TeacherMode) -> TeacherSignal {
        self.action_biases
            .iter()
            .fold(
                state_items_signal(mode, &self.state_items),
                |signal, bias| signal.with_action_bias(&bias.action, bias.strength),
            )
            .with_optional_feedback(self.feedback.map(Feedback::from))
    }
}

impl Default for EducationIntervention {
    fn default() -> Self {
        Self::empty()
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ActionBias {
    pub action: String,
    pub strength: f32,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ScaffoldFeedback {
    Reward,
    Punishment,
}

impl From<ScaffoldFeedback> for Feedback {
    fn from(feedback: ScaffoldFeedback) -> Self {
        match feedback {
            ScaffoldFeedback::Reward => Self::Reward,
            ScaffoldFeedback::Punishment => Self::Punishment,
        }
    }
}

fn keep_when<T>(condition: bool, value: Vec<T>) -> Vec<T> {
    if condition { value } else { Vec::new() }
}

fn state_items_signal(mode: TeacherMode, state_items: &[String]) -> TeacherSignal {
    state_items
        .iter()
        .fold(TeacherSignal::new(mode), |signal, item| {
            signal.with_state_item(item)
        })
}

trait OptionalFeedback {
    fn with_optional_feedback(self, feedback: Option<Feedback>) -> Self;
}

impl OptionalFeedback for TeacherSignal {
    fn with_optional_feedback(self, feedback: Option<Feedback>) -> Self {
        if let Some(feedback) = feedback {
            self.with_feedback(feedback)
        } else {
            self
        }
    }
}
