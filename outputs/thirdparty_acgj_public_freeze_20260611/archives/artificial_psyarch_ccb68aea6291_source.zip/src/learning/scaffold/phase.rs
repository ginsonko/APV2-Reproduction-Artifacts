use serde::{Deserialize, Serialize};

use crate::core::ap::TeacherMode;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ScaffoldPhaseId {
    Demonstrate,
    StrongScaffold,
    WeakScaffold,
    FeedbackOnly,
    TeacherOff,
    ColdRetest,
}

impl ScaffoldPhaseId {
    pub fn all() -> [Self; 6] {
        [
            Self::Demonstrate,
            Self::StrongScaffold,
            Self::WeakScaffold,
            Self::FeedbackOnly,
            Self::TeacherOff,
            Self::ColdRetest,
        ]
    }

    pub fn label(self) -> &'static str {
        PHASE_LABELS[self as usize]
    }

    pub fn teacher_mode(self) -> TeacherMode {
        match self {
            Self::Demonstrate | Self::StrongScaffold => TeacherMode::TeacherOn,
            Self::WeakScaffold => TeacherMode::Fade,
            Self::FeedbackOnly => TeacherMode::FeedbackOnly,
            Self::TeacherOff | Self::ColdRetest => TeacherMode::TeacherOff,
        }
    }

    pub fn teacher_signal(self) -> TeacherSignalPolicy {
        match self {
            Self::Demonstrate | Self::StrongScaffold | Self::WeakScaffold => {
                TeacherSignalPolicy::full()
            }
            Self::FeedbackOnly => TeacherSignalPolicy::feedback_only(),
            Self::TeacherOff | Self::ColdRetest => TeacherSignalPolicy::empty(),
        }
    }

    pub fn default_strength(self) -> f32 {
        DEFAULT_PHASES
            .iter()
            .find(|(phase, _)| *phase == self)
            .map(|(_, strength)| *strength)
            .unwrap_or_default()
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct ScaffoldPhase {
    pub phase_id: ScaffoldPhaseId,
    pub strength: f32,
    pub teacher_signal: TeacherSignalPolicy,
}

impl ScaffoldPhase {
    pub fn new(phase_id: ScaffoldPhaseId, strength: f32) -> Self {
        Self {
            phase_id,
            strength: strength.clamp(0.0, 1.0),
            teacher_signal: phase_id.teacher_signal(),
        }
    }

    pub fn default_path() -> Vec<Self> {
        DEFAULT_PHASES
            .into_iter()
            .map(|(phase, strength)| Self::new(phase, strength))
            .collect()
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct TeacherSignalPolicy {
    pub state_items: bool,
    pub action_biases: bool,
    pub feedback: bool,
}

impl TeacherSignalPolicy {
    pub fn full() -> Self {
        Self {
            state_items: true,
            action_biases: true,
            feedback: true,
        }
    }

    pub fn feedback_only() -> Self {
        Self {
            state_items: false,
            action_biases: false,
            feedback: true,
        }
    }

    pub fn empty() -> Self {
        Self {
            state_items: false,
            action_biases: false,
            feedback: false,
        }
    }

    pub fn is_empty(self) -> bool {
        !self.state_items && !self.action_biases && !self.feedback
    }
}

const PHASE_LABELS: [&str; 6] = [
    "demonstrate",
    "strong_scaffold",
    "weak_scaffold",
    "feedback_only",
    "teacher_off",
    "cold_retest",
];

const DEFAULT_PHASES: [(ScaffoldPhaseId, f32); 6] = [
    (ScaffoldPhaseId::Demonstrate, 1.0),
    (ScaffoldPhaseId::StrongScaffold, 0.86),
    (ScaffoldPhaseId::WeakScaffold, 0.38),
    (ScaffoldPhaseId::FeedbackOnly, 0.72),
    (ScaffoldPhaseId::TeacherOff, 0.0),
    (ScaffoldPhaseId::ColdRetest, 0.0),
];
