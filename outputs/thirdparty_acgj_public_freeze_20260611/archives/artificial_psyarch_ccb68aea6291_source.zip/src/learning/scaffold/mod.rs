mod controller;
mod execution;
mod intervention;
mod phase;
mod report;
mod runner;
mod spec;

pub use controller::{SkillProtocolState, SkillScaffoldController};
pub use execution::{ScaffoldMasterySummary, ScaffoldSpecRunBundle, ScaffoldSpecRunner};
pub use intervention::{ActionBias, EducationIntervention, ScaffoldFeedback};
pub use phase::{ScaffoldPhase, ScaffoldPhaseId, TeacherSignalPolicy};
pub use report::{ScaffoldAttempt, ScaffoldPhaseReport, ScaffoldRunReport};
pub use runner::ScaffoldRunner;
pub use spec::{
    MasteryPolicy, ScaffoldBuildingBlock, ScaffoldStep, SkillScaffoldSpec, StepActionBias,
    StepFeedback,
};

#[cfg(test)]
mod tests {
    use crate::core::ap::{Feedback, TeacherMode};
    use crate::learning::agent::LearnableAgent;
    use crate::learning::model::{
        FeedbackPolicy, LearningInput, LearningMaterial, LearningSource, LessonTask,
        MaterialStimulus,
    };

    use super::*;

    #[test]
    fn default_scaffold_path_matches_teacher_fade_protocol() {
        let phases = ScaffoldPhase::default_path();

        assert_eq!(
            phases
                .iter()
                .map(|phase| phase.phase_id)
                .collect::<Vec<_>>(),
            vec![
                ScaffoldPhaseId::Demonstrate,
                ScaffoldPhaseId::StrongScaffold,
                ScaffoldPhaseId::WeakScaffold,
                ScaffoldPhaseId::FeedbackOnly,
                ScaffoldPhaseId::TeacherOff,
                ScaffoldPhaseId::ColdRetest,
            ]
        );
        assert!(phases[4].teacher_signal.is_empty());
        assert!(phases[5].teacher_signal.is_empty());
    }

    #[test]
    fn scaffold_runner_strips_teacher_packet_in_teacher_off() {
        let lesson = simple_lesson();
        let mut agent = LearnableAgent::new("scaffold-test");

        let report = ScaffoldRunner::new("skill.shape").run(&mut agent, &lesson);

        assert!(report.teacher_off_clean());
        assert_eq!(report.teacher_off_accuracy(), 1.0);
        assert_eq!(report.cold_retest_accuracy(), 1.0);
    }

    #[test]
    fn feedback_only_phase_has_no_action_bias_but_writes_memory() {
        let lesson = simple_lesson();
        let mut agent = LearnableAgent::new("feedback-only-scaffold");
        let phases = vec![ScaffoldPhase::new(ScaffoldPhaseId::FeedbackOnly, 0.72)];

        let report = ScaffoldRunner::new("skill.feedback")
            .with_phases(phases)
            .run(&mut agent, &lesson);
        let attempt = &report.phases[0].attempts[0];

        assert!(attempt.teacher_packet.state_items.is_empty());
        assert!(attempt.teacher_packet.action_biases.is_empty());
        assert!(attempt.memory_write_enabled);
        assert_eq!(agent.memory_rows(), 1);
    }

    #[test]
    fn scaffold_controller_applies_phase_policy_and_mastery_annealing() {
        let mut controller = SkillScaffoldController::new();
        let spec = scaffold_spec_with_step();
        controller.register_spec(spec);
        controller.enable("skill.reread", ScaffoldPhaseId::StrongScaffold);

        let first = controller
            .intervention_for_step("skill.reread", "step.reread")
            .unwrap();
        assert_eq!(first.state_items, vec!["hint::look_again"]);
        assert_eq!(first.action_biases[0].action, "reread");
        assert_eq!(first.action_biases[0].strength, 0.86);

        controller.update_mastery("skill.reread", Feedback::Reward);
        let second = controller
            .intervention_for_step("skill.reread", "step.reread")
            .unwrap();
        assert!(second.action_biases[0].strength < first.action_biases[0].strength);
    }

    #[test]
    fn scaffold_controller_strips_teacher_off_intervention() {
        let mut controller = SkillScaffoldController::new();
        controller.register_spec(scaffold_spec_with_step());
        controller.enable("skill.reread", ScaffoldPhaseId::TeacherOff);

        let packet = controller
            .intervention_for_step("skill.reread", "step.reread")
            .unwrap();

        assert!(packet.is_empty());
    }

    #[test]
    fn education_intervention_bridges_to_runtime_teacher_signal() {
        let packet = EducationIntervention {
            state_items: vec!["hint::look_again".to_owned()],
            action_biases: vec![ActionBias {
                action: "reread".to_owned(),
                strength: 0.5,
            }],
            feedback: Some(ScaffoldFeedback::Reward),
        };

        let fade = packet.to_teacher_signal(TeacherMode::Fade);
        assert_eq!(
            fade.visible_state_items().collect::<Vec<_>>(),
            vec!["hint::look_again"]
        );
        assert_eq!(fade.action_bias_strength("reread"), 0.5);
        assert_eq!(fade.learner_feedback(), Some(Feedback::Reward));

        let teacher_off = packet.to_teacher_signal(TeacherMode::TeacherOff);
        assert!(teacher_off.visible_state_items().next().is_none());
        assert_eq!(teacher_off.action_bias_strength("reread"), 0.0);
        assert_eq!(teacher_off.learner_feedback(), None);
    }

    #[test]
    fn scaffold_spec_runner_trains_and_retests_under_teacher_off() {
        let spec = scaffold_spec_with_step();
        let mut agent = LearnableAgent::new("scaffold-spec-test");

        let bundle = ScaffoldSpecRunner::new("scaffold-spec-test").run(&mut agent, &spec);

        assert!(bundle.report.teacher_off_clean());
        assert_eq!(bundle.report.teacher_off_accuracy(), 1.0);
        assert_eq!(bundle.report.cold_retest_accuracy(), 1.0);
        assert!(bundle.mastery.success_steps > 0);
    }

    fn simple_lesson() -> crate::learning::Lesson {
        LearningInput::new(
            LearningSource::User,
            LearningMaterial::TaskSet(vec![
                LessonTask::new("shape-0", MaterialStimulus::Text("red circle".to_owned()))
                    .with_expected_action("ClassifyRedCircle"),
            ]),
            "classify shape",
            TeacherMode::FeedbackOnly,
            FeedbackPolicy::AutomaticExaminer,
        )
        .into_lesson("shape-scaffold")
    }

    fn scaffold_spec_with_step() -> SkillScaffoldSpec {
        let mut step = ScaffoldStep::new("step.reread");
        step.state_items.push("hint::look_again".to_owned());
        step.action_biases.push(StepActionBias::new("reread", 1.0));
        step.feedback = Some(StepFeedback::Reward);
        let mut spec = SkillScaffoldSpec::new("skill.reread");
        spec.steps.push(step);
        spec
    }
}
