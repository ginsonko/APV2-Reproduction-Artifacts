use serde::{Deserialize, Serialize};

use crate::core::ap::Feedback;

use super::intervention::EducationIntervention;
use super::phase::ScaffoldPhaseId;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ScaffoldRunReport {
    pub skill_id: String,
    pub phases: Vec<ScaffoldPhaseReport>,
}

impl ScaffoldRunReport {
    pub fn teacher_off_clean(&self) -> bool {
        self.phases
            .iter()
            .filter(|phase| phase.phase_id == ScaffoldPhaseId::TeacherOff)
            .all(ScaffoldPhaseReport::teacher_packet_empty)
    }

    pub fn cold_retest_accuracy(&self) -> f32 {
        self.phase_accuracy(ScaffoldPhaseId::ColdRetest)
    }

    pub fn teacher_off_accuracy(&self) -> f32 {
        self.phase_accuracy(ScaffoldPhaseId::TeacherOff)
    }

    fn phase_accuracy(&self, phase_id: ScaffoldPhaseId) -> f32 {
        self.phases
            .iter()
            .find(|phase| phase.phase_id == phase_id)
            .map(ScaffoldPhaseReport::accuracy)
            .unwrap_or_default()
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ScaffoldPhaseReport {
    pub phase_id: ScaffoldPhaseId,
    pub attempts: Vec<ScaffoldAttempt>,
}

impl ScaffoldPhaseReport {
    pub fn accuracy(&self) -> f32 {
        let total = self.attempts.len();
        if total == 0 {
            return 0.0;
        }
        let rewards = self
            .attempts
            .iter()
            .filter(|attempt| attempt.feedback == Some(Feedback::Reward))
            .count();
        rewards as f32 / total as f32
    }

    pub fn teacher_packet_empty(&self) -> bool {
        self.attempts
            .iter()
            .all(|attempt| attempt.teacher_packet.is_empty())
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ScaffoldAttempt {
    pub task_id: String,
    pub response: String,
    pub expected_action: Option<String>,
    pub feedback: Option<Feedback>,
    pub teacher_packet: EducationIntervention,
    pub memory_write_enabled: bool,
}
