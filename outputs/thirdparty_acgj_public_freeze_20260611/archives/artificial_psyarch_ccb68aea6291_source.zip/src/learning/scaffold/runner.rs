use crate::core::ap::{Feedback, TeacherMode};
use crate::learning::agent::LearnableAgent;
use crate::learning::model::{Lesson, LessonTask};

use super::intervention::{EducationIntervention, ScaffoldFeedback};
use super::phase::ScaffoldPhase;
use super::report::{ScaffoldAttempt, ScaffoldPhaseReport, ScaffoldRunReport};

#[derive(Debug, Clone)]
pub struct ScaffoldRunner {
    pub skill_id: String,
    pub phases: Vec<ScaffoldPhase>,
}

impl ScaffoldRunner {
    pub fn new(skill_id: impl Into<String>) -> Self {
        Self {
            skill_id: skill_id.into(),
            phases: ScaffoldPhase::default_path(),
        }
    }

    pub fn with_phases(mut self, phases: Vec<ScaffoldPhase>) -> Self {
        self.phases = phases;
        self
    }

    pub fn run(&self, agent: &mut LearnableAgent, lesson: &Lesson) -> ScaffoldRunReport {
        if lesson.is_trainable() {
            agent.prepare_lesson(lesson);
        }
        let phases = self
            .phases
            .iter()
            .map(|phase| run_phase(agent, lesson, *phase))
            .collect();
        ScaffoldRunReport {
            skill_id: self.skill_id.clone(),
            phases,
        }
    }
}

fn run_phase(
    agent: &mut LearnableAgent,
    lesson: &Lesson,
    phase: ScaffoldPhase,
) -> ScaffoldPhaseReport {
    let memory_before = agent.memory_rows();
    let attempts = lesson
        .tasks
        .iter()
        .map(|task| run_attempt(agent, lesson, task, phase))
        .collect();
    debug_assert_memory_boundary(agent, phase.phase_id.teacher_mode(), memory_before);
    ScaffoldPhaseReport {
        phase_id: phase.phase_id,
        attempts,
    }
}

fn run_attempt(
    agent: &mut LearnableAgent,
    lesson: &Lesson,
    task: &LessonTask,
    phase: ScaffoldPhase,
) -> ScaffoldAttempt {
    let mode = phase.phase_id.teacher_mode();
    let teacher_packet = teacher_packet(task, phase);
    let response = agent.respond_with_intervention(task, mode, &teacher_packet);
    let feedback = score_response(task.expected_action.as_deref(), &response);
    if phase.teacher_signal.feedback {
        agent.learn_from_feedback(lesson, task, &response, feedback, mode);
    }
    ScaffoldAttempt {
        task_id: task.task_id.clone(),
        response,
        expected_action: task.expected_action.clone(),
        feedback: Some(feedback),
        teacher_packet,
        memory_write_enabled: mode.memory_write_enabled(),
    }
}

fn teacher_packet(task: &LessonTask, phase: ScaffoldPhase) -> EducationIntervention {
    EducationIntervention::for_expected_action(task.expected_action.as_deref(), phase.strength)
        .apply_policy(phase.teacher_signal)
}

fn score_response(expected_action: Option<&str>, response: &str) -> Feedback {
    if expected_action.is_none_or(|expected| expected == response) {
        Feedback::Reward
    } else {
        Feedback::Punishment
    }
}

fn debug_assert_memory_boundary(agent: &LearnableAgent, mode: TeacherMode, memory_before: usize) {
    if !mode.memory_write_enabled() {
        debug_assert_eq!(agent.memory_rows(), memory_before);
    }
}

impl From<Feedback> for ScaffoldFeedback {
    fn from(feedback: Feedback) -> Self {
        match feedback {
            Feedback::Reward => Self::Reward,
            Feedback::Punishment => Self::Punishment,
        }
    }
}
