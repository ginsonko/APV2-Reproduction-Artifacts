use serde::{Deserialize, Serialize};

use super::phase::{ScaffoldPhase, ScaffoldPhaseId};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SkillScaffoldSpec {
    pub skill_id: String,
    #[serde(default)]
    pub title: String,
    #[serde(default)]
    pub goal: String,
    #[serde(default)]
    pub domain_tags: Vec<String>,
    #[serde(default)]
    pub building_blocks: Vec<ScaffoldBuildingBlock>,
    #[serde(default = "ScaffoldPhase::default_path")]
    pub phases: Vec<ScaffoldPhase>,
    #[serde(default)]
    pub steps: Vec<ScaffoldStep>,
    #[serde(default)]
    pub mastery: MasteryPolicy,
    #[serde(default = "default_guardrails")]
    pub guardrails: Vec<String>,
    #[serde(default)]
    pub notes: Vec<String>,
}

impl SkillScaffoldSpec {
    pub fn new(skill_id: impl Into<String>) -> Self {
        let skill_id = skill_id.into();
        Self {
            title: skill_id.clone(),
            skill_id,
            goal: String::new(),
            domain_tags: Vec::new(),
            building_blocks: Vec::new(),
            phases: ScaffoldPhase::default_path(),
            steps: Vec::new(),
            mastery: MasteryPolicy::default(),
            guardrails: default_guardrails(),
            notes: Vec::new(),
        }
    }

    pub fn phase(&self, phase_id: ScaffoldPhaseId) -> ScaffoldPhase {
        self.phases
            .iter()
            .find(|phase| phase.phase_id == phase_id)
            .copied()
            .unwrap_or_else(|| ScaffoldPhase::new(phase_id, phase_id.default_strength()))
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ScaffoldBuildingBlock {
    pub block_id: String,
    #[serde(default)]
    pub label: String,
    #[serde(default = "default_modality")]
    pub modality: String,
    #[serde(default = "default_block_role")]
    pub role: String,
    #[serde(default)]
    pub notes: Vec<String>,
}

impl ScaffoldBuildingBlock {
    pub fn new(block_id: impl Into<String>, label: impl Into<String>) -> Self {
        Self {
            block_id: block_id.into(),
            label: label.into(),
            modality: "mixed".to_owned(),
            role: "building_block".to_owned(),
            notes: Vec::new(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ScaffoldStep {
    pub step_id: String,
    #[serde(default)]
    pub title: String,
    #[serde(default)]
    pub scenario_tags: Vec<String>,
    #[serde(default)]
    pub state_items: Vec<String>,
    #[serde(default)]
    pub action_biases: Vec<StepActionBias>,
    #[serde(default)]
    pub feedback: Option<StepFeedback>,
    #[serde(default)]
    pub expected_evidence: Vec<String>,
    #[serde(default)]
    pub notes: Vec<String>,
}

impl ScaffoldStep {
    pub fn new(step_id: impl Into<String>) -> Self {
        let step_id = step_id.into();
        Self {
            title: step_id.clone(),
            step_id,
            scenario_tags: Vec::new(),
            state_items: Vec::new(),
            action_biases: Vec::new(),
            feedback: None,
            expected_evidence: Vec::new(),
            notes: Vec::new(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct StepActionBias {
    pub action: String,
    pub strength: f32,
}

impl StepActionBias {
    pub fn new(action: impl Into<String>, strength: f32) -> Self {
        Self {
            action: action.into(),
            strength: strength.clamp(0.0, 1.0),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum StepFeedback {
    Reward,
    Punishment,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct MasteryPolicy {
    pub success_threshold: f32,
    pub update_rate: f32,
    pub decay_per_mastery: f32,
    pub warmup_successes: usize,
}

impl Default for MasteryPolicy {
    fn default() -> Self {
        Self {
            success_threshold: 0.42,
            update_rate: 0.30,
            decay_per_mastery: 0.72,
            warmup_successes: 6,
        }
    }
}

fn default_guardrails() -> Vec<String> {
    [
        "external teacher, not AP core",
        "soft bias only; AP may accept, ignore, or outcompete it",
        "all-SA state-field citizenship is preserved",
        "teacher-off emits no state_items, action_biases, or feedback",
        "no hardcoded answers in teacher-off probes",
    ]
    .into_iter()
    .map(str::to_owned)
    .collect()
}

fn default_modality() -> String {
    "mixed".to_owned()
}

fn default_block_role() -> String {
    "building_block".to_owned()
}
