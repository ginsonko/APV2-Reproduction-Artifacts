use serde::{Deserialize, Serialize};

use crate::core::ap::Feedback;
use crate::learning::agent::LearnableAgent;
use crate::learning::model::{
    FeedbackPolicy, LearningInput, LearningMaterial, LearningSource, Lesson, LessonTask,
    MaterialStimulus,
};

use super::controller::SkillScaffoldController;
use super::phase::{ScaffoldPhase, ScaffoldPhaseId};
use super::report::{ScaffoldAttempt, ScaffoldPhaseReport, ScaffoldRunReport};
use super::spec::{ScaffoldStep, SkillScaffoldSpec};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ScaffoldSpecRunBundle {
    pub spec: SkillScaffoldSpec,
    pub report: ScaffoldRunReport,
    pub mastery: ScaffoldMasterySummary,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ScaffoldMasterySummary {
    pub skill_id: String,
    pub mastery_estimate: f32,
    pub success_steps: usize,
    pub failure_steps: usize,
    pub last_step_id: String,
    pub last_effective_strength: f32,
}

#[derive(Debug, Clone)]
pub struct ScaffoldSpecRunner {
    pub domain: String,
}

impl ScaffoldSpecRunner {
    pub fn new(domain: impl Into<String>) -> Self {
        Self {
            domain: domain.into(),
        }
    }

    pub fn run(
        &self,
        agent: &mut LearnableAgent,
        spec: &SkillScaffoldSpec,
    ) -> ScaffoldSpecRunBundle {
        let lesson = lesson_from_spec(spec, &self.domain);
        if lesson.is_trainable() {
            agent.prepare_lesson(&lesson);
        }
        let mut controller = SkillScaffoldController::new();
        controller.register_spec(spec.clone());
        let phases = spec
            .phases
            .iter()
            .copied()
            .map(|phase| run_phase(agent, &lesson, spec, &mut controller, phase))
            .collect();
        let mastery = controller
            .state(&spec.skill_id)
            .map(ScaffoldMasterySummary::from)
            .unwrap_or_else(|| empty_mastery(&spec.skill_id));
        ScaffoldSpecRunBundle {
            spec: spec.clone(),
            report: ScaffoldRunReport {
                skill_id: spec.skill_id.clone(),
                phases,
            },
            mastery,
        }
    }
}

fn run_phase(
    agent: &mut LearnableAgent,
    lesson: &Lesson,
    spec: &SkillScaffoldSpec,
    controller: &mut SkillScaffoldController,
    phase: ScaffoldPhase,
) -> ScaffoldPhaseReport {
    controller.enable(&spec.skill_id, phase.phase_id);
    let memory_before = agent.memory_rows();
    let attempts = spec
        .steps
        .iter()
        .zip(lesson.tasks.iter())
        .map(|(step, task)| run_step(agent, lesson, spec, controller, phase.phase_id, step, task))
        .collect();
    if !phase.phase_id.teacher_mode().memory_write_enabled() {
        debug_assert_eq!(agent.memory_rows(), memory_before);
    }
    ScaffoldPhaseReport {
        phase_id: phase.phase_id,
        attempts,
    }
}

fn run_step(
    agent: &mut LearnableAgent,
    lesson: &Lesson,
    spec: &SkillScaffoldSpec,
    controller: &mut SkillScaffoldController,
    phase_id: ScaffoldPhaseId,
    step: &ScaffoldStep,
    task: &LessonTask,
) -> ScaffoldAttempt {
    let mode = phase_id.teacher_mode();
    let teacher_packet = controller
        .intervention_for_step(&spec.skill_id, &step.step_id)
        .unwrap_or_default();
    let response = agent.respond_with_intervention(task, mode, &teacher_packet);
    let feedback = score_response(task.expected_action.as_deref(), &response);
    if phase_id.teacher_signal().feedback {
        agent.learn_from_feedback(lesson, task, &response, feedback, mode);
        controller.update_mastery(&spec.skill_id, feedback);
    }
    ScaffoldAttempt {
        task_id: task.task_id.clone(),
        response,
        expected_action: task.expected_action.clone(),
        feedback: Some(feedback),
        teacher_packet,
        memory_write_enabled: mode.memory_write_enabled(),
    }
}

fn lesson_from_spec(spec: &SkillScaffoldSpec, domain: &str) -> Lesson {
    LearningInput::new(
        LearningSource::Script {
            name: format!("scaffold:{}", spec.skill_id),
        },
        LearningMaterial::TaskSet(spec.steps.iter().map(task_from_step).collect()),
        spec.goal.clone(),
        crate::core::ap::TeacherMode::FeedbackOnly,
        FeedbackPolicy::AutomaticExaminer,
    )
    .into_lesson(format!("{domain}-{}", spec.skill_id))
}

fn task_from_step(step: &ScaffoldStep) -> LessonTask {
    let mut task = LessonTask::new(
        step.step_id.clone(),
        MaterialStimulus::Text(step_stimulus_text(step)),
    );
    if let Some(action) = expected_action(step) {
        task = task.with_expected_action(action);
    }
    task
}

fn step_stimulus_text(step: &ScaffoldStep) -> String {
    if step.state_items.is_empty() {
        step.title.clone()
    } else {
        step.state_items.join(" | ")
    }
}

fn expected_action(step: &ScaffoldStep) -> Option<String> {
    step.action_biases
        .iter()
        .max_by(|left, right| left.strength.total_cmp(&right.strength))
        .map(|bias| bias.action.clone())
}

fn score_response(expected_action: Option<&str>, response: &str) -> Feedback {
    if expected_action.is_none_or(|expected| expected == response) {
        Feedback::Reward
    } else {
        Feedback::Punishment
    }
}

fn empty_mastery(skill_id: &str) -> ScaffoldMasterySummary {
    ScaffoldMasterySummary {
        skill_id: skill_id.to_owned(),
        mastery_estimate: 0.0,
        success_steps: 0,
        failure_steps: 0,
        last_step_id: String::new(),
        last_effective_strength: 0.0,
    }
}

impl From<&super::controller::SkillProtocolState> for ScaffoldMasterySummary {
    fn from(state: &super::controller::SkillProtocolState) -> Self {
        Self {
            skill_id: state.skill_id.clone(),
            mastery_estimate: state.mastery_estimate,
            success_steps: state.success_steps,
            failure_steps: state.failure_steps,
            last_step_id: state.last_step_id.clone(),
            last_effective_strength: state.last_effective_strength,
        }
    }
}
