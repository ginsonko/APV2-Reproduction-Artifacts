use std::collections::BTreeMap;

use serde::{Deserialize, Serialize};

use crate::core::ap::Feedback;

use super::intervention::{ActionBias, EducationIntervention, ScaffoldFeedback};
use super::phase::ScaffoldPhaseId;
use super::spec::{ScaffoldStep, SkillScaffoldSpec, StepFeedback};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SkillProtocolState {
    pub skill_id: String,
    pub enabled: bool,
    pub phase_id: ScaffoldPhaseId,
    pub base_strength: f32,
    pub mastery_estimate: f32,
    pub success_steps: usize,
    pub failure_steps: usize,
    pub last_step_id: String,
    pub last_effective_strength: f32,
}

impl SkillProtocolState {
    pub fn new(skill_id: impl Into<String>) -> Self {
        Self {
            skill_id: skill_id.into(),
            enabled: false,
            phase_id: ScaffoldPhaseId::StrongScaffold,
            base_strength: 1.0,
            mastery_estimate: 0.0,
            success_steps: 0,
            failure_steps: 0,
            last_step_id: String::new(),
            last_effective_strength: 0.0,
        }
    }
}

#[derive(Debug, Default, Clone)]
pub struct SkillScaffoldController {
    specs: BTreeMap<String, SkillScaffoldSpec>,
    states: BTreeMap<String, SkillProtocolState>,
}

impl SkillScaffoldController {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn register_spec(&mut self, spec: SkillScaffoldSpec) -> SkillProtocolState {
        let skill_id = spec.skill_id.clone();
        self.specs.insert(skill_id.clone(), spec);
        self.states
            .entry(skill_id.clone())
            .or_insert_with(|| SkillProtocolState::new(skill_id))
            .clone()
    }

    pub fn enable(
        &mut self,
        skill_id: &str,
        phase_id: ScaffoldPhaseId,
    ) -> Option<SkillProtocolState> {
        let state = self.state_mut(skill_id)?;
        state.enabled = true;
        state.phase_id = phase_id;
        Some(state.clone())
    }

    pub fn disable(&mut self, skill_id: &str) -> Option<SkillProtocolState> {
        let state = self.state_mut(skill_id)?;
        state.enabled = false;
        Some(state.clone())
    }

    pub fn intervention_for_step(
        &mut self,
        skill_id: &str,
        step_id: &str,
    ) -> Option<EducationIntervention> {
        let spec = self.specs.get(skill_id)?;
        let step = spec.steps.iter().find(|step| step.step_id == step_id)?;
        let state = self.states.get_mut(skill_id)?;
        Some(intervention_from_step(spec, state, step))
    }

    pub fn update_mastery(
        &mut self,
        skill_id: &str,
        feedback: Feedback,
    ) -> Option<SkillProtocolState> {
        let policy = self.specs.get(skill_id)?.mastery;
        let state = self.state_mut(skill_id)?;
        apply_mastery_update(state, policy.update_rate, feedback);
        Some(state.clone())
    }

    pub fn state(&self, skill_id: &str) -> Option<&SkillProtocolState> {
        self.states.get(skill_id)
    }

    fn state_mut(&mut self, skill_id: &str) -> Option<&mut SkillProtocolState> {
        self.states.get_mut(skill_id)
    }
}

fn intervention_from_step(
    spec: &SkillScaffoldSpec,
    state: &mut SkillProtocolState,
    step: &ScaffoldStep,
) -> EducationIntervention {
    let phase = spec.phase(state.phase_id);
    let strength = effective_strength(state.base_strength, phase.strength, state.mastery_estimate);
    state.last_step_id = step.step_id.clone();
    state.last_effective_strength = strength;
    EducationIntervention {
        state_items: step.state_items.clone(),
        action_biases: step
            .action_biases
            .iter()
            .map(|bias| ActionBias {
                action: bias.action.clone(),
                strength: bias.strength * strength,
            })
            .collect(),
        feedback: step.feedback.map(scaffold_feedback),
    }
    .apply_policy(phase.teacher_signal)
}

fn effective_strength(base: f32, phase: f32, mastery: f32) -> f32 {
    (base * phase * (1.0 - mastery.clamp(0.0, 1.0))).clamp(0.0, 1.0)
}

fn scaffold_feedback(feedback: StepFeedback) -> ScaffoldFeedback {
    match feedback {
        StepFeedback::Reward => ScaffoldFeedback::Reward,
        StepFeedback::Punishment => ScaffoldFeedback::Punishment,
    }
}

fn apply_mastery_update(state: &mut SkillProtocolState, update_rate: f32, feedback: Feedback) {
    match feedback {
        Feedback::Reward => {
            state.success_steps += 1;
            state.mastery_estimate += (1.0 - state.mastery_estimate) * update_rate;
        }
        Feedback::Punishment => {
            state.failure_steps += 1;
            state.mastery_estimate *= 1.0 - update_rate;
        }
    }
    state.mastery_estimate = state.mastery_estimate.clamp(0.0, 1.0);
}
