use serde::{Deserialize, Serialize};

use crate::core::ap::{AuditTrace, Feedback, TaintAuditSummary, TeacherMode};
use crate::learning::agent::LearnableAgent;
use crate::learning::model::{Lesson, LessonAttempt, SkillReport};
use crate::skill_registry::SkillBoundary;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct LessonRunReport {
    pub lesson_id: String,
    pub train_attempts: Vec<LessonAttempt>,
    pub holdout_attempts: Vec<LessonAttempt>,
    pub taint_audit: TaintAuditSummary,
    pub skill_report: SkillReport,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LessonRunner {
    pub domain: String,
}

impl LessonRunner {
    pub fn new(domain: impl Into<String>) -> Self {
        Self {
            domain: domain.into(),
        }
    }

    pub fn run(&self, lesson: &Lesson) -> LessonRunReport {
        let mut agent = LearnableAgent::new(self.domain.clone());
        self.run_with_agent(&mut agent, lesson)
    }

    pub fn run_with_agent(&self, agent: &mut LearnableAgent, lesson: &Lesson) -> LessonRunReport {
        if lesson.is_trainable() {
            agent.prepare_lesson(lesson);
        }
        let train_attempts = run_attempts(agent, lesson, lesson.teacher_mode);
        let memory_before_holdout = agent.memory_rows();
        let holdout_attempts = run_attempts(agent, lesson, TeacherMode::TeacherOff);
        debug_assert_eq!(agent.memory_rows(), memory_before_holdout);
        let skill_report = self.skill_report(agent, lesson, &train_attempts, &holdout_attempts);
        let taint_audit = taint_audit_from_holdout(&holdout_attempts);
        LessonRunReport {
            lesson_id: lesson.lesson_id.clone(),
            train_attempts,
            holdout_attempts,
            taint_audit,
            skill_report,
        }
    }

    pub fn run_probe_with_agent(
        &self,
        agent: &mut LearnableAgent,
        lesson: &Lesson,
    ) -> LessonRunReport {
        let memory_before_probe = agent.memory_rows();
        let holdout_attempts = run_attempts(agent, lesson, TeacherMode::TeacherOff);
        debug_assert_eq!(agent.memory_rows(), memory_before_probe);
        let train_attempts = Vec::new();
        let skill_report = self.skill_report(agent, lesson, &train_attempts, &holdout_attempts);
        let taint_audit = taint_audit_from_holdout(&holdout_attempts);
        LessonRunReport {
            lesson_id: lesson.lesson_id.clone(),
            train_attempts,
            holdout_attempts,
            taint_audit,
            skill_report,
        }
    }

    fn skill_report(
        &self,
        agent: &LearnableAgent,
        lesson: &Lesson,
        train_attempts: &[LessonAttempt],
        holdout_attempts: &[LessonAttempt],
    ) -> SkillReport {
        let mut report = SkillReport::new(
            format!("skill.{}", lesson.lesson_id),
            lesson.lesson_id.clone(),
            SkillBoundary::new(self.domain.clone(), 1, lesson.task_count().max(1)),
        );
        record_feedback(&mut report, train_attempts, PhaseKind::Train);
        record_feedback(&mut report, holdout_attempts, PhaseKind::Holdout);
        report.artifacts.push(agent.artifact_ref(&lesson.lesson_id));
        report.finalize()
    }
}

fn run_attempts(
    agent: &mut LearnableAgent,
    lesson: &Lesson,
    mode: TeacherMode,
) -> Vec<LessonAttempt> {
    lesson
        .tasks
        .iter()
        .map(|task| {
            let response = agent.respond(task, mode);
            let feedback = score_response(task.expected_action.as_deref(), &response);
            agent.learn_from_feedback(lesson, task, &response, feedback, mode);
            LessonAttempt::new(task.task_id.clone(), response, Some(feedback), mode)
        })
        .collect()
}

fn score_response(expected_action: Option<&str>, response: &str) -> Feedback {
    if expected_action.is_none_or(|expected| expected == response) {
        Feedback::Reward
    } else {
        Feedback::Punishment
    }
}

fn record_feedback(report: &mut SkillReport, attempts: &[LessonAttempt], phase: PhaseKind) {
    for attempt in attempts {
        if let Some(feedback) = attempt.feedback {
            record_phase_feedback(report, feedback, phase);
        }
    }
}

fn record_phase_feedback(report: &mut SkillReport, feedback: Feedback, phase: PhaseKind) {
    match phase {
        PhaseKind::Train => report.record_train_attempt(feedback),
        PhaseKind::Holdout => report.record_holdout_attempt(feedback),
    }
}

fn taint_audit_from_holdout(attempts: &[LessonAttempt]) -> TaintAuditSummary {
    TaintAuditSummary::from_teacher_off_traces(attempts.iter().map(attempt_trace))
}

fn attempt_trace(attempt: &LessonAttempt) -> AuditTrace {
    AuditTrace::for_mode(attempt.teacher_mode)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum PhaseKind {
    Train,
    Holdout,
}
