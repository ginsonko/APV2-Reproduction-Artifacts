use std::path::Path;

use serde::{Deserialize, Serialize};

use crate::learning::io::{LearningIoError, read_skill_package};
use crate::learning::model::{Lesson, LessonTask, MaterialStimulus};
use crate::learning::relation_scene::{
    RelationScene, RelationSceneError, relation_scene_from_json, relation_scene_state_items,
};
use crate::learning::runner::LessonRunner;
use crate::learning::{
    DEFAULT_RELATION_DOMAIN, DEFAULT_RELATION_SKILL, FeedbackPolicy, LearnableAgent, LearningInput,
    LearningSource,
};
use crate::workspace::WorkspacePaths;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct RelationProbeReport {
    pub action: String,
    pub text: String,
    pub state_items: Vec<String>,
    pub clean: bool,
}

#[derive(Debug)]
pub enum RelationProbeError {
    Scene(RelationSceneError),
    Io(LearningIoError),
}

impl std::fmt::Display for RelationProbeError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Scene(error) => write!(formatter, "{error}"),
            Self::Io(error) => write!(formatter, "{error}"),
        }
    }
}

impl std::error::Error for RelationProbeError {}

impl From<RelationSceneError> for RelationProbeError {
    fn from(error: RelationSceneError) -> Self {
        Self::Scene(error)
    }
}

impl From<LearningIoError> for RelationProbeError {
    fn from(error: LearningIoError) -> Self {
        Self::Io(error)
    }
}

pub fn default_relation_skill_path() -> std::path::PathBuf {
    WorkspacePaths::from_env().external_skill(DEFAULT_RELATION_SKILL)
}

pub fn probe_relation_scene_json(
    skill_path: impl AsRef<Path>,
    scene_json: &str,
) -> Result<RelationProbeReport, RelationProbeError> {
    let scene = relation_scene_from_json(scene_json)?;
    probe_relation_scene(skill_path, &scene)
}

pub fn probe_relation_scene(
    skill_path: impl AsRef<Path>,
    scene: &RelationScene,
) -> Result<RelationProbeReport, RelationProbeError> {
    let state_items = relation_scene_state_items(scene)?;
    let action = probe_state_items(skill_path, &state_items)?;
    Ok(RelationProbeReport {
        text: relation_action_text(&action).unwrap_or(&action).to_owned(),
        action,
        state_items,
        clean: true,
    })
}

fn probe_state_items(
    skill_path: impl AsRef<Path>,
    state_items: &[String],
) -> Result<String, RelationProbeError> {
    let mut agent = LearnableAgent::from_skill_package(read_skill_package(skill_path)?);
    let report = LessonRunner::new(DEFAULT_RELATION_DOMAIN)
        .run_probe_with_agent(&mut agent, &probe_lesson(state_items));
    Ok(report
        .holdout_attempts
        .first()
        .map(|attempt| attempt.response.clone())
        .unwrap_or_else(|| "NoAnswer".to_owned()))
}

fn probe_lesson(state_items: &[String]) -> Lesson {
    LearningInput::new(
        LearningSource::User,
        crate::learning::LearningMaterial::TaskSet(vec![LessonTask::new(
            "relation-scene-probe",
            MaterialStimulus::Text(state_items.join(" | ")),
        )]),
        "probe learned visual relation from scene features",
        crate::core::ap::TeacherMode::TeacherOff,
        FeedbackPolicy::NoFeedback,
    )
    .into_lesson("relation-scene-probe")
}

fn relation_action_text(action: &str) -> Option<&'static str> {
    RELATION_ACTION_TEXT
        .iter()
        .find_map(|(candidate, text)| (*candidate == action).then_some(*text))
}

const RELATION_ACTION_TEXT: &[(&str, &str)] = &[
    ("RelationWordLeft", "在左边"),
    ("RelationWordRight", "在右边"),
    ("RelationWordAbove", "在上方"),
    ("RelationWordBelow", "在下方"),
    ("RelationWordParallel", "平行于"),
    ("RelationWordPerpendicular", "垂直于"),
];

#[cfg(test)]
mod tests {
    use super::*;
    use crate::learning::io::write_skill_package;
    use crate::learning::scaffold::ScaffoldSpecRunner;
    use crate::learning::{ScaffoldPhase, ScaffoldPhaseId, SkillScaffoldSpec, StepActionBias};

    #[test]
    fn relation_probe_uses_loaded_skill_package() {
        let path =
            std::env::temp_dir().join(format!("relation-runtime-{}.apbin", std::process::id()));
        let mut agent = LearnableAgent::new(DEFAULT_RELATION_DOMAIN);
        let spec = tiny_spec();
        ScaffoldSpecRunner::new(DEFAULT_RELATION_DOMAIN).run(&mut agent, &spec);
        write_skill_package(
            &path,
            &agent.export_skill_package("skill.test.relation", "test"),
        )
        .unwrap();

        let report = probe_relation_scene_json(
            &path,
            r#"{"objects":[{"id":"p","center":[10,50]},{"id":"q","center":[90,50]}]}"#,
        )
        .unwrap();
        let _ = std::fs::remove_file(path);

        assert_eq!(report.action, "RelationWordLeft");
        assert_eq!(report.text, "在左边");
        assert!(report.clean);
    }

    fn tiny_spec() -> SkillScaffoldSpec {
        let mut spec = SkillScaffoldSpec::new("skill.test.relation");
        spec.phases = vec![
            ScaffoldPhase::new(ScaffoldPhaseId::FeedbackOnly, 1.0),
            ScaffoldPhase::new(ScaffoldPhaseId::TeacherOff, 0.0),
        ];
        let mut step = crate::learning::ScaffoldStep::new("left");
        step.state_items = vec![
            "object::a center=(20,50)".to_owned(),
            "object::b center=(80,50)".to_owned(),
            "axis::x_delta(a,b)=-60".to_owned(),
            "axis::abs_y_delta(a,b)=0".to_owned(),
        ];
        step.action_biases = vec![StepActionBias::new("RelationWordLeft", 1.0)];
        spec.steps = vec![step];
        spec
    }
}
