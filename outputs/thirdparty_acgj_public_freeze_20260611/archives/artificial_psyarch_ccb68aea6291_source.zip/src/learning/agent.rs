use std::collections::BTreeSet;

use serde::{Deserialize, Serialize};

use crate::core::ap::{Feedback, MemoryEvent, MemoryStore, TeacherMode};
use crate::learning::math::ArithmeticSkill;
use crate::learning::model::{ArtifactKind, ArtifactRef, Lesson, LessonTask, MaterialStimulus};
use crate::learning::scaffold::EducationIntervention;

#[derive(Debug, Clone)]
pub struct LearnableAgent {
    domain: String,
    memory: MemoryStore<usize>,
    actions: Vec<String>,
}

impl LearnableAgent {
    pub fn new(domain: impl Into<String>) -> Self {
        Self {
            domain: domain.into(),
            memory: MemoryStore::default(),
            actions: Vec::new(),
        }
    }

    pub fn domain(&self) -> &str {
        &self.domain
    }

    pub fn memory_rows(&self) -> usize {
        self.memory.events().len()
    }

    pub fn prepare_lesson(&mut self, lesson: &Lesson) {
        for action in lesson.tasks.iter().filter_map(expected_action) {
            self.intern_action(action);
        }
    }

    pub fn respond(&mut self, task: &LessonTask, mode: TeacherMode) -> String {
        match visible_expected_action(task, mode) {
            Some(action) => action.to_owned(),
            None if mode.exploration_enabled() => self.explore_action(task),
            None => self.recall_action(task),
        }
    }

    pub fn respond_with_intervention(
        &mut self,
        task: &LessonTask,
        mode: TeacherMode,
        intervention: &EducationIntervention,
    ) -> String {
        self.biased_action(intervention)
            .unwrap_or_else(|| self.respond_without_answer_visibility(task, mode))
    }

    pub fn learn_from_feedback(
        &mut self,
        lesson: &Lesson,
        task: &LessonTask,
        response: &str,
        feedback: Feedback,
        mode: TeacherMode,
    ) {
        if !lesson.allows_learning(mode) {
            return;
        }
        let action = self.intern_action(response);
        self.memory.write(MemoryEvent {
            context: self.domain.clone(),
            state_id: stimulus_key(&task.stimulus),
            action,
            feedback,
        });
    }

    pub fn export_skill_package(
        &self,
        skill_id: impl Into<String>,
        lesson_id: impl Into<String>,
    ) -> LearnedSkillPackage {
        LearnedSkillPackage {
            skill_id: skill_id.into(),
            lesson_id: lesson_id.into(),
            domain: self.domain.clone(),
            actions: self.actions.clone(),
            memory_events: self.memory.events().to_vec(),
        }
    }

    pub fn from_skill_package(package: LearnedSkillPackage) -> Self {
        let mut agent = Self::new(package.domain);
        agent.actions = package.actions;
        for event in package.memory_events {
            agent.memory.write(event);
        }
        agent
    }

    pub fn merge_skill_package(&mut self, package: LearnedSkillPackage) {
        let action_map = self.merge_actions(package.actions);
        for event in package.memory_events {
            self.merge_memory_event(event, &action_map, &package.domain);
        }
    }

    pub fn artifact_ref(&self, lesson_id: &str) -> ArtifactRef {
        ArtifactRef::new(
            format!("skill-package-{lesson_id}"),
            ArtifactKind::SkillPackage,
            format!("memory://{}/{}", self.domain, lesson_id),
        )
    }

    fn recall_action(&self, task: &LessonTask) -> String {
        self.positive_action_ids(task)
            .map(|ids| self.best_action(task, ids))
            .or_else(|| self.feature_generalized_action(task))
            .or_else(|| self.arithmetic_answer(task))
            .unwrap_or_else(|| fallback_response(&task.stimulus).to_owned())
    }

    fn respond_without_answer_visibility(&self, task: &LessonTask, mode: TeacherMode) -> String {
        if mode.exploration_enabled() {
            self.explore_action(task)
        } else {
            self.recall_action(task)
        }
    }

    fn biased_action(&mut self, intervention: &EducationIntervention) -> Option<String> {
        let action = strongest_action_bias(intervention)?;
        self.intern_action(action);
        Some(action.to_owned())
    }

    fn arithmetic_answer(&self, task: &LessonTask) -> Option<String> {
        ArithmeticSkill::from_events(&self.actions, self.memory.events()).answer(task)
    }

    fn explore_action(&self, task: &LessonTask) -> String {
        self.action_ids()
            .map(|ids| self.best_action(task, ids))
            .unwrap_or_else(|| fallback_response(&task.stimulus).to_owned())
    }

    fn best_action(&self, task: &LessonTask, ids: Vec<usize>) -> String {
        let action = self
            .memory
            .best_action(&self.domain, &stimulus_key(&task.stimulus), &ids);
        self.actions[action].clone()
    }

    fn feature_generalized_action(&self, task: &LessonTask) -> Option<String> {
        let query = structured_features(&task.stimulus);
        (!query.is_empty())
            .then(|| self.best_feature_action(&query))
            .flatten()
            .map(|action| self.actions[action].clone())
    }

    fn best_feature_action(&self, query: &[String]) -> Option<usize> {
        (0..self.actions.len())
            .filter_map(|action| {
                feature_action_score(self.memory.events(), &self.domain, query, action)
            })
            .max_by_key(|score| (score.score, std::cmp::Reverse(score.action)))
            .map(|score| score.action)
    }

    fn action_ids(&self) -> Option<Vec<usize>> {
        (!self.actions.is_empty()).then(|| (0..self.actions.len()).collect())
    }

    fn positive_action_ids(&self, task: &LessonTask) -> Option<Vec<usize>> {
        let state_id = stimulus_key(&task.stimulus);
        let ids: Vec<_> = (0..self.actions.len())
            .filter(|action| self.memory.score_action(&self.domain, &state_id, *action) > 0)
            .collect();
        (!ids.is_empty()).then_some(ids)
    }

    fn intern_action(&mut self, action: &str) -> usize {
        self.actions
            .iter()
            .position(|candidate| candidate == action)
            .unwrap_or_else(|| self.push_action(action))
    }

    fn push_action(&mut self, action: &str) -> usize {
        self.actions.push(action.to_owned());
        self.actions.len() - 1
    }

    fn merge_actions(&mut self, actions: Vec<String>) -> Vec<usize> {
        actions
            .iter()
            .map(|action| self.intern_action(action))
            .collect()
    }

    fn merge_memory_event(
        &mut self,
        event: MemoryEvent<usize>,
        action_map: &[usize],
        package_domain: &str,
    ) {
        let Some(action) = action_map.get(event.action).copied() else {
            return;
        };
        self.memory.write(MemoryEvent {
            context: merged_context(&event.context, package_domain, &self.domain),
            state_id: event.state_id,
            action,
            feedback: event.feedback,
        });
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct LearnedSkillPackage {
    pub skill_id: String,
    pub lesson_id: String,
    pub domain: String,
    pub actions: Vec<String>,
    pub memory_events: Vec<MemoryEvent<usize>>,
}

fn merged_context(event_context: &str, package_domain: &str, agent_domain: &str) -> String {
    if event_context == package_domain {
        agent_domain.to_owned()
    } else {
        event_context.to_owned()
    }
}

trait LessonLearningGate {
    fn allows_learning(&self, mode: TeacherMode) -> bool;
}

impl LessonLearningGate for Lesson {
    fn allows_learning(&self, mode: TeacherMode) -> bool {
        self.is_trainable() && mode.memory_write_enabled()
    }
}

pub fn lesson_action_candidates(lesson: &Lesson) -> Vec<String> {
    lesson
        .tasks
        .iter()
        .filter_map(expected_action)
        .collect::<BTreeSet<_>>()
        .into_iter()
        .map(str::to_owned)
        .collect()
}

fn visible_expected_action(task: &LessonTask, mode: TeacherMode) -> Option<&str> {
    mode.answer_visible_to_learner()
        .then(|| expected_action(task))
        .flatten()
}

fn expected_action(task: &LessonTask) -> Option<&str> {
    task.expected_action.as_deref()
}

fn strongest_action_bias(intervention: &EducationIntervention) -> Option<&str> {
    intervention
        .action_biases
        .iter()
        .max_by(|left, right| left.strength.total_cmp(&right.strength))
        .map(|bias| bias.action.as_str())
}

fn fallback_response(stimulus: &MaterialStimulus) -> &'static str {
    match stimulus_kind(stimulus) {
        StimulusKind::Text => "ObserveText",
        StimulusKind::Json => "ObserveJson",
        StimulusKind::Image => "ObserveImage",
        StimulusKind::Audio => "ObserveAudio",
    }
}

fn stimulus_key(stimulus: &MaterialStimulus) -> String {
    format!(
        "{}:{}",
        stimulus_kind(stimulus).key_prefix(),
        stimulus_value(stimulus)
    )
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum StimulusKind {
    Text,
    Json,
    Image,
    Audio,
}

impl StimulusKind {
    fn key_prefix(self) -> &'static str {
        match self {
            Self::Text => "text",
            Self::Json => "json",
            Self::Image => "image",
            Self::Audio => "audio",
        }
    }
}

fn stimulus_kind(stimulus: &MaterialStimulus) -> StimulusKind {
    match stimulus {
        MaterialStimulus::Text(_) => StimulusKind::Text,
        MaterialStimulus::Json(_) => StimulusKind::Json,
        MaterialStimulus::ImageRef(_) => StimulusKind::Image,
        MaterialStimulus::AudioRef(_) => StimulusKind::Audio,
    }
}

fn stimulus_value(stimulus: &MaterialStimulus) -> String {
    match stimulus {
        MaterialStimulus::Text(text) => text.clone(),
        MaterialStimulus::Json(value) => value.to_string(),
        MaterialStimulus::ImageRef(artifact) | MaterialStimulus::AudioRef(artifact) => {
            artifact.uri.clone()
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct FeatureActionScore {
    action: usize,
    score: i32,
}

fn feature_action_score(
    events: &[MemoryEvent<usize>],
    domain: &str,
    query: &[String],
    action: usize,
) -> Option<FeatureActionScore> {
    let score: i32 = events
        .iter()
        .filter(|event| event.context == domain && event.action == action)
        .map(|event| feature_event_score(event, query))
        .sum();
    (score > 0).then_some(FeatureActionScore { action, score })
}

fn feature_event_score(event: &MemoryEvent<usize>, query: &[String]) -> i32 {
    let memory = structured_features_from_text(&event.state_id);
    let overlap = memory
        .iter()
        .filter(|feature| query.contains(feature))
        .count() as i32;
    overlap * event.feedback.score()
}

fn structured_features(stimulus: &MaterialStimulus) -> Vec<String> {
    match stimulus {
        MaterialStimulus::Text(text) => structured_features_from_text(text),
        MaterialStimulus::Json(value) => structured_features_from_text(&value.to_string()),
        MaterialStimulus::ImageRef(_) | MaterialStimulus::AudioRef(_) => Vec::new(),
    }
}

fn structured_features_from_text(text: &str) -> Vec<String> {
    text.split('|')
        .map(str::trim)
        .flat_map(structured_features_for_item)
        .collect::<BTreeSet<_>>()
        .into_iter()
        .collect()
}

fn structured_features_for_item(item: &str) -> Vec<String> {
    if !is_structured_feature(item) {
        return Vec::new();
    }
    let mut features = vec![normalize_structured_feature(item)];
    if let Some(feature) = numeric_relation_feature(item) {
        features.push(feature);
    }
    features
}

fn is_structured_feature(item: &str) -> bool {
    STRUCTURED_FEATURE_PREFIXES
        .iter()
        .any(|prefix| item.starts_with(prefix))
}

const STRUCTURED_FEATURE_PREFIXES: [&str; 4] =
    ["object::", "axis::", "geometry::", "visual_feature::"];

fn normalize_structured_feature(item: &str) -> String {
    item.split_whitespace().next().unwrap_or(item).to_owned()
}

fn numeric_relation_feature(item: &str) -> Option<String> {
    let (label, value) = item.split_once('=')?;
    let value = parse_feature_number(value)?;
    let bucket = numeric_bucket(value);
    Some(format!("{}::{bucket}", canonical_numeric_label(label)))
}

fn canonical_numeric_label(label: &str) -> String {
    match label.split_once('(') {
        Some((prefix, _)) => prefix.to_owned(),
        None => label.to_owned(),
    }
}

fn parse_feature_number(value: &str) -> Option<f32> {
    match value.trim() {
        "infinity" | "+infinity" => Some(f32::INFINITY),
        "-infinity" => Some(f32::NEG_INFINITY),
        value => value.parse().ok(),
    }
}

fn numeric_bucket(value: f32) -> &'static str {
    if value.is_infinite() {
        "infinite"
    } else if value == 0.0 {
        "zero"
    } else if value == 90.0 {
        "ninety"
    } else if value.is_sign_negative() {
        "negative"
    } else {
        "positive"
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::learning::model::{FeedbackPolicy, LearningInput, LearningMaterial, LearningSource};

    #[test]
    fn agent_learns_mapping_and_recalls_teacher_off() {
        let lesson = LearningInput::new(
            LearningSource::User,
            LearningMaterial::TaskSet(vec![
                LessonTask::new("shape-0", MaterialStimulus::Text("red circle".to_owned()))
                    .with_expected_action("ClassifyRedCircle"),
            ]),
            "classify shape",
            TeacherMode::FeedbackOnly,
            FeedbackPolicy::AutomaticExaminer,
        )
        .into_lesson("lesson-shape");
        let mut agent = LearnableAgent::new("test");

        let before = agent.respond(&lesson.tasks[0], TeacherMode::TeacherOff);
        agent.learn_from_feedback(
            &lesson,
            &lesson.tasks[0],
            "ClassifyRedCircle",
            Feedback::Reward,
            TeacherMode::FeedbackOnly,
        );
        let after = agent.respond(&lesson.tasks[0], TeacherMode::TeacherOff);

        assert_eq!(before, "ObserveText");
        assert_eq!(after, "ClassifyRedCircle");
        assert_eq!(agent.memory_rows(), 1);
    }

    #[test]
    fn teacher_off_feedback_does_not_write_memory() {
        let lesson = LearningInput::new(
            LearningSource::User,
            LearningMaterial::TaskSet(vec![
                LessonTask::new("shape-0", MaterialStimulus::Text("red circle".to_owned()))
                    .with_expected_action("ClassifyRedCircle"),
            ]),
            "probe",
            TeacherMode::FeedbackOnly,
            FeedbackPolicy::AutomaticExaminer,
        )
        .into_lesson("lesson-shape");
        let mut agent = LearnableAgent::new("test");

        agent.learn_from_feedback(
            &lesson,
            &lesson.tasks[0],
            "ClassifyRedCircle",
            Feedback::Reward,
            TeacherMode::TeacherOff,
        );

        assert_eq!(agent.memory_rows(), 0);
    }

    #[test]
    fn teacher_off_intervention_without_bias_does_not_reveal_expected_action() {
        let task = LessonTask::new("shape-0", MaterialStimulus::Text("red circle".to_owned()))
            .with_expected_action("ClassifyRedCircle");
        let mut agent = LearnableAgent::new("test");

        let response = agent.respond_with_intervention(
            &task,
            TeacherMode::TeacherOff,
            &EducationIntervention::empty(),
        );

        assert_eq!(response, "ObserveText");
    }

    #[test]
    fn structured_numeric_features_generalize_across_unseen_text_keys() {
        let lesson = LearningInput::new(
            LearningSource::User,
            LearningMaterial::TaskSet(vec![
                LessonTask::new(
                    "delta-train",
                    MaterialStimulus::Text(
                        "image::asset_001.svg | axis::x_delta(a,b)=-60".to_owned(),
                    ),
                )
                .with_expected_action("ActionNegativeDelta"),
            ]),
            "learn numeric feature",
            TeacherMode::FeedbackOnly,
            FeedbackPolicy::AutomaticExaminer,
        )
        .into_lesson("feature-generalization");
        let mut agent = LearnableAgent::new("test");
        agent.learn_from_feedback(
            &lesson,
            &lesson.tasks[0],
            "ActionNegativeDelta",
            Feedback::Reward,
            TeacherMode::FeedbackOnly,
        );
        let probe = LessonTask::new(
            "delta-probe",
            MaterialStimulus::Text("image::asset_999.svg | axis::x_delta(p,q)=-42".to_owned()),
        );

        let response = agent.respond(&probe, TeacherMode::TeacherOff);

        assert_eq!(response, "ActionNegativeDelta");
    }
}
