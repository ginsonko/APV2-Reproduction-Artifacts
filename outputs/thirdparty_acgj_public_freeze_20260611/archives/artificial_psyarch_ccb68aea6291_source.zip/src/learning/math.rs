mod parser;
mod skill;

pub use skill::ArithmeticSkill;

pub fn evaluate_arithmetic_expression(text: &str) -> Option<i16> {
    parser::ArithmeticExpression::parse(text)?.evaluate_builtin()
}

pub fn is_arithmetic_expression(text: &str) -> bool {
    parser::ArithmeticExpression::parse(text).is_some()
        && text.chars().any(|ch| matches!(ch, '+' | '-' | '*' | '/'))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::ap::{Feedback, MemoryEvent};
    use crate::learning::model::{LessonTask, MaterialStimulus};

    fn event(state_id: &str, action: usize, feedback: Feedback) -> MemoryEvent<usize> {
        MemoryEvent {
            context: "math".to_owned(),
            state_id: state_id.to_owned(),
            action,
            feedback,
        }
    }

    #[test]
    fn learns_operator_from_rewarded_examples() {
        let actions = vec!["3".to_owned(), "13".to_owned()];
        let skill = ArithmeticSkill::from_events(
            &actions,
            &[
                event("text:1 + 2", 0, Feedback::Reward),
                event("text:12 + 1", 1, Feedback::Reward),
            ],
        );
        let task = LessonTask::new("probe", MaterialStimulus::Text("9 + 4".to_owned()));

        assert_eq!(skill.answer(&task).as_deref(), Some("13"));
    }

    #[test]
    fn ignores_unrewarded_examples() {
        let actions = vec!["wrong".to_owned(), "3".to_owned()];
        let skill = ArithmeticSkill::from_events(
            &actions,
            &[
                event("text:1 + 2", 0, Feedback::Punishment),
                event("text:1 * 3", 1, Feedback::Punishment),
            ],
        );
        let task = LessonTask::new("probe", MaterialStimulus::Text("9 + 4".to_owned()));

        assert_eq!(skill.answer(&task), None);
    }

    #[test]
    fn rewarded_feedback_is_the_learning_signal_not_builtin_answer_check() {
        let actions = vec!["5".to_owned()];
        let skill =
            ArithmeticSkill::from_events(&actions, &[event("text:2 + 3", 0, Feedback::Reward)]);
        let task = LessonTask::new("probe", MaterialStimulus::Text("4 + 1".to_owned()));

        assert_eq!(skill.answer(&task).as_deref(), Some("5"));
    }

    #[test]
    fn learned_operator_without_counting_path_does_not_act_like_calculator() {
        let actions = vec!["3".to_owned()];
        let skill =
            ArithmeticSkill::from_events(&actions, &[event("text:1 + 2", 0, Feedback::Reward)]);
        let task = LessonTask::new("probe", MaterialStimulus::Text("40 + 2".to_owned()));

        assert_eq!(skill.answer(&task), None);
    }

    #[test]
    fn generalizes_multi_step_expression_after_learning_ops() {
        let actions = vec![
            "3".to_owned(),
            "6".to_owned(),
            "2".to_owned(),
            "7".to_owned(),
        ];
        let skill = ArithmeticSkill::from_events(
            &actions,
            &[
                event("text:1 + 2", 0, Feedback::Reward),
                event("text:2 * 3", 1, Feedback::Reward),
                event("text:6 / 3", 2, Feedback::Reward),
                event("text:6 + 1", 3, Feedback::Reward),
            ],
        );
        let task = LessonTask::new("probe", MaterialStimulus::Text("1 + 2 * 3".to_owned()));

        assert_eq!(skill.answer(&task).as_deref(), Some("7"));
    }

    #[test]
    fn requires_all_expression_ops_to_be_learned() {
        let actions = vec!["3".to_owned()];
        let skill =
            ArithmeticSkill::from_events(&actions, &[event("text:1 + 2", 0, Feedback::Reward)]);
        let task = LessonTask::new("probe", MaterialStimulus::Text("2 + 3 * 4".to_owned()));

        assert_eq!(skill.answer(&task), None);
    }

    #[test]
    fn evaluates_parenthesized_expression() {
        assert_eq!(evaluate_arithmetic_expression("(2 + 3) * 4"), Some(20));
    }

    #[test]
    fn detects_expression_for_routing_without_answering_plain_numbers() {
        assert!(is_arithmetic_expression("1 + 1"));
        assert!(is_arithmetic_expression("1*1"));
        assert!(!is_arithmetic_expression("11"));
        assert!(!is_arithmetic_expression("你是谁"));
    }
}
