use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, BTreeSet};
use std::path::{Path, PathBuf};

use crate::learning::agent::LearnableAgent;
use crate::learning::io::{LearningIoError, read_skill_package, write_skill_package};
use crate::learning::model::{
    FeedbackPolicy, LearningInput, LearningMaterial, LearningSource, Lesson, LessonTask,
    MaterialStimulus,
};
use crate::learning::runner::LessonRunner;
use crate::learning::scaffold::{
    ScaffoldPhaseId, ScaffoldSpecRunBundle, ScaffoldSpecRunner, ScaffoldStep, SkillScaffoldSpec,
};
use crate::workspace::ensure_parent;

pub const DEFAULT_RELATION_SKILL_ID: &str = "skill.relation.spatial_words.zh.v1";
pub const DEFAULT_RELATION_DOMAIN: &str = "relation_words";
pub const DEFAULT_RELATION_SPEC: &str = "scaffold-relation-zh-v1-strict.json";
pub const DEFAULT_RELATION_HOLDOUT_SPEC: &str = "scaffold-relation-zh-v1-holdout.json";
pub const DEFAULT_RELATION_BUNDLE: &str = "scaffold-relation-zh-v1-strict-bundle.json";
pub const DEFAULT_RELATION_SKILL: &str = "skill.relation.spatial_words.zh.v1.apbin";

const MIN_STEPS: usize = 24;
const MIN_PER_RELATION: usize = 3;

const REQUIRED_ACTIONS: [&str; 6] = [
    "RelationWordLeft",
    "RelationWordRight",
    "RelationWordParallel",
    "RelationWordPerpendicular",
    "RelationWordAbove",
    "RelationWordBelow",
];

const REQUIRED_SCENARIOS: [&str; 3] = ["point_point", "line_line", "shape_shape"];

const LEAKAGE_TERMS: [&str; 18] = [
    "relation::left",
    "relation::right",
    "relation::parallel",
    "relation::perpendicular",
    "relation::above",
    "relation::below",
    "answer::",
    "action::",
    "RelationWordLeft",
    "RelationWordRight",
    "RelationWordParallel",
    "RelationWordPerpendicular",
    "RelationWordAbove",
    "RelationWordBelow",
    "left_",
    "right_",
    "parallel_",
    "perp_",
];

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct RelationWordTrainingReport {
    pub spec_path: String,
    pub holdout_spec_path: Option<String>,
    pub skill_path: String,
    pub bundle_path: String,
    pub skill_id: String,
    pub domain: String,
    pub steps: usize,
    pub image_refs: usize,
    pub unique_image_refs: usize,
    pub action_counts: BTreeMap<String, usize>,
    pub scenario_counts: BTreeMap<String, usize>,
    pub audit: RelationWordAuditReport,
    pub holdout_audit: Option<RelationWordAuditReport>,
    pub scaffold: ScaffoldMetricSummary,
    pub reload_probe: Option<ProbeSummary>,
    pub holdout_probe: Option<ProbeSummary>,
    pub control_probes: Option<ControlProbeReport>,
}

impl RelationWordTrainingReport {
    pub fn passed(&self) -> bool {
        self.pass_checks().into_iter().all(|passed| passed)
    }

    fn pass_checks(&self) -> [bool; 9] {
        [
            self.audit.passed,
            self.holdout_audit_passed(),
            self.scaffold.teacher_off_clean,
            self.scaffold.cold_retest_clean,
            self.scaffold.teacher_off_accuracy >= 1.0,
            self.scaffold.cold_retest_accuracy >= 1.0,
            self.reload_probe_passed(),
            self.holdout_probe_passed(),
            self.control_probes_passed(),
        ]
    }

    fn reload_probe_passed(&self) -> bool {
        self.reload_probe.as_ref().is_none_or(ProbeSummary::passed)
    }

    fn holdout_audit_passed(&self) -> bool {
        self.holdout_audit.as_ref().is_none_or(|audit| audit.passed)
    }

    fn holdout_probe_passed(&self) -> bool {
        self.holdout_probe.as_ref().is_none_or(ProbeSummary::passed)
    }

    fn control_probes_passed(&self) -> bool {
        self.control_probes
            .as_ref()
            .is_none_or(ControlProbeReport::passed)
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ScaffoldMetricSummary {
    pub teacher_off_accuracy: f32,
    pub cold_retest_accuracy: f32,
    pub teacher_off_clean: bool,
    pub cold_retest_clean: bool,
    pub mastery_estimate: f32,
    pub mastery_success_steps: usize,
    pub mastery_failure_steps: usize,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ProbeSummary {
    pub accuracy: f32,
    pub clean: bool,
    pub attempts: usize,
    pub answers: Vec<String>,
}

impl ProbeSummary {
    fn passed(&self) -> bool {
        self.accuracy >= 1.0 && self.clean
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ControlProbeReport {
    pub geometry_only: ProbeSummary,
    pub no_geometry: ProbeSummary,
    pub shuffled_expected: ProbeSummary,
}

impl ControlProbeReport {
    fn passed(&self) -> bool {
        self.geometry_only.passed()
            && self.no_geometry.clean
            && self.no_geometry.accuracy <= chance_accuracy_ceiling()
            && self.shuffled_expected.clean
            && self.shuffled_expected.accuracy <= 0.0
    }
}

fn chance_accuracy_ceiling() -> f32 {
    1.0 / REQUIRED_ACTIONS.len() as f32
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct RelationWordAuditReport {
    pub passed: bool,
    pub issues: Vec<String>,
}

impl RelationWordAuditReport {
    pub fn pass() -> Self {
        Self {
            passed: true,
            issues: Vec::new(),
        }
    }

    fn from_issues(issues: Vec<String>) -> Self {
        Self {
            passed: issues.is_empty(),
            issues,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RelationWordTrainingConfig {
    pub spec_path: PathBuf,
    pub holdout_spec_path: Option<PathBuf>,
    pub bundle_path: PathBuf,
    pub skill_path: PathBuf,
    pub domain: String,
    pub fail_on_audit: bool,
    pub reload_probe: bool,
    pub control_probes: bool,
}

pub fn audit_relation_word_spec(spec: &SkillScaffoldSpec) -> RelationWordAuditReport {
    RelationWordAudit::new(spec).run()
}

pub fn run_relation_word_training(
    spec: SkillScaffoldSpec,
    holdout_spec: Option<SkillScaffoldSpec>,
    config: &RelationWordTrainingConfig,
) -> Result<(RelationWordTrainingReport, ScaffoldSpecRunBundle), LearningIoError> {
    let audit = audit_relation_word_spec(&spec);
    let holdout_audit = holdout_spec.as_ref().map(audit_relation_word_spec);
    if let Some(result) = audit_failure_result(&spec, config, &audit, holdout_audit.clone()) {
        return Ok(result);
    }
    run_audited_relation_word_training(spec, holdout_spec, config, audit, holdout_audit)
}

fn audit_failure_result(
    spec: &SkillScaffoldSpec,
    config: &RelationWordTrainingConfig,
    audit: &RelationWordAuditReport,
    holdout_audit: Option<RelationWordAuditReport>,
) -> Option<(RelationWordTrainingReport, ScaffoldSpecRunBundle)> {
    (config.fail_on_audit && audit_failed(audit, holdout_audit.as_ref())).then(|| {
        let report = report_without_training(spec, config, audit.clone(), holdout_audit);
        (report, empty_bundle(spec.clone()))
    })
}

fn audit_failed(
    audit: &RelationWordAuditReport,
    holdout: Option<&RelationWordAuditReport>,
) -> bool {
    !audit.passed || holdout.is_some_and(|audit| !audit.passed)
}

fn run_audited_relation_word_training(
    spec: SkillScaffoldSpec,
    holdout_spec: Option<SkillScaffoldSpec>,
    config: &RelationWordTrainingConfig,
    audit: RelationWordAuditReport,
    holdout_audit: Option<RelationWordAuditReport>,
) -> Result<(RelationWordTrainingReport, ScaffoldSpecRunBundle), LearningIoError> {
    let mut agent = LearnableAgent::new(config.domain.clone());
    let bundle = ScaffoldSpecRunner::new(&config.domain).run(&mut agent, &spec);
    save_trained_skill(&agent, &spec, &config.skill_path)?;
    let reload_probe = maybe_run_reload_probe(config, &spec)?;
    let holdout_probe = maybe_run_holdout_probe(config, holdout_spec.as_ref())?;
    let control_probes = maybe_run_control_probes(config, holdout_spec.as_ref().unwrap_or(&spec))?;
    let report = build_report(ReportInputs {
        spec,
        config,
        audit,
        holdout_audit,
        bundle: &bundle,
        reload_probe,
        holdout_probe,
        control_probes,
    });
    Ok((report, bundle))
}

fn save_trained_skill(
    agent: &LearnableAgent,
    spec: &SkillScaffoldSpec,
    skill_path: &Path,
) -> Result<(), LearningIoError> {
    ensure_parent(skill_path)?;
    write_skill_package(
        skill_path,
        &agent.export_skill_package(&spec.skill_id, &spec.skill_id),
    )
}

fn maybe_run_reload_probe(
    config: &RelationWordTrainingConfig,
    spec: &SkillScaffoldSpec,
) -> Result<Option<ProbeSummary>, LearningIoError> {
    config
        .reload_probe
        .then(|| run_relation_word_holdout_probe(&config.skill_path, spec, &config.domain))
        .transpose()
}

fn maybe_run_holdout_probe(
    config: &RelationWordTrainingConfig,
    holdout_spec: Option<&SkillScaffoldSpec>,
) -> Result<Option<ProbeSummary>, LearningIoError> {
    holdout_spec
        .map(|spec| run_relation_word_holdout_probe(&config.skill_path, spec, &config.domain))
        .transpose()
}

fn maybe_run_control_probes(
    config: &RelationWordTrainingConfig,
    spec: &SkillScaffoldSpec,
) -> Result<Option<ControlProbeReport>, LearningIoError> {
    config
        .control_probes
        .then(|| run_control_probes(&config.skill_path, spec, &config.domain))
        .transpose()
}

pub fn run_control_probes(
    skill_path: &Path,
    spec: &SkillScaffoldSpec,
    domain: &str,
) -> Result<ControlProbeReport, LearningIoError> {
    Ok(ControlProbeReport {
        geometry_only: run_relation_word_holdout_probe(
            skill_path,
            &control_spec(spec, ControlVariant::GeometryOnly),
            domain,
        )?,
        no_geometry: run_relation_word_holdout_probe(
            skill_path,
            &control_spec(spec, ControlVariant::NoGeometry),
            domain,
        )?,
        shuffled_expected: run_relation_word_holdout_probe(
            skill_path,
            &control_spec(spec, ControlVariant::ShuffledExpected),
            domain,
        )?,
    })
}

pub fn run_relation_word_holdout_probe(
    skill_path: &Path,
    spec: &SkillScaffoldSpec,
    domain: &str,
) -> Result<ProbeSummary, LearningIoError> {
    let mut agent = LearnableAgent::from_skill_package(read_skill_package(skill_path)?);
    let lesson = holdout_lesson_from_spec(spec, domain);
    let report = LessonRunner::new(domain).run_probe_with_agent(&mut agent, &lesson);
    Ok(ProbeSummary {
        accuracy: report.skill_report.holdout_accuracy(),
        clean: report.taint_audit.passed(),
        attempts: report.holdout_attempts.len(),
        answers: report
            .holdout_attempts
            .iter()
            .map(|attempt| attempt.response.clone())
            .collect(),
    })
}

struct ReportInputs<'a> {
    spec: SkillScaffoldSpec,
    config: &'a RelationWordTrainingConfig,
    audit: RelationWordAuditReport,
    holdout_audit: Option<RelationWordAuditReport>,
    bundle: &'a ScaffoldSpecRunBundle,
    reload_probe: Option<ProbeSummary>,
    holdout_probe: Option<ProbeSummary>,
    control_probes: Option<ControlProbeReport>,
}

fn build_report(inputs: ReportInputs<'_>) -> RelationWordTrainingReport {
    let spec = inputs.spec;
    RelationWordTrainingReport {
        spec_path: inputs.config.spec_path.display().to_string(),
        holdout_spec_path: inputs
            .config
            .holdout_spec_path
            .as_ref()
            .map(|path| path.display().to_string()),
        skill_path: inputs.config.skill_path.display().to_string(),
        bundle_path: inputs.config.bundle_path.display().to_string(),
        skill_id: spec.skill_id.clone(),
        domain: inputs.config.domain.clone(),
        steps: spec.steps.len(),
        image_refs: image_refs(&spec).len(),
        unique_image_refs: image_refs(&spec).into_iter().collect::<BTreeSet<_>>().len(),
        action_counts: action_counts(&spec),
        scenario_counts: scenario_counts(&spec),
        audit: inputs.audit,
        holdout_audit: inputs.holdout_audit,
        scaffold: ScaffoldMetricSummary::from(inputs.bundle),
        reload_probe: inputs.reload_probe,
        holdout_probe: inputs.holdout_probe,
        control_probes: inputs.control_probes,
    }
}

fn report_without_training(
    spec: &SkillScaffoldSpec,
    config: &RelationWordTrainingConfig,
    audit: RelationWordAuditReport,
    holdout_audit: Option<RelationWordAuditReport>,
) -> RelationWordTrainingReport {
    RelationWordTrainingReport {
        spec_path: config.spec_path.display().to_string(),
        holdout_spec_path: config
            .holdout_spec_path
            .as_ref()
            .map(|path| path.display().to_string()),
        skill_path: config.skill_path.display().to_string(),
        bundle_path: config.bundle_path.display().to_string(),
        skill_id: spec.skill_id.clone(),
        domain: config.domain.clone(),
        steps: spec.steps.len(),
        image_refs: image_refs(spec).len(),
        unique_image_refs: image_refs(spec).into_iter().collect::<BTreeSet<_>>().len(),
        action_counts: action_counts(spec),
        scenario_counts: scenario_counts(spec),
        audit,
        holdout_audit,
        scaffold: ScaffoldMetricSummary::default(),
        reload_probe: None,
        holdout_probe: None,
        control_probes: None,
    }
}

fn empty_bundle(spec: SkillScaffoldSpec) -> ScaffoldSpecRunBundle {
    ScaffoldSpecRunBundle {
        spec: spec.clone(),
        report: crate::learning::scaffold::ScaffoldRunReport {
            skill_id: spec.skill_id.clone(),
            phases: Vec::new(),
        },
        mastery: crate::learning::scaffold::ScaffoldMasterySummary {
            skill_id: spec.skill_id,
            mastery_estimate: 0.0,
            success_steps: 0,
            failure_steps: 0,
            last_step_id: String::new(),
            last_effective_strength: 0.0,
        },
    }
}

fn holdout_lesson_from_spec(spec: &SkillScaffoldSpec, domain: &str) -> Lesson {
    LearningInput::new(
        LearningSource::Script {
            name: format!("relation-holdout:{}", spec.skill_id),
        },
        LearningMaterial::TaskSet(spec.steps.iter().map(holdout_task_from_step).collect()),
        spec.goal.clone(),
        crate::core::ap::TeacherMode::TeacherOff,
        FeedbackPolicy::NoFeedback,
    )
    .into_lesson(format!("{domain}-{}-holdout", spec.skill_id))
}

fn holdout_task_from_step(step: &ScaffoldStep) -> LessonTask {
    let mut task = LessonTask::new(
        step.step_id.clone(),
        MaterialStimulus::Text(step.state_items.join(" | ")),
    );
    if let Some(action) = expected_action(step) {
        task = task.with_expected_action(action);
    }
    task
}

fn expected_action(step: &ScaffoldStep) -> Option<String> {
    step.action_biases
        .iter()
        .max_by(|left, right| left.strength.total_cmp(&right.strength))
        .map(|bias| bias.action.clone())
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ControlVariant {
    GeometryOnly,
    NoGeometry,
    ShuffledExpected,
}

fn control_spec(spec: &SkillScaffoldSpec, variant: ControlVariant) -> SkillScaffoldSpec {
    let mut control = spec.clone();
    control.title = format!("{} {:?}", control.title, variant);
    control.steps = match variant {
        ControlVariant::GeometryOnly => spec.steps.iter().map(geometry_only_step).collect(),
        ControlVariant::NoGeometry => spec.steps.iter().map(no_geometry_step).collect(),
        ControlVariant::ShuffledExpected => shuffled_expected_steps(&spec.steps),
    };
    control
}

fn geometry_only_step(step: &ScaffoldStep) -> ScaffoldStep {
    let mut control = step.clone();
    control.state_items = step
        .state_items
        .iter()
        .filter(|item| is_geometry_feature(item))
        .cloned()
        .collect();
    control
}

fn no_geometry_step(step: &ScaffoldStep) -> ScaffoldStep {
    let mut control = step.clone();
    control.state_items = step
        .state_items
        .iter()
        .filter(|item| !is_geometry_feature(item))
        .cloned()
        .collect();
    control
}

fn shuffled_expected_steps(steps: &[ScaffoldStep]) -> Vec<ScaffoldStep> {
    steps
        .iter()
        .map(|step| step_with_expected_action(step, wrong_expected_action(step)))
        .collect()
}

fn wrong_expected_action(step: &ScaffoldStep) -> String {
    expected_action(step)
        .as_deref()
        .and_then(shuffled_action)
        .unwrap_or("RelationWordLeft")
        .to_owned()
}

fn shuffled_action(action: &str) -> Option<&'static str> {
    SHUFFLED_ACTION_PAIRS.iter().find_map(
        |(from, to)| {
            if *from == action { Some(*to) } else { None }
        },
    )
}

const SHUFFLED_ACTION_PAIRS: &[(&str, &str)] = &[
    ("RelationWordLeft", "RelationWordRight"),
    ("RelationWordRight", "RelationWordLeft"),
    ("RelationWordAbove", "RelationWordBelow"),
    ("RelationWordBelow", "RelationWordAbove"),
    ("RelationWordParallel", "RelationWordPerpendicular"),
    ("RelationWordPerpendicular", "RelationWordParallel"),
];

fn step_with_expected_action(step: &ScaffoldStep, action: String) -> ScaffoldStep {
    let mut control = step.clone();
    control.action_biases = vec![crate::learning::scaffold::StepActionBias::new(action, 1.0)];
    control
}

fn is_geometry_feature(item: &str) -> bool {
    item.starts_with("axis::") || item.starts_with("geometry::")
}

impl Default for ScaffoldMetricSummary {
    fn default() -> Self {
        Self {
            teacher_off_accuracy: 0.0,
            cold_retest_accuracy: 0.0,
            teacher_off_clean: false,
            cold_retest_clean: false,
            mastery_estimate: 0.0,
            mastery_success_steps: 0,
            mastery_failure_steps: 0,
        }
    }
}

impl From<&ScaffoldSpecRunBundle> for ScaffoldMetricSummary {
    fn from(bundle: &ScaffoldSpecRunBundle) -> Self {
        Self {
            teacher_off_accuracy: bundle.report.teacher_off_accuracy(),
            cold_retest_accuracy: bundle.report.cold_retest_accuracy(),
            teacher_off_clean: bundle.report.teacher_off_clean(),
            cold_retest_clean: cold_retest_clean(bundle),
            mastery_estimate: bundle.mastery.mastery_estimate,
            mastery_success_steps: bundle.mastery.success_steps,
            mastery_failure_steps: bundle.mastery.failure_steps,
        }
    }
}

fn cold_retest_clean(bundle: &ScaffoldSpecRunBundle) -> bool {
    bundle
        .report
        .phases
        .iter()
        .filter(|phase| phase.phase_id == ScaffoldPhaseId::ColdRetest)
        .all(|phase| phase.teacher_packet_empty())
}

struct RelationWordAudit<'a> {
    spec: &'a SkillScaffoldSpec,
    issues: Vec<String>,
}

impl<'a> RelationWordAudit<'a> {
    fn new(spec: &'a SkillScaffoldSpec) -> Self {
        Self {
            spec,
            issues: Vec::new(),
        }
    }

    fn run(mut self) -> RelationWordAuditReport {
        self.require_step_count();
        self.require_phase_contracts();
        self.require_actions();
        self.require_scenarios();
        self.require_visual_refs();
        self.reject_leakage_terms();
        RelationWordAuditReport::from_issues(self.issues)
    }

    fn require_step_count(&mut self) {
        self.require(
            self.spec.steps.len() >= MIN_STEPS,
            format!("steps must be >= {MIN_STEPS}"),
        );
    }

    fn require_phase_contracts(&mut self) {
        self.require_phase_silence(ScaffoldPhaseId::TeacherOff);
        self.require_phase_silence(ScaffoldPhaseId::ColdRetest);
        let feedback_only = self.spec.phase(ScaffoldPhaseId::FeedbackOnly);
        self.require(
            !feedback_only.teacher_signal.state_items
                && !feedback_only.teacher_signal.action_biases
                && feedback_only.teacher_signal.feedback,
            "feedback_only must hide state/action bias and keep feedback".to_owned(),
        );
    }

    fn require_phase_silence(&mut self, phase_id: ScaffoldPhaseId) {
        let phase = self.spec.phase(phase_id);
        self.require(
            !phase.teacher_signal.state_items
                && !phase.teacher_signal.action_biases
                && !phase.teacher_signal.feedback,
            format!("{phase_id:?} teacher_signal must be all false"),
        );
    }

    fn require_actions(&mut self) {
        for action in REQUIRED_ACTIONS {
            self.require(
                action_count(self.spec, action) >= MIN_PER_RELATION,
                format!("{action} must have at least {MIN_PER_RELATION} steps"),
            );
        }
    }

    fn require_scenarios(&mut self) {
        for scenario in REQUIRED_SCENARIOS {
            self.require(
                self.spec
                    .steps
                    .iter()
                    .any(|step| step.scenario_tags.iter().any(|tag| tag == scenario)),
                format!("missing scenario tag {scenario}"),
            );
        }
    }

    fn require_visual_refs(&mut self) {
        let refs = image_refs(self.spec);
        self.require(
            refs.len() == self.spec.steps.len(),
            "each step must contain exactly one image:: state item".to_owned(),
        );
        self.require(
            refs.iter().collect::<BTreeSet<_>>().len() == refs.len(),
            "image:: refs must be unique per step".to_owned(),
        );
    }

    fn reject_leakage_terms(&mut self) {
        for step in &self.spec.steps {
            self.reject_step_leakage(step);
        }
    }

    fn reject_step_leakage(&mut self, step: &ScaffoldStep) {
        for item in &step.state_items {
            if let Some(term) = leakage_term(item) {
                self.issues.push(format!(
                    "{} state item leaks term {term}: {item}",
                    step.step_id
                ));
            }
        }
    }

    fn require(&mut self, passed: bool, issue: String) {
        if !passed {
            self.issues.push(issue);
        }
    }
}

fn leakage_term(item: &str) -> Option<&'static str> {
    LEAKAGE_TERMS
        .iter()
        .find(|term| item.contains(**term))
        .copied()
}

fn image_refs(spec: &SkillScaffoldSpec) -> Vec<String> {
    spec.steps
        .iter()
        .filter_map(step_image_ref)
        .collect::<Vec<_>>()
}

fn step_image_ref(step: &ScaffoldStep) -> Option<String> {
    let refs = step
        .state_items
        .iter()
        .filter_map(|item| item.strip_prefix("image::"))
        .map(str::to_owned)
        .collect::<Vec<_>>();
    (refs.len() == 1).then(|| refs[0].clone())
}

fn action_counts(spec: &SkillScaffoldSpec) -> BTreeMap<String, usize> {
    let mut counts = BTreeMap::new();
    for action in spec
        .steps
        .iter()
        .flat_map(|step| step.action_biases.iter().map(|bias| bias.action.clone()))
    {
        *counts.entry(action).or_default() += 1;
    }
    counts
}

fn action_count(spec: &SkillScaffoldSpec, action: &str) -> usize {
    spec.steps
        .iter()
        .filter(|step| step.action_biases.iter().any(|bias| bias.action == action))
        .count()
}

fn scenario_counts(spec: &SkillScaffoldSpec) -> BTreeMap<String, usize> {
    let mut counts = BTreeMap::new();
    for tag in spec.steps.iter().flat_map(|step| step.scenario_tags.iter()) {
        *counts.entry(tag.clone()).or_default() += 1;
    }
    counts
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::learning::scaffold::{
        ScaffoldPhase, StepActionBias, StepFeedback, TeacherSignalPolicy,
    };

    #[test]
    fn audit_rejects_label_leaking_image_names() {
        let spec = spec_with_steps(|index| {
            format!("image::.ap/exports/media/relation/left_pp_{index:03}.svg")
        });

        let audit = audit_relation_word_spec(&spec);

        assert!(!audit.passed);
        assert!(
            audit
                .issues
                .iter()
                .any(|issue| issue.contains("leaks term left_"))
        );
    }

    #[test]
    fn audit_accepts_neutral_visual_feature_spec() {
        let spec = spec_with_steps(|index| {
            format!("image::.ap/exports/media/relation/asset_{index:03}.svg")
        });

        let audit = audit_relation_word_spec(&spec);

        assert_eq!(audit, RelationWordAuditReport::pass());
    }

    #[test]
    fn holdout_probe_loads_skill_without_scaffold_retraining() {
        let train = spec_with_steps(|index| {
            format!("image::.ap/exports/media/relation/train_{index:03}.svg")
        });
        let holdout = spec_with_steps(|index| {
            format!("image::.ap/exports/media/relation/probe_{index:03}.svg")
        });
        let config = test_config("holdout-probe");

        let (report, _) =
            run_relation_word_training(train, Some(holdout), &config).expect("training");
        let _ = std::fs::remove_file(&config.skill_path);

        assert!(
            report
                .reload_probe
                .as_ref()
                .is_some_and(ProbeSummary::passed)
        );
        assert!(
            report
                .holdout_probe
                .as_ref()
                .is_some_and(ProbeSummary::passed)
        );
        assert!(
            report
                .holdout_audit
                .as_ref()
                .is_some_and(|audit| audit.passed)
        );
        assert!(
            report
                .control_probes
                .as_ref()
                .is_some_and(ControlProbeReport::passed)
        );
    }

    #[test]
    fn holdout_audit_failure_blocks_training_when_enabled() {
        let train = spec_with_steps(|index| {
            format!("image::.ap/exports/media/relation/train_{index:03}.svg")
        });
        let holdout = spec_with_steps(|index| {
            format!("image::.ap/exports/media/relation/left_probe_{index:03}.svg")
        });
        let config = test_config("holdout-audit-fail");

        let (report, bundle) =
            run_relation_word_training(train, Some(holdout), &config).expect("training");

        assert!(!report.passed());
        assert!(
            report
                .holdout_audit
                .as_ref()
                .is_some_and(|audit| !audit.passed)
        );
        assert!(bundle.report.phases.is_empty());
        assert!(!config.skill_path.exists());
    }

    fn spec_with_steps(image: impl Fn(usize) -> String) -> SkillScaffoldSpec {
        let mut spec = SkillScaffoldSpec::new(DEFAULT_RELATION_SKILL_ID);
        spec.phases = phases();
        spec.steps = REQUIRED_ACTIONS
            .iter()
            .flat_map(|action| (0..4).map(move |index| (*action, index)))
            .enumerate()
            .map(|(index, (action, local_index))| step(index, local_index, action, &image))
            .collect();
        spec
    }

    fn phases() -> Vec<ScaffoldPhase> {
        vec![
            phase(ScaffoldPhaseId::Demonstrate, true, true, true),
            phase(ScaffoldPhaseId::StrongScaffold, true, true, true),
            phase(ScaffoldPhaseId::WeakScaffold, true, true, true),
            phase(ScaffoldPhaseId::FeedbackOnly, false, false, true),
            phase(ScaffoldPhaseId::TeacherOff, false, false, false),
            phase(ScaffoldPhaseId::ColdRetest, false, false, false),
        ]
    }

    fn phase(
        phase_id: ScaffoldPhaseId,
        state_items: bool,
        action_biases: bool,
        feedback: bool,
    ) -> ScaffoldPhase {
        ScaffoldPhase {
            phase_id,
            strength: phase_id.default_strength(),
            teacher_signal: TeacherSignalPolicy {
                state_items,
                action_biases,
                feedback,
            },
        }
    }

    fn step(
        index: usize,
        local_index: usize,
        action: &str,
        image: &impl Fn(usize) -> String,
    ) -> ScaffoldStep {
        ScaffoldStep {
            step_id: format!("step-{index:03}"),
            title: format!("visual relation {index}"),
            scenario_tags: vec![scenario_tag(local_index).to_owned()],
            state_items: vec![
                image(index),
                format!("object::a center=({},10)", 10 + index),
                format!("object::b center=({},20)", 20 + index),
                neutral_relation_feature(action).to_owned(),
            ],
            action_biases: vec![StepActionBias::new(action, 1.0)],
            feedback: Some(StepFeedback::Reward),
            expected_evidence: Vec::new(),
            notes: Vec::new(),
        }
    }

    fn scenario_tag(index: usize) -> &'static str {
        REQUIRED_SCENARIOS[index % REQUIRED_SCENARIOS.len()]
    }

    fn neutral_relation_feature(action: &str) -> &'static str {
        match action {
            "RelationWordLeft" => "axis::x_delta(a,b)=-60",
            "RelationWordRight" => "axis::x_delta(a,b)=60",
            "RelationWordAbove" => "axis::y_delta(a,b)=-60",
            "RelationWordBelow" => "axis::y_delta(a,b)=60",
            "RelationWordParallel" => "geometry::slope_delta(a,b)=0",
            "RelationWordPerpendicular" => "geometry::angle(a,b)=90",
            _ => "geometry::unknown=0",
        }
    }

    fn test_config(name: &str) -> RelationWordTrainingConfig {
        let root = std::env::temp_dir().join(format!("ap-relation-{name}-{}", std::process::id()));
        RelationWordTrainingConfig {
            spec_path: root.join("train.json"),
            holdout_spec_path: Some(root.join("holdout.json")),
            bundle_path: root.join("bundle.json"),
            skill_path: root.join("skill.apbin"),
            domain: DEFAULT_RELATION_DOMAIN.to_owned(),
            fail_on_audit: true,
            reload_probe: true,
            control_probes: true,
        }
    }
}
