use std::collections::HashMap;

use serde::{Deserialize, Serialize};

use super::dialog::DialogUnderstanding;
use super::features::LanguageFeature;
use super::response_policy::{ResponsePolicy, ResponsePolicyDecision, response_policy_features};
use super::response_policy_curriculum;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ResponseSurfaceDecision {
    pub surface_id: String,
    pub text: String,
    pub evidence: Vec<String>,
}

#[derive(Debug, Default, Clone)]
pub struct ResponseSurfaceLearner {
    scores: HashMap<FeatureSurface, i32>,
    surfaces: HashMap<String, String>,
    memory_rows: usize,
}

impl ResponseSurfaceLearner {
    pub fn canonical_trained() -> Self {
        let mut learner = Self::default();
        train_canonical_surfaces(&mut learner, 3);
        learner
    }

    pub fn predict(
        &self,
        understanding: &DialogUnderstanding,
        policy: &ResponsePolicyDecision,
        text: &str,
        context: &str,
    ) -> ResponseSurfaceDecision {
        let features = surface_features(understanding, policy.policy, text, context);
        let surface_id = self.best_surface(&features);
        ResponseSurfaceDecision {
            text: self.surface_text(&surface_id),
            surface_id,
            evidence: features.into_iter().map(|feature| feature.0).collect(),
        }
    }

    pub fn learn(
        &mut self,
        understanding: &DialogUnderstanding,
        policy: ResponsePolicy,
        text: &str,
        context: &str,
        surface_id: impl Into<String>,
        surface_text: impl Into<String>,
    ) {
        let surface_id = surface_id.into();
        self.surfaces
            .insert(surface_id.clone(), surface_text.into());
        surface_features(understanding, policy, text, context)
            .into_iter()
            .for_each(|feature| self.add_score(feature, &surface_id, 1));
        self.memory_rows += 1;
    }

    pub fn memory_rows(&self) -> usize {
        self.memory_rows
    }

    fn best_surface(&self, features: &[LanguageFeature]) -> String {
        self.surfaces
            .keys()
            .max_by_key(|surface_id| self.surface_score(features, surface_id))
            .cloned()
            .unwrap_or_else(|| "surface:fallback".to_owned())
    }

    fn surface_score(&self, features: &[LanguageFeature], surface_id: &str) -> i32 {
        features
            .iter()
            .map(|feature| self.feature_score(feature, surface_id))
            .sum()
    }

    fn surface_text(&self, surface_id: &str) -> String {
        self.surfaces
            .get(surface_id)
            .cloned()
            .unwrap_or_else(|| "我已收到，会按当前学习状态处理。".to_owned())
    }

    fn add_score(&mut self, feature: LanguageFeature, surface_id: &str, delta: i32) {
        *self
            .scores
            .entry(FeatureSurface {
                feature,
                surface_id: surface_id.to_owned(),
            })
            .or_default() += delta;
    }

    fn feature_score(&self, feature: &LanguageFeature, surface_id: &str) -> i32 {
        self.scores
            .get(&FeatureSurface {
                feature: feature.clone(),
                surface_id: surface_id.to_owned(),
            })
            .copied()
            .unwrap_or_default()
    }
}

pub fn surface_features(
    understanding: &DialogUnderstanding,
    policy: ResponsePolicy,
    text: &str,
    context: &str,
) -> Vec<LanguageFeature> {
    let mut features = response_policy_features(understanding, text, context);
    features.push(LanguageFeature::new(format!("policy:{}", policy.label())));
    features.sort();
    features.dedup();
    features
}

fn train_canonical_surfaces(learner: &mut ResponseSurfaceLearner, repeats: usize) {
    let items = response_policy_curriculum::train_items();
    (0..repeats).flat_map(|_| items.iter()).for_each(|item| {
        learner.learn(
            &(*item).understanding(),
            item.policy,
            item.text,
            item.context,
            surface_id(item.policy),
            surface_text(item.policy),
        );
    });
}

fn surface_id(policy: ResponsePolicy) -> String {
    policy.label().replacen("response:", "surface:", 1)
}

fn surface_text(policy: ResponsePolicy) -> &'static str {
    SURFACE_TEXTS[policy as usize]
}

const SURFACE_TEXTS: [&str; 10] = [
    "收到。你可以继续说目标、材料或要处理的问题。",
    "我会先确认需要修复的地方，再给出下一步动作。",
    "我会先把风险和未知项列清楚，再决定是否继续。",
    "我会先识别目标和约束，再给出可执行的下一步。",
    "我会说明依据、边界和可以验证的地方。",
    "我会按你的纠正更新当前理解，再继续处理。",
    "我会比较几个选项的取舍，再给出建议。",
    "我会记录这个目标，并把它拆成后续动作。",
    "我会把这条反馈记下来，用它调整后续行为。",
    "我还缺少关键信息，会先提出需要确认的问题。",
];

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct FeatureSurface {
    feature: LanguageFeature,
    surface_id: String,
}

#[cfg(test)]
mod tests {
    use crate::language_core::{DialogAct, LanguageFrame};

    use super::*;

    #[test]
    fn surface_learner_outputs_text_not_policy_label() {
        let learner = ResponseSurfaceLearner::canonical_trained();
        let understanding = DialogUnderstanding {
            frame: LanguageFrame::REQUEST,
            act: DialogAct::ServeRequest,
            frame_label: LanguageFrame::REQUEST.label().to_owned(),
            response_hint: String::new(),
        };
        let policy = ResponsePolicyDecision {
            policy: ResponsePolicy::TaskPlan,
            policy_label: ResponsePolicy::TaskPlan.label().to_owned(),
            evidence: Vec::new(),
        };

        let decision = learner.predict(&understanding, &policy, "帮我检查", "请求执行任务");

        assert!(!decision.text.contains("policy="));
        assert!(decision.text.contains("下一步"));
    }
}
