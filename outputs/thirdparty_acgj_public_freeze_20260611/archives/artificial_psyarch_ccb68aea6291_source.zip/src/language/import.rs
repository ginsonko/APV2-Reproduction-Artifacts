use std::fmt::{Display, Formatter};

use serde::{Deserialize, Serialize};

use super::curriculum::{LanguageGroundingStimulus, LanguageGroundingWorld};
use super::dialog::{DialogAct, DialogUnderstanding};
use super::frame::LanguageFrame;
use super::response_policy::{
    ResponsePolicy, ResponsePolicyStimulus, ResponsePolicyWorld, response_policy_from_label,
};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct LanguageGroundingRecord {
    pub text: String,
    #[serde(default)]
    pub context: String,
    pub expected_frame: String,
    #[serde(default)]
    pub id: Option<String>,
    #[serde(default = "default_split")]
    pub split: LanguageGroundingSplit,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum LanguageGroundingSplit {
    Train,
    Holdout,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct LanguageGroundingDataset {
    #[serde(default)]
    pub train: Vec<LanguageGroundingRecord>,
    #[serde(default)]
    pub holdout: Vec<LanguageGroundingRecord>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ResponsePolicyRecord {
    pub text: String,
    #[serde(default)]
    pub context: String,
    pub expected_policy: String,
    #[serde(default)]
    pub frame: Option<String>,
    #[serde(default)]
    pub dialog_act: Option<String>,
    #[serde(default)]
    pub id: Option<String>,
    #[serde(default = "default_split")]
    pub split: LanguageGroundingSplit,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ResponsePolicyDataset {
    #[serde(default)]
    pub train: Vec<ResponsePolicyRecord>,
    #[serde(default)]
    pub holdout: Vec<ResponsePolicyRecord>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum LanguageImportError {
    Json(String),
    UnknownFrame(String),
    UnknownPolicy(String),
    UnknownDialogAct(String),
    EmptyDataset,
}

impl Display for LanguageImportError {
    fn fmt(&self, formatter: &mut Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Json(error) => write!(formatter, "json error: {error}"),
            Self::UnknownFrame(label)
            | Self::UnknownPolicy(label)
            | Self::UnknownDialogAct(label) => {
                write!(formatter, "unknown language label: {label}")
            }
            Self::EmptyDataset => write!(formatter, "language dataset has no train items"),
        }
    }
}

impl std::error::Error for LanguageImportError {}

pub fn language_world_from_json_text(
    text: &str,
) -> Result<LanguageGroundingWorld, LanguageImportError> {
    if looks_like_jsonl(text) {
        world_from_records(parse_jsonl_records(text)?)
    } else {
        parse_json_dataset(text)
    }
}

pub fn response_policy_world_from_json_text(
    text: &str,
) -> Result<ResponsePolicyWorld, LanguageImportError> {
    if looks_like_jsonl(text) {
        response_policy_world_from_records(parse_jsonl_policy_records(text)?)
    } else {
        parse_response_policy_dataset(text)
    }
}

pub fn language_frame_from_label(label: &str) -> Option<LanguageFrame> {
    LanguageFrame::all()
        .into_iter()
        .find(|frame| frame.label() == label)
}

pub fn dialog_act_from_label(label: &str) -> Option<DialogAct> {
    DIALOG_ACT_LABELS
        .iter()
        .find(|(name, _)| *name == label)
        .map(|(_, act)| *act)
}

fn parse_json_dataset(text: &str) -> Result<LanguageGroundingWorld, LanguageImportError> {
    serde_json::from_str::<LanguageGroundingDataset>(text)
        .map(dataset_records)
        .or_else(|_| serde_json::from_str::<Vec<LanguageGroundingRecord>>(text))
        .map_err(|error| LanguageImportError::Json(error.to_string()))
        .and_then(world_from_records)
}

fn parse_response_policy_dataset(text: &str) -> Result<ResponsePolicyWorld, LanguageImportError> {
    serde_json::from_str::<ResponsePolicyDataset>(text)
        .map(policy_dataset_records)
        .or_else(|_| serde_json::from_str::<Vec<ResponsePolicyRecord>>(text))
        .map_err(|error| LanguageImportError::Json(error.to_string()))
        .and_then(response_policy_world_from_records)
}

fn parse_jsonl_records(text: &str) -> Result<Vec<LanguageGroundingRecord>, LanguageImportError> {
    text.lines()
        .map(str::trim)
        .filter(|line| !line.is_empty())
        .map(|line| {
            serde_json::from_str(line).map_err(|error| LanguageImportError::Json(error.to_string()))
        })
        .collect()
}

fn parse_jsonl_policy_records(
    text: &str,
) -> Result<Vec<ResponsePolicyRecord>, LanguageImportError> {
    text.lines()
        .map(str::trim)
        .filter(|line| !line.is_empty())
        .map(|line| {
            serde_json::from_str(line).map_err(|error| LanguageImportError::Json(error.to_string()))
        })
        .collect()
}

fn world_from_records(
    records: Vec<LanguageGroundingRecord>,
) -> Result<LanguageGroundingWorld, LanguageImportError> {
    let train = records
        .iter()
        .filter(|record| record.split == LanguageGroundingSplit::Train)
        .enumerate()
        .map(|(index, record)| stimulus_from_record(record, "T", index))
        .collect::<Result<Vec<_>, _>>()?;
    let holdout = records
        .iter()
        .filter(|record| record.split == LanguageGroundingSplit::Holdout)
        .enumerate()
        .map(|(index, record)| stimulus_from_record(record, "H", index))
        .collect::<Result<Vec<_>, _>>()?;
    (!train.is_empty())
        .then(|| LanguageGroundingWorld::new(train, holdout))
        .ok_or(LanguageImportError::EmptyDataset)
}

fn response_policy_world_from_records(
    records: Vec<ResponsePolicyRecord>,
) -> Result<ResponsePolicyWorld, LanguageImportError> {
    let train = policy_records_for_split(&records, LanguageGroundingSplit::Train, "T")?;
    let holdout = policy_records_for_split(&records, LanguageGroundingSplit::Holdout, "H")?;
    (!train.is_empty())
        .then(|| ResponsePolicyWorld::new(train, holdout))
        .ok_or(LanguageImportError::EmptyDataset)
}

fn policy_records_for_split(
    records: &[ResponsePolicyRecord],
    split: LanguageGroundingSplit,
    prefix: &str,
) -> Result<Vec<ResponsePolicyStimulus>, LanguageImportError> {
    records
        .iter()
        .filter(|record| record.split == split)
        .enumerate()
        .map(|(index, record)| response_policy_stimulus_from_record(record, prefix, index))
        .collect()
}

fn dataset_records(dataset: LanguageGroundingDataset) -> Vec<LanguageGroundingRecord> {
    dataset
        .train
        .into_iter()
        .map(|record| record.with_split(LanguageGroundingSplit::Train))
        .chain(
            dataset
                .holdout
                .into_iter()
                .map(|record| record.with_split(LanguageGroundingSplit::Holdout)),
        )
        .collect()
}

fn policy_dataset_records(dataset: ResponsePolicyDataset) -> Vec<ResponsePolicyRecord> {
    dataset
        .train
        .into_iter()
        .map(|record| record.with_split(LanguageGroundingSplit::Train))
        .chain(
            dataset
                .holdout
                .into_iter()
                .map(|record| record.with_split(LanguageGroundingSplit::Holdout)),
        )
        .collect()
}

fn stimulus_from_record(
    record: &LanguageGroundingRecord,
    prefix: &str,
    index: usize,
) -> Result<LanguageGroundingStimulus, LanguageImportError> {
    let frame = language_frame_from_label(&record.expected_frame)
        .ok_or_else(|| LanguageImportError::UnknownFrame(record.expected_frame.clone()))?;
    Ok(LanguageGroundingStimulus::new(
        record
            .id
            .clone()
            .unwrap_or_else(|| format!("{prefix}{index:03}")),
        record.text.clone(),
        record.context.clone(),
        frame,
    ))
}

fn response_policy_stimulus_from_record(
    record: &ResponsePolicyRecord,
    prefix: &str,
    index: usize,
) -> Result<ResponsePolicyStimulus, LanguageImportError> {
    let policy = policy_from_record(record)?;
    let frame = frame_from_record(record)?;
    let act = act_from_record(record, frame)?;
    Ok(ResponsePolicyStimulus::new(
        record
            .id
            .clone()
            .unwrap_or_else(|| format!("{prefix}{index:03}")),
        record.text.clone(),
        record.context.clone(),
        DialogUnderstanding {
            frame,
            act,
            frame_label: frame.label().to_owned(),
            response_hint: "imported response policy item".to_owned(),
        },
        policy,
    ))
}

fn policy_from_record(
    record: &ResponsePolicyRecord,
) -> Result<ResponsePolicy, LanguageImportError> {
    response_policy_from_label(&record.expected_policy)
        .ok_or_else(|| LanguageImportError::UnknownPolicy(record.expected_policy.clone()))
}

fn frame_from_record(record: &ResponsePolicyRecord) -> Result<LanguageFrame, LanguageImportError> {
    if let Some(label) = record.frame.as_deref() {
        language_frame_from_label(label)
            .ok_or_else(|| LanguageImportError::UnknownFrame(label.to_owned()))
    } else {
        Ok(policy_default_frame(policy_from_record(record)?))
    }
}

fn act_from_record(
    record: &ResponsePolicyRecord,
    frame: LanguageFrame,
) -> Result<DialogAct, LanguageImportError> {
    if let Some(label) = record.dialog_act.as_deref() {
        dialog_act_from_label(label)
            .ok_or_else(|| LanguageImportError::UnknownDialogAct(label.to_owned()))
    } else {
        Ok(policy_default_act(
            policy_from_record(record).unwrap_or_else(|_| policy_from_frame(frame)),
        ))
    }
}

fn looks_like_jsonl(text: &str) -> bool {
    let lines = text
        .lines()
        .map(str::trim)
        .filter(|line| !line.is_empty())
        .collect::<Vec<_>>();
    lines.len() > 1
        && lines
            .iter()
            .all(|line| line.starts_with('{') && line.ends_with('}'))
}

fn default_split() -> LanguageGroundingSplit {
    LanguageGroundingSplit::Train
}

impl LanguageGroundingRecord {
    fn with_split(mut self, split: LanguageGroundingSplit) -> Self {
        self.split = split;
        self
    }
}

impl ResponsePolicyRecord {
    fn with_split(mut self, split: LanguageGroundingSplit) -> Self {
        self.split = split;
        self
    }
}

const DIALOG_ACT_LABELS: [(&str, DialogAct); 10] = [
    ("dialog:open-channel", DialogAct::OpenChannel),
    ("dialog:repair-relation", DialogAct::RepairRelation),
    ("dialog:seek-safety", DialogAct::SeekSafety),
    ("dialog:serve-request", DialogAct::ServeRequest),
    ("dialog:explain-reason", DialogAct::ExplainReason),
    ("dialog:align-correction", DialogAct::AlignCorrection),
    ("dialog:compare-options", DialogAct::CompareOptions),
    ("dialog:track-goal", DialogAct::TrackGoal),
    ("dialog:record-evaluation", DialogAct::RecordEvaluation),
    ("dialog:ask-clarification", DialogAct::AskClarification),
];

const POLICY_FRAMES: [LanguageFrame; 10] = [
    LanguageFrame::GREETING,
    LanguageFrame::REGRET,
    LanguageFrame::FEAR,
    LanguageFrame::REQUEST,
    LanguageFrame::EXPLAIN,
    LanguageFrame::CORRECT,
    LanguageFrame::CHOOSE,
    LanguageFrame::GOAL,
    LanguageFrame::EVALUATE,
    LanguageFrame::UNCERTAIN,
];

const POLICY_ACTS: [DialogAct; 10] = [
    DialogAct::OpenChannel,
    DialogAct::RepairRelation,
    DialogAct::SeekSafety,
    DialogAct::ServeRequest,
    DialogAct::ExplainReason,
    DialogAct::AlignCorrection,
    DialogAct::CompareOptions,
    DialogAct::TrackGoal,
    DialogAct::RecordEvaluation,
    DialogAct::AskClarification,
];

const ACTION_POLICIES: [ResponsePolicy; 10] = [
    ResponsePolicy::BriefAcknowledge,
    ResponsePolicy::RepairNextStep,
    ResponsePolicy::SafetyClarify,
    ResponsePolicy::TaskPlan,
    ResponsePolicy::ExplainGrounds,
    ResponsePolicy::AcceptCorrection,
    ResponsePolicy::CompareTradeoffs,
    ResponsePolicy::TrackGoal,
    ResponsePolicy::UseFeedback,
    ResponsePolicy::AskClarifyingQuestion,
];

fn policy_default_frame(policy: ResponsePolicy) -> LanguageFrame {
    POLICY_FRAMES[policy as usize]
}

fn policy_default_act(policy: ResponsePolicy) -> DialogAct {
    POLICY_ACTS[policy as usize]
}

fn policy_from_frame(frame: LanguageFrame) -> ResponsePolicy {
    ACTION_POLICIES[frame.action.index()]
}
