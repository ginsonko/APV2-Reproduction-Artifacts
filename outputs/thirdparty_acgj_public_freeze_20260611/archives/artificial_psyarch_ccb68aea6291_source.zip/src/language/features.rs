use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
pub struct LanguageFeature(pub String);

impl LanguageFeature {
    pub fn new(value: impl Into<String>) -> Self {
        Self(value.into())
    }
}

pub fn language_features(text: &str, context: &str) -> Vec<LanguageFeature> {
    let text = normalize_text(text);
    let context = normalize_text(context);
    let mut features = Vec::new();
    push_tokens(&mut features, "text", &text);
    push_tokens(&mut features, "context", &context);
    push_cues(&mut features, &text, &context);
    features.sort();
    features.dedup();
    features
}

fn normalize_text(text: &str) -> String {
    text.to_lowercase()
        .chars()
        .map(normalized_char)
        .filter(|c| !c.is_control())
        .collect::<String>()
}

fn normalized_char(c: char) -> char {
    if c.is_ascii_punctuation() || c.is_whitespace() {
        ' '
    } else {
        c
    }
}

fn push_tokens(features: &mut Vec<LanguageFeature>, prefix: &str, text: &str) {
    text.split_whitespace()
        .filter(|token| !token.is_empty())
        .for_each(|token| features.push(LanguageFeature::new(format!("{prefix}:{token}"))));
}

fn push_cues(features: &mut Vec<LanguageFeature>, text: &str, context: &str) {
    let joined = format!("{text} {context}");
    CUE_GROUPS
        .iter()
        .filter(|group| contains_any(&joined, group.cues))
        .for_each(|group| features.push(LanguageFeature::new(group.feature)));
}

fn contains_any(text: &str, cues: &[&str]) -> bool {
    cues.iter().any(|cue| text.contains(cue))
}

#[derive(Debug, Clone, Copy)]
struct CueGroup {
    feature: &'static str,
    cues: &'static [&'static str],
}

const CUE_GROUPS: &[CueGroup] = &[
    CueGroup {
        feature: "cue:contact_opening",
        cues: &["你好", "您好", "hello", "hi", "见面", "打招呼", "开场"],
    },
    CueGroup {
        feature: "cue:relationship_maintain",
        cues: &["熟人", "朋友", "聊天", "维持", "礼貌", "回应"],
    },
    CueGroup {
        feature: "cue:past_self_cause",
        cues: &["后悔", "悔", "不该", "早知道", "过去", "做错", "自责"],
    },
    CueGroup {
        feature: "cue:repair_action",
        cues: &["补救", "道歉", "修复", "弥补", "重新来", "改变不了"],
    },
    CueGroup {
        feature: "cue:future_threat",
        cues: &["害怕", "怕", "担心", "危险", "威胁", "未知风险", "出事"],
    },
    CueGroup {
        feature: "cue:safety_action",
        cues: &["保护", "躲开", "确认", "安全", "求助", "警惕"],
    },
    CueGroup {
        feature: "cue:service_request",
        cues: &[
            "帮我",
            "请你",
            "能不能",
            "可以",
            "麻烦",
            "执行",
            "处理",
            "做一下",
        ],
    },
    CueGroup {
        feature: "cue:reason_request",
        cues: &["为什么", "原因", "解释", "说明", "怎么回事", "原理", "依据"],
    },
    CueGroup {
        feature: "cue:correction",
        cues: &["不对", "不是", "错了", "修正", "纠正", "应该是", "别这样"],
    },
    CueGroup {
        feature: "cue:choice_branch",
        cues: &["选哪个", "还是", "或者", "比较", "取舍", "方案", "哪个更"],
    },
    CueGroup {
        feature: "cue:goal_signal",
        cues: &[
            "我想",
            "目标",
            "计划",
            "接下来",
            "最终",
            "训练",
            "学习",
            "完成",
        ],
    },
    CueGroup {
        feature: "cue:evaluation",
        cues: &[
            "很好",
            "可以",
            "不满意",
            "太慢",
            "好用",
            "不好用",
            "符合",
            "问题",
        ],
    },
    CueGroup {
        feature: "cue:uncertainty",
        cues: &[
            "不知道",
            "不确定",
            "可能",
            "也许",
            "看不懂",
            "没明白",
            "疑惑",
        ],
    },
];

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn extracts_cues_across_text_and_context() {
        let features = language_features("我有点怕", "未知风险，需要确认安全");

        assert!(features.contains(&LanguageFeature::new("cue:future_threat")));
        assert!(features.contains(&LanguageFeature::new("cue:safety_action")));
    }

    #[test]
    fn normalizes_ascii_punctuation() {
        let features = language_features("hello, friend", "opening");

        assert!(features.contains(&LanguageFeature::new("text:hello")));
        assert!(features.contains(&LanguageFeature::new("text:friend")));
    }
}
