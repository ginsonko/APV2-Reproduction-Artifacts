use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
pub enum TimeOrientation {
    PresentContact,
    PastIrreversible,
    FutureThreat,
    PresentNeed,
    ReasoningNow,
    BranchingFuture,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
pub enum AffectiveState {
    WarmContact,
    SelfBlamePain,
    VigilantFear,
    NeutralNeed,
    ConfusedGap,
    EvaluativeSignal,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
pub enum RelationMode {
    OpenChannel,
    RepairRupture,
    SeekSafety,
    AskService,
    ExplainGround,
    AlignUnderstanding,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
pub enum Agency {
    Mutual,
    SelfCausal,
    ExternalUncertain,
    UserGoal,
    AgentExpected,
    SharedUnknown,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[repr(usize)]
pub enum ActionTendency {
    Greet,
    Repair,
    Protect,
    Help,
    Explain,
    Correct,
    Choose,
    TrackGoal,
    Evaluate,
    Clarify,
}

pub const ACTION_COUNT: usize = 10;

const ACTION_FRAME_LABELS: [&str; ACTION_COUNT] = [
    "frame:greeting/contact/greet",
    "frame:regret/rupture/repair",
    "frame:fear/threat/protect",
    "frame:request/service/help",
    "frame:question/reason/explain",
    "frame:correction/align/correct",
    "frame:choice/branch/choose",
    "frame:goal/plan/track",
    "frame:evaluation/feedback/evaluate",
    "frame:uncertain/gap/clarify",
];

impl ActionTendency {
    pub fn index(self) -> usize {
        self as usize
    }

    pub fn frame_label(self) -> &'static str {
        ACTION_FRAME_LABELS[self.index()]
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
pub struct LanguageFrame {
    pub time: TimeOrientation,
    pub affect: AffectiveState,
    pub relation: RelationMode,
    pub agency: Agency,
    pub action: ActionTendency,
}

impl LanguageFrame {
    pub const GREETING: Self = Self {
        time: TimeOrientation::PresentContact,
        affect: AffectiveState::WarmContact,
        relation: RelationMode::OpenChannel,
        agency: Agency::Mutual,
        action: ActionTendency::Greet,
    };

    pub const REGRET: Self = Self {
        time: TimeOrientation::PastIrreversible,
        affect: AffectiveState::SelfBlamePain,
        relation: RelationMode::RepairRupture,
        agency: Agency::SelfCausal,
        action: ActionTendency::Repair,
    };

    pub const FEAR: Self = Self {
        time: TimeOrientation::FutureThreat,
        affect: AffectiveState::VigilantFear,
        relation: RelationMode::SeekSafety,
        agency: Agency::ExternalUncertain,
        action: ActionTendency::Protect,
    };

    pub const REQUEST: Self = Self {
        time: TimeOrientation::PresentNeed,
        affect: AffectiveState::NeutralNeed,
        relation: RelationMode::AskService,
        agency: Agency::AgentExpected,
        action: ActionTendency::Help,
    };

    pub const EXPLAIN: Self = Self {
        time: TimeOrientation::ReasoningNow,
        affect: AffectiveState::ConfusedGap,
        relation: RelationMode::ExplainGround,
        agency: Agency::AgentExpected,
        action: ActionTendency::Explain,
    };

    pub const CORRECT: Self = Self {
        time: TimeOrientation::PresentNeed,
        affect: AffectiveState::EvaluativeSignal,
        relation: RelationMode::AlignUnderstanding,
        agency: Agency::Mutual,
        action: ActionTendency::Correct,
    };

    pub const CHOOSE: Self = Self {
        time: TimeOrientation::BranchingFuture,
        affect: AffectiveState::NeutralNeed,
        relation: RelationMode::AskService,
        agency: Agency::SharedUnknown,
        action: ActionTendency::Choose,
    };

    pub const GOAL: Self = Self {
        time: TimeOrientation::BranchingFuture,
        affect: AffectiveState::NeutralNeed,
        relation: RelationMode::AskService,
        agency: Agency::UserGoal,
        action: ActionTendency::TrackGoal,
    };

    pub const EVALUATE: Self = Self {
        time: TimeOrientation::ReasoningNow,
        affect: AffectiveState::EvaluativeSignal,
        relation: RelationMode::AlignUnderstanding,
        agency: Agency::Mutual,
        action: ActionTendency::Evaluate,
    };

    pub const UNCERTAIN: Self = Self {
        time: TimeOrientation::ReasoningNow,
        affect: AffectiveState::ConfusedGap,
        relation: RelationMode::ExplainGround,
        agency: Agency::SharedUnknown,
        action: ActionTendency::Clarify,
    };

    pub fn label(self) -> &'static str {
        self.action.frame_label()
    }

    pub fn all() -> [Self; 10] {
        [
            Self::GREETING,
            Self::REGRET,
            Self::FEAR,
            Self::REQUEST,
            Self::EXPLAIN,
            Self::CORRECT,
            Self::CHOOSE,
            Self::GOAL,
            Self::EVALUATE,
            Self::UNCERTAIN,
        ]
    }
}
