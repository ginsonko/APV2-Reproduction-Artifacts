use super::dialog::{DialogAct, DialogUnderstanding};
use super::frame::LanguageFrame;
use super::response_policy::{ResponsePolicy, ResponsePolicyStimulus};

const ACT_FRAMES: [LanguageFrame; 10] = [
    LanguageFrame::GREETING,
    LanguageFrame::REGRET,
    LanguageFrame::FEAR,
    LanguageFrame::REQUEST,
    LanguageFrame::EXPLAIN,
    LanguageFrame::CORRECT,
    LanguageFrame::CHOOSE,
    LanguageFrame::GOAL,
    LanguageFrame::EVALUATE,
    LanguageFrame::UNCERTAIN,
];

#[derive(Debug, Clone, Copy)]
pub(crate) struct PolicyItem {
    pub(crate) text: &'static str,
    pub(crate) context: &'static str,
    pub(crate) act: DialogAct,
    pub(crate) policy: ResponsePolicy,
}

impl PolicyItem {
    pub(crate) fn understanding(self) -> DialogUnderstanding {
        let frame = frame_for_act(self.act);
        DialogUnderstanding {
            frame,
            act: self.act,
            frame_label: frame.label().to_owned(),
            response_hint: "policy training item".to_owned(),
        }
    }
}

pub(crate) fn train_items() -> Vec<PolicyItem> {
    CANONICAL_POLICY_ITEMS.to_vec()
}

pub(crate) fn holdout_stimuli() -> Vec<ResponsePolicyStimulus> {
    policy_stimuli(&CANONICAL_POLICY_HOLDOUT, "H")
}

pub(crate) fn train_stimuli(items: &[PolicyItem]) -> Vec<ResponsePolicyStimulus> {
    policy_stimuli(items, "T")
}

const CANONICAL_POLICY_ITEMS: [PolicyItem; 10] = [
    item(
        "你好",
        "打开交流通道",
        DialogAct::OpenChannel,
        ResponsePolicy::BriefAcknowledge,
    ),
    item(
        "我想道歉",
        "修复关系",
        DialogAct::RepairRelation,
        ResponsePolicy::RepairNextStep,
    ),
    item(
        "我害怕有危险",
        "确认安全",
        DialogAct::SeekSafety,
        ResponsePolicy::SafetyClarify,
    ),
    item(
        "帮我处理这个",
        "执行任务",
        DialogAct::ServeRequest,
        ResponsePolicy::TaskPlan,
    ),
    item(
        "为什么这样",
        "说明依据",
        DialogAct::ExplainReason,
        ResponsePolicy::ExplainGrounds,
    ),
    item(
        "不对，修正",
        "用户纠错",
        DialogAct::AlignCorrection,
        ResponsePolicy::AcceptCorrection,
    ),
    item(
        "选哪个方案",
        "比较取舍",
        DialogAct::CompareOptions,
        ResponsePolicy::CompareTradeoffs,
    ),
    item(
        "我想完成训练",
        "追踪目标",
        DialogAct::TrackGoal,
        ResponsePolicy::TrackGoal,
    ),
    item(
        "这个不好用",
        "用户反馈",
        DialogAct::RecordEvaluation,
        ResponsePolicy::UseFeedback,
    ),
    item(
        "我不确定",
        "需要澄清",
        DialogAct::AskClarification,
        ResponsePolicy::AskClarifyingQuestion,
    ),
];

const CANONICAL_POLICY_HOLDOUT: [PolicyItem; 10] = [
    item(
        "朋友你好",
        "熟人开场，维持交流",
        DialogAct::OpenChannel,
        ResponsePolicy::BriefAcknowledge,
    ),
    item(
        "我想补救这件事",
        "过去关系破裂，需要下一步",
        DialogAct::RepairRelation,
        ResponsePolicy::RepairNextStep,
    ),
    item(
        "先确认风险吧",
        "未来威胁不清",
        DialogAct::SeekSafety,
        ResponsePolicy::SafetyClarify,
    ),
    item(
        "麻烦你跑一下检查",
        "请求执行当前任务",
        DialogAct::ServeRequest,
        ResponsePolicy::TaskPlan,
    ),
    item(
        "说明一下依据",
        "用户要求解释判断",
        DialogAct::ExplainReason,
        ResponsePolicy::ExplainGrounds,
    ),
    item(
        "不是这个意思，改一下",
        "用户纠正对齐方向",
        DialogAct::AlignCorrection,
        ResponsePolicy::AcceptCorrection,
    ),
    item(
        "继续写还是先测试",
        "需要比较两个分支",
        DialogAct::CompareOptions,
        ResponsePolicy::CompareTradeoffs,
    ),
    item(
        "下一步是完成语言训练",
        "持续目标管理",
        DialogAct::TrackGoal,
        ResponsePolicy::TrackGoal,
    ),
    item(
        "这个方向不好用",
        "用户评价当前结果",
        DialogAct::RecordEvaluation,
        ResponsePolicy::UseFeedback,
    ),
    item(
        "我不知道缺什么",
        "共享未知，需要提问",
        DialogAct::AskClarification,
        ResponsePolicy::AskClarifyingQuestion,
    ),
];

fn policy_stimuli(items: &[PolicyItem], prefix: &str) -> Vec<ResponsePolicyStimulus> {
    items
        .iter()
        .enumerate()
        .map(|(index, item)| policy_stimulus(*item, prefix, index))
        .collect()
}

fn policy_stimulus(item: PolicyItem, prefix: &str, index: usize) -> ResponsePolicyStimulus {
    ResponsePolicyStimulus::new(
        format!("{prefix}{index:03}"),
        item.text,
        item.context,
        item.understanding(),
        item.policy,
    )
}

const fn item(
    text: &'static str,
    context: &'static str,
    act: DialogAct,
    policy: ResponsePolicy,
) -> PolicyItem {
    PolicyItem {
        text,
        context,
        act,
        policy,
    }
}

fn frame_for_act(act: DialogAct) -> LanguageFrame {
    ACT_FRAMES[act as usize]
}
