use serde::{Deserialize, Serialize};

use super::curriculum::LanguageGroundingStimulus;
use super::frame::{ACTION_COUNT, LanguageFrame};
use super::learner::LanguageGroundingLearner;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum DialogAct {
    OpenChannel,
    RepairRelation,
    SeekSafety,
    ServeRequest,
    ExplainReason,
    AlignCorrection,
    CompareOptions,
    TrackGoal,
    RecordEvaluation,
    AskClarification,
}

const DIALOG_ACT_LABELS: [&str; ACTION_COUNT] = [
    "dialog:open-channel",
    "dialog:repair-relation",
    "dialog:seek-safety",
    "dialog:serve-request",
    "dialog:explain-reason",
    "dialog:align-correction",
    "dialog:compare-options",
    "dialog:track-goal",
    "dialog:record-evaluation",
    "dialog:ask-clarification",
];

const ACTION_DIALOG_ACTS: [DialogAct; ACTION_COUNT] = [
    DialogAct::OpenChannel,
    DialogAct::RepairRelation,
    DialogAct::SeekSafety,
    DialogAct::ServeRequest,
    DialogAct::ExplainReason,
    DialogAct::AlignCorrection,
    DialogAct::CompareOptions,
    DialogAct::TrackGoal,
    DialogAct::RecordEvaluation,
    DialogAct::AskClarification,
];

const RESPONSE_HINTS: [&str; ACTION_COUNT] = [
    "打开对话通道，保持轻量回应",
    "承认过去不可逆，优先给出修复动作",
    "先降低风险，再请求必要信息",
    "识别为请求，转入可执行任务或计划",
    "给出依据、因果和可验证边界",
    "接受纠错，更新当前对齐方向",
    "比较选项，给出取舍依据",
    "记录目标，并拆成下一步动作",
    "把评价作为反馈信号进入后续调整",
    "提出澄清问题或列出未知项",
];

impl DialogAct {
    pub fn label(self) -> &'static str {
        DIALOG_ACT_LABELS[self as usize]
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct DialogUnderstanding {
    pub frame: LanguageFrame,
    pub act: DialogAct,
    pub frame_label: String,
    pub response_hint: String,
}

impl DialogUnderstanding {
    pub fn trace_line(&self) -> String {
        format!("language {} -> {}", self.frame_label, self.act.label())
    }
}

pub fn understand_dialog(
    learner: &LanguageGroundingLearner,
    text: &str,
    context: &str,
) -> DialogUnderstanding {
    let stimulus =
        LanguageGroundingStimulus::new("dialog-live", text, context, LanguageFrame::GREETING);
    let frame = learner.predict_frame(&stimulus);
    DialogUnderstanding {
        frame,
        act: dialog_act(frame),
        frame_label: frame.label().to_owned(),
        response_hint: response_hint(frame).to_owned(),
    }
}

fn dialog_act(frame: LanguageFrame) -> DialogAct {
    ACTION_DIALOG_ACTS[frame.action.index()]
}

fn response_hint(frame: LanguageFrame) -> &'static str {
    RESPONSE_HINTS[frame.action.index()]
}
