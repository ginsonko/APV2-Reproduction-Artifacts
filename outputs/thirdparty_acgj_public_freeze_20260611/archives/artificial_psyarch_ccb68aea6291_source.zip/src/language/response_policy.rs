use std::collections::HashMap;

use serde::{Deserialize, Serialize};

use crate::ap::{AuditTrace, Feedback, TeacherMode};
use crate::core::runner::{
    CoreLearner, CorePhaseResult, CoreWorld, run_core_phase, train_core_repeats,
};

use super::dialog::DialogUnderstanding;
use super::features::{LanguageFeature, language_features};
use super::response_policy_curriculum;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[repr(usize)]
pub enum ResponsePolicy {
    BriefAcknowledge,
    RepairNextStep,
    SafetyClarify,
    TaskPlan,
    ExplainGrounds,
    AcceptCorrection,
    CompareTradeoffs,
    TrackGoal,
    UseFeedback,
    AskClarifyingQuestion,
}

const RESPONSE_POLICIES: [ResponsePolicy; 10] = [
    ResponsePolicy::BriefAcknowledge,
    ResponsePolicy::RepairNextStep,
    ResponsePolicy::SafetyClarify,
    ResponsePolicy::TaskPlan,
    ResponsePolicy::ExplainGrounds,
    ResponsePolicy::AcceptCorrection,
    ResponsePolicy::CompareTradeoffs,
    ResponsePolicy::TrackGoal,
    ResponsePolicy::UseFeedback,
    ResponsePolicy::AskClarifyingQuestion,
];

const POLICY_LABELS: [&str; 10] = [
    "response:brief-acknowledge",
    "response:repair-next-step",
    "response:safety-clarify",
    "response:task-plan",
    "response:explain-grounds",
    "response:accept-correction",
    "response:compare-tradeoffs",
    "response:track-goal",
    "response:use-feedback",
    "response:ask-clarifying-question",
];

impl ResponsePolicy {
    pub fn all() -> [Self; 10] {
        RESPONSE_POLICIES
    }

    pub fn label(self) -> &'static str {
        POLICY_LABELS[self as usize]
    }
}

pub fn response_policy_from_label(label: &str) -> Option<ResponsePolicy> {
    ResponsePolicy::all()
        .into_iter()
        .find(|policy| policy.label() == label)
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ResponsePolicyDecision {
    pub policy: ResponsePolicy,
    pub policy_label: String,
    pub evidence: Vec<String>,
}

#[derive(Debug, Default, Clone)]
pub struct ResponsePolicyLearner {
    scores: HashMap<FeaturePolicy, i32>,
    stimulus_policy_attempts: HashMap<StimulusPolicy, usize>,
    memory_rows: usize,
}

impl ResponsePolicyLearner {
    pub fn canonical_trained() -> Self {
        let mut learner = Self::default();
        train_canonical_response_policies(&mut learner, 3);
        learner
    }

    pub fn predict(
        &self,
        understanding: &DialogUnderstanding,
        text: &str,
        context: &str,
    ) -> ResponsePolicyDecision {
        let features = response_policy_features(understanding, text, context);
        let policy = best_policy(&features, |feature, policy| {
            self.feature_score(feature, policy)
        });
        ResponsePolicyDecision {
            policy,
            policy_label: policy.label().to_owned(),
            evidence: features.into_iter().map(|feature| feature.0).collect(),
        }
    }

    pub fn predict_for_mode(
        &self,
        stimulus: &ResponsePolicyStimulus,
        mode: TeacherMode,
    ) -> ResponsePolicy {
        if mode.exploration_enabled() {
            self.first_untried_policy(stimulus)
                .unwrap_or_else(|| self.predict_stimulus(stimulus))
        } else {
            self.predict_stimulus(stimulus)
        }
    }

    pub fn predict_stimulus(&self, stimulus: &ResponsePolicyStimulus) -> ResponsePolicy {
        self.predict(&stimulus.understanding, &stimulus.text, &stimulus.context)
            .policy
    }

    pub fn learn(
        &mut self,
        understanding: &DialogUnderstanding,
        text: &str,
        context: &str,
        expected: ResponsePolicy,
    ) {
        response_policy_features(understanding, text, context)
            .into_iter()
            .for_each(|feature| self.add_score(feature, expected, 1));
        self.memory_rows += 1;
    }

    pub fn receive_policy_feedback(
        &mut self,
        stimulus: &ResponsePolicyStimulus,
        policy: ResponsePolicy,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        if mode.memory_write_enabled() {
            self.record_feedback(stimulus, policy, feedback);
        }
        AuditTrace::for_mode(mode)
    }

    pub fn memory_rows(&self) -> usize {
        self.memory_rows
    }

    fn add_score(&mut self, feature: LanguageFeature, policy: ResponsePolicy, delta: i32) {
        *self
            .scores
            .entry(FeaturePolicy { feature, policy })
            .or_default() += delta;
    }

    fn feature_score(&self, feature: &LanguageFeature, policy: ResponsePolicy) -> i32 {
        self.scores
            .get(&FeaturePolicy {
                feature: feature.clone(),
                policy,
            })
            .copied()
            .unwrap_or_default()
    }

    fn first_untried_policy(&self, stimulus: &ResponsePolicyStimulus) -> Option<ResponsePolicy> {
        ResponsePolicy::all()
            .into_iter()
            .find(|policy| !self.seen_stimulus_policy(stimulus, *policy))
    }

    fn seen_stimulus_policy(
        &self,
        stimulus: &ResponsePolicyStimulus,
        policy: ResponsePolicy,
    ) -> bool {
        self.stimulus_policy_attempts
            .contains_key(&StimulusPolicy::new(stimulus, policy))
    }

    fn record_feedback(
        &mut self,
        stimulus: &ResponsePolicyStimulus,
        policy: ResponsePolicy,
        feedback: Feedback,
    ) {
        *self
            .stimulus_policy_attempts
            .entry(StimulusPolicy::new(stimulus, policy))
            .or_default() += 1;
        response_policy_features(&stimulus.understanding, &stimulus.text, &stimulus.context)
            .into_iter()
            .for_each(|feature| self.add_score(feature, policy, feedback.score()));
        self.memory_rows += 1;
    }
}

impl CoreLearner<ResponsePolicyWorld> for ResponsePolicyLearner {
    fn select_response(
        &self,
        _world: &ResponsePolicyWorld,
        stimulus: &ResponsePolicyStimulus,
        mode: TeacherMode,
    ) -> ResponsePolicy {
        self.predict_for_mode(stimulus, mode)
    }

    fn receive_feedback(
        &mut self,
        _world: &ResponsePolicyWorld,
        stimulus: &ResponsePolicyStimulus,
        response: ResponsePolicy,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        self.receive_policy_feedback(stimulus, response, feedback, mode)
    }

    fn memory_rows(&self) -> Option<usize> {
        Some(self.memory_rows())
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ResponsePolicyStimulus {
    pub id: String,
    pub text: String,
    pub context: String,
    pub understanding: DialogUnderstanding,
    pub expected_policy: ResponsePolicy,
}

impl ResponsePolicyStimulus {
    pub fn new(
        id: impl Into<String>,
        text: impl Into<String>,
        context: impl Into<String>,
        understanding: DialogUnderstanding,
        expected_policy: ResponsePolicy,
    ) -> Self {
        Self {
            id: id.into(),
            text: text.into(),
            context: context.into(),
            understanding,
            expected_policy,
        }
    }
}

#[derive(Debug, Clone)]
pub struct ResponsePolicyWorld {
    train_items: Vec<ResponsePolicyStimulus>,
    holdout_items: Vec<ResponsePolicyStimulus>,
}

impl ResponsePolicyWorld {
    pub fn new(
        train_items: Vec<ResponsePolicyStimulus>,
        holdout_items: Vec<ResponsePolicyStimulus>,
    ) -> Self {
        Self {
            train_items,
            holdout_items,
        }
    }

    pub fn canonical() -> Self {
        let items = response_policy_curriculum::train_items();
        Self::new(
            response_policy_curriculum::train_stimuli(&items),
            response_policy_curriculum::holdout_stimuli(),
        )
    }

    pub fn train_items(&self) -> &[ResponsePolicyStimulus] {
        &self.train_items
    }

    pub fn holdout_items(&self) -> &[ResponsePolicyStimulus] {
        &self.holdout_items
    }

    pub fn commit_policy(
        &self,
        stimulus: &ResponsePolicyStimulus,
        policy: ResponsePolicy,
    ) -> Feedback {
        if policy == stimulus.expected_policy {
            Feedback::Reward
        } else {
            Feedback::Punishment
        }
    }
}

impl CoreWorld for ResponsePolicyWorld {
    type Stimulus = ResponsePolicyStimulus;
    type Response = ResponsePolicy;

    fn commit_response(&self, stimulus: &Self::Stimulus, response: Self::Response) -> Feedback {
        self.commit_policy(stimulus, response)
    }
}

pub type ResponsePolicyPhaseResult = CorePhaseResult;

pub fn train_response_policy(
    world: &ResponsePolicyWorld,
    learner: &mut ResponsePolicyLearner,
    repeats: usize,
) -> Vec<ResponsePolicyPhaseResult> {
    train_core_repeats(
        world.train_items(),
        world,
        learner,
        repeats.max(ResponsePolicy::all().len() + 2),
    )
}

pub fn run_response_policy_phase(
    stimuli: &[ResponsePolicyStimulus],
    world: &ResponsePolicyWorld,
    learner: &mut ResponsePolicyLearner,
    mode: TeacherMode,
) -> ResponsePolicyPhaseResult {
    run_core_phase(stimuli, world, learner, mode)
}

pub fn response_policy_features(
    understanding: &DialogUnderstanding,
    text: &str,
    context: &str,
) -> Vec<LanguageFeature> {
    let mut features = language_features(text, context);
    features.extend([
        LanguageFeature::new(format!("frame:{}", understanding.frame_label)),
        LanguageFeature::new(format!("dialog:{}", understanding.act.label())),
    ]);
    features.sort();
    features.dedup();
    features
}

fn train_canonical_response_policies(learner: &mut ResponsePolicyLearner, repeats: usize) {
    let items = response_policy_curriculum::train_items();
    (0..repeats).flat_map(|_| items.iter()).for_each(|item| {
        let understanding = (*item).understanding();
        learner.learn(&understanding, item.text, item.context, item.policy);
    });
}

fn best_policy(
    features: &[LanguageFeature],
    score: impl Fn(&LanguageFeature, ResponsePolicy) -> i32,
) -> ResponsePolicy {
    ResponsePolicy::all()
        .into_iter()
        .fold(
            (ResponsePolicy::BriefAcknowledge, i32::MIN),
            |best, policy| {
                best_by_score(
                    best,
                    (
                        policy,
                        features.iter().map(|feature| score(feature, policy)).sum(),
                    ),
                )
            },
        )
        .0
}

fn best_by_score(
    best: (ResponsePolicy, i32),
    candidate: (ResponsePolicy, i32),
) -> (ResponsePolicy, i32) {
    if candidate.1 > best.1 {
        candidate
    } else {
        best
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct FeaturePolicy {
    feature: LanguageFeature,
    policy: ResponsePolicy,
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct StimulusPolicy {
    stimulus_id: String,
    policy: ResponsePolicy,
}

impl StimulusPolicy {
    fn new(stimulus: &ResponsePolicyStimulus, policy: ResponsePolicy) -> Self {
        Self {
            stimulus_id: stimulus.id.clone(),
            policy,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::language_core::{DialogAct, LanguageFrame};

    #[test]
    fn response_policy_learns_from_dialog_features() {
        let learner = ResponsePolicyLearner::canonical_trained();
        let understanding = DialogUnderstanding {
            frame: LanguageFrame::REQUEST,
            act: DialogAct::ServeRequest,
            frame_label: "frame:request/service/help".to_owned(),
            response_hint: String::new(),
        };

        let decision = learner.predict(&understanding, "能不能帮我检查", "请求执行当前任务");

        assert_eq!(decision.policy, ResponsePolicy::TaskPlan);
        assert!(
            decision
                .evidence
                .iter()
                .any(|item| item.contains("dialog:"))
        );
    }

    #[test]
    fn response_policy_runs_teacher_off_holdout() {
        let world = ResponsePolicyWorld::canonical();
        let mut learner = ResponsePolicyLearner::default();

        train_response_policy(&world, &mut learner, 3);
        let holdout = run_response_policy_phase(
            world.holdout_items(),
            &world,
            &mut learner,
            TeacherMode::TeacherOff,
        );

        assert_eq!(holdout.accuracy, 1.0);
    }
}
