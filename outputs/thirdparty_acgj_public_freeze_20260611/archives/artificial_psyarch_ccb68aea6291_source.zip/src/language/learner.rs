use std::collections::HashMap;

use crate::ap::{AuditTrace, Feedback, TeacherMode};
use crate::core::runner::CoreLearner;

use super::curriculum::{LanguageGroundingStimulus, LanguageGroundingWorld};
use super::features::{LanguageFeature, language_features};
use super::frame::LanguageFrame;

#[derive(Debug, Default, Clone)]
pub struct LanguageGroundingLearner {
    feature_frame_scores: HashMap<FeatureFrame, i32>,
    stimulus_frame_attempts: HashMap<StimulusFrame, usize>,
    memory_rows: usize,
}

impl LanguageGroundingLearner {
    pub fn predict_frame(&self, stimulus: &LanguageGroundingStimulus) -> LanguageFrame {
        self.best_scored_frame(stimulus)
    }

    pub fn predict_for_mode(
        &self,
        stimulus: &LanguageGroundingStimulus,
        mode: TeacherMode,
    ) -> LanguageFrame {
        if mode.exploration_enabled() {
            self.first_untried_frame(stimulus)
                .unwrap_or_else(|| self.best_scored_frame(stimulus))
        } else {
            self.best_scored_frame(stimulus)
        }
    }

    pub fn receive_language_feedback(
        &mut self,
        stimulus: &LanguageGroundingStimulus,
        frame: LanguageFrame,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        if mode.memory_write_enabled() {
            self.record_feedback(stimulus, frame, feedback);
        }
        AuditTrace::for_mode(mode)
    }

    pub fn score_frame(&self, stimulus: &LanguageGroundingStimulus, frame: LanguageFrame) -> i32 {
        language_features(&stimulus.text, &stimulus.context)
            .into_iter()
            .map(|feature| self.feature_score(feature, frame))
            .sum()
    }

    pub fn memory_rows(&self) -> usize {
        self.memory_rows
    }

    fn best_scored_frame(&self, stimulus: &LanguageGroundingStimulus) -> LanguageFrame {
        LanguageFrame::all()
            .into_iter()
            .fold((LanguageFrame::GREETING, i32::MIN), |best, frame| {
                best_by_score(best, (frame, self.score_frame(stimulus, frame)))
            })
            .0
    }

    fn first_untried_frame(&self, stimulus: &LanguageGroundingStimulus) -> Option<LanguageFrame> {
        LanguageFrame::all()
            .into_iter()
            .find(|frame| !self.seen_stimulus_frame(stimulus, *frame))
    }

    fn seen_stimulus_frame(
        &self,
        stimulus: &LanguageGroundingStimulus,
        frame: LanguageFrame,
    ) -> bool {
        self.stimulus_frame_attempts
            .contains_key(&StimulusFrame::new(stimulus, frame))
    }

    fn record_feedback(
        &mut self,
        stimulus: &LanguageGroundingStimulus,
        frame: LanguageFrame,
        feedback: Feedback,
    ) {
        let delta = feedback.score();
        *self
            .stimulus_frame_attempts
            .entry(StimulusFrame::new(stimulus, frame))
            .or_default() += 1;
        language_features(&stimulus.text, &stimulus.context)
            .into_iter()
            .for_each(|feature| self.add_feature_score(feature, frame, delta));
        self.memory_rows += 1;
    }

    fn add_feature_score(&mut self, feature: LanguageFeature, frame: LanguageFrame, delta: i32) {
        *self
            .feature_frame_scores
            .entry(FeatureFrame { feature, frame })
            .or_default() += delta;
    }

    fn feature_score(&self, feature: LanguageFeature, frame: LanguageFrame) -> i32 {
        self.feature_frame_scores
            .get(&FeatureFrame { feature, frame })
            .copied()
            .unwrap_or_default()
    }
}

impl CoreLearner<LanguageGroundingWorld> for LanguageGroundingLearner {
    fn select_response(
        &self,
        _world: &LanguageGroundingWorld,
        stimulus: &LanguageGroundingStimulus,
        mode: TeacherMode,
    ) -> LanguageFrame {
        self.predict_for_mode(stimulus, mode)
    }

    fn receive_feedback(
        &mut self,
        _world: &LanguageGroundingWorld,
        stimulus: &LanguageGroundingStimulus,
        response: LanguageFrame,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        self.receive_language_feedback(stimulus, response, feedback, mode)
    }

    fn memory_rows(&self) -> Option<usize> {
        Some(self.memory_rows())
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct FeatureFrame {
    feature: LanguageFeature,
    frame: LanguageFrame,
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct StimulusFrame {
    stimulus_id: String,
    frame: LanguageFrame,
}

impl StimulusFrame {
    fn new(stimulus: &LanguageGroundingStimulus, frame: LanguageFrame) -> Self {
        Self {
            stimulus_id: stimulus.id.clone(),
            frame,
        }
    }
}

fn best_by_score(
    best: (LanguageFrame, i32),
    candidate: (LanguageFrame, i32),
) -> (LanguageFrame, i32) {
    if candidate.1 > best.1 {
        candidate
    } else {
        best
    }
}
