use serde::{Deserialize, Serialize};

use crate::ap::{Feedback, TeacherMode};
use crate::core::runner::{CorePhaseResult, CoreWorld, run_core_phase, train_core_repeats};

use super::frame::LanguageFrame;
use super::learner::LanguageGroundingLearner;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct LanguageGroundingStimulus {
    pub id: String,
    pub text: String,
    pub context: String,
    pub expected_frame: LanguageFrame,
}

impl LanguageGroundingStimulus {
    pub fn new(
        id: impl Into<String>,
        text: impl Into<String>,
        context: impl Into<String>,
        expected_frame: LanguageFrame,
    ) -> Self {
        Self {
            id: id.into(),
            text: text.into(),
            context: context.into(),
            expected_frame,
        }
    }
}

#[derive(Debug, Clone)]
pub struct LanguageGroundingWorld {
    train_items: Vec<LanguageGroundingStimulus>,
    holdout_items: Vec<LanguageGroundingStimulus>,
}

impl LanguageGroundingWorld {
    pub fn new(
        train_items: Vec<LanguageGroundingStimulus>,
        holdout_items: Vec<LanguageGroundingStimulus>,
    ) -> Self {
        Self {
            train_items,
            holdout_items,
        }
    }

    pub fn canonical() -> Self {
        Self::new(train_items(), holdout_items())
    }

    pub fn train_items(&self) -> &[LanguageGroundingStimulus] {
        &self.train_items
    }

    pub fn holdout_items(&self) -> &[LanguageGroundingStimulus] {
        &self.holdout_items
    }

    pub fn commit_frame(
        &self,
        stimulus: &LanguageGroundingStimulus,
        frame: LanguageFrame,
    ) -> Feedback {
        if frame == stimulus.expected_frame {
            Feedback::Reward
        } else {
            Feedback::Punishment
        }
    }
}

impl CoreWorld for LanguageGroundingWorld {
    type Stimulus = LanguageGroundingStimulus;
    type Response = LanguageFrame;

    fn commit_response(&self, stimulus: &Self::Stimulus, response: Self::Response) -> Feedback {
        self.commit_frame(stimulus, response)
    }
}

pub type LanguageGroundingPhaseResult = CorePhaseResult;

pub fn train_language_grounding(
    world: &LanguageGroundingWorld,
    learner: &mut LanguageGroundingLearner,
    repeats: usize,
) -> Vec<LanguageGroundingPhaseResult> {
    train_core_repeats(
        world.train_items(),
        world,
        learner,
        language_training_repeats(repeats),
    )
}

pub fn run_language_grounding_phase(
    stimuli: &[LanguageGroundingStimulus],
    world: &LanguageGroundingWorld,
    learner: &mut LanguageGroundingLearner,
    mode: TeacherMode,
) -> LanguageGroundingPhaseResult {
    run_core_phase(stimuli, world, learner, mode)
}

fn train_items() -> Vec<LanguageGroundingStimulus> {
    vec![
        greeting("T00", "你好", "初次见面，打开交流通道"),
        greeting("T01", "您好，见到你很高兴", "礼貌开场，建立关系"),
        greeting("T02", "hello", "conversation opening with a new person"),
        regret("T10", "我很后悔", "过去做错，想补救但无法重来"),
        regret("T11", "早知道我不该那样说", "自责并希望修复关系"),
        regret("T12", "我想道歉弥补", "承认自己造成了关系破裂"),
        fear("T20", "我有点害怕", "未知风险，需要确认安全"),
        fear("T21", "这件事让我担心", "未来可能有威胁，要保持警惕"),
        fear("T22", "我怕出危险", "外部威胁临近，需要保护自己"),
        request("T30", "帮我整理一下", "用户请求 AP 执行一个当前任务"),
        request("T31", "请你处理这个问题", "用户期待 agent 给出帮助"),
        explain("T40", "为什么会这样", "用户要求说明原因和依据"),
        explain("T41", "解释一下这个原理", "当前理解存在缺口"),
        correct("T50", "不对，应该是另一种方式", "用户纠正 AP 的理解"),
        correct("T51", "你这里错了，需要修正", "反馈要求对齐认知"),
        choose("T60", "这两个方案选哪个", "未来分支需要比较取舍"),
        choose("T61", "用 A 还是 B 更好", "多个路径需要选择"),
        goal("T70", "我想训练通用语言能力", "用户给出接下来的目标"),
        goal("T71", "目标是完成论文功能", "需要持续追踪计划"),
        evaluate("T80", "这个结果很好", "用户提供正向评价反馈"),
        evaluate("T81", "现在不好用，有问题", "用户提供负向评价反馈"),
        uncertain("T90", "我不确定接下来怎么做", "共享未知，需要澄清"),
        uncertain("T91", "这段我没明白", "理解存在缺口"),
    ]
}

fn language_training_repeats(requested: usize) -> usize {
    requested.max(LanguageFrame::all().len() + 2)
}

fn holdout_items() -> Vec<LanguageGroundingStimulus> {
    vec![
        greeting("H00", "嗨，第一次聊", "陌生人开场，想建立联系"),
        greeting("H01", "朋友你好", "熟人聊天开头，维持关系"),
        regret("H10", "如果能重来就好了", "过去选择造成伤害，现在想修复"),
        regret("H11", "我做错了，想补救", "自我原因导致关系破裂"),
        fear("H20", "前面有未知风险，我想先确认", "威胁下寻求安全"),
        fear("H21", "我担心会出事", "未来风险引发警惕和保护倾向"),
        request("H30", "能不能帮我跑一下检查", "请求 AP 执行当前任务"),
        request("H31", "麻烦把这些都处理掉", "用户期待 agent 帮助完成"),
        explain("H40", "说明一下依据", "要求解释判断理由"),
        explain("H41", "这是怎么回事", "原因不清，需要说明"),
        correct("H50", "不是这个意思，改一下", "用户纠正对话方向"),
        correct("H51", "别这样做，应该换方案", "要求修正行为"),
        choose("H60", "现在用哪个方案比较合适", "多分支取舍"),
        choose("H61", "继续写还是先测试", "需要选择下一步"),
        goal("H70", "接下来计划先做语言训练", "用户表达近期目标"),
        goal("H71", "最终要让 AP 能学习", "长期目标追踪"),
        evaluate("H80", "这个方向符合我的想法", "评价当前结果"),
        evaluate("H81", "太慢了，不满意", "负向评价当前表现"),
        uncertain("H90", "可能还缺东西，我不知道", "不确定并请求澄清"),
        uncertain("H91", "我看不懂这是什么意思", "理解缺口"),
    ]
}

fn greeting(
    id: impl Into<String>,
    text: impl Into<String>,
    context: impl Into<String>,
) -> LanguageGroundingStimulus {
    LanguageGroundingStimulus::new(id, text, context, LanguageFrame::GREETING)
}

fn regret(
    id: impl Into<String>,
    text: impl Into<String>,
    context: impl Into<String>,
) -> LanguageGroundingStimulus {
    LanguageGroundingStimulus::new(id, text, context, LanguageFrame::REGRET)
}

fn fear(
    id: impl Into<String>,
    text: impl Into<String>,
    context: impl Into<String>,
) -> LanguageGroundingStimulus {
    LanguageGroundingStimulus::new(id, text, context, LanguageFrame::FEAR)
}

fn request(
    id: impl Into<String>,
    text: impl Into<String>,
    context: impl Into<String>,
) -> LanguageGroundingStimulus {
    LanguageGroundingStimulus::new(id, text, context, LanguageFrame::REQUEST)
}

fn explain(
    id: impl Into<String>,
    text: impl Into<String>,
    context: impl Into<String>,
) -> LanguageGroundingStimulus {
    LanguageGroundingStimulus::new(id, text, context, LanguageFrame::EXPLAIN)
}

fn correct(
    id: impl Into<String>,
    text: impl Into<String>,
    context: impl Into<String>,
) -> LanguageGroundingStimulus {
    LanguageGroundingStimulus::new(id, text, context, LanguageFrame::CORRECT)
}

fn choose(
    id: impl Into<String>,
    text: impl Into<String>,
    context: impl Into<String>,
) -> LanguageGroundingStimulus {
    LanguageGroundingStimulus::new(id, text, context, LanguageFrame::CHOOSE)
}

fn goal(
    id: impl Into<String>,
    text: impl Into<String>,
    context: impl Into<String>,
) -> LanguageGroundingStimulus {
    LanguageGroundingStimulus::new(id, text, context, LanguageFrame::GOAL)
}

fn evaluate(
    id: impl Into<String>,
    text: impl Into<String>,
    context: impl Into<String>,
) -> LanguageGroundingStimulus {
    LanguageGroundingStimulus::new(id, text, context, LanguageFrame::EVALUATE)
}

fn uncertain(
    id: impl Into<String>,
    text: impl Into<String>,
    context: impl Into<String>,
) -> LanguageGroundingStimulus {
    LanguageGroundingStimulus::new(id, text, context, LanguageFrame::UNCERTAIN)
}
