use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum AtomKind {
    Observation,
    Action,
    Feedback,
    Feeling,
    Control,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct StateAtom {
    pub key: String,
    pub kind: AtomKind,
    pub real_energy: f32,
    pub virtual_energy: f32,
    pub cognitive_pressure: f32,
    pub attention_gain: f32,
    pub fatigue: f32,
    pub last_touched_tick: u64,
}

impl StateAtom {
    pub fn new(key: impl Into<String>, kind: AtomKind) -> Self {
        Self {
            key: key.into(),
            kind,
            real_energy: 1.0,
            virtual_energy: 0.0,
            cognitive_pressure: 0.0,
            attention_gain: 0.0,
            fatigue: 0.0,
            last_touched_tick: 0,
        }
    }

    pub fn predicted(mut self, strength: f32) -> Self {
        self.real_energy = 0.0;
        self.virtual_energy = strength;
        self.cognitive_pressure = strength;
        self
    }

    pub fn with_attention_gain(mut self, gain: f32) -> Self {
        self.attention_gain = gain;
        self
    }
}
