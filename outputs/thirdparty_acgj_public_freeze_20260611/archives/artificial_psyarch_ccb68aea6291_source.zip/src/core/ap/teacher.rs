use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TeacherMode {
    TeacherOn,
    FeedbackOnly,
    Fade,
    NoAnswerFeedback,
    TeacherOff,
}

impl TeacherMode {
    pub fn feedback_visible_to_learner(self) -> bool {
        matches!(
            self,
            Self::TeacherOn | Self::FeedbackOnly | Self::Fade | Self::NoAnswerFeedback
        )
    }

    pub fn memory_write_enabled(self) -> bool {
        matches!(self, Self::TeacherOn | Self::FeedbackOnly | Self::Fade)
    }

    pub fn answer_visible_to_learner(self) -> bool {
        matches!(self, Self::TeacherOn)
    }

    pub fn exploration_enabled(self) -> bool {
        !matches!(self, Self::TeacherOff)
    }
}
