use std::borrow::Borrow;

use serde::{Deserialize, Serialize};

use super::TeacherMode;

#[derive(Debug, Default, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AuditTrace {
    pub feedback_visible_to_learner: bool,
    pub memory_write_enabled: bool,
    pub examiner_private_scoring: bool,
    pub answer_visible_to_learner: bool,
}

impl AuditTrace {
    pub fn for_mode(mode: TeacherMode) -> Self {
        Self {
            feedback_visible_to_learner: mode.feedback_visible_to_learner(),
            memory_write_enabled: mode.memory_write_enabled(),
            examiner_private_scoring: true,
            answer_visible_to_learner: mode.answer_visible_to_learner(),
        }
    }

    pub fn teacher_on() -> Self {
        Self::for_mode(TeacherMode::TeacherOn)
    }

    pub fn feedback_only() -> Self {
        Self::for_mode(TeacherMode::FeedbackOnly)
    }

    pub fn fade() -> Self {
        Self::for_mode(TeacherMode::Fade)
    }

    pub fn no_answer_feedback() -> Self {
        Self::for_mode(TeacherMode::NoAnswerFeedback)
    }

    pub fn teacher_off() -> Self {
        Self::for_mode(TeacherMode::TeacherOff)
    }
}

#[derive(Debug, Default, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct TaintAuditSummary {
    pub visible_payload_has_hidden_truth: bool,
    pub package_has_hidden_truth: bool,
    pub solver_visible_to_learner: bool,
    pub teacher_off_feedback_visible: bool,
    pub teacher_off_memory_write: bool,
    pub examiner_private_scoring_only: bool,
}

impl TaintAuditSummary {
    pub fn clean_teacher_off() -> Self {
        Self {
            visible_payload_has_hidden_truth: false,
            package_has_hidden_truth: false,
            solver_visible_to_learner: false,
            teacher_off_feedback_visible: false,
            teacher_off_memory_write: false,
            examiner_private_scoring_only: true,
        }
    }

    pub fn from_teacher_off_traces<T>(traces: impl IntoIterator<Item = T>) -> Self
    where
        T: Borrow<AuditTrace>,
    {
        let mut summary = Self::clean_teacher_off();
        let mut saw_teacher_off = false;

        for trace in traces {
            let trace = trace.borrow();
            saw_teacher_off = true;
            summary.teacher_off_feedback_visible |= trace.feedback_visible_to_learner;
            summary.teacher_off_memory_write |= trace.memory_write_enabled;
            summary.visible_payload_has_hidden_truth |= trace.answer_visible_to_learner;
            summary.examiner_private_scoring_only &= trace.examiner_private_scoring;
        }

        if !saw_teacher_off {
            summary.examiner_private_scoring_only = false;
        }
        summary
    }

    pub fn passed(&self) -> bool {
        self.has_no_taint() && self.has_valid_private_scoring()
    }

    fn has_no_taint(&self) -> bool {
        ![
            self.visible_payload_has_hidden_truth,
            self.package_has_hidden_truth,
            self.solver_visible_to_learner,
            self.teacher_off_feedback_visible,
            self.teacher_off_memory_write,
        ]
        .into_iter()
        .any(|flag| flag)
    }

    fn has_valid_private_scoring(&self) -> bool {
        self.examiner_private_scoring_only
    }
}
