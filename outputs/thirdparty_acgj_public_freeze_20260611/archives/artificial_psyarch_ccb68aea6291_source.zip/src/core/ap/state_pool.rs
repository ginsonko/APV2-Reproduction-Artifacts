use std::collections::HashMap;

use super::state_atom::{AtomKind, StateAtom};

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct StatePoolMaintenanceConfig {
    pub real_decay: f32,
    pub virtual_decay: f32,
    pub attention_decay: f32,
    pub fatigue_decay: f32,
    pub fatigue_increment: f32,
    pub prune_below_energy: f32,
    pub maintenance_budget: usize,
}

impl Default for StatePoolMaintenanceConfig {
    fn default() -> Self {
        Self {
            real_decay: 0.70,
            virtual_decay: 0.82,
            attention_decay: 0.75,
            fatigue_decay: 0.60,
            fatigue_increment: 0.08,
            prune_below_energy: 0.02,
            maintenance_budget: 256,
        }
    }
}

#[derive(Debug, Default, Clone)]
pub struct DualEnergyStatePool {
    atoms: HashMap<String, StateAtom>,
    tick: u64,
    maintenance: StatePoolMaintenanceConfig,
}

impl DualEnergyStatePool {
    pub fn new(maintenance: StatePoolMaintenanceConfig) -> Self {
        Self {
            maintenance,
            ..Self::default()
        }
    }

    pub fn upsert(&mut self, atom: StateAtom) {
        let key = atom.key.clone();
        self.atoms
            .entry(key)
            .and_modify(|existing| merge_atom(existing, &atom, self.tick, self.maintenance))
            .or_insert_with(|| touched_atom(atom, self.tick));
    }

    pub fn observe(&mut self, key: impl Into<String>) {
        self.upsert(StateAtom::new(key, AtomKind::Observation));
    }

    pub fn mark_action(&mut self, key: impl Into<String>) {
        self.upsert(StateAtom::new(key, AtomKind::Action));
    }

    pub fn mark_feedback(&mut self, key: impl Into<String>) {
        self.upsert(StateAtom::new(key, AtomKind::Feedback));
    }

    pub fn predict(&mut self, key: impl Into<String>, strength: f32) {
        self.upsert(StateAtom::new(key, AtomKind::Feeling).predicted(strength));
    }

    pub fn control_attention(&mut self, target_key: impl Into<String>, gain: f32) {
        let mut atom = StateAtom::new(target_key, AtomKind::Control);
        atom.real_energy = 0.0;
        atom.virtual_energy = 0.0;
        self.upsert(atom.with_attention_gain(gain.clamp(0.0, 1.0)));
    }

    pub fn get(&self, key: &str) -> Option<&StateAtom> {
        self.atoms.get(key)
    }

    pub fn atoms(&self) -> impl Iterator<Item = &StateAtom> {
        self.atoms.values()
    }

    pub fn tick_index(&self) -> u64 {
        self.tick
    }

    pub fn begin_tick(&mut self) {
        self.tick += 1;
        decay_atoms(&mut self.atoms, self.maintenance);
        prune_atoms(&mut self.atoms, self.maintenance);
    }

    pub fn clear_tick(&mut self) {
        self.atoms.clear();
    }
}

fn touched_atom(mut atom: StateAtom, tick: u64) -> StateAtom {
    atom.last_touched_tick = tick;
    atom.cognitive_pressure = cognitive_pressure(atom.real_energy, atom.virtual_energy);
    atom
}

fn merge_atom(
    existing: &mut StateAtom,
    incoming: &StateAtom,
    tick: u64,
    maintenance: StatePoolMaintenanceConfig,
) {
    existing.kind = incoming.kind.clone();
    existing.real_energy = (existing.real_energy + incoming.real_energy).min(1.0);
    existing.virtual_energy = (existing.virtual_energy + incoming.virtual_energy).min(1.0);
    existing.attention_gain = (existing.attention_gain + incoming.attention_gain).min(1.0);
    existing.fatigue = (existing.fatigue + maintenance.fatigue_increment).min(1.0);
    existing.last_touched_tick = tick;
    existing.cognitive_pressure = cognitive_pressure(existing.real_energy, existing.virtual_energy);
}

fn decay_atoms(atoms: &mut HashMap<String, StateAtom>, maintenance: StatePoolMaintenanceConfig) {
    for atom in atoms.values_mut().take(maintenance.maintenance_budget) {
        atom.real_energy *= maintenance.real_decay;
        atom.virtual_energy *= maintenance.virtual_decay;
        atom.attention_gain *= maintenance.attention_decay;
        atom.fatigue *= maintenance.fatigue_decay;
        atom.cognitive_pressure = cognitive_pressure(atom.real_energy, atom.virtual_energy);
    }
}

fn prune_atoms(atoms: &mut HashMap<String, StateAtom>, maintenance: StatePoolMaintenanceConfig) {
    atoms.retain(|_, atom| {
        atom.real_energy
            .max(atom.virtual_energy)
            .max(atom.attention_gain)
            >= maintenance.prune_below_energy
    });
}

fn cognitive_pressure(real_energy: f32, virtual_energy: f32) -> f32 {
    (real_energy - virtual_energy).abs()
}
