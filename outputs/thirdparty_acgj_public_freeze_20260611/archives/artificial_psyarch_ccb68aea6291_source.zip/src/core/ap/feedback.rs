use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Feedback {
    Reward,
    Punishment,
}

impl Feedback {
    pub fn score(self) -> i32 {
        match self {
            Self::Reward => 1,
            Self::Punishment => -1,
        }
    }
}
