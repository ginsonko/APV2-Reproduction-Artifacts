use serde::{Deserialize, Serialize};

use super::Feedback;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct MemoryEvent<A> {
    pub context: String,
    pub state_id: String,
    pub action: A,
    pub feedback: Feedback,
}

#[derive(Debug, Clone)]
pub struct MemoryStore<A> {
    events: Vec<MemoryEvent<A>>,
}

impl<A> Default for MemoryStore<A> {
    fn default() -> Self {
        Self { events: Vec::new() }
    }
}

impl<A> MemoryStore<A>
where
    A: Copy + Eq,
{
    pub fn write(&mut self, event: MemoryEvent<A>) {
        self.events.push(event);
    }

    pub fn events(&self) -> &[MemoryEvent<A>] {
        &self.events
    }

    pub fn score_action(&self, context: &str, state_id: &str, action: A) -> i32 {
        self.events
            .iter()
            .filter(|event| {
                event.context == context && event.state_id == state_id && event.action == action
            })
            .map(|event| event.feedback.score())
            .sum()
    }

    pub fn best_action(&self, context: &str, state_id: &str, actions: &[A]) -> A {
        self.best_action_first_tie(context, state_id, actions)
    }

    pub fn best_action_first_tie(&self, context: &str, state_id: &str, actions: &[A]) -> A {
        let mut iter = actions.iter().copied();
        let mut best = iter.next().expect("policy requires at least one action");
        let mut best_score = self.score_action(context, state_id, best);

        for action in iter {
            let score = self.score_action(context, state_id, action);
            if score > best_score {
                best = action;
                best_score = score;
            }
        }

        best
    }
}
