use std::collections::HashMap;

use serde::{Deserialize, Serialize};

use crate::core::ap::{AtomKind, DualEnergyStatePool, StateAtom};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExperienceFrame {
    pub state_keys: Vec<String>,
    pub successor_keys: Vec<String>,
}

impl ExperienceFrame {
    pub fn new(
        state_keys: impl IntoIterator<Item = impl Into<String>>,
        successor_keys: impl IntoIterator<Item = impl Into<String>>,
    ) -> Self {
        Self {
            state_keys: state_keys.into_iter().map(Into::into).collect(),
            successor_keys: successor_keys.into_iter().map(Into::into).collect(),
        }
    }
}

#[derive(Debug, Default, Clone)]
pub struct SuccessorMemory {
    frames: Vec<ExperienceFrame>,
}

impl SuccessorMemory {
    pub fn write(&mut self, frame: ExperienceFrame) {
        self.frames.push(frame);
    }

    pub fn frames(&self) -> &[ExperienceFrame] {
        &self.frames
    }

    pub fn recall_bn(&self, current_keys: &[String], limit: usize) -> Vec<BnRecall> {
        self.recall_bn_with_required_keys(current_keys, &[], limit)
    }

    pub fn recall_bn_with_required_keys(
        &self,
        current_keys: &[String],
        required_keys: &[String],
        limit: usize,
    ) -> Vec<BnRecall> {
        let mut recalls: Vec<_> = self
            .frames
            .iter()
            .enumerate()
            .filter(|(_, frame)| {
                required_keys
                    .iter()
                    .all(|required| frame.state_keys.contains(required))
            })
            .filter_map(|(frame_index, frame)| {
                let overlap = frame
                    .state_keys
                    .iter()
                    .filter(|key| current_keys.contains(key))
                    .count();
                (overlap > 0).then_some(BnRecall {
                    frame_index,
                    matched_keys: overlap,
                    score: overlap as f32 / current_keys.len().max(1) as f32,
                })
            })
            .collect();

        recalls.sort_by(|left, right| {
            right
                .score
                .total_cmp(&left.score)
                .then(left.frame_index.cmp(&right.frame_index))
        });
        recalls.truncate(limit);
        recalls
    }

    pub fn predict_cstar(
        &self,
        current_keys: &[String],
        config: PredictionConfig,
    ) -> PredictionPackage {
        self.predict_cstar_with_required_keys(current_keys, &[], config)
    }

    pub fn predict_cstar_with_required_keys(
        &self,
        current_keys: &[String],
        required_keys: &[String],
        config: PredictionConfig,
    ) -> PredictionPackage {
        let recalls =
            self.recall_bn_with_required_keys(current_keys, required_keys, config.bn_limit);
        let mut candidate_energy = HashMap::<String, f32>::new();

        for recall in &recalls {
            let Some(frame) = self.frames.get(recall.frame_index) else {
                continue;
            };
            for successor in &frame.successor_keys {
                *candidate_energy.entry(successor.clone()).or_default() += recall.score;
            }
        }

        let mut candidates: Vec<_> = candidate_energy
            .into_iter()
            .map(|(key, energy)| CnCandidate { key, energy })
            .collect();
        candidates.sort_by(|left, right| {
            right
                .energy
                .total_cmp(&left.energy)
                .then(left.key.cmp(&right.key))
        });
        candidates.truncate(config.cstar_budget);

        PredictionPackage {
            recalls,
            candidates,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct PredictionConfig {
    pub bn_limit: usize,
    pub cstar_budget: usize,
}

impl Default for PredictionConfig {
    fn default() -> Self {
        Self {
            bn_limit: 8,
            cstar_budget: 4,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct BnRecall {
    pub frame_index: usize,
    pub matched_keys: usize,
    pub score: f32,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct CnCandidate {
    pub key: String,
    pub energy: f32,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct PredictionPackage {
    pub recalls: Vec<BnRecall>,
    pub candidates: Vec<CnCandidate>,
}

impl PredictionPackage {
    pub fn strongest(&self) -> Option<&CnCandidate> {
        self.candidates.first()
    }

    pub fn energy_for(&self, key: &str) -> f32 {
        self.candidates
            .iter()
            .find(|candidate| candidate.key == key)
            .map(|candidate| candidate.energy)
            .unwrap_or(0.0)
    }

    pub fn inject_virtual_energy(&self, pool: &mut DualEnergyStatePool) {
        for candidate in &self.candidates {
            pool.upsert(
                StateAtom::new(candidate.key.clone(), AtomKind::Feeling)
                    .predicted(candidate.energy),
            );
        }
    }
}

#[repr(usize)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum CognitiveFeelingKind {
    Grasp,
    Mismatch,
    Uncertainty,
    EvidenceGap,
    Closure,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct CognitiveFeeling {
    pub kind: CognitiveFeelingKind,
    pub strength: f32,
    pub reason: String,
}

pub struct CognitiveFeelingFactory;

impl CognitiveFeelingFactory {
    pub fn from_prediction(
        package: &PredictionPackage,
        actual_key: Option<&str>,
    ) -> CognitiveFeeling {
        let Some(strongest) = package.strongest() else {
            return CognitiveFeeling {
                kind: CognitiveFeelingKind::EvidenceGap,
                strength: 1.0,
                reason: "no_successor_prediction".to_owned(),
            };
        };

        match actual_key {
            Some(actual) if actual == strongest.key => CognitiveFeeling {
                kind: CognitiveFeelingKind::Grasp,
                strength: strongest.energy,
                reason: format!("predicted_successor_matched::{actual}"),
            },
            Some(actual) => CognitiveFeeling {
                kind: CognitiveFeelingKind::Mismatch,
                strength: strongest.energy,
                reason: format!("predicted::{} actual::{actual}", strongest.key),
            },
            None if strongest.energy < 1.0 => CognitiveFeeling {
                kind: CognitiveFeelingKind::Uncertainty,
                strength: 1.0 - strongest.energy,
                reason: format!("weak_successor_prediction::{}", strongest.key),
            },
            None => CognitiveFeeling {
                kind: CognitiveFeelingKind::Closure,
                strength: strongest.energy,
                reason: format!("strong_successor_prediction::{}", strongest.key),
            },
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct ActionConsequence {
    pub expected_reward: f32,
    pub expected_punishment: f32,
    pub drive: f32,
}

pub struct ActionConsequenceEvaluator;

impl ActionConsequenceEvaluator {
    pub fn evaluate(package: &PredictionPackage) -> ActionConsequence {
        let expected_reward = package.energy_for("feedback::Reward");
        let expected_punishment = package.energy_for("feedback::Punishment");
        ActionConsequence {
            expected_reward,
            expected_punishment,
            drive: expected_reward - expected_punishment,
        }
    }
}
