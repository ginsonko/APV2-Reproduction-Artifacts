use serde::{Deserialize, Serialize};

use super::feeling::RuntimeFeelingTrace;
use super::planner::ActionEstimate;

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct RuntimeModulationConfig {
    pub pressure_attention_gain: f32,
    pub fulfillment_attention_gain: f32,
    pub dopamine_drive_gain: f32,
    pub noradrenaline_penalty_gain: f32,
    pub serotonin_stability_gain: f32,
}

impl Default for RuntimeModulationConfig {
    fn default() -> Self {
        Self {
            pressure_attention_gain: 0.45,
            fulfillment_attention_gain: 0.20,
            dopamine_drive_gain: 0.35,
            noradrenaline_penalty_gain: 0.30,
            serotonin_stability_gain: 0.15,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct RuntimeModulationTrace {
    pub valence: f32,
    pub arousal: f32,
    pub dopamine_proxy: f32,
    pub noradrenaline_proxy: f32,
    pub serotonin_proxy: f32,
    pub attention_target: Option<String>,
    pub attention_gain: f32,
    pub drive_bias: f32,
}

impl RuntimeModulationTrace {
    pub fn from_feeling(
        feeling: &RuntimeFeelingTrace,
        config: RuntimeModulationConfig,
        attention_target: Option<String>,
    ) -> Self {
        let valence = component_total(&feeling.positive_components)
            - component_total(&feeling.negative_components);
        let arousal = feeling
            .channels
            .computation_pressure
            .max(feeling.expectation.pressure)
            .clamp(0.0, 1.0);
        let dopamine_proxy = feeling.task.fulfillment.clamp(0.0, 1.0);
        let noradrenaline_proxy = (feeling.expectation.expectation_gap
            + feeling.task.unfinishedness)
            .mul_add(0.5, 0.0)
            .clamp(0.0, 1.0);
        let serotonin_proxy = (feeling.channels.step_closure + feeling.expectation.satisfaction)
            .mul_add(0.5, 0.0)
            .clamp(0.0, 1.0);
        let attention_gain = attention_gain(
            arousal,
            dopamine_proxy,
            serotonin_proxy,
            config.pressure_attention_gain,
            config.fulfillment_attention_gain,
        );
        let drive_bias = drive_bias(dopamine_proxy, noradrenaline_proxy, serotonin_proxy, config);

        Self {
            valence,
            arousal,
            dopamine_proxy,
            noradrenaline_proxy,
            serotonin_proxy,
            attention_target,
            attention_gain,
            drive_bias,
        }
    }
}

pub fn apply_modulation_to_estimates(
    estimates: &mut [ActionEstimate],
    modulation: &RuntimeModulationTrace,
) {
    estimates.iter_mut().for_each(|estimate| {
        estimate.drive += modulation.drive_bias - estimate.expected_punishment * 0.05;
    });
}

pub fn choose_modulated_action(estimates: &[ActionEstimate]) -> Option<String> {
    estimates
        .iter()
        .max_by(|left, right| {
            left.drive
                .total_cmp(&right.drive)
                .then(right.action.cmp(&left.action))
        })
        .map(|estimate| estimate.action.clone())
}

fn attention_gain(
    arousal: f32,
    dopamine_proxy: f32,
    serotonin_proxy: f32,
    pressure_gain: f32,
    fulfillment_gain: f32,
) -> f32 {
    (arousal * pressure_gain
        + dopamine_proxy * fulfillment_gain
        + serotonin_proxy * fulfillment_gain * 0.5)
        .clamp(0.0, 1.0)
}

fn drive_bias(
    dopamine_proxy: f32,
    noradrenaline_proxy: f32,
    serotonin_proxy: f32,
    config: RuntimeModulationConfig,
) -> f32 {
    dopamine_proxy * config.dopamine_drive_gain
        - noradrenaline_proxy * config.noradrenaline_penalty_gain
        + serotonin_proxy * config.serotonin_stability_gain
}

fn component_total(components: &[super::feeling::FeelingComponentTrace]) -> f32 {
    components
        .iter()
        .map(|component| component.strength)
        .sum::<f32>()
        .clamp(0.0, 1.0)
}
