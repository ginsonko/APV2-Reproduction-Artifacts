use std::collections::HashMap;

use crate::core::prediction::ExperienceFrame;

use super::scoring::RuntimeRecall;

const VIRTUAL_ENERGY_BUDGET: f32 = 1.0;

pub fn build_cstar_candidates(
    recalls: &[RuntimeRecall],
    frames: &[ExperienceFrame],
    budget: usize,
) -> Vec<RuntimeCstarCandidate> {
    let mut energy = HashMap::<String, f32>::new();
    for recall in recalls {
        let Some(frame) = frames.get(recall.bn.frame_index) else {
            continue;
        };
        let successor_share = recall.normalized_weight / frame.successor_keys.len().max(1) as f32;
        for successor in &frame.successor_keys {
            *energy.entry(successor.clone()).or_default() += successor_share;
        }
    }

    let mut candidates = energy
        .into_iter()
        .map(|(key, payload_share)| RuntimeCstarCandidate {
            key,
            payload_share,
            virtual_energy: payload_share * VIRTUAL_ENERGY_BUDGET,
        })
        .collect::<Vec<_>>();
    candidates.sort_by(|left, right| {
        right
            .virtual_energy
            .total_cmp(&left.virtual_energy)
            .then(left.key.cmp(&right.key))
    });
    candidates.truncate(budget);
    candidates
}

#[derive(Debug, Clone, PartialEq)]
pub struct RuntimeCstarCandidate {
    pub key: String,
    pub payload_share: f32,
    pub virtual_energy: f32,
}
