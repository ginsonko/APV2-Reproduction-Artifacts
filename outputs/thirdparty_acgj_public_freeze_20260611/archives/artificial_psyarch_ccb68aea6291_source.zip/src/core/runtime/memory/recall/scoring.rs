use std::collections::HashSet;

use crate::core::prediction::{BnRecall, ExperienceFrame};

use super::candidate::{CandidateSource, RecallCandidate};
use crate::core::runtime::memory::MemorySnapshot;

const TEMPORAL_HALF_LIFE_TICKS: f32 = 24.0;
const TEMPORAL_FLOOR: f32 = 0.20;
const RECENT_BOOST_TICKS: u64 = 3;
const RECENT_BOOST: f32 = 1.15;

pub fn score_recalls(
    query_keys: &[String],
    frames: &[ExperienceFrame],
    snapshots: &[MemorySnapshot],
    candidates: Vec<RecallCandidate>,
    current_tick: u64,
) -> Vec<RuntimeRecall> {
    let query = query_keys.iter().cloned().collect::<HashSet<_>>();
    candidates
        .into_iter()
        .filter_map(|candidate| score_recall(&query, frames, snapshots, candidate, current_tick))
        .collect()
}

pub fn limit_recalls(mut recalls: Vec<RuntimeRecall>, limit: usize) -> Vec<RuntimeRecall> {
    recalls.sort_by(|left, right| {
        right
            .bn
            .score
            .total_cmp(&left.bn.score)
            .then(left.bn.frame_index.cmp(&right.bn.frame_index))
    });
    recalls.truncate(limit);
    let total = recalls.iter().map(|recall| recall.bn.score).sum::<f32>();
    if total > 0.0 {
        for recall in &mut recalls {
            recall.normalized_weight = recall.bn.score / total;
        }
    }
    recalls
}

fn score_recall(
    query: &HashSet<String>,
    frames: &[ExperienceFrame],
    snapshots: &[MemorySnapshot],
    candidate: RecallCandidate,
    current_tick: u64,
) -> Option<RuntimeRecall> {
    let frame = frames.get(candidate.frame_index)?;
    let matched_keys = frame
        .state_keys
        .iter()
        .filter(|key| query.contains(*key))
        .count();
    let overlap_score = matched_keys as f32 / query.len().max(1) as f32;
    let temporal_factor = temporal_factor(snapshots.get(candidate.frame_index), current_tick);
    let raw_score = (overlap_score + candidate.source_score).max(0.0);
    let score = raw_score * temporal_factor;
    (score > 0.0).then_some(RuntimeRecall {
        bn: BnRecall {
            frame_index: candidate.frame_index,
            matched_keys,
            score,
        },
        sources: candidate.sources,
        source_score: candidate.source_score,
        temporal_factor,
        raw_score,
        normalized_weight: 0.0,
    })
}

fn temporal_factor(snapshot: Option<&MemorySnapshot>, current_tick: u64) -> f32 {
    let Some(snapshot) = snapshot else {
        return 1.0;
    };
    let age = current_tick.saturating_sub(snapshot.tick);
    let decay = 0.5_f32.powf(age as f32 / TEMPORAL_HALF_LIFE_TICKS);
    let recent_boost = if age <= RECENT_BOOST_TICKS {
        RECENT_BOOST
    } else {
        1.0
    };
    (decay * recent_boost).clamp(TEMPORAL_FLOOR, 1.0)
}

#[derive(Debug, Clone, PartialEq)]
pub struct RuntimeRecall {
    pub bn: BnRecall,
    pub sources: Vec<CandidateSource>,
    pub source_score: f32,
    pub temporal_factor: f32,
    pub raw_score: f32,
    pub normalized_weight: f32,
}
