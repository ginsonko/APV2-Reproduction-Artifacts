use serde::{Deserialize, Serialize};

use crate::core::prediction::PredictionPackage;

use super::recall::{RuntimeCstarCandidate, RuntimeRecall};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct RuntimePredictionTrace {
    pub query_keys: Vec<String>,
    pub required_keys: Vec<String>,
    pub bn_trace: BnTrace,
    pub cstar_trace: CstarTrace,
    pub package: PredictionPackage,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct BnTrace {
    pub recall_count: usize,
    pub total_score: f32,
    pub recalls: Vec<BnRecallTrace>,
}

impl BnTrace {
    pub fn from_runtime_recalls(recalls: &[RuntimeRecall]) -> Self {
        Self {
            recall_count: recalls.len(),
            total_score: recalls.iter().map(|recall| recall.bn.score).sum(),
            recalls: recalls.iter().map(BnRecallTrace::from_runtime).collect(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct BnRecallTrace {
    pub frame_index: usize,
    pub matched_keys: usize,
    pub score: f32,
    pub normalized_weight: f32,
    pub match_efficiency: f32,
    pub candidate_sources: Vec<String>,
    pub source_score: f32,
    pub temporal_factor: f32,
    pub raw_score: f32,
}

impl BnRecallTrace {
    fn from_runtime(recall: &RuntimeRecall) -> Self {
        Self {
            frame_index: recall.bn.frame_index,
            matched_keys: recall.bn.matched_keys,
            score: recall.bn.score,
            normalized_weight: recall.normalized_weight,
            match_efficiency: recall.bn.score.clamp(0.0, 1.0),
            candidate_sources: recall
                .sources
                .iter()
                .map(|source| source.as_str().to_owned())
                .collect(),
            source_score: recall.source_score,
            temporal_factor: recall.temporal_factor,
            raw_score: recall.raw_score,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct CstarTrace {
    pub candidate_count: usize,
    pub strongest_key: Option<String>,
    pub energy_budget_semantics: String,
    pub source_mass: f32,
    pub retained_payload_share: f32,
    pub candidates: Vec<CstarCandidateTrace>,
}

impl CstarTrace {
    pub fn from_runtime_candidates(
        recalls: &[RuntimeRecall],
        candidates: &[RuntimeCstarCandidate],
    ) -> Self {
        Self {
            candidate_count: candidates.len(),
            strongest_key: candidates.first().map(|candidate| candidate.key.clone()),
            energy_budget_semantics:
                "fixed_virtual_energy_budget_normalized_by_bn_and_successor_payload".to_owned(),
            source_mass: recalls.iter().map(|recall| recall.bn.score).sum(),
            retained_payload_share: candidates
                .iter()
                .map(|candidate| candidate.payload_share)
                .sum(),
            candidates: candidates
                .iter()
                .map(CstarCandidateTrace::from_runtime)
                .collect(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct CstarCandidateTrace {
    pub key: String,
    pub virtual_energy: f32,
    pub payload_share: f32,
}

impl CstarCandidateTrace {
    fn from_runtime(candidate: &RuntimeCstarCandidate) -> Self {
        Self {
            key: candidate.key.clone(),
            virtual_energy: candidate.virtual_energy,
            payload_share: candidate.payload_share,
        }
    }
}
