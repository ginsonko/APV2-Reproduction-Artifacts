mod candidate;
mod cstar;
mod scoring;

use crate::core::prediction::{CnCandidate, ExperienceFrame, PredictionConfig};

use super::MemorySnapshot;
use super::trace::{BnTrace, CstarTrace, RuntimePredictionTrace};
pub use candidate::{CandidateSource, FrameIndexes, RecallCandidate, build_recall_candidates};
pub use cstar::RuntimeCstarCandidate;
use cstar::build_cstar_candidates;
pub use scoring::RuntimeRecall;
use scoring::{limit_recalls, score_recalls};

pub fn build_runtime_prediction(
    query_keys: &[String],
    required_keys: &[String],
    frames: &[ExperienceFrame],
    snapshots: &[MemorySnapshot],
    candidates: Vec<RecallCandidate>,
    config: PredictionConfig,
    current_tick: u64,
) -> RuntimePredictionTrace {
    let recalls = score_recalls(query_keys, frames, snapshots, candidates, current_tick);
    let recalls = limit_recalls(recalls, config.bn_limit);
    let cstar = build_cstar_candidates(&recalls, frames, config.cstar_budget);
    let package = crate::core::prediction::PredictionPackage {
        recalls: recalls.iter().map(|recall| recall.bn.clone()).collect(),
        candidates: cstar
            .iter()
            .map(|candidate| CnCandidate {
                key: candidate.key.clone(),
                energy: candidate.virtual_energy,
            })
            .collect(),
    };

    RuntimePredictionTrace {
        query_keys: query_keys.to_vec(),
        required_keys: required_keys.to_vec(),
        bn_trace: BnTrace::from_runtime_recalls(&recalls),
        cstar_trace: CstarTrace::from_runtime_candidates(&recalls, &cstar),
        package,
    }
}
