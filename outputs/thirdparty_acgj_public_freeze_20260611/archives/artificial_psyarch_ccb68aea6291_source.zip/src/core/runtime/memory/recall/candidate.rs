use std::collections::{HashMap, HashSet, VecDeque};

use serde::{Deserialize, Serialize};

use crate::core::runtime::memory::{numeric_feature_buckets, relation_features, sequence_bigrams};

const EXACT_SOURCE_WEIGHT: f32 = 1.0;
const SEQUENCE_SOURCE_WEIGHT: f32 = 0.65;
const NUMERIC_SOURCE_WEIGHT: f32 = 0.55;
const RELATION_SOURCE_WEIGHT: f32 = 0.40;
const RECENT_SOURCE_WEIGHT: f32 = 0.18;

#[repr(usize)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum CandidateSource {
    ExactKey,
    SequenceBigram,
    NumericFeature,
    RelationFeature,
    RecentFallback,
}

impl CandidateSource {
    pub fn as_str(self) -> &'static str {
        SOURCE_LABELS[self as usize]
    }
}

const SOURCE_LABELS: [&str; 5] = [
    "exact_key",
    "sequence_bigram",
    "numeric_feature",
    "relation_feature",
    "recent_fallback",
];

const SOURCE_WEIGHTS: [f32; 5] = [
    EXACT_SOURCE_WEIGHT,
    SEQUENCE_SOURCE_WEIGHT,
    NUMERIC_SOURCE_WEIGHT,
    RELATION_SOURCE_WEIGHT,
    RECENT_SOURCE_WEIGHT,
];

#[derive(Debug, Clone, PartialEq)]
pub struct RecallCandidate {
    pub frame_index: usize,
    pub sources: Vec<CandidateSource>,
    pub source_score: f32,
}

pub struct FrameIndexes<'a> {
    pub key_index: &'a HashMap<String, Vec<usize>>,
    pub sequence_index: &'a HashMap<String, Vec<usize>>,
    pub numeric_index: &'a HashMap<String, Vec<usize>>,
    pub relation_index: &'a HashMap<String, Vec<usize>>,
    pub recent_frames: &'a VecDeque<usize>,
}

pub fn build_recall_candidates(
    current_keys: &[String],
    required_keys: &[String],
    indexes: FrameIndexes<'_>,
) -> Vec<RecallCandidate> {
    let mut candidates = HashMap::<usize, RecallCandidate>::new();
    add_exact_candidates(&mut candidates, current_keys, indexes.key_index);
    add_sequence_candidates(&mut candidates, current_keys, indexes.sequence_index);
    add_numeric_candidates(&mut candidates, current_keys, indexes.numeric_index);
    add_relation_candidates(&mut candidates, current_keys, indexes.relation_index);
    add_recent_candidates(&mut candidates, indexes.recent_frames);

    let required = required_keys.iter().cloned().collect::<HashSet<_>>();
    let mut candidates = candidates.into_values().collect::<Vec<_>>();
    if !required.is_empty() {
        let allowed = required_frame_indexes(required_keys, indexes.key_index);
        candidates.retain(|candidate| allowed.contains(&candidate.frame_index));
    }
    candidates.sort_by(|left, right| {
        right
            .source_score
            .total_cmp(&left.source_score)
            .then(left.frame_index.cmp(&right.frame_index))
    });
    candidates
}

fn add_exact_candidates(
    candidates: &mut HashMap<usize, RecallCandidate>,
    current_keys: &[String],
    key_index: &HashMap<String, Vec<usize>>,
) {
    for key in current_keys {
        add_candidates_from_index(candidates, key_index.get(key), CandidateSource::ExactKey);
    }
}

fn add_sequence_candidates(
    candidates: &mut HashMap<usize, RecallCandidate>,
    current_keys: &[String],
    sequence_index: &HashMap<String, Vec<usize>>,
) {
    for bigram in sequence_bigrams(current_keys) {
        add_candidates_from_index(
            candidates,
            sequence_index.get(&bigram),
            CandidateSource::SequenceBigram,
        );
    }
}

fn add_relation_candidates(
    candidates: &mut HashMap<usize, RecallCandidate>,
    current_keys: &[String],
    relation_index: &HashMap<String, Vec<usize>>,
) {
    for relation in relation_features(current_keys) {
        add_candidates_from_index(
            candidates,
            relation_index.get(&relation),
            CandidateSource::RelationFeature,
        );
    }
}

fn add_numeric_candidates(
    candidates: &mut HashMap<usize, RecallCandidate>,
    current_keys: &[String],
    numeric_index: &HashMap<String, Vec<usize>>,
) {
    for bucket in numeric_feature_buckets(current_keys) {
        add_candidates_from_index(
            candidates,
            numeric_index.get(&bucket),
            CandidateSource::NumericFeature,
        );
    }
}

fn add_recent_candidates(
    candidates: &mut HashMap<usize, RecallCandidate>,
    recent_frames: &VecDeque<usize>,
) {
    for frame_index in recent_frames {
        add_candidate(candidates, *frame_index, CandidateSource::RecentFallback);
    }
}

fn add_candidates_from_index(
    candidates: &mut HashMap<usize, RecallCandidate>,
    indexes: Option<&Vec<usize>>,
    source: CandidateSource,
) {
    for frame_index in indexes.into_iter().flatten() {
        add_candidate(candidates, *frame_index, source);
    }
}

fn add_candidate(
    candidates: &mut HashMap<usize, RecallCandidate>,
    frame_index: usize,
    source: CandidateSource,
) {
    let entry = candidates.entry(frame_index).or_insert(RecallCandidate {
        frame_index,
        sources: Vec::new(),
        source_score: 0.0,
    });
    if !entry.sources.contains(&source) {
        entry.sources.push(source);
        entry.source_score += source_weight(source);
    }
}

fn required_frame_indexes(
    required_keys: &[String],
    key_index: &HashMap<String, Vec<usize>>,
) -> HashSet<usize> {
    let mut iter = required_keys.iter().filter_map(|key| key_index.get(key));
    let Some(first) = iter.next() else {
        return HashSet::new();
    };
    let mut allowed = first.iter().copied().collect::<HashSet<_>>();
    for indexes in iter {
        let current = indexes.iter().copied().collect::<HashSet<_>>();
        allowed.retain(|frame_index| current.contains(frame_index));
    }
    allowed
}

fn source_weight(source: CandidateSource) -> f32 {
    SOURCE_WEIGHTS[source as usize]
}
