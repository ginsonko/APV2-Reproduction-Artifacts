mod recall;
mod trace;

use std::collections::{HashMap, VecDeque};

use serde::{Deserialize, Serialize};

use crate::core::ap::Feedback;
use crate::core::prediction::{ExperienceFrame, PredictionConfig};

use super::types::{ActionFeedback, RuntimeObservation};
pub use recall::{CandidateSource, RecallCandidate};
use recall::{FrameIndexes, build_recall_candidates, build_runtime_prediction};
pub use trace::{BnRecallTrace, BnTrace, CstarCandidateTrace, CstarTrace, RuntimePredictionTrace};

const RECENT_FALLBACK_LIMIT: usize = 4;

#[derive(Debug, Default, Clone)]
pub struct RuntimeMemoryStore {
    frames: Vec<ExperienceFrame>,
    snapshots: Vec<MemorySnapshot>,
    key_index: HashMap<String, Vec<usize>>,
    sequence_index: HashMap<String, Vec<usize>>,
    numeric_index: HashMap<String, Vec<usize>>,
    relation_index: HashMap<String, Vec<usize>>,
    recent_frames: VecDeque<usize>,
}

impl RuntimeMemoryStore {
    pub fn frames(&self) -> &[ExperienceFrame] {
        &self.frames
    }

    pub fn snapshots(&self) -> &[MemorySnapshot] {
        &self.snapshots
    }

    pub fn predict_cstar(
        &self,
        current_keys: &[String],
        config: PredictionConfig,
    ) -> RuntimePredictionTrace {
        self.predict_cstar_at_tick(current_keys, &[], config, self.current_tick())
    }

    pub fn predict_cstar_with_required_keys(
        &self,
        current_keys: &[String],
        required_keys: &[String],
        config: PredictionConfig,
    ) -> RuntimePredictionTrace {
        self.predict_cstar_at_tick(current_keys, required_keys, config, self.current_tick())
    }

    pub fn predict_cstar_at_tick(
        &self,
        current_keys: &[String],
        required_keys: &[String],
        config: PredictionConfig,
        current_tick: u64,
    ) -> RuntimePredictionTrace {
        let indexes = FrameIndexes {
            key_index: &self.key_index,
            sequence_index: &self.sequence_index,
            numeric_index: &self.numeric_index,
            relation_index: &self.relation_index,
            recent_frames: &self.recent_frames,
        };
        let candidates = build_recall_candidates(current_keys, required_keys, indexes);
        build_runtime_prediction(
            current_keys,
            required_keys,
            &self.frames,
            &self.snapshots,
            candidates,
            config,
            current_tick,
        )
    }

    pub fn write_feedback_snapshot(&mut self, input: FeedbackSnapshotInput<'_>) {
        let snapshot = MemorySnapshot::from_feedback_input(&input);
        let frame = ExperienceFrame::new(
            snapshot.state_field_items.clone(),
            snapshot.prediction_payload_items.clone(),
        );
        self.write_frame(snapshot, frame);
    }

    fn write_frame(&mut self, snapshot: MemorySnapshot, frame: ExperienceFrame) {
        let frame_index = self.frames.len();
        self.index_frame(frame_index, &frame);
        self.frames.push(frame);
        self.snapshots.push(snapshot);
        self.recent_frames.push_back(frame_index);
        while self.recent_frames.len() > RECENT_FALLBACK_LIMIT {
            self.recent_frames.pop_front();
        }
    }

    fn index_frame(&mut self, frame_index: usize, frame: &ExperienceFrame) {
        index_terms(
            &mut self.key_index,
            frame.state_keys.iter().cloned(),
            frame_index,
        );
        index_terms(
            &mut self.sequence_index,
            sequence_bigrams(&frame.state_keys),
            frame_index,
        );
        index_terms(
            &mut self.numeric_index,
            numeric_feature_buckets(&frame.state_keys),
            frame_index,
        );
        index_terms(
            &mut self.relation_index,
            relation_features(&frame.state_keys),
            frame_index,
        );
    }

    fn current_tick(&self) -> u64 {
        self.snapshots
            .last()
            .map(|snapshot| snapshot.tick)
            .unwrap_or(0)
    }
}

fn index_terms(
    index: &mut HashMap<String, Vec<usize>>,
    terms: impl IntoIterator<Item = String>,
    frame_index: usize,
) {
    for term in terms {
        index.entry(term).or_default().push(frame_index);
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct MemorySnapshot {
    pub tick: u64,
    pub state_field_items: Vec<String>,
    pub anchor_items: Vec<String>,
    pub prediction_payload_items: Vec<String>,
    pub action_feedback_items: Vec<String>,
    pub write_policy: String,
}

impl MemorySnapshot {
    fn from_feedback_input(input: &FeedbackSnapshotInput<'_>) -> Self {
        let mut state_field_items = input.observation.state_keys();
        state_field_items.push(format!("action::{}", input.action));
        state_field_items.sort();
        state_field_items.dedup();

        Self {
            tick: input.tick,
            state_field_items,
            anchor_items: input.observation.state_keys(),
            prediction_payload_items: vec![feedback_key(input.feedback.feedback).to_owned()],
            action_feedback_items: vec![format!(
                "action_feedback::{}::{:?}",
                input.feedback.action, input.feedback.feedback
            )],
            write_policy: "feedback_memory_snapshot/v0.2".to_owned(),
        }
    }
}

#[derive(Debug, Clone, Copy)]
pub struct FeedbackSnapshotInput<'a> {
    pub tick: u64,
    pub observation: &'a RuntimeObservation,
    pub action: &'a str,
    pub feedback: &'a ActionFeedback,
}

fn sequence_bigrams(keys: &[String]) -> impl Iterator<Item = String> + '_ {
    keys.windows(2)
        .map(|window| format!("{}=>{}", window[0], window[1]))
}

fn numeric_feature_buckets(keys: &[String]) -> Vec<String> {
    keys.iter()
        .filter_map(|key| numeric_feature_bucket(key))
        .collect()
}

fn numeric_feature_bucket(key: &str) -> Option<String> {
    let (label, value) = key.rsplit_once('=')?;
    let parsed = value.parse::<f32>().ok()?;
    let bucket = (parsed * 10.0).round() as i32;
    Some(format!("numeric::{label}::{bucket}"))
}

fn relation_features(keys: &[String]) -> Vec<String> {
    let prefixes = keys
        .iter()
        .filter_map(|key| key.split_once("::").map(|(prefix, _)| prefix.to_owned()))
        .collect::<Vec<_>>();
    prefixes
        .windows(2)
        .map(|window| format!("{}~{}", window[0], window[1]))
        .collect()
}

fn feedback_key(feedback: Feedback) -> &'static str {
    match feedback {
        Feedback::Reward => "feedback::Reward",
        Feedback::Punishment => "feedback::Punishment",
    }
}
