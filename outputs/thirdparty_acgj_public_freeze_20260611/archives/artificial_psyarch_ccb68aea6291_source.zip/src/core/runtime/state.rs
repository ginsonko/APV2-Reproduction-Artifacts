use crate::core::ap::{DualEnergyStatePool, StateAtom};

use super::types::{
    ActionFeedback, RStateHeadTrace, RStateTrace, RuntimeObservation, TeacherSignal,
};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct RStateConfig {
    pub limit: usize,
}

impl Default for RStateConfig {
    fn default() -> Self {
        Self { limit: 16 }
    }
}

pub fn apply_observation(pool: &mut DualEnergyStatePool, observation: &RuntimeObservation) {
    for key in observation.state_keys() {
        pool.observe(key);
    }
}

pub fn apply_teacher_signal(pool: &mut DualEnergyStatePool, teacher: &TeacherSignal) {
    for item in teacher.visible_state_items() {
        pool.observe(format!("teacher::{item}"));
    }
    for action in teacher_action_biases(teacher) {
        pool.control_attention(format!("action::{}", action.action), action.strength);
    }
    if let Some(feedback) = teacher.learner_feedback() {
        pool.mark_feedback(format!("teacher_feedback::{feedback:?}"));
    }
}

pub fn apply_action_feedback(pool: &mut DualEnergyStatePool, feedback: &ActionFeedback) {
    pool.mark_action(format!("action::{}", feedback.action));
    pool.mark_feedback(feedback.feedback_key());
}

pub fn read_r_state(
    pool: &DualEnergyStatePool,
    observation: &RuntimeObservation,
    config: RStateConfig,
) -> RStateTrace {
    let mut heads = Vec::new();
    let mut keys = head_from_iter("observation", observation.state_keys(), &mut heads);
    keys.extend(head_from_pool(
        "high_real",
        pool,
        config.limit,
        |atom| atom.real_energy,
        &mut heads,
    ));
    keys.extend(head_from_pool(
        "high_virtual",
        pool,
        config.limit,
        |atom| atom.virtual_energy,
        &mut heads,
    ));
    keys.extend(head_from_pool(
        "high_pressure",
        pool,
        config.limit,
        |atom| atom.cognitive_pressure,
        &mut heads,
    ));
    keys.extend(head_from_pool(
        "attention_low_fatigue",
        pool,
        config.limit,
        |atom| atom.attention_gain - atom.fatigue,
        &mut heads,
    ));
    keys.extend(head_from_iter(
        "feedback_presence",
        ["feedback::Reward", "feedback::Punishment"]
            .into_iter()
            .filter(|key| pool.get(key).is_some())
            .map(ToOwned::to_owned),
        &mut heads,
    ));

    keys.sort();
    keys.dedup();
    let candidate_count = keys.len();
    keys.truncate(config.limit);
    RStateTrace {
        selected_keys: keys,
        candidate_count,
        limit: config.limit,
        policy: "multi_head_energy_pressure_attention/v0.1".to_owned(),
        heads,
    }
}

fn head_from_iter(
    head: &str,
    keys: impl IntoIterator<Item = String>,
    heads: &mut Vec<RStateHeadTrace>,
) -> Vec<String> {
    let keys = keys.into_iter().collect::<Vec<_>>();
    heads.push(RStateHeadTrace {
        head: head.to_owned(),
        candidate_count: keys.len(),
    });
    keys
}

fn head_from_pool(
    head: &str,
    pool: &DualEnergyStatePool,
    limit: usize,
    score: impl Fn(&StateAtom) -> f32,
    heads: &mut Vec<RStateHeadTrace>,
) -> Vec<String> {
    let mut scored = pool
        .atoms()
        .map(|atom| (atom.key.clone(), score(atom)))
        .filter(|(_, score)| *score > 0.0)
        .collect::<Vec<_>>();
    scored.sort_by(|left, right| right.1.total_cmp(&left.1).then(left.0.cmp(&right.0)));
    scored.truncate(limit);
    heads.push(RStateHeadTrace {
        head: head.to_owned(),
        candidate_count: scored.len(),
    });
    scored.into_iter().map(|(key, _)| key).collect()
}

fn teacher_action_biases(teacher: &TeacherSignal) -> Vec<super::types::TeacherActionBias> {
    teacher
        .action_bias()
        .map(|action| super::types::TeacherActionBias {
            action: action.to_owned(),
            strength: 1.0,
        })
        .into_iter()
        .chain(
            teacher
                .action_biases
                .iter()
                .filter(|bias| teacher.action_bias_strength(&bias.action) > 0.0)
                .cloned(),
        )
        .collect()
}
