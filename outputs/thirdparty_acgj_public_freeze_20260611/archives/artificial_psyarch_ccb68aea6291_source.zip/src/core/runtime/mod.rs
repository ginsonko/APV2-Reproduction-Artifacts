mod anchor;
mod feeling;
mod memory;
mod modulation;
mod observatory;
mod planner;
mod state;
mod types;
mod validation;

pub use memory::{
    BnRecallTrace, BnTrace, CandidateSource, CstarCandidateTrace, CstarTrace, MemorySnapshot,
    RecallCandidate, RuntimeMemoryStore, RuntimePredictionTrace,
};
pub use modulation::{RuntimeModulationConfig, RuntimeModulationTrace};
pub use observatory::{RuntimeTraceEntry, RuntimeTraceLog};
pub use planner::ActionEstimate;
use state::{
    RStateConfig, apply_action_feedback, apply_observation, apply_teacher_signal, read_r_state,
};
pub use types::{
    ActionFeedback, RuntimeObservation, RuntimeTickInput, RuntimeTickTrace, TeacherActionBias,
    TeacherSignal,
};
pub use validation::PredictionValidationTrace;

use crate::core::ap::{AuditTrace, DualEnergyStatePool};
use crate::core::prediction::{CognitiveFeelingFactory, PredictionConfig};

#[derive(Debug, Default, Clone, PartialEq)]
pub struct RuntimeConfig {
    pub r_state: RStateConfig,
    pub prediction: PredictionConfig,
    pub modulation: RuntimeModulationConfig,
}

#[derive(Debug, Default, Clone)]
pub struct APV21Runtime {
    tick: u64,
    pool: DualEnergyStatePool,
    memory: RuntimeMemoryStore,
    trace_log: RuntimeTraceLog,
    config: RuntimeConfig,
}

impl APV21Runtime {
    pub fn new(config: RuntimeConfig) -> Self {
        Self {
            config,
            ..Self::default()
        }
    }

    pub fn memory(&self) -> &RuntimeMemoryStore {
        &self.memory
    }

    pub fn state_pool(&self) -> &DualEnergyStatePool {
        &self.pool
    }

    pub fn trace_log(&self) -> &RuntimeTraceLog {
        &self.trace_log
    }

    pub fn export_trace_log_json(&self) -> serde_json::Result<String> {
        self.trace_log.export_json()
    }

    pub fn tick(&mut self, input: RuntimeTickInput) -> RuntimeTickTrace {
        let trace_input = input.clone();
        self.tick += 1;
        self.pool.begin_tick();
        self.apply_tick_inputs(&input);

        let r_state = read_r_state(&self.pool, &input.observation, self.config.r_state);
        let prediction = self.memory.predict_cstar_at_tick(
            &r_state.selected_keys,
            &[],
            self.config.prediction,
            self.tick,
        );
        prediction.package.inject_virtual_energy(&mut self.pool);

        let feeling = CognitiveFeelingFactory::from_prediction(
            &prediction.package,
            input.actual_successor.as_deref(),
        );
        let prediction_validation = PredictionValidationTrace::from_prediction(
            &prediction.package,
            input.actual_successor.as_deref(),
        );
        let feeling_trace = RuntimeFeelingTrace::from_tick(
            &input,
            &r_state,
            &prediction,
            &prediction_validation,
            feeling.clone(),
        );
        let attention_target = r_state.selected_keys.first().cloned();
        let modulation_trace = RuntimeModulationTrace::from_feeling(
            &feeling_trace,
            self.config.modulation,
            attention_target.clone(),
        );
        if let Some(target) = attention_target {
            self.pool
                .control_attention(target, modulation_trace.attention_gain);
        }

        let mut action_estimates = planner::action_estimates(
            &self.memory,
            &input.observation,
            &input.actions,
            &input.teacher,
            self.config.prediction,
            self.tick,
        );
        modulation::apply_modulation_to_estimates(&mut action_estimates, &modulation_trace);
        let selected_action = modulation::choose_modulated_action(&action_estimates);
        if let Some(action) = &selected_action {
            self.pool.mark_action(format!("action::{action}"));
        }

        let anchor_trace = AnchorVerifierTrace::from_tick(&input, &prediction_validation);
        let memory_snapshot = self.write_memory_frame(&input, selected_action.as_deref());
        let teacher_audit = AuditTrace::for_mode(input.teacher.mode);

        let trace = RuntimeTickTrace {
            tick: self.tick,
            r_state,
            selected_action,
            prediction,
            prediction_validation,
            feeling,
            feeling_trace,
            modulation_trace,
            anchor_trace,
            action_estimates,
            teacher_audit,
            feedback_written: input.feedback.is_some(),
            memory_frame_written: memory_snapshot.is_some(),
            memory_snapshot,
        };
        self.trace_log.push(trace_input, trace.clone());
        trace
    }

    pub fn train_feedback(
        &mut self,
        observation: RuntimeObservation,
        action: impl Into<String>,
        feedback: crate::core::ap::Feedback,
    ) -> RuntimeTickTrace {
        let action = action.into();
        let input = RuntimeTickInput {
            observation,
            actions: vec![action.clone()],
            teacher: TeacherSignal::new(crate::core::ap::TeacherMode::FeedbackOnly)
                .with_feedback(feedback),
            feedback: Some(ActionFeedback { action, feedback }),
            actual_successor: Some(feedback_key(feedback).to_owned()),
        };
        self.tick(input)
    }

    fn apply_tick_inputs(&mut self, input: &RuntimeTickInput) {
        apply_observation(&mut self.pool, &input.observation);
        apply_teacher_signal(&mut self.pool, &input.teacher);
        if let Some(feedback) = &input.feedback {
            apply_action_feedback(&mut self.pool, feedback);
        }
    }

    fn write_memory_frame(
        &mut self,
        input: &RuntimeTickInput,
        selected_action: Option<&str>,
    ) -> Option<MemorySnapshot> {
        if !input.teacher.mode.memory_write_enabled() {
            return None;
        }
        let Some(feedback) = &input.feedback else {
            return None;
        };

        let action = selected_action.unwrap_or(&feedback.action);
        self.memory
            .write_feedback_snapshot(memory::FeedbackSnapshotInput {
                tick: self.tick,
                observation: &input.observation,
                action,
                feedback,
            });
        self.memory.snapshots().last().cloned()
    }
}

fn feedback_key(feedback: crate::core::ap::Feedback) -> &'static str {
    match feedback {
        crate::core::ap::Feedback::Reward => "feedback::Reward",
        crate::core::ap::Feedback::Punishment => "feedback::Punishment",
    }
}
pub use anchor::{AnchorVerifierStatus, AnchorVerifierTrace};
pub use feeling::{
    ExpectationPressureTrace, FeelingChannelsTrace, FeelingComponentTrace, RuntimeFeelingTrace,
    TaskFeelingTrace,
};
