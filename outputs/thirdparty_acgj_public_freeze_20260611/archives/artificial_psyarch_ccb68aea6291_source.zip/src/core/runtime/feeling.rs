use serde::{Deserialize, Serialize};

use crate::core::prediction::{CognitiveFeeling, CognitiveFeelingKind};

use super::memory::RuntimePredictionTrace;
use super::types::{RStateTrace, RuntimeTickInput};
use super::validation::PredictionValidationTrace;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct RuntimeFeelingTrace {
    pub primary: CognitiveFeeling,
    pub positive_components: Vec<FeelingComponentTrace>,
    pub negative_components: Vec<FeelingComponentTrace>,
    pub channels: FeelingChannelsTrace,
    pub expectation: ExpectationPressureTrace,
    pub task: TaskFeelingTrace,
}

impl RuntimeFeelingTrace {
    pub fn from_tick(
        input: &RuntimeTickInput,
        r_state: &RStateTrace,
        prediction: &RuntimePredictionTrace,
        validation: &PredictionValidationTrace,
        primary: CognitiveFeeling,
    ) -> Self {
        let channels = FeelingChannelsTrace::from_tick(input, r_state, prediction, validation);
        let expectation = ExpectationPressureTrace::from_prediction(prediction, validation);
        let task = TaskFeelingTrace::from_channels(input, &channels, &expectation);
        let (positive_components, negative_components) =
            feeling_components(&primary, &channels, &expectation, &task);

        Self {
            primary,
            positive_components,
            negative_components,
            channels,
            expectation,
            task,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct FeelingComponentTrace {
    pub name: String,
    pub strength: f32,
    pub reason: String,
}

impl FeelingComponentTrace {
    fn new(name: &str, strength: f32, reason: impl Into<String>) -> Self {
        Self {
            name: name.to_owned(),
            strength: strength.clamp(0.0, 1.0),
            reason: reason.into(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct FeelingChannelsTrace {
    pub computation_pressure: f32,
    pub quantity_grasp: f32,
    pub sensory_clarity: f32,
    pub step_closure: f32,
}

impl FeelingChannelsTrace {
    fn from_tick(
        input: &RuntimeTickInput,
        r_state: &RStateTrace,
        prediction: &RuntimePredictionTrace,
        validation: &PredictionValidationTrace,
    ) -> Self {
        Self {
            computation_pressure: computation_pressure(r_state, prediction, validation),
            quantity_grasp: quantity_grasp(&input.observation.items),
            sensory_clarity: sensory_clarity(&input.observation.items),
            step_closure: step_closure(input, validation),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ExpectationPressureTrace {
    pub expected: Option<String>,
    pub actual: Option<String>,
    pub pressure: f32,
    pub satisfaction: f32,
    pub expectation_gap: f32,
}

impl ExpectationPressureTrace {
    fn from_prediction(
        prediction: &RuntimePredictionTrace,
        validation: &PredictionValidationTrace,
    ) -> Self {
        let expected = prediction.cstar_trace.strongest_key.clone();
        let actual = validation.actual.clone();
        let has_expectation = expected.is_some();
        let satisfaction = validation.matched.len().min(1) as f32;
        let expectation_gap = expectation_gap(has_expectation, validation);
        Self {
            expected,
            actual,
            pressure: prediction
                .package
                .strongest()
                .map(|candidate| candidate.energy)
                .unwrap_or_default()
                .clamp(0.0, 1.0),
            satisfaction,
            expectation_gap,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TaskFeelingTrace {
    pub boredom: f32,
    pub fulfillment: f32,
    pub unfinishedness: f32,
}

impl TaskFeelingTrace {
    fn from_channels(
        input: &RuntimeTickInput,
        channels: &FeelingChannelsTrace,
        expectation: &ExpectationPressureTrace,
    ) -> Self {
        let has_task = !input.actions.is_empty();
        let fulfillment = channels.step_closure.max(expectation.satisfaction);
        Self {
            boredom: boredom(has_task, channels, expectation),
            fulfillment,
            unfinishedness: (1.0 - fulfillment).clamp(0.0, 1.0),
        }
    }
}

fn feeling_components(
    primary: &CognitiveFeeling,
    channels: &FeelingChannelsTrace,
    expectation: &ExpectationPressureTrace,
    task: &TaskFeelingTrace,
) -> (Vec<FeelingComponentTrace>, Vec<FeelingComponentTrace>) {
    let mut positive = Vec::new();
    let mut negative = Vec::new();
    push_primary_component(primary, &mut positive, &mut negative);
    push_channel_components(channels, &mut positive, &mut negative);
    push_expectation_components(expectation, &mut positive, &mut negative);
    push_task_components(task, &mut positive, &mut negative);
    (positive, negative)
}

fn push_primary_component(
    primary: &CognitiveFeeling,
    positive: &mut Vec<FeelingComponentTrace>,
    negative: &mut Vec<FeelingComponentTrace>,
) {
    let component = FeelingComponentTrace::new(
        primary_component_name(primary.kind),
        primary.strength,
        primary.reason.clone(),
    );
    if primary_is_positive(primary.kind) {
        positive.push(component);
    } else {
        negative.push(component);
    }
}

fn push_channel_components(
    channels: &FeelingChannelsTrace,
    positive: &mut Vec<FeelingComponentTrace>,
    negative: &mut Vec<FeelingComponentTrace>,
) {
    positive.push(FeelingComponentTrace::new(
        "sensory_clarity",
        channels.sensory_clarity,
        "observation_items_are_present",
    ));
    positive.push(FeelingComponentTrace::new(
        "step_closure",
        channels.step_closure,
        "feedback_or_prediction_match_closes_step",
    ));
    negative.push(FeelingComponentTrace::new(
        "computation_pressure",
        channels.computation_pressure,
        "wide_r_state_or_prediction_mismatch_increases_pressure",
    ));
}

fn push_expectation_components(
    expectation: &ExpectationPressureTrace,
    positive: &mut Vec<FeelingComponentTrace>,
    negative: &mut Vec<FeelingComponentTrace>,
) {
    positive.push(FeelingComponentTrace::new(
        "expectation_satisfaction",
        expectation.satisfaction,
        "actual_successor_matched_prediction",
    ));
    negative.push(FeelingComponentTrace::new(
        "expectation_gap",
        expectation.expectation_gap,
        "actual_successor_missing_or_unexpected",
    ));
}

fn push_task_components(
    task: &TaskFeelingTrace,
    positive: &mut Vec<FeelingComponentTrace>,
    negative: &mut Vec<FeelingComponentTrace>,
) {
    positive.push(FeelingComponentTrace::new(
        "task_fulfillment",
        task.fulfillment,
        "task_step_has_feedback_or_matched_expectation",
    ));
    negative.push(FeelingComponentTrace::new(
        "task_unfinishedness",
        task.unfinishedness,
        "task_step_remains_open",
    ));
    negative.push(FeelingComponentTrace::new(
        "task_boredom",
        task.boredom,
        "low_pressure_low_novelty_task_state",
    ));
}

fn computation_pressure(
    r_state: &RStateTrace,
    prediction: &RuntimePredictionTrace,
    validation: &PredictionValidationTrace,
) -> f32 {
    let r_state_load = r_state.candidate_count as f32 / r_state.limit.max(1) as f32;
    let prediction_gap = f32::from(prediction.package.candidates.is_empty());
    (r_state_load * 0.35 + validation.mismatch_ratio * 0.45 + prediction_gap * 0.20).clamp(0.0, 1.0)
}

fn quantity_grasp(items: &[String]) -> f32 {
    if items.iter().any(|item| item_contains_number(item)) {
        1.0
    } else {
        0.0
    }
}

fn sensory_clarity(items: &[String]) -> f32 {
    (items.len() as f32 / 4.0).clamp(0.0, 1.0)
}

fn step_closure(input: &RuntimeTickInput, validation: &PredictionValidationTrace) -> f32 {
    f32::from(input.feedback.is_some() || !validation.matched.is_empty())
}

fn expectation_gap(has_expectation: bool, validation: &PredictionValidationTrace) -> f32 {
    if !has_expectation {
        f32::from(validation.actual.is_some())
    } else {
        validation.mismatch_ratio
    }
}

fn boredom(
    has_task: bool,
    channels: &FeelingChannelsTrace,
    expectation: &ExpectationPressureTrace,
) -> f32 {
    if !has_task {
        return 0.0;
    }
    (1.0 - channels.computation_pressure)
        .min(1.0 - expectation.expectation_gap)
        .min(1.0 - channels.quantity_grasp)
        .clamp(0.0, 1.0)
}

fn item_contains_number(item: &str) -> bool {
    item.chars().any(|c| c.is_ascii_digit())
}

fn primary_component_name(kind: CognitiveFeelingKind) -> &'static str {
    PRIMARY_COMPONENT_NAMES[kind as usize]
}

fn primary_is_positive(kind: CognitiveFeelingKind) -> bool {
    PRIMARY_COMPONENT_POLARITY[kind as usize]
}

const PRIMARY_COMPONENT_NAMES: [&str; 5] = [
    "grasp",
    "mismatch",
    "uncertainty",
    "evidence_gap",
    "closure",
];

const PRIMARY_COMPONENT_POLARITY: [bool; 5] = [true, false, false, false, true];
