use serde::{Deserialize, Serialize};

use super::types::RuntimeTickInput;
use super::validation::PredictionValidationTrace;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum AnchorVerifierStatus {
    Created,
    Validated,
    Missed,
    Idle,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct AnchorVerifierTrace {
    pub status: AnchorVerifierStatus,
    pub anchors: Vec<String>,
    pub expectation: Option<String>,
    pub actual: Option<String>,
    pub miss_count: usize,
    pub validation_count: usize,
    pub notes: Vec<String>,
}

impl AnchorVerifierTrace {
    pub fn from_tick(input: &RuntimeTickInput, validation: &PredictionValidationTrace) -> Self {
        let anchors = anchor_items(input);
        let expectation = expectation_item(input);
        let actual = input.actual_successor.clone();
        let status = verifier_status(&anchors, expectation.as_deref(), actual.as_deref());
        let miss_count = usize::from(matches!(status, AnchorVerifierStatus::Missed));
        let validation_count = usize::from(matches!(status, AnchorVerifierStatus::Validated));
        let notes = verifier_notes(&status, validation);

        Self {
            status,
            anchors,
            expectation,
            actual,
            miss_count,
            validation_count,
            notes,
        }
    }

    pub fn is_miss(&self) -> bool {
        self.status == AnchorVerifierStatus::Missed
    }
}

fn anchor_items(input: &RuntimeTickInput) -> Vec<String> {
    input
        .observation
        .items
        .iter()
        .filter(|item| item.starts_with("anchor::"))
        .cloned()
        .collect()
}

fn expectation_item(input: &RuntimeTickInput) -> Option<String> {
    input
        .observation
        .items
        .iter()
        .find_map(|item| item.strip_prefix("expect::").map(ToOwned::to_owned))
        .or_else(|| {
            input
                .teacher
                .learner_feedback()
                .map(feedback_key)
                .map(str::to_owned)
        })
}

fn verifier_status(
    anchors: &[String],
    expectation: Option<&str>,
    actual: Option<&str>,
) -> AnchorVerifierStatus {
    match (anchors.is_empty(), expectation, actual) {
        (true, None, _) => AnchorVerifierStatus::Idle,
        (_, Some(expected), Some(actual)) if expected == actual => AnchorVerifierStatus::Validated,
        (_, Some(_), Some(_)) => AnchorVerifierStatus::Missed,
        (_, Some(_), None) | (false, None, _) => AnchorVerifierStatus::Created,
    }
}

fn verifier_notes(
    status: &AnchorVerifierStatus,
    validation: &PredictionValidationTrace,
) -> Vec<String> {
    let mut notes = vec![status_note(status).to_owned()];
    notes.extend(mismatch_note(validation));
    notes
}

fn status_note(status: &AnchorVerifierStatus) -> &'static str {
    match status {
        AnchorVerifierStatus::Created => "anchor expectation created",
        AnchorVerifierStatus::Validated => "anchor expectation validated",
        AnchorVerifierStatus::Missed => "anchor miss requires revision or refocus",
        AnchorVerifierStatus::Idle => "no anchor expectation active",
    }
}

fn mismatch_note(validation: &PredictionValidationTrace) -> Option<String> {
    (validation.mismatch_ratio > 0.0)
        .then(|| format!("prediction mismatch {:.2}", validation.mismatch_ratio))
}

fn feedback_key(feedback: crate::core::ap::Feedback) -> &'static str {
    match feedback {
        crate::core::ap::Feedback::Reward => "feedback::Reward",
        crate::core::ap::Feedback::Punishment => "feedback::Punishment",
    }
}
