use serde::{Deserialize, Serialize};

use crate::core::prediction::PredictionPackage;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct PredictionValidationTrace {
    pub actual: Option<String>,
    pub matched: Vec<String>,
    pub missed: Vec<String>,
    pub unexpected: Vec<String>,
    pub mismatch_ratio: f32,
}

impl PredictionValidationTrace {
    pub fn from_prediction(package: &PredictionPackage, actual: Option<&str>) -> Self {
        let predicted = package
            .candidates
            .iter()
            .map(|candidate| candidate.key.as_str())
            .collect::<Vec<_>>();
        let actual = actual.map(ToOwned::to_owned);
        let matched = matched_predictions(&predicted, actual.as_deref());
        let missed = missed_predictions(&predicted, actual.as_deref());
        let unexpected = unexpected_actual(&predicted, actual.as_deref());
        let mismatch_ratio = mismatch_ratio(predicted.len(), matched.len(), unexpected.len());

        Self {
            actual,
            matched,
            missed,
            unexpected,
            mismatch_ratio,
        }
    }
}

fn matched_predictions(predicted: &[&str], actual: Option<&str>) -> Vec<String> {
    actual
        .filter(|actual| predicted.contains(actual))
        .map(|actual| vec![actual.to_owned()])
        .unwrap_or_default()
}

fn missed_predictions(predicted: &[&str], actual: Option<&str>) -> Vec<String> {
    actual
        .map(|actual| {
            predicted
                .iter()
                .filter(|prediction| **prediction != actual)
                .map(|prediction| (*prediction).to_owned())
                .collect()
        })
        .unwrap_or_default()
}

fn unexpected_actual(predicted: &[&str], actual: Option<&str>) -> Vec<String> {
    actual
        .filter(|actual| !predicted.contains(actual))
        .map(|actual| vec![actual.to_owned()])
        .unwrap_or_default()
}

fn mismatch_ratio(predicted_count: usize, matched_count: usize, unexpected_count: usize) -> f32 {
    let denominator = predicted_count.max(1) as f32;
    let mismatches = predicted_count.saturating_sub(matched_count) + unexpected_count;
    (mismatches as f32 / denominator).min(1.0)
}
