use serde::{Deserialize, Serialize};

use super::{APV21Runtime, RuntimeConfig};
use crate::core::runtime::types::{RuntimeTickInput, RuntimeTickTrace};

#[derive(Debug, Default, Clone, PartialEq, Serialize, Deserialize)]
pub struct RuntimeTraceLog {
    pub entries: Vec<RuntimeTraceEntry>,
}

impl RuntimeTraceLog {
    pub fn push(&mut self, input: RuntimeTickInput, trace: RuntimeTickTrace) {
        self.entries.push(RuntimeTraceEntry { input, trace });
    }

    pub fn entries(&self) -> &[RuntimeTraceEntry] {
        &self.entries
    }

    pub fn export_json(&self) -> serde_json::Result<String> {
        serde_json::to_string_pretty(self)
    }

    pub fn replay(
        config: RuntimeConfig,
        inputs: impl IntoIterator<Item = RuntimeTickInput>,
    ) -> Self {
        let mut runtime = APV21Runtime::new(config);
        for input in inputs {
            runtime.tick(input);
        }
        runtime.trace_log().clone()
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct RuntimeTraceEntry {
    pub input: RuntimeTickInput,
    pub trace: RuntimeTickTrace,
}
