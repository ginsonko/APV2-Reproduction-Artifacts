use serde::{Deserialize, Serialize};

use crate::core::prediction::{ActionConsequenceEvaluator, PredictionConfig};

use super::memory::RuntimeMemoryStore;
use super::types::{RuntimeObservation, TeacherSignal};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ActionEstimate {
    pub action: String,
    pub drive: f32,
    pub expected_reward: f32,
    pub expected_punishment: f32,
    pub teacher_bias: bool,
    pub teacher_bias_strength: f32,
}

pub fn action_estimates(
    memory: &RuntimeMemoryStore,
    observation: &RuntimeObservation,
    actions: &[String],
    teacher: &TeacherSignal,
    prediction_config: PredictionConfig,
    current_tick: u64,
) -> Vec<ActionEstimate> {
    actions
        .iter()
        .map(|action| {
            action_estimate(
                memory,
                observation,
                action,
                teacher,
                prediction_config,
                current_tick,
            )
        })
        .collect()
}

fn action_estimate(
    memory: &RuntimeMemoryStore,
    observation: &RuntimeObservation,
    action: &str,
    teacher: &TeacherSignal,
    prediction_config: PredictionConfig,
    current_tick: u64,
) -> ActionEstimate {
    let keys = action_query_keys(observation, action);
    let required = vec![format!("action::{action}")];
    let prediction =
        memory.predict_cstar_at_tick(&keys, &required, prediction_config, current_tick);
    let consequence = ActionConsequenceEvaluator::evaluate(&prediction.package);
    let teacher_bias_strength = teacher.action_bias_strength(action);
    let teacher_bias = teacher_bias_strength > 0.0;

    ActionEstimate {
        action: action.to_owned(),
        drive: consequence.drive + teacher_bias_strength,
        expected_reward: consequence.expected_reward,
        expected_punishment: consequence.expected_punishment,
        teacher_bias,
        teacher_bias_strength,
    }
}

fn action_query_keys(observation: &RuntimeObservation, action: &str) -> Vec<String> {
    let mut keys = observation.state_keys();
    keys.push(format!("action::{action}"));
    keys
}
