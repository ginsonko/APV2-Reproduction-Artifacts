use serde::{Deserialize, Serialize};

use crate::core::ap::{AuditTrace, Feedback, TeacherMode};
use crate::core::prediction::CognitiveFeeling;

use super::RuntimeFeelingTrace;
use super::anchor::AnchorVerifierTrace;
use super::memory::{MemorySnapshot, RuntimePredictionTrace};
use super::modulation::RuntimeModulationTrace;
use super::planner::ActionEstimate;
use super::validation::PredictionValidationTrace;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct RuntimeObservation {
    pub context: String,
    pub state_id: String,
    pub items: Vec<String>,
}

impl RuntimeObservation {
    pub fn new(
        context: impl Into<String>,
        state_id: impl Into<String>,
        items: impl IntoIterator<Item = impl Into<String>>,
    ) -> Self {
        Self {
            context: context.into(),
            state_id: state_id.into(),
            items: items.into_iter().map(Into::into).collect(),
        }
    }

    pub fn state_keys(&self) -> Vec<String> {
        std::iter::once(format!("context::{}", self.context))
            .chain(std::iter::once(format!("state::{}", self.state_id)))
            .chain(self.items.iter().cloned())
            .collect()
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TeacherSignal {
    pub mode: TeacherMode,
    pub suggested_action: Option<String>,
    pub state_items: Vec<String>,
    pub action_biases: Vec<TeacherActionBias>,
    pub feedback: Option<Feedback>,
}

impl TeacherSignal {
    pub fn new(mode: TeacherMode) -> Self {
        Self {
            mode,
            suggested_action: None,
            state_items: Vec::new(),
            action_biases: Vec::new(),
            feedback: None,
        }
    }

    pub fn with_suggested_action(mut self, action: impl Into<String>) -> Self {
        self.suggested_action = Some(action.into());
        self
    }

    pub fn with_state_item(mut self, item: impl Into<String>) -> Self {
        self.state_items.push(item.into());
        self
    }

    pub fn with_action_bias(mut self, action: impl Into<String>, strength: f32) -> Self {
        self.action_biases.push(TeacherActionBias {
            action: action.into(),
            strength: strength.clamp(0.0, 1.0),
        });
        self
    }

    pub fn with_feedback(mut self, feedback: Feedback) -> Self {
        self.feedback = Some(feedback);
        self
    }

    pub fn action_bias(&self) -> Option<&str> {
        self.mode
            .answer_visible_to_learner()
            .then_some(self.suggested_action.as_deref())
            .flatten()
    }

    pub fn visible_state_items(&self) -> impl Iterator<Item = &str> {
        self.teacher_material_visible()
            .then_some(self.state_items.iter().map(String::as_str))
            .into_iter()
            .flatten()
    }

    pub fn action_bias_strength(&self, action: &str) -> f32 {
        let explicit_bias = if self.teacher_bias_visible() {
            self.action_biases
                .iter()
                .filter(|bias| bias.action == action)
                .map(|bias| bias.strength)
                .fold(0.0_f32, f32::max)
        } else {
            0.0
        };
        let answer_hint_bias = (self.action_bias() == Some(action)) as u8 as f32;
        explicit_bias.max(answer_hint_bias)
    }

    pub fn learner_feedback(&self) -> Option<Feedback> {
        self.mode
            .feedback_visible_to_learner()
            .then_some(self.feedback)
            .flatten()
    }

    fn teacher_bias_visible(&self) -> bool {
        matches!(self.mode, TeacherMode::TeacherOn | TeacherMode::Fade)
    }

    fn teacher_material_visible(&self) -> bool {
        matches!(self.mode, TeacherMode::TeacherOn | TeacherMode::Fade)
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TeacherActionBias {
    pub action: String,
    pub strength: f32,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ActionFeedback {
    pub action: String,
    pub feedback: Feedback,
}

impl ActionFeedback {
    pub fn reward(action: impl Into<String>) -> Self {
        Self {
            action: action.into(),
            feedback: Feedback::Reward,
        }
    }

    pub fn punishment(action: impl Into<String>) -> Self {
        Self {
            action: action.into(),
            feedback: Feedback::Punishment,
        }
    }

    pub fn feedback_key(&self) -> &'static str {
        match self.feedback {
            Feedback::Reward => "feedback::Reward",
            Feedback::Punishment => "feedback::Punishment",
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct RuntimeTickInput {
    pub observation: RuntimeObservation,
    pub actions: Vec<String>,
    pub teacher: TeacherSignal,
    pub feedback: Option<ActionFeedback>,
    pub actual_successor: Option<String>,
}

impl RuntimeTickInput {
    pub fn new(
        observation: RuntimeObservation,
        actions: impl IntoIterator<Item = impl Into<String>>,
    ) -> Self {
        Self {
            observation,
            actions: actions.into_iter().map(Into::into).collect(),
            teacher: TeacherSignal::new(TeacherMode::TeacherOff),
            feedback: None,
            actual_successor: None,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct RuntimeTickTrace {
    pub tick: u64,
    pub r_state: RStateTrace,
    pub selected_action: Option<String>,
    pub prediction: RuntimePredictionTrace,
    pub prediction_validation: PredictionValidationTrace,
    pub feeling: CognitiveFeeling,
    pub feeling_trace: RuntimeFeelingTrace,
    pub modulation_trace: RuntimeModulationTrace,
    pub anchor_trace: AnchorVerifierTrace,
    pub action_estimates: Vec<ActionEstimate>,
    pub teacher_audit: AuditTrace,
    pub feedback_written: bool,
    pub memory_frame_written: bool,
    pub memory_snapshot: Option<MemorySnapshot>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct RStateTrace {
    pub selected_keys: Vec<String>,
    pub candidate_count: usize,
    pub limit: usize,
    pub policy: String,
    pub heads: Vec<RStateHeadTrace>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct RStateHeadTrace {
    pub head: String,
    pub candidate_count: usize,
}
