use std::collections::HashMap;

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SkillManifest {
    pub skill_id: String,
    pub domain: String,
    pub dependencies: Vec<SkillDependency>,
    pub evidence: SkillEvidence,
    pub boundary: SkillBoundary,
}

impl SkillManifest {
    pub fn new(
        skill_id: impl Into<String>,
        domain: impl Into<String>,
        evidence: SkillEvidence,
        boundary: SkillBoundary,
    ) -> Self {
        Self {
            skill_id: skill_id.into(),
            domain: domain.into(),
            dependencies: Vec::new(),
            evidence,
            boundary,
        }
    }

    pub fn with_dependency(mut self, dependency: SkillDependency) -> Self {
        self.dependencies.push(dependency);
        self
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SkillDependency {
    pub skill_id: String,
    pub required: bool,
}

impl SkillDependency {
    pub fn required(skill_id: impl Into<String>) -> Self {
        Self {
            skill_id: skill_id.into(),
            required: true,
        }
    }

    pub fn optional(skill_id: impl Into<String>) -> Self {
        Self {
            skill_id: skill_id.into(),
            required: false,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct SkillEvidence {
    pub train_accuracy: f32,
    pub holdout_accuracy: f32,
    pub sample_count: usize,
}

impl SkillEvidence {
    pub fn meets(self, gate: EvidenceGate) -> bool {
        self.train_accuracy >= gate.min_train_accuracy
            && self.holdout_accuracy >= gate.min_holdout_accuracy
            && self.sample_count >= gate.min_sample_count
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct EvidenceGate {
    pub min_train_accuracy: f32,
    pub min_holdout_accuracy: f32,
    pub min_sample_count: usize,
}

impl Default for EvidenceGate {
    fn default() -> Self {
        Self {
            min_train_accuracy: 1.0,
            min_holdout_accuracy: 1.0,
            min_sample_count: 1,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SkillBoundary {
    pub context_prefix: String,
    pub state_count_min: usize,
    pub state_count_max: usize,
}

impl SkillBoundary {
    pub fn new(
        context_prefix: impl Into<String>,
        state_count_min: usize,
        state_count_max: usize,
    ) -> Self {
        Self {
            context_prefix: context_prefix.into(),
            state_count_min,
            state_count_max,
        }
    }

    pub fn contains(&self, context: &SkillContext) -> bool {
        context.context.starts_with(&self.context_prefix)
            && context.state_count >= self.state_count_min
            && context.state_count <= self.state_count_max
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SkillContext {
    pub context: String,
    pub state_count: usize,
}

impl SkillContext {
    pub fn new(context: impl Into<String>, state_count: usize) -> Self {
        Self {
            context: context.into(),
            state_count,
        }
    }
}

#[derive(Debug, Default, Clone)]
pub struct SkillRegistry {
    manifests: HashMap<String, SkillManifest>,
}

impl SkillRegistry {
    pub fn register(&mut self, manifest: SkillManifest) -> Result<(), SkillRegistryError> {
        if self.manifests.contains_key(&manifest.skill_id) {
            return Err(SkillRegistryError::DuplicateSkill(manifest.skill_id));
        }
        let missing = self.missing_required_dependencies(&manifest);
        if !missing.is_empty() {
            return Err(SkillRegistryError::MissingRequiredDependencies {
                skill_id: manifest.skill_id,
                missing,
            });
        }
        self.manifests.insert(manifest.skill_id.clone(), manifest);
        Ok(())
    }

    pub fn get(&self, skill_id: &str) -> Option<&SkillManifest> {
        self.manifests.get(skill_id)
    }

    pub fn can_reload(
        &self,
        skill_id: &str,
        context: &SkillContext,
        gate: EvidenceGate,
    ) -> Result<(), SkillRegistryError> {
        let manifest = self
            .get(skill_id)
            .ok_or_else(|| SkillRegistryError::UnknownSkill(skill_id.to_owned()))?;
        if !manifest.evidence.meets(gate) {
            return Err(SkillRegistryError::InsufficientEvidence(
                skill_id.to_owned(),
            ));
        }
        if !manifest.boundary.contains(context) {
            return Err(SkillRegistryError::BoundaryMismatch(skill_id.to_owned()));
        }
        Ok(())
    }

    pub fn reloadable<'a>(
        &'a self,
        context: &SkillContext,
        gate: EvidenceGate,
    ) -> Vec<&'a SkillManifest> {
        let mut manifests: Vec<_> = self
            .manifests
            .values()
            .filter(|manifest| self.can_reload(&manifest.skill_id, context, gate).is_ok())
            .collect();
        manifests.sort_by(|left, right| left.skill_id.cmp(&right.skill_id));
        manifests
    }

    pub fn len(&self) -> usize {
        self.manifests.len()
    }

    pub fn is_empty(&self) -> bool {
        self.manifests.is_empty()
    }

    fn missing_required_dependencies(&self, manifest: &SkillManifest) -> Vec<String> {
        manifest
            .dependencies
            .iter()
            .filter(|dependency| dependency.required)
            .filter(|dependency| !self.manifests.contains_key(&dependency.skill_id))
            .map(|dependency| dependency.skill_id.clone())
            .collect()
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SkillRegistryError {
    DuplicateSkill(String),
    MissingRequiredDependencies {
        skill_id: String,
        missing: Vec<String>,
    },
    UnknownSkill(String),
    InsufficientEvidence(String),
    BoundaryMismatch(String),
}
