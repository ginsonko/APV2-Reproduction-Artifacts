use crate::core::ap::{AuditTrace, Feedback, TeacherMode};

pub trait CoreWorld {
    type Stimulus;
    type Response: Copy;

    fn commit_response(&self, stimulus: &Self::Stimulus, response: Self::Response) -> Feedback;

    fn teacher_response(&self, _stimulus: &Self::Stimulus) -> Option<Self::Response> {
        None
    }
}

pub trait CoreLearner<W: CoreWorld> {
    fn select_response(&self, world: &W, stimulus: &W::Stimulus, mode: TeacherMode) -> W::Response;

    fn receive_feedback(
        &mut self,
        world: &W,
        stimulus: &W::Stimulus,
        response: W::Response,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace;

    fn memory_rows(&self) -> Option<usize> {
        None
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct CorePhaseResult {
    pub correct: usize,
    pub total: usize,
    pub accuracy: f32,
    pub traces: Vec<AuditTrace>,
}

pub fn train_core_repeats<W, L>(
    training_set: &[W::Stimulus],
    world: &W,
    learner: &mut L,
    repeats: usize,
) -> Vec<CorePhaseResult>
where
    W: CoreWorld,
    L: CoreLearner<W>,
{
    (0..repeats)
        .map(|_| run_core_phase(training_set, world, learner, TeacherMode::FeedbackOnly))
        .collect()
}

pub fn run_core_phase<W, L>(
    stimuli: &[W::Stimulus],
    world: &W,
    learner: &mut L,
    mode: TeacherMode,
) -> CorePhaseResult
where
    W: CoreWorld,
    L: CoreLearner<W>,
{
    let mut correct = 0;
    let mut traces = Vec::with_capacity(stimuli.len());

    for stimulus in stimuli {
        let response = select_phase_response(world, learner, stimulus, mode);
        let feedback = world.commit_response(stimulus, response);
        correct += usize::from(feedback == Feedback::Reward);
        traces.push(learner.receive_feedback(world, stimulus, response, feedback, mode));
    }

    CorePhaseResult {
        correct,
        total: stimuli.len(),
        accuracy: accuracy(correct, stimuli.len()),
        traces,
    }
}

fn select_phase_response<W, L>(
    world: &W,
    learner: &L,
    stimulus: &W::Stimulus,
    mode: TeacherMode,
) -> W::Response
where
    W: CoreWorld,
    L: CoreLearner<W>,
{
    if let Some(response) = visible_teacher_response(world, stimulus, mode) {
        response
    } else {
        learner.select_response(world, stimulus, mode)
    }
}

fn visible_teacher_response<W>(
    world: &W,
    stimulus: &W::Stimulus,
    mode: TeacherMode,
) -> Option<W::Response>
where
    W: CoreWorld,
{
    mode.answer_visible_to_learner()
        .then(|| world.teacher_response(stimulus))
        .flatten()
}

fn accuracy(correct: usize, total: usize) -> f32 {
    correct as f32 / total as f32
}
