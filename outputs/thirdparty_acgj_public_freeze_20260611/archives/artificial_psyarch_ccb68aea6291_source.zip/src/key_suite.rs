use std::fs;
use std::path::{Path, PathBuf};

use serde::Serialize;
use sha2::{Digest, Sha256};

use crate::core::ap::{AuditTrace, TaintAuditSummary};
use crate::experiments::records::ExperimentRecords;
use crate::repeat_map::records::Records as RepeatMapRecords;

mod case_snapshot;
mod reproduction;
mod suite_registry;

pub use case_snapshot::{CaseSnapshot, CaseSnapshotBundle};
pub use reproduction::ReproductionRecord;
use suite_registry::{build_key_suite_results, sorted_key_suite_registry};

#[derive(Debug, Clone, PartialEq, Serialize)]
pub struct KeySuiteBundle {
    pub results: KeySuiteResults,
    pub claim_matrix: ClaimMatrix,
    pub taint_audit: KeySuiteTaintAudit,
    pub case_snapshots: CaseSnapshotBundle,
    pub reproduction: ReproductionRecord,
    pub provenance: ArtifactProvenance,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct ArtifactProvenance {
    pub schema_id: &'static str,
    pub generator: &'static str,
    pub git_commit: Option<String>,
    pub git_dirty: Option<bool>,
    pub archive_sha256: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Serialize)]
pub struct KeySuiteResults {
    pub schema_id: &'static str,
    pub route: &'static str,
    pub evidence_level: &'static str,
    pub status: &'static str,
    pub suite_count: usize,
    pub passed_count: usize,
    pub suites: Vec<KeySuiteResult>,
}

#[derive(Debug, Clone, PartialEq, Serialize)]
pub struct KeySuiteResult {
    pub id: &'static str,
    pub claim_id: &'static str,
    pub title: &'static str,
    pub status: &'static str,
    pub evidence: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Serialize)]
pub struct ClaimMatrix {
    pub schema_id: &'static str,
    pub route: &'static str,
    pub claims: Vec<ClaimEntry>,
}

#[derive(Debug, Clone, PartialEq, Serialize)]
pub struct ClaimEntry {
    pub suite_id: &'static str,
    pub claim_id: &'static str,
    pub evidence_topic: &'static str,
    pub status: &'static str,
    pub supports: &'static str,
    pub does_not_support: &'static str,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct KeySuiteTaintAudit {
    pub schema_id: &'static str,
    pub route: &'static str,
    pub status: &'static str,
    pub summary: TaintAuditSummary,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct ManifestSha256 {
    pub schema_id: &'static str,
    pub files: Vec<ManifestFile>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct ManifestFile {
    pub path: String,
    pub sha256: String,
    pub bytes: u64,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct WrittenKeySuiteBundle {
    pub out_dir: PathBuf,
    pub manifest: ManifestSha256,
}

pub fn build_key_suite_bundle(
    experiments: &ExperimentRecords,
    repeat_map: &RepeatMapRecords,
) -> KeySuiteBundle {
    build_key_suite_bundle_with_provenance(experiments, repeat_map, ArtifactProvenance::unknown())
}

pub fn build_key_suite_bundle_with_provenance(
    experiments: &ExperimentRecords,
    repeat_map: &RepeatMapRecords,
    provenance: ArtifactProvenance,
) -> KeySuiteBundle {
    let suites = build_key_suite_results(experiments, repeat_map);
    KeySuiteBundle {
        results: KeySuiteResults::new(suites),
        claim_matrix: ClaimMatrix::from_registry(),
        taint_audit: KeySuiteTaintAudit::from_records(experiments, repeat_map),
        case_snapshots: case_snapshot::build_case_snapshot_bundle(experiments, repeat_map),
        reproduction: ReproductionRecord::from_inputs(experiments, repeat_map, &provenance),
        provenance,
    }
}

pub fn write_key_suite_bundle(
    out_dir: &Path,
    bundle: &KeySuiteBundle,
) -> Result<WrittenKeySuiteBundle, Box<dyn std::error::Error>> {
    fs::create_dir_all(out_dir)?;
    let files = key_suite_files(bundle)?;
    let manifest = write_key_suite_files(out_dir, &files)?;

    Ok(WrittenKeySuiteBundle {
        out_dir: out_dir.to_path_buf(),
        manifest,
    })
}

fn key_suite_files(
    bundle: &KeySuiteBundle,
) -> Result<Vec<ArtifactFile>, Box<dyn std::error::Error>> {
    Ok(vec![
        ArtifactFile::json("KEY_SUITE_RESULTS.json", &bundle.results)?,
        ArtifactFile::json("CLAIM_MATRIX.json", &bundle.claim_matrix)?,
        ArtifactFile::json("TAINT_AUDIT_SUMMARY.json", &bundle.taint_audit)?,
        ArtifactFile::json("CASE_SNAPSHOTS.json", &bundle.case_snapshots)?,
        ArtifactFile::json("REPRODUCTION_RECORD.json", &bundle.reproduction)?,
        ArtifactFile::json("PROVENANCE.json", &bundle.provenance)?,
        ArtifactFile::text(
            "KEY_SUITE_REPORT.md",
            render_key_suite_report(
                &bundle.results,
                &bundle.taint_audit,
                &bundle.case_snapshots,
                &bundle.reproduction,
            ),
        ),
    ])
}

#[deprecated(note = "use KeySuiteBundle")]
pub type PaperArtifactBundle = KeySuiteBundle;

#[deprecated(note = "use WrittenKeySuiteBundle")]
pub type WrittenPaperArtifact = WrittenKeySuiteBundle;

#[deprecated(note = "use build_key_suite_bundle")]
pub fn build_paper_artifact_bundle(
    experiments: &ExperimentRecords,
    repeat_map: &RepeatMapRecords,
) -> KeySuiteBundle {
    build_key_suite_bundle(experiments, repeat_map)
}

#[deprecated(note = "use build_key_suite_bundle_with_provenance")]
pub fn build_paper_artifact_bundle_with_provenance(
    experiments: &ExperimentRecords,
    repeat_map: &RepeatMapRecords,
    provenance: ArtifactProvenance,
) -> KeySuiteBundle {
    build_key_suite_bundle_with_provenance(experiments, repeat_map, provenance)
}

#[deprecated(note = "use write_key_suite_bundle")]
pub fn write_paper_artifact_bundle(
    out_dir: &Path,
    bundle: &KeySuiteBundle,
) -> Result<WrittenKeySuiteBundle, Box<dyn std::error::Error>> {
    write_key_suite_bundle(out_dir, bundle)
}

fn write_key_suite_files(
    out_dir: &Path,
    files: &[ArtifactFile],
) -> Result<ManifestSha256, Box<dyn std::error::Error>> {
    write_artifact_files(out_dir, files)?;
    let manifest = build_manifest(files);
    write_manifest(out_dir, &manifest)?;
    Ok(manifest)
}

fn write_artifact_files(
    out_dir: &Path,
    files: &[ArtifactFile],
) -> Result<(), Box<dyn std::error::Error>> {
    for file in files {
        fs::write(out_dir.join(file.name), &file.bytes)?;
    }
    Ok(())
}

fn build_manifest(files: &[ArtifactFile]) -> ManifestSha256 {
    ManifestSha256 {
        schema_id: "paper_artifact_manifest/v0.1",
        files: files.iter().map(ManifestFile::from_artifact_file).collect(),
    }
}

fn write_manifest(
    out_dir: &Path,
    manifest: &ManifestSha256,
) -> Result<(), Box<dyn std::error::Error>> {
    fs::write(
        out_dir.join("MANIFEST_SHA256.json"),
        serde_json::to_vec_pretty(manifest)?,
    )?;
    Ok(())
}

impl ManifestFile {
    fn from_artifact_file(file: &ArtifactFile) -> Self {
        Self {
            path: file.name.to_owned(),
            sha256: sha256_hex(&file.bytes),
            bytes: file.bytes.len() as u64,
        }
    }
}

impl KeySuiteResults {
    fn new(suites: Vec<KeySuiteResult>) -> Self {
        let passed_count = suites.iter().filter(|suite| suite.status == "PASS").count();
        let suite_count = suites.len();
        Self {
            schema_id: "canonical_key_suite_local/v0.1",
            route: "AP-Core clean-room local",
            evidence_level: "E4-local",
            status: if passed_count == suite_count {
                "PASS"
            } else {
                "FAIL"
            },
            suite_count,
            passed_count,
            suites,
        }
    }
}

impl ArtifactProvenance {
    pub fn new(git_commit: Option<String>, git_dirty: Option<bool>) -> Self {
        Self {
            schema_id: "paper_artifact_provenance/v0.1",
            generator: "paper_key_suite",
            git_commit,
            git_dirty,
            archive_sha256: None,
        }
    }

    pub fn unknown() -> Self {
        Self::new(None, None)
    }
}

impl ClaimMatrix {
    fn from_registry() -> Self {
        Self {
            schema_id: "claim_matrix/v0.1",
            route: "AP-Core clean-room local",
            claims: sorted_key_suite_registry()
                .iter()
                .map(|entry| ClaimEntry {
                    suite_id: entry.spec.suite_id,
                    claim_id: entry.spec.claim_id,
                    evidence_topic: entry.spec.title,
                    status: "tracked",
                    supports: entry.spec.supports,
                    does_not_support: entry.spec.does_not_support,
                })
                .collect(),
        }
    }
}

impl KeySuiteTaintAudit {
    fn from_records(experiments: &ExperimentRecords, repeat_map: &RepeatMapRecords) -> Self {
        let summary = TaintAuditSummary::from_teacher_off_traces(
            experiment_teacher_off_traces(experiments)
                .chain(repeat_map_teacher_off_traces(repeat_map)),
        );
        Self {
            schema_id: "taint_audit_summary/v0.1",
            route: "AP-Core clean-room local",
            status: if summary.passed() { "PASS" } else { "FAIL" },
            summary,
        }
    }
}

fn experiment_teacher_off_traces(records: &ExperimentRecords) -> impl Iterator<Item = &AuditTrace> {
    records
        .experiments
        .iter()
        .flat_map(|run| run.phases.iter())
        .filter(|phase| teacher_off_phase(phase.phase))
        .flat_map(|phase| phase.events.iter())
        .map(|event| &event.trace)
}

fn repeat_map_teacher_off_traces(records: &RepeatMapRecords) -> impl Iterator<Item = &AuditTrace> {
    records
        .seed_runs
        .iter()
        .flat_map(|seed| seed.groups.iter())
        .flat_map(|group| group.phases.iter())
        .filter(|(phase, _)| teacher_off_phase(phase))
        .flat_map(|(_, events)| events.iter())
        .map(|event| &event.trace.audit)
}

fn teacher_off_phase(phase: &str) -> bool {
    matches!(
        phase,
        "pretest" | "holdout" | "wake_probe" | "package_reload"
    )
}

fn render_key_suite_report(
    results: &KeySuiteResults,
    taint_audit: &KeySuiteTaintAudit,
    snapshots: &CaseSnapshotBundle,
    reproduction: &ReproductionRecord,
) -> String {
    let mut report = format!(
        "# Canonical-KeySuite Local Report\n\nstatus: {}\nsuites: {}\npassed: {}\nroute: {}\nevidence_level: {}\ntaint_audit: {}\ncase_snapshots: {}\nrepository_status: {}\nvalidation_command: {}\n\n",
        results.status,
        results.suite_count,
        results.passed_count,
        results.route,
        results.evidence_level,
        taint_audit.status,
        snapshots.snapshots.len(),
        reproduction.repository_status.status,
        reproduction.validation_command
    );

    report.push_str("## Taint Audit Summary\n\n");
    report.push_str(&format!(
        "- visible_payload_has_hidden_truth: {}\n- package_has_hidden_truth: {}\n- solver_visible_to_learner: {}\n- teacher_off_feedback_visible: {}\n- teacher_off_memory_write: {}\n- examiner_private_scoring_only: {}\n\n",
        taint_audit.summary.visible_payload_has_hidden_truth,
        taint_audit.summary.package_has_hidden_truth,
        taint_audit.summary.solver_visible_to_learner,
        taint_audit.summary.teacher_off_feedback_visible,
        taint_audit.summary.teacher_off_memory_write,
        taint_audit.summary.examiner_private_scoring_only,
    ));

    for suite in &results.suites {
        report.push_str(&format!(
            "## {} {} {}\n\nclaim: {}\n\n",
            suite.id, suite.status, suite.title, suite.claim_id
        ));
        for evidence in &suite.evidence {
            report.push_str(&format!("- {evidence}\n"));
        }
        report.push('\n');
    }

    report
}

struct ArtifactFile {
    name: &'static str,
    bytes: Vec<u8>,
}

impl ArtifactFile {
    fn json<T: Serialize>(
        name: &'static str,
        value: &T,
    ) -> Result<Self, Box<dyn std::error::Error>> {
        Ok(Self {
            name,
            bytes: serde_json::to_vec_pretty(value)?,
        })
    }

    fn text(name: &'static str, value: String) -> Self {
        Self {
            name,
            bytes: value.into_bytes(),
        }
    }
}

fn sha256_hex(bytes: &[u8]) -> String {
    let digest = Sha256::digest(bytes);
    digest.iter().map(|byte| format!("{byte:02x}")).collect()
}
