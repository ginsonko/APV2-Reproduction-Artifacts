//! Clean-room AP-Core minimal prototype.
//!
//! This crate is not the original APV2.1 implementation. It is a small Rust
//! architecture sketch based on the public paper's concepts: state atoms,
//! dual-energy state pool, action-feedback memory, teacher-off evaluation, and
//! skill reload.

pub mod codec;
pub mod core;
pub mod experiments;
pub mod gl;
pub mod key_suite;
pub mod language;
pub mod learning;
pub mod repeat_map;
pub mod tui;
pub mod workspace;

pub use core::ap;
pub use core::prediction;
pub use core::runner as ap_core;
pub use core::runtime;
pub use core::skill_registry;
pub use experiments::canvas_geometry;
pub use experiments::count_loop;
pub use experiments::desktop_control;
pub use experiments::feature_combo;
pub use experiments::language_grounding;
pub use experiments::long_run;
pub use experiments::math_fullchain;
pub use experiments::math_slice;
pub use experiments::multimodal_revision;
pub use experiments::sensor_assoc;
pub use key_suite as paper_artifact;
pub use language as language_core;
