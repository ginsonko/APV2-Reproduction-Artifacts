use std::fmt::{Display, Formatter};

use serde::{Serialize, de::DeserializeOwned};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Codec {
    JsonPretty,
    Bincode,
}

#[derive(Debug)]
pub enum CodecError {
    Json(serde_json::Error),
    BincodeEncode(bincode::error::EncodeError),
    BincodeDecode(bincode::error::DecodeError),
}

impl Codec {
    pub fn encode<T>(self, value: &T) -> Result<Vec<u8>, CodecError>
    where
        T: Serialize,
    {
        match self {
            Self::JsonPretty => Ok(serde_json::to_vec_pretty(value)?),
            Self::Bincode => Ok(bincode::serde::encode_to_vec(
                value,
                bincode::config::standard(),
            )?),
        }
    }

    pub fn decode<T>(self, bytes: &[u8]) -> Result<T, CodecError>
    where
        T: DeserializeOwned,
    {
        match self {
            Self::JsonPretty => Ok(serde_json::from_slice(bytes)?),
            Self::Bincode => {
                let (value, _) =
                    bincode::serde::decode_from_slice(bytes, bincode::config::standard())?;
                Ok(value)
            }
        }
    }
}

impl Display for CodecError {
    fn fmt(&self, formatter: &mut Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Json(error) => write!(formatter, "json codec error: {error}"),
            Self::BincodeEncode(error) => write!(formatter, "bincode encode error: {error}"),
            Self::BincodeDecode(error) => write!(formatter, "bincode decode error: {error}"),
        }
    }
}

impl std::error::Error for CodecError {}

impl From<serde_json::Error> for CodecError {
    fn from(error: serde_json::Error) -> Self {
        Self::Json(error)
    }
}

impl From<bincode::error::EncodeError> for CodecError {
    fn from(error: bincode::error::EncodeError) -> Self {
        Self::BincodeEncode(error)
    }
}

impl From<bincode::error::DecodeError> for CodecError {
    fn from(error: bincode::error::DecodeError) -> Self {
        Self::BincodeDecode(error)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde::{Deserialize, Serialize};

    #[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
    struct Sample {
        id: String,
        value: u16,
    }

    #[test]
    fn json_round_trip() {
        assert_round_trip(Codec::JsonPretty);
    }

    #[test]
    fn bincode_round_trip() {
        assert_round_trip(Codec::Bincode);
    }

    fn assert_round_trip(codec: Codec) {
        let sample = Sample {
            id: "sample".to_owned(),
            value: 42,
        };
        let bytes = codec.encode(&sample).unwrap();
        let decoded: Sample = codec.decode(&bytes).unwrap();

        assert_eq!(decoded, sample);
    }
}
