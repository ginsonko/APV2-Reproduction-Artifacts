use std::collections::HashMap;

use serde::{Deserialize, Serialize};

use crate::core::ap::{AuditTrace, Feedback, TeacherMode};
use crate::core::runner::{
    CoreLearner, CorePhaseResult, CoreWorld, run_core_phase, train_core_repeats,
};
use crate::experiments::local_runner::{ExperimentRunConfig, run_math_fullchain_records};
use crate::experiments::records::ExperimentRun;
use crate::experiments::registry::ExperimentRegistryEntry;

pub const fn registry_entry() -> ExperimentRegistryEntry {
    ExperimentRegistryEntry::new(50, "math_fullchain", run_registry_entry)
}

fn run_registry_entry(config: ExperimentRunConfig) -> Vec<ExperimentRun> {
    vec![run_math_fullchain_records(config)]
}

inventory::submit! {
    registry_entry()
}
use crate::core::skill_registry::{
    SkillBoundary, SkillDependency, SkillEvidence, SkillManifest, SkillRegistry, SkillRegistryError,
};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct WordProblem {
    pub id: String,
    pub groups: u16,
    pub extra: u16,
    pub total: u16,
    pub each: u16,
}

impl WordProblem {
    fn new(id: impl Into<String>, groups: u16, extra: u16, total: u16, each: u16) -> Self {
        Self {
            id: id.into(),
            groups,
            extra,
            total,
            each,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
pub struct WordProblemAnswer(pub u16);

#[derive(Debug, Clone)]
pub struct MathFullChainWorld {
    train_problems: Vec<WordProblem>,
    holdout_problems: Vec<WordProblem>,
    examiner: MathFullChainExaminer,
}

impl MathFullChainWorld {
    pub fn canonical() -> Self {
        Self {
            train_problems: vec![
                WordProblem::new("FC-T00", 3, 5, 23, 6),
                WordProblem::new("FC-T01", 2, 4, 18, 7),
                WordProblem::new("FC-T02", 4, 3, 23, 5),
            ],
            holdout_problems: vec![
                WordProblem::new("FC-H00", 3, 5, 26, 7),
                WordProblem::new("FC-H01", 2, 4, 20, 8),
                WordProblem::new("FC-H02", 4, 3, 27, 6),
            ],
            examiner: MathFullChainExaminer,
        }
    }

    pub fn train_problems(&self) -> &[WordProblem] {
        &self.train_problems
    }

    pub fn holdout_problems(&self) -> &[WordProblem] {
        &self.holdout_problems
    }

    pub fn commit_answer(&self, problem: &WordProblem, answer: WordProblemAnswer) -> Feedback {
        self.examiner.score(problem, answer)
    }
}

impl CoreWorld for MathFullChainWorld {
    type Stimulus = WordProblem;
    type Response = WordProblemAnswer;

    fn commit_response(&self, stimulus: &Self::Stimulus, response: Self::Response) -> Feedback {
        self.commit_answer(stimulus, response)
    }
}

#[derive(Debug, Clone)]
struct MathFullChainExaminer;

impl MathFullChainExaminer {
    fn score(&self, problem: &WordProblem, answer: WordProblemAnswer) -> Feedback {
        if problem.each == answer.0 {
            Feedback::Reward
        } else {
            Feedback::Punishment
        }
    }
}

#[derive(Debug, Default, Clone)]
pub struct MathFullChainLearner {
    templates: HashMap<TemplateKey, ChainTemplate>,
    attempts: HashMap<ProblemAnswer, usize>,
    memory_rows: usize,
    foundation_loaded: bool,
}

impl MathFullChainLearner {
    pub fn with_foundation_skills() -> Self {
        Self {
            foundation_loaded: true,
            ..Self::default()
        }
    }

    pub fn export_skill_manifest(&self, evidence: SkillEvidence) -> SkillManifest {
        SkillManifest::new(
            "skill.math.linear_equation_word_problem.v1",
            "math",
            evidence,
            SkillBoundary::new("math_fullchain.linear_word_problem", 1, 16),
        )
        .with_dependency(SkillDependency::required("skill.math.vertical_subtract.v1"))
        .with_dependency(SkillDependency::required(
            "skill.math.repeated_subtract_division.v1",
        ))
        .with_dependency(SkillDependency::required("skill.math.vertical_multiply.v1"))
        .with_dependency(SkillDependency::required("skill.math.vertical_add.v1"))
    }

    pub fn register_with_foundation(
        &self,
        evidence: SkillEvidence,
    ) -> Result<SkillRegistry, SkillRegistryError> {
        let mut registry = SkillRegistry::default();
        for manifest in foundation_skill_manifests() {
            registry.register(manifest)?;
        }
        registry.register(self.export_skill_manifest(evidence))?;
        Ok(registry)
    }

    pub fn chain_trace(&self, problem: &WordProblem) -> Option<Vec<String>> {
        let template = self
            .templates
            .get(&TemplateKey::new(problem.groups, problem.extra))?;
        let remaining = checked_subtract(problem.total, template.extra)?;
        let each = repeated_subtract_division(remaining, template.groups)?;
        Some(vec![
            format!("{}x+{}={}", template.groups, template.extra, problem.total),
            format!("{}-{}={}", problem.total, template.extra, remaining),
            format!(
                "{remaining} repeated subtract {} -> {each} groups",
                template.groups
            ),
            format!(
                "{}*{}+{}={}",
                template.groups, each, template.extra, problem.total
            ),
            format!("submit {each}"),
        ])
    }

    pub fn select_answer(&self, problem: &WordProblem) -> WordProblemAnswer {
        self.apply_template(problem)
            .map(WordProblemAnswer)
            .unwrap_or(WordProblemAnswer(0))
    }

    pub fn select_answer_for_mode(
        &self,
        problem: &WordProblem,
        mode: TeacherMode,
    ) -> WordProblemAnswer {
        let learned_answer = self.select_answer(problem);
        if self.apply_template(problem).is_some() {
            return learned_answer;
        }
        if mode.exploration_enabled() {
            self.first_untried_answer(problem).unwrap_or(learned_answer)
        } else {
            learned_answer
        }
    }

    pub fn receive_feedback(
        &mut self,
        problem: &WordProblem,
        answer: WordProblemAnswer,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        if mode.memory_write_enabled() {
            *self
                .attempts
                .entry(ProblemAnswer::new(problem, answer))
                .or_default() += 1;
            if self.foundation_loaded && feedback == Feedback::Reward {
                self.templates.insert(
                    TemplateKey::new(problem.groups, problem.extra),
                    ChainTemplate::from_problem(problem),
                );
            }
            self.memory_rows += 1;
        }
        AuditTrace::for_mode(mode)
    }

    pub fn memory_rows(&self) -> usize {
        self.memory_rows
    }

    fn apply_template(&self, problem: &WordProblem) -> Option<u16> {
        let template = self
            .templates
            .get(&TemplateKey::new(problem.groups, problem.extra))?;
        let remaining = checked_subtract(problem.total, template.extra)?;
        repeated_subtract_division(remaining, template.groups)
    }

    fn first_untried_answer(&self, problem: &WordProblem) -> Option<WordProblemAnswer> {
        (0..=24).map(WordProblemAnswer).find(|answer| {
            !self
                .attempts
                .contains_key(&ProblemAnswer::new(problem, *answer))
        })
    }
}

impl CoreLearner<MathFullChainWorld> for MathFullChainLearner {
    fn select_response(
        &self,
        _world: &MathFullChainWorld,
        stimulus: &WordProblem,
        mode: TeacherMode,
    ) -> WordProblemAnswer {
        self.select_answer_for_mode(stimulus, mode)
    }

    fn receive_feedback(
        &mut self,
        _world: &MathFullChainWorld,
        stimulus: &WordProblem,
        response: WordProblemAnswer,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        self.receive_feedback(stimulus, response, feedback, mode)
    }

    fn memory_rows(&self) -> Option<usize> {
        Some(self.memory_rows())
    }
}

pub type MathFullChainPhaseResult = CorePhaseResult;

pub fn train_math_fullchain(
    world: &MathFullChainWorld,
    learner: &mut MathFullChainLearner,
    repeats: usize,
) -> Vec<MathFullChainPhaseResult> {
    train_core_repeats(world.train_problems(), world, learner, repeats)
}

pub fn run_math_fullchain_phase(
    problems: &[WordProblem],
    world: &MathFullChainWorld,
    learner: &mut MathFullChainLearner,
    mode: TeacherMode,
) -> MathFullChainPhaseResult {
    run_core_phase(problems, world, learner, mode)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
struct TemplateKey {
    groups: u16,
    extra: u16,
}

impl TemplateKey {
    fn new(groups: u16, extra: u16) -> Self {
        Self { groups, extra }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct ChainTemplate {
    groups: u16,
    extra: u16,
}

impl ChainTemplate {
    fn from_problem(problem: &WordProblem) -> Self {
        Self {
            groups: problem.groups,
            extra: problem.extra,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct ProblemAnswer {
    problem_id: String,
    answer: WordProblemAnswer,
}

impl ProblemAnswer {
    fn new(problem: &WordProblem, answer: WordProblemAnswer) -> Self {
        Self {
            problem_id: problem.id.clone(),
            answer,
        }
    }
}

fn checked_subtract(left: u16, right: u16) -> Option<u16> {
    (left >= right).then_some(left - right)
}

fn repeated_subtract_division(total: u16, divisor: u16) -> Option<u16> {
    if divisor == 0 {
        return None;
    }
    let mut remainder = total;
    let mut groups = 0;
    while remainder >= divisor {
        remainder -= divisor;
        groups += 1;
    }
    (remainder == 0).then_some(groups)
}

fn foundation_skill_manifests() -> [SkillManifest; 4] {
    [
        math_skill_manifest("skill.math.vertical_subtract.v1"),
        math_skill_manifest("skill.math.repeated_subtract_division.v1"),
        math_skill_manifest("skill.math.vertical_multiply.v1"),
        math_skill_manifest("skill.math.vertical_add.v1"),
    ]
}

fn math_skill_manifest(skill_id: &str) -> SkillManifest {
    SkillManifest::new(
        skill_id,
        "math",
        SkillEvidence {
            train_accuracy: 1.0,
            holdout_accuracy: 1.0,
            sample_count: 4,
        },
        SkillBoundary::new("math_core", 1, 32),
    )
}
