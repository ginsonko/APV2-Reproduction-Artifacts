use std::collections::HashMap;

use serde::{Deserialize, Serialize};

use crate::core::ap::{AuditTrace, Feedback, TeacherMode};
use crate::core::runner::{
    CoreLearner, CorePhaseResult, CoreWorld, run_core_phase, train_core_repeats,
};
use crate::experiments::local_runner::{ExperimentRunConfig, run_multimodal_revision_records};
use crate::experiments::records::ExperimentRun;
use crate::experiments::registry::ExperimentRegistryEntry;

pub const fn registry_entry() -> ExperimentRegistryEntry {
    ExperimentRegistryEntry::new(80, "multimodal_revision", run_registry_entry)
}

fn run_registry_entry(config: ExperimentRunConfig) -> Vec<ExperimentRun> {
    vec![run_multimodal_revision_records(config)]
}

inventory::submit! {
    registry_entry()
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
pub enum RevisionLabel {
    Red,
    Blue,
    Green,
}

pub const REVISION_LABELS: [RevisionLabel; 3] = [
    RevisionLabel::Red,
    RevisionLabel::Blue,
    RevisionLabel::Green,
];

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct MultimodalPrompt {
    pub id: String,
    pub text_hint: RevisionLabel,
    pub visual_bytes: Vec<u8>,
    pub target: RevisionLabel,
}

#[derive(Debug, Clone)]
pub struct MultimodalRevisionWorld {
    train_prompts: Vec<MultimodalPrompt>,
    holdout_prompts: Vec<MultimodalPrompt>,
    examiner: RevisionExaminer,
}

impl MultimodalRevisionWorld {
    pub fn canonical() -> Self {
        Self {
            train_prompts: vec![
                MultimodalPrompt::new("T00", RevisionLabel::Red, [12, 10, 11], RevisionLabel::Red),
                MultimodalPrompt::new(
                    "T01",
                    RevisionLabel::Blue,
                    [80, 82, 79],
                    RevisionLabel::Blue,
                ),
                MultimodalPrompt::new(
                    "T02",
                    RevisionLabel::Green,
                    [170, 168, 171],
                    RevisionLabel::Green,
                ),
                MultimodalPrompt::new("T03", RevisionLabel::Blue, [13, 11, 10], RevisionLabel::Red),
                MultimodalPrompt::new(
                    "T04",
                    RevisionLabel::Green,
                    [81, 79, 82],
                    RevisionLabel::Blue,
                ),
                MultimodalPrompt::new(
                    "T05",
                    RevisionLabel::Red,
                    [171, 170, 168],
                    RevisionLabel::Green,
                ),
            ],
            holdout_prompts: vec![
                MultimodalPrompt::new(
                    "H00",
                    RevisionLabel::Green,
                    [11, 12, 10],
                    RevisionLabel::Red,
                ),
                MultimodalPrompt::new("H01", RevisionLabel::Red, [79, 83, 80], RevisionLabel::Blue),
                MultimodalPrompt::new(
                    "H02",
                    RevisionLabel::Blue,
                    [172, 169, 170],
                    RevisionLabel::Green,
                ),
            ],
            examiner: RevisionExaminer,
        }
    }

    pub fn train_prompts(&self) -> &[MultimodalPrompt] {
        &self.train_prompts
    }

    pub fn holdout_prompts(&self) -> &[MultimodalPrompt] {
        &self.holdout_prompts
    }

    pub fn commit_label(&self, prompt: &MultimodalPrompt, label: RevisionLabel) -> Feedback {
        self.examiner.score(prompt, label)
    }
}

impl CoreWorld for MultimodalRevisionWorld {
    type Stimulus = MultimodalPrompt;
    type Response = RevisionLabel;

    fn commit_response(&self, stimulus: &Self::Stimulus, response: Self::Response) -> Feedback {
        self.commit_label(stimulus, response)
    }
}

impl MultimodalPrompt {
    fn new(
        id: impl Into<String>,
        text_hint: RevisionLabel,
        visual_bytes: impl IntoIterator<Item = u8>,
        target: RevisionLabel,
    ) -> Self {
        Self {
            id: id.into(),
            text_hint,
            visual_bytes: visual_bytes.into_iter().collect(),
            target,
        }
    }
}

#[derive(Debug, Clone)]
struct RevisionExaminer;

impl RevisionExaminer {
    fn score(&self, prompt: &MultimodalPrompt, label: RevisionLabel) -> Feedback {
        if label == prompt.target {
            Feedback::Reward
        } else {
            Feedback::Punishment
        }
    }
}

#[derive(Debug, Default, Clone)]
pub struct MultimodalRevisionLearner {
    visual_prototypes: HashMap<RevisionLabel, Vec<Vec<u8>>>,
    text_label_scores: HashMap<TextLabel, i32>,
    prompt_label_attempts: HashMap<PromptLabel, usize>,
    memory_rows: usize,
}

impl MultimodalRevisionLearner {
    pub fn select_label(&self, prompt: &MultimodalPrompt) -> RevisionLabel {
        self.revised_label(prompt)
    }

    pub fn select_label_for_mode(
        &self,
        prompt: &MultimodalPrompt,
        mode: TeacherMode,
    ) -> RevisionLabel {
        if mode.exploration_enabled() {
            self.confident_visual_label(prompt)
                .or_else(|| self.first_untried_label(prompt))
                .unwrap_or_else(|| self.revised_label(prompt))
        } else {
            self.revised_label(prompt)
        }
    }

    pub fn receive_feedback(
        &mut self,
        prompt: &MultimodalPrompt,
        label: RevisionLabel,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        if mode.memory_write_enabled() {
            *self
                .prompt_label_attempts
                .entry(PromptLabel::new(prompt, label))
                .or_default() += 1;
            *self
                .text_label_scores
                .entry(TextLabel::new(prompt.text_hint, label))
                .or_default() += feedback.score();
            if feedback == Feedback::Reward {
                self.visual_prototypes
                    .entry(label)
                    .or_default()
                    .push(prompt.visual_bytes.clone());
            }
            self.memory_rows += 1;
        }
        AuditTrace::for_mode(mode)
    }

    pub fn revision_needed(&self, prompt: &MultimodalPrompt) -> bool {
        self.text_first_label(prompt) != self.revised_label(prompt)
    }

    pub fn prototype_count(&self, label: RevisionLabel) -> usize {
        self.visual_prototypes
            .get(&label)
            .map(Vec::len)
            .unwrap_or_default()
    }

    pub fn memory_rows(&self) -> usize {
        self.memory_rows
    }

    fn revised_label(&self, prompt: &MultimodalPrompt) -> RevisionLabel {
        let text = self.text_first_label(prompt);
        let visual = self.best_visual_label(prompt);
        if self.visual_score(prompt, visual) > self.text_score(prompt, text) {
            visual
        } else {
            text
        }
    }

    fn text_first_label(&self, prompt: &MultimodalPrompt) -> RevisionLabel {
        REVISION_LABELS
            .into_iter()
            .fold((prompt.text_hint, i32::MIN), |(best, best_score), label| {
                let score = self.text_score(prompt, label);
                if score > best_score {
                    (label, score)
                } else {
                    (best, best_score)
                }
            })
            .0
    }

    fn best_visual_label(&self, prompt: &MultimodalPrompt) -> RevisionLabel {
        REVISION_LABELS
            .into_iter()
            .fold(
                (REVISION_LABELS[0], i32::MIN),
                |(best, best_score), label| {
                    let score = self.visual_score(prompt, label);
                    if score > best_score {
                        (label, score)
                    } else {
                        (best, best_score)
                    }
                },
            )
            .0
    }

    fn confident_visual_label(&self, prompt: &MultimodalPrompt) -> Option<RevisionLabel> {
        let label = self.best_visual_label(prompt);
        (self.visual_score(prompt, label) > 0).then_some(label)
    }

    fn text_score(&self, prompt: &MultimodalPrompt, label: RevisionLabel) -> i32 {
        self.text_label_scores
            .get(&TextLabel::new(prompt.text_hint, label))
            .copied()
            .unwrap_or_default()
    }

    fn visual_score(&self, prompt: &MultimodalPrompt, label: RevisionLabel) -> i32 {
        let Some(prototypes) = self.visual_prototypes.get(&label) else {
            return i32::MIN / 2;
        };
        prototypes
            .iter()
            .map(|prototype| 96 - manhattan_distance(&prompt.visual_bytes, prototype))
            .max()
            .unwrap_or(i32::MIN / 2)
    }

    fn first_untried_label(&self, prompt: &MultimodalPrompt) -> Option<RevisionLabel> {
        REVISION_LABELS.into_iter().find(|label| {
            !self
                .prompt_label_attempts
                .contains_key(&PromptLabel::new(prompt, *label))
        })
    }
}

impl CoreLearner<MultimodalRevisionWorld> for MultimodalRevisionLearner {
    fn select_response(
        &self,
        _world: &MultimodalRevisionWorld,
        stimulus: &MultimodalPrompt,
        mode: TeacherMode,
    ) -> RevisionLabel {
        self.select_label_for_mode(stimulus, mode)
    }

    fn receive_feedback(
        &mut self,
        _world: &MultimodalRevisionWorld,
        stimulus: &MultimodalPrompt,
        response: RevisionLabel,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        self.receive_feedback(stimulus, response, feedback, mode)
    }

    fn memory_rows(&self) -> Option<usize> {
        Some(self.memory_rows())
    }
}

pub type MultimodalRevisionPhaseResult = CorePhaseResult;

pub fn train_multimodal_revision(
    world: &MultimodalRevisionWorld,
    learner: &mut MultimodalRevisionLearner,
    repeats: usize,
) -> Vec<MultimodalRevisionPhaseResult> {
    train_core_repeats(world.train_prompts(), world, learner, repeats)
}

pub fn run_multimodal_revision_phase(
    prompts: &[MultimodalPrompt],
    world: &MultimodalRevisionWorld,
    learner: &mut MultimodalRevisionLearner,
    mode: TeacherMode,
) -> MultimodalRevisionPhaseResult {
    run_core_phase(prompts, world, learner, mode)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
struct TextLabel {
    text_hint: RevisionLabel,
    label: RevisionLabel,
}

impl TextLabel {
    fn new(text_hint: RevisionLabel, label: RevisionLabel) -> Self {
        Self { text_hint, label }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct PromptLabel {
    prompt_id: String,
    label: RevisionLabel,
}

impl PromptLabel {
    fn new(prompt: &MultimodalPrompt, label: RevisionLabel) -> Self {
        Self {
            prompt_id: prompt.id.clone(),
            label,
        }
    }
}

fn manhattan_distance(left: &[u8], right: &[u8]) -> i32 {
    let value_distance: u32 = left
        .iter()
        .zip(right)
        .map(|(left, right)| left.abs_diff(*right) as u32)
        .sum();
    let length_distance = left.len().abs_diff(right.len()) as u32 * u8::MAX as u32;
    (value_distance + length_distance) as i32
}
