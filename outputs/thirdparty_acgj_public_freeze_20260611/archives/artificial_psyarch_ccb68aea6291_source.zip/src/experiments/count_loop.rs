use std::collections::HashMap;

use serde::{Deserialize, Serialize};

use crate::core::ap::{AuditTrace, Feedback, TeacherMode};
use crate::core::runner::{
    CoreLearner, CorePhaseResult, CoreWorld, run_core_phase, train_core_repeats,
};
use crate::experiments::local_runner::{ExperimentRunConfig, run_count_loop_records};
use crate::experiments::records::ExperimentRun;
use crate::experiments::registry::ExperimentRegistryEntry;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum CountAction {
    Add,
    Remove,
}

pub const COUNT_ACTIONS: [CountAction; 2] = [CountAction::Add, CountAction::Remove];

pub const fn registry_entry() -> ExperimentRegistryEntry {
    ExperimentRegistryEntry::new(10, "count_loop", run_registry_entry)
}

fn run_registry_entry(config: ExperimentRunConfig) -> Vec<ExperimentRun> {
    vec![run_count_loop_records(config)]
}

inventory::submit! {
    registry_entry()
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct CountState {
    pub id: String,
    pub object_count: u8,
    pub target_count: u8,
}

#[derive(Debug, Clone)]
pub struct CountLoopWorld {
    train_states: Vec<CountState>,
    holdout_states: Vec<CountState>,
    examiner: CountLoopExaminer,
}

impl CountLoopWorld {
    pub fn canonical() -> Self {
        Self {
            train_states: vec![
                CountState::new("T00", 0, 1),
                CountState::new("T01", 1, 2),
                CountState::new("T02", 3, 2),
                CountState::new("T03", 4, 3),
                CountState::new("T04", 2, 3),
                CountState::new("T05", 5, 4),
            ],
            holdout_states: vec![
                CountState::new("H00", 2, 1),
                CountState::new("H01", 3, 4),
                CountState::new("H02", 4, 5),
                CountState::new("H03", 1, 0),
            ],
            examiner: CountLoopExaminer,
        }
    }

    pub fn train_states(&self) -> &[CountState] {
        &self.train_states
    }

    pub fn holdout_states(&self) -> &[CountState] {
        &self.holdout_states
    }

    pub fn commit_action(&self, state: &CountState, action: CountAction) -> Feedback {
        self.examiner.score(state, action)
    }
}

impl CoreWorld for CountLoopWorld {
    type Stimulus = CountState;
    type Response = CountAction;

    fn commit_response(&self, stimulus: &Self::Stimulus, response: Self::Response) -> Feedback {
        self.commit_action(stimulus, response)
    }
}

impl CountState {
    fn new(id: impl Into<String>, object_count: u8, target_count: u8) -> Self {
        Self {
            id: id.into(),
            object_count,
            target_count,
        }
    }

    pub fn delta_sign(&self) -> DeltaSign {
        match self.target_count.cmp(&self.object_count) {
            std::cmp::Ordering::Greater => DeltaSign::NeedMore,
            std::cmp::Ordering::Less => DeltaSign::NeedFewer,
            std::cmp::Ordering::Equal => DeltaSign::Satisfied,
        }
    }
}

#[derive(Debug, Clone)]
struct CountLoopExaminer;

impl CountLoopExaminer {
    fn score(&self, state: &CountState, action: CountAction) -> Feedback {
        if action == expected_action(state) {
            Feedback::Reward
        } else {
            Feedback::Punishment
        }
    }
}

#[derive(Debug, Default, Clone)]
pub struct CountLoopLearner {
    delta_action_scores: HashMap<DeltaAction, i32>,
    state_action_attempts: HashMap<StateAction, usize>,
    memory_rows: usize,
}

impl CountLoopLearner {
    pub fn select_action(&self, state: &CountState) -> CountAction {
        self.best_scored_action(state)
    }

    pub fn select_action_for_mode(&self, state: &CountState, mode: TeacherMode) -> CountAction {
        if mode.exploration_enabled() {
            self.first_untried_action(state)
                .unwrap_or_else(|| self.best_scored_action(state))
        } else {
            self.best_scored_action(state)
        }
    }

    pub fn receive_feedback(
        &mut self,
        state: &CountState,
        action: CountAction,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        if mode.memory_write_enabled() {
            *self
                .state_action_attempts
                .entry(StateAction::new(state, action))
                .or_default() += 1;
            *self
                .delta_action_scores
                .entry(DeltaAction::new(state.delta_sign(), action))
                .or_default() += feedback.score();
            self.memory_rows += 1;
        }
        AuditTrace::for_mode(mode)
    }

    pub fn score_action(&self, state: &CountState, action: CountAction) -> i32 {
        self.delta_action_scores
            .get(&DeltaAction::new(state.delta_sign(), action))
            .copied()
            .unwrap_or_default()
    }

    pub fn memory_rows(&self) -> usize {
        self.memory_rows
    }

    fn best_scored_action(&self, state: &CountState) -> CountAction {
        COUNT_ACTIONS
            .into_iter()
            .fold(
                (COUNT_ACTIONS[0], i32::MIN),
                |(best, best_score), action| {
                    let score = self.score_action(state, action);
                    if score > best_score {
                        (action, score)
                    } else {
                        (best, best_score)
                    }
                },
            )
            .0
    }

    fn first_untried_action(&self, state: &CountState) -> Option<CountAction> {
        COUNT_ACTIONS.into_iter().find(|action| {
            !self
                .state_action_attempts
                .contains_key(&StateAction::new(state, *action))
        })
    }
}

impl CoreLearner<CountLoopWorld> for CountLoopLearner {
    fn select_response(
        &self,
        _world: &CountLoopWorld,
        stimulus: &CountState,
        mode: TeacherMode,
    ) -> CountAction {
        self.select_action_for_mode(stimulus, mode)
    }

    fn receive_feedback(
        &mut self,
        _world: &CountLoopWorld,
        stimulus: &CountState,
        response: CountAction,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        self.receive_feedback(stimulus, response, feedback, mode)
    }

    fn memory_rows(&self) -> Option<usize> {
        Some(self.memory_rows())
    }
}

pub type CountPhaseResult = CorePhaseResult;

pub fn train_count_loop(
    world: &CountLoopWorld,
    learner: &mut CountLoopLearner,
    repeats: usize,
) -> Vec<CountPhaseResult> {
    train_core_repeats(world.train_states(), world, learner, repeats)
}

pub fn run_count_phase(
    states: &[CountState],
    world: &CountLoopWorld,
    learner: &mut CountLoopLearner,
    mode: TeacherMode,
) -> CountPhaseResult {
    run_core_phase(states, world, learner, mode)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum DeltaSign {
    NeedMore,
    NeedFewer,
    Satisfied,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
struct DeltaAction {
    delta: DeltaSign,
    action: CountAction,
}

impl DeltaAction {
    fn new(delta: DeltaSign, action: CountAction) -> Self {
        Self { delta, action }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct StateAction {
    state_id: String,
    action: CountAction,
}

impl StateAction {
    fn new(state: &CountState, action: CountAction) -> Self {
        Self {
            state_id: state.id.clone(),
            action,
        }
    }
}

fn expected_action(state: &CountState) -> CountAction {
    match state.delta_sign() {
        DeltaSign::NeedMore | DeltaSign::Satisfied => CountAction::Add,
        DeltaSign::NeedFewer => CountAction::Remove,
    }
}
