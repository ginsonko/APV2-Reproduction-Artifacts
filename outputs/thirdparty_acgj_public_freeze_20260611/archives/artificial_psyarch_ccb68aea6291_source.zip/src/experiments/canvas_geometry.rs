use std::collections::HashMap;

use serde::{Deserialize, Serialize};

use crate::core::ap::{AuditTrace, Feedback, TeacherMode};
use crate::core::runner::{
    CoreLearner, CorePhaseResult, CoreWorld, run_core_phase, train_core_repeats,
};
use crate::experiments::local_runner::{ExperimentRunConfig, run_canvas_geometry_records};
use crate::experiments::records::ExperimentRun;
use crate::experiments::registry::ExperimentRegistryEntry;

pub const fn registry_entry() -> ExperimentRegistryEntry {
    ExperimentRegistryEntry::new(70, "canvas_geometry", run_registry_entry)
}

fn run_registry_entry(config: ExperimentRunConfig) -> Vec<ExperimentRun> {
    vec![run_canvas_geometry_records(config)]
}

inventory::submit! {
    registry_entry()
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum GeometryAction {
    DrawHorizontal,
    DrawVertical,
    DrawDiagonalUp,
    DrawDiagonalDown,
}

pub const GEOMETRY_ACTIONS: [GeometryAction; 4] = [
    GeometryAction::DrawHorizontal,
    GeometryAction::DrawVertical,
    GeometryAction::DrawDiagonalUp,
    GeometryAction::DrawDiagonalDown,
];

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum GeometryRelation {
    Horizontal,
    Vertical,
    DiagonalUp,
    DiagonalDown,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct GeometryTask {
    pub id: String,
    pub start: (i8, i8),
    pub end: (i8, i8),
}

#[derive(Debug, Clone)]
pub struct CanvasGeometryWorld {
    train_tasks: Vec<GeometryTask>,
    holdout_tasks: Vec<GeometryTask>,
    examiner: GeometryExaminer,
}

impl CanvasGeometryWorld {
    pub fn canonical() -> Self {
        Self {
            train_tasks: vec![
                GeometryTask::new("T00", (0, 0), (4, 0)),
                GeometryTask::new("T01", (2, 3), (2, -1)),
                GeometryTask::new("T02", (0, 0), (3, 3)),
                GeometryTask::new("T03", (0, 3), (3, 0)),
                GeometryTask::new("T04", (-2, 1), (2, 1)),
                GeometryTask::new("T05", (-1, -2), (-1, 2)),
            ],
            holdout_tasks: vec![
                GeometryTask::new("H00", (-3, -2), (1, -2)),
                GeometryTask::new("H01", (4, 3), (4, -1)),
                GeometryTask::new("H02", (-2, -2), (1, 1)),
                GeometryTask::new("H03", (-2, 4), (2, 0)),
            ],
            examiner: GeometryExaminer,
        }
    }

    pub fn train_tasks(&self) -> &[GeometryTask] {
        &self.train_tasks
    }

    pub fn holdout_tasks(&self) -> &[GeometryTask] {
        &self.holdout_tasks
    }

    pub fn commit_action(&self, task: &GeometryTask, action: GeometryAction) -> Feedback {
        self.examiner.score(task, action)
    }
}

impl CoreWorld for CanvasGeometryWorld {
    type Stimulus = GeometryTask;
    type Response = GeometryAction;

    fn commit_response(&self, stimulus: &Self::Stimulus, response: Self::Response) -> Feedback {
        self.commit_action(stimulus, response)
    }
}

impl GeometryTask {
    fn new(id: impl Into<String>, start: (i8, i8), end: (i8, i8)) -> Self {
        Self {
            id: id.into(),
            start,
            end,
        }
    }

    pub fn relation(&self) -> GeometryRelation {
        let dx = self.end.0 - self.start.0;
        let dy = self.end.1 - self.start.1;
        match (dx, dy) {
            (_, 0) => GeometryRelation::Horizontal,
            (0, _) => GeometryRelation::Vertical,
            _ if dx.signum() == dy.signum() => GeometryRelation::DiagonalUp,
            _ => GeometryRelation::DiagonalDown,
        }
    }
}

#[derive(Debug, Clone)]
struct GeometryExaminer;

impl GeometryExaminer {
    fn score(&self, task: &GeometryTask, action: GeometryAction) -> Feedback {
        if action == expected_action(task.relation()) {
            Feedback::Reward
        } else {
            Feedback::Punishment
        }
    }
}

#[derive(Debug, Default, Clone)]
pub struct CanvasGeometryLearner {
    relation_action_scores: HashMap<RelationAction, i32>,
    task_action_attempts: HashMap<TaskAction, usize>,
    memory_rows: usize,
}

impl CanvasGeometryLearner {
    pub fn select_action(&self, task: &GeometryTask) -> GeometryAction {
        self.best_scored_action(task)
    }

    pub fn select_action_for_mode(&self, task: &GeometryTask, mode: TeacherMode) -> GeometryAction {
        if mode.exploration_enabled() {
            self.first_untried_action(task)
                .unwrap_or_else(|| self.best_scored_action(task))
        } else {
            self.best_scored_action(task)
        }
    }

    pub fn receive_feedback(
        &mut self,
        task: &GeometryTask,
        action: GeometryAction,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        if mode.memory_write_enabled() {
            *self
                .task_action_attempts
                .entry(TaskAction::new(task, action))
                .or_default() += 1;
            *self
                .relation_action_scores
                .entry(RelationAction::new(task.relation(), action))
                .or_default() += feedback.score();
            self.memory_rows += 1;
        }
        AuditTrace::for_mode(mode)
    }

    pub fn score_action(&self, task: &GeometryTask, action: GeometryAction) -> i32 {
        self.relation_action_scores
            .get(&RelationAction::new(task.relation(), action))
            .copied()
            .unwrap_or_default()
    }

    pub fn memory_rows(&self) -> usize {
        self.memory_rows
    }

    fn best_scored_action(&self, task: &GeometryTask) -> GeometryAction {
        GEOMETRY_ACTIONS
            .into_iter()
            .fold(
                (GEOMETRY_ACTIONS[0], i32::MIN),
                |(best, best_score), action| {
                    let score = self.score_action(task, action);
                    if score > best_score {
                        (action, score)
                    } else {
                        (best, best_score)
                    }
                },
            )
            .0
    }

    fn first_untried_action(&self, task: &GeometryTask) -> Option<GeometryAction> {
        GEOMETRY_ACTIONS.into_iter().find(|action| {
            !self
                .task_action_attempts
                .contains_key(&TaskAction::new(task, *action))
        })
    }
}

impl CoreLearner<CanvasGeometryWorld> for CanvasGeometryLearner {
    fn select_response(
        &self,
        _world: &CanvasGeometryWorld,
        stimulus: &GeometryTask,
        mode: TeacherMode,
    ) -> GeometryAction {
        self.select_action_for_mode(stimulus, mode)
    }

    fn receive_feedback(
        &mut self,
        _world: &CanvasGeometryWorld,
        stimulus: &GeometryTask,
        response: GeometryAction,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        self.receive_feedback(stimulus, response, feedback, mode)
    }

    fn memory_rows(&self) -> Option<usize> {
        Some(self.memory_rows())
    }
}

pub type CanvasGeometryPhaseResult = CorePhaseResult;

pub fn train_canvas_geometry(
    world: &CanvasGeometryWorld,
    learner: &mut CanvasGeometryLearner,
    repeats: usize,
) -> Vec<CanvasGeometryPhaseResult> {
    train_core_repeats(world.train_tasks(), world, learner, repeats)
}

pub fn run_canvas_geometry_phase(
    tasks: &[GeometryTask],
    world: &CanvasGeometryWorld,
    learner: &mut CanvasGeometryLearner,
    mode: TeacherMode,
) -> CanvasGeometryPhaseResult {
    run_core_phase(tasks, world, learner, mode)
}

fn expected_action(relation: GeometryRelation) -> GeometryAction {
    match relation {
        GeometryRelation::Horizontal => GeometryAction::DrawHorizontal,
        GeometryRelation::Vertical => GeometryAction::DrawVertical,
        GeometryRelation::DiagonalUp => GeometryAction::DrawDiagonalUp,
        GeometryRelation::DiagonalDown => GeometryAction::DrawDiagonalDown,
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
struct RelationAction {
    relation: GeometryRelation,
    action: GeometryAction,
}

impl RelationAction {
    fn new(relation: GeometryRelation, action: GeometryAction) -> Self {
        Self { relation, action }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct TaskAction {
    task_id: String,
    action: GeometryAction,
}

impl TaskAction {
    fn new(task: &GeometryTask, action: GeometryAction) -> Self {
        Self {
            task_id: task.id.clone(),
            action,
        }
    }
}
