use std::collections::HashMap;

use serde::{Deserialize, Serialize};

use crate::core::ap::{AuditTrace, Feedback, TeacherMode};
use crate::core::runner::{
    CoreLearner, CorePhaseResult, CoreWorld, run_core_phase, train_core_repeats,
};
use crate::experiments::local_runner::{ExperimentRunConfig, run_feature_combo_records};
use crate::experiments::records::ExperimentRun;
use crate::experiments::registry::ExperimentRegistryEntry;

pub const fn registry_entry() -> ExperimentRegistryEntry {
    ExperimentRegistryEntry::new(20, "feature_combo", run_registry_entry)
}

fn run_registry_entry(config: ExperimentRunConfig) -> Vec<ExperimentRun> {
    vec![run_feature_combo_records(config)]
}

inventory::submit! {
    registry_entry()
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
pub enum ComboAction {
    A,
    B,
    C,
}

pub const COMBO_ACTIONS: [ComboAction; 3] = [ComboAction::A, ComboAction::B, ComboAction::C];

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ComboState {
    pub id: String,
    pub shape: &'static str,
    pub color: &'static str,
}

#[derive(Debug, Clone)]
pub struct FeatureComboWorld {
    train_states: Vec<ComboState>,
    holdout_states: Vec<ComboState>,
    examiner: FeatureComboExaminer,
}

impl FeatureComboWorld {
    pub fn canonical() -> Self {
        let train_states = vec![
            ComboState::new("T00", "circle", "red"),
            ComboState::new("T01", "circle", "blue"),
            ComboState::new("T02", "square", "blue"),
            ComboState::new("T03", "square", "green"),
            ComboState::new("T04", "triangle", "red"),
            ComboState::new("T05", "triangle", "green"),
        ];
        let holdout_states = vec![
            ComboState::new("H00", "circle", "green"),
            ComboState::new("H01", "square", "red"),
            ComboState::new("H02", "triangle", "blue"),
        ];

        Self {
            train_states,
            holdout_states,
            examiner: FeatureComboExaminer,
        }
    }

    pub fn train_states(&self) -> &[ComboState] {
        &self.train_states
    }

    pub fn holdout_states(&self) -> &[ComboState] {
        &self.holdout_states
    }

    pub fn commit_action(&self, state: &ComboState, action: ComboAction) -> Feedback {
        self.examiner.score(state, action)
    }
}

impl CoreWorld for FeatureComboWorld {
    type Stimulus = ComboState;
    type Response = ComboAction;

    fn commit_response(&self, stimulus: &Self::Stimulus, response: Self::Response) -> Feedback {
        self.commit_action(stimulus, response)
    }
}

impl ComboState {
    fn new(id: impl Into<String>, shape: &'static str, color: &'static str) -> Self {
        Self {
            id: id.into(),
            shape,
            color,
        }
    }
}

#[derive(Debug, Clone)]
struct FeatureComboExaminer;

impl FeatureComboExaminer {
    fn score(&self, state: &ComboState, action: ComboAction) -> Feedback {
        if action == expected_action(state) {
            Feedback::Reward
        } else {
            Feedback::Punishment
        }
    }
}

#[derive(Debug, Default, Clone)]
pub struct FeatureComboLearner {
    feature_scores: HashMap<FeatureAction, i32>,
    state_action_attempts: HashMap<StateAction, usize>,
    memory_rows: usize,
}

impl FeatureComboLearner {
    pub fn select_action(&self, state: &ComboState) -> ComboAction {
        self.best_scored_action(state)
    }

    pub fn select_action_for_mode(&self, state: &ComboState, mode: TeacherMode) -> ComboAction {
        if mode.exploration_enabled() {
            self.first_untried_action(state)
                .unwrap_or_else(|| self.best_scored_action(state))
        } else {
            self.best_scored_action(state)
        }
    }

    fn best_scored_action(&self, state: &ComboState) -> ComboAction {
        COMBO_ACTIONS
            .into_iter()
            .fold(
                (COMBO_ACTIONS[0], i32::MIN),
                |(best, best_score), action| {
                    let score = self.score_action(state, action);
                    if score > best_score {
                        (action, score)
                    } else {
                        (best, best_score)
                    }
                },
            )
            .0
    }

    fn first_untried_action(&self, state: &ComboState) -> Option<ComboAction> {
        COMBO_ACTIONS.into_iter().find(|action| {
            !self
                .state_action_attempts
                .contains_key(&StateAction::new(state, *action))
        })
    }

    pub fn receive_feedback(
        &mut self,
        state: &ComboState,
        action: ComboAction,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        if mode.memory_write_enabled() {
            let delta = feedback.score();
            *self
                .state_action_attempts
                .entry(StateAction::new(state, action))
                .or_default() += 1;
            *self
                .feature_scores
                .entry(FeatureAction::shape(state.shape, action))
                .or_default() += delta;
            *self
                .feature_scores
                .entry(FeatureAction::color(state.color, action))
                .or_default() += delta;
            self.memory_rows += 1;
        }
        AuditTrace::for_mode(mode)
    }

    pub fn score_action(&self, state: &ComboState, action: ComboAction) -> i32 {
        self.feature_scores
            .get(&FeatureAction::shape(state.shape, action))
            .copied()
            .unwrap_or_default()
            + self
                .feature_scores
                .get(&FeatureAction::color(state.color, action))
                .copied()
                .unwrap_or_default()
    }

    pub fn memory_rows(&self) -> usize {
        self.memory_rows
    }
}

impl CoreLearner<FeatureComboWorld> for FeatureComboLearner {
    fn select_response(
        &self,
        _world: &FeatureComboWorld,
        stimulus: &ComboState,
        mode: TeacherMode,
    ) -> ComboAction {
        self.select_action_for_mode(stimulus, mode)
    }

    fn receive_feedback(
        &mut self,
        _world: &FeatureComboWorld,
        stimulus: &ComboState,
        response: ComboAction,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        self.receive_feedback(stimulus, response, feedback, mode)
    }

    fn memory_rows(&self) -> Option<usize> {
        Some(self.memory_rows())
    }
}

pub type ComboPhaseResult = CorePhaseResult;

pub fn train_feature_combo(
    world: &FeatureComboWorld,
    learner: &mut FeatureComboLearner,
    repeats: usize,
) -> Vec<ComboPhaseResult> {
    train_core_repeats(world.train_states(), world, learner, repeats)
}

pub fn run_combo_phase(
    states: &[ComboState],
    world: &FeatureComboWorld,
    learner: &mut FeatureComboLearner,
    mode: TeacherMode,
) -> ComboPhaseResult {
    run_core_phase(states, world, learner, mode)
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
enum FeatureKind {
    Shape,
    Color,
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct FeatureAction {
    kind: FeatureKind,
    value: &'static str,
    action: ComboAction,
}

impl FeatureAction {
    fn shape(value: &'static str, action: ComboAction) -> Self {
        Self {
            kind: FeatureKind::Shape,
            value,
            action,
        }
    }

    fn color(value: &'static str, action: ComboAction) -> Self {
        Self {
            kind: FeatureKind::Color,
            value,
            action,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct StateAction {
    state_id: String,
    action: ComboAction,
}

impl StateAction {
    fn new(state: &ComboState, action: ComboAction) -> Self {
        Self {
            state_id: state.id.clone(),
            action,
        }
    }
}

fn expected_action(state: &ComboState) -> ComboAction {
    let shape_scores = shape_contribution(state.shape);
    let color_scores = color_contribution(state.color);

    COMBO_ACTIONS
        .into_iter()
        .max_by_key(|action| {
            let index = *action as usize;
            shape_scores[index] + color_scores[index]
        })
        .expect("combo action set is non-empty")
}

fn shape_contribution(shape: &str) -> [i32; 3] {
    match shape {
        "circle" => [2, 0, 0],
        "square" => [0, 2, 0],
        "triangle" => [0, 0, 2],
        other => panic!("unknown shape {other}"),
    }
}

fn color_contribution(color: &str) -> [i32; 3] {
    match color {
        "red" => [1, 0, 0],
        "blue" => [0, 1, 0],
        "green" => [0, 0, 1],
        other => panic!("unknown color {other}"),
    }
}
