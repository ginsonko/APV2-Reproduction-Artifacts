use crate::experiments::local_runner::{ExperimentRunConfig, run_language_grounding_records};
use crate::experiments::records::ExperimentRun;
use crate::experiments::registry::ExperimentRegistryEntry;
use crate::language_core::{
    LanguageGroundingLearner, LanguageGroundingWorld, run_language_grounding_phase,
    train_language_grounding,
};

pub const fn registry_entry() -> ExperimentRegistryEntry {
    ExperimentRegistryEntry::new(95, "language_grounding", run_registry_entry)
}

fn run_registry_entry(config: ExperimentRunConfig) -> Vec<ExperimentRun> {
    vec![run_language_grounding_records(config)]
}

inventory::submit! {
    registry_entry()
}

pub use crate::language_core::{
    ActionTendency, AffectiveState, Agency, LanguageFrame, RelationMode, TimeOrientation,
};

pub fn train_language_state_grounding(
    world: &LanguageGroundingWorld,
    learner: &mut LanguageGroundingLearner,
    repeats: usize,
) -> Vec<crate::core::runner::CorePhaseResult> {
    train_language_grounding(world, learner, repeats)
}

pub fn run_language_state_grounding_phase(
    stimuli: &[crate::language::curriculum::LanguageGroundingStimulus],
    world: &LanguageGroundingWorld,
    learner: &mut LanguageGroundingLearner,
    mode: crate::ap::TeacherMode,
) -> crate::core::runner::CorePhaseResult {
    run_language_grounding_phase(stimuli, world, learner, mode)
}
