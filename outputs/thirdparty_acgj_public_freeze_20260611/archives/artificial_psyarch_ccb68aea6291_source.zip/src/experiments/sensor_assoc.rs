use std::collections::HashMap;

use serde::{Deserialize, Serialize};

use crate::core::ap::{AuditTrace, Feedback, TeacherMode};
use crate::core::runner::{
    CoreLearner, CorePhaseResult, CoreWorld, run_core_phase, train_core_repeats,
};
use crate::experiments::local_runner::{ExperimentRunConfig, run_sensor_assoc_records};
use crate::experiments::records::ExperimentRun;
use crate::experiments::registry::ExperimentRegistryEntry;

pub const fn registry_entry() -> ExperimentRegistryEntry {
    ExperimentRegistryEntry::new(30, "sensor_assoc", run_registry_entry)
}

fn run_registry_entry(config: ExperimentRunConfig) -> Vec<ExperimentRun> {
    vec![run_sensor_assoc_records(config)]
}

inventory::submit! {
    registry_entry()
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
pub enum SensorLabel {
    Alpha,
    Beta,
    Gamma,
}

pub const SENSOR_LABELS: [SensorLabel; 3] =
    [SensorLabel::Alpha, SensorLabel::Beta, SensorLabel::Gamma];

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SensorSample {
    pub id: String,
    pub bytes: Vec<u8>,
    pub label: SensorLabel,
}

#[derive(Debug, Clone)]
pub struct SensorAssocWorld {
    train_samples: Vec<SensorSample>,
    holdout_samples: Vec<SensorSample>,
    examiner: SensorAssocExaminer,
}

impl SensorAssocWorld {
    pub fn canonical() -> Self {
        Self {
            train_samples: vec![
                SensorSample::new("T00", [10, 12, 11, 9], SensorLabel::Alpha),
                SensorSample::new("T01", [12, 11, 9, 10], SensorLabel::Alpha),
                SensorSample::new("T02", [80, 82, 79, 81], SensorLabel::Beta),
                SensorSample::new("T03", [83, 80, 81, 78], SensorLabel::Beta),
                SensorSample::new("T04", [170, 168, 171, 169], SensorLabel::Gamma),
                SensorSample::new("T05", [172, 169, 170, 168], SensorLabel::Gamma),
            ],
            holdout_samples: vec![
                SensorSample::new("H00", [11, 10, 12, 10], SensorLabel::Alpha),
                SensorSample::new("H01", [79, 83, 80, 82], SensorLabel::Beta),
                SensorSample::new("H02", [171, 170, 169, 172], SensorLabel::Gamma),
            ],
            examiner: SensorAssocExaminer,
        }
    }

    pub fn train_samples(&self) -> &[SensorSample] {
        &self.train_samples
    }

    pub fn holdout_samples(&self) -> &[SensorSample] {
        &self.holdout_samples
    }

    pub fn commit_label(&self, sample: &SensorSample, label: SensorLabel) -> Feedback {
        self.examiner.score(sample, label)
    }
}

impl CoreWorld for SensorAssocWorld {
    type Stimulus = SensorSample;
    type Response = SensorLabel;

    fn commit_response(&self, stimulus: &Self::Stimulus, response: Self::Response) -> Feedback {
        self.commit_label(stimulus, response)
    }
}

impl SensorSample {
    fn new(id: impl Into<String>, bytes: impl IntoIterator<Item = u8>, label: SensorLabel) -> Self {
        Self {
            id: id.into(),
            bytes: bytes.into_iter().collect(),
            label,
        }
    }
}

#[derive(Debug, Clone)]
struct SensorAssocExaminer;

impl SensorAssocExaminer {
    fn score(&self, sample: &SensorSample, label: SensorLabel) -> Feedback {
        if label == sample.label {
            Feedback::Reward
        } else {
            Feedback::Punishment
        }
    }
}

#[derive(Debug, Default, Clone)]
pub struct SensorAssocLearner {
    prototypes: HashMap<SensorLabel, Vec<Vec<u8>>>,
    sample_label_attempts: HashMap<SampleLabel, usize>,
    memory_rows: usize,
}

impl SensorAssocLearner {
    pub fn select_label(&self, sample: &SensorSample) -> SensorLabel {
        self.best_scored_label(sample)
    }

    pub fn select_label_for_mode(&self, sample: &SensorSample, mode: TeacherMode) -> SensorLabel {
        if mode.exploration_enabled() {
            self.first_untried_label(sample)
                .unwrap_or_else(|| self.best_scored_label(sample))
        } else {
            self.best_scored_label(sample)
        }
    }

    pub fn receive_feedback(
        &mut self,
        sample: &SensorSample,
        label: SensorLabel,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        if mode.memory_write_enabled() {
            *self
                .sample_label_attempts
                .entry(SampleLabel::new(sample, label))
                .or_default() += 1;
            if feedback == Feedback::Reward {
                self.prototypes
                    .entry(label)
                    .or_default()
                    .push(sample.bytes.clone());
            }
            self.memory_rows += 1;
        }
        AuditTrace::for_mode(mode)
    }

    pub fn score_label(&self, sample: &SensorSample, label: SensorLabel) -> i32 {
        let Some(prototypes) = self.prototypes.get(&label) else {
            return i32::MIN / 2;
        };

        prototypes
            .iter()
            .map(|prototype| -manhattan_distance(&sample.bytes, prototype))
            .max()
            .unwrap_or(i32::MIN / 2)
    }

    pub fn prototype_count(&self, label: SensorLabel) -> usize {
        self.prototypes
            .get(&label)
            .map(Vec::len)
            .unwrap_or_default()
    }

    pub fn memory_rows(&self) -> usize {
        self.memory_rows
    }

    fn best_scored_label(&self, sample: &SensorSample) -> SensorLabel {
        SENSOR_LABELS
            .into_iter()
            .fold((SENSOR_LABELS[0], i32::MIN), |(best, best_score), label| {
                let score = self.score_label(sample, label);
                if score > best_score {
                    (label, score)
                } else {
                    (best, best_score)
                }
            })
            .0
    }

    fn first_untried_label(&self, sample: &SensorSample) -> Option<SensorLabel> {
        SENSOR_LABELS.into_iter().find(|label| {
            !self
                .sample_label_attempts
                .contains_key(&SampleLabel::new(sample, *label))
        })
    }
}

impl CoreLearner<SensorAssocWorld> for SensorAssocLearner {
    fn select_response(
        &self,
        _world: &SensorAssocWorld,
        stimulus: &SensorSample,
        mode: TeacherMode,
    ) -> SensorLabel {
        self.select_label_for_mode(stimulus, mode)
    }

    fn receive_feedback(
        &mut self,
        _world: &SensorAssocWorld,
        stimulus: &SensorSample,
        response: SensorLabel,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        self.receive_feedback(stimulus, response, feedback, mode)
    }

    fn memory_rows(&self) -> Option<usize> {
        Some(self.memory_rows())
    }
}

pub type SensorAssocPhaseResult = CorePhaseResult;

pub fn train_sensor_assoc(
    world: &SensorAssocWorld,
    learner: &mut SensorAssocLearner,
    repeats: usize,
) -> Vec<SensorAssocPhaseResult> {
    train_core_repeats(world.train_samples(), world, learner, repeats)
}

pub fn run_sensor_assoc_phase(
    samples: &[SensorSample],
    world: &SensorAssocWorld,
    learner: &mut SensorAssocLearner,
    mode: TeacherMode,
) -> SensorAssocPhaseResult {
    run_core_phase(samples, world, learner, mode)
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct SampleLabel {
    sample_id: String,
    label: SensorLabel,
}

impl SampleLabel {
    fn new(sample: &SensorSample, label: SensorLabel) -> Self {
        Self {
            sample_id: sample.id.clone(),
            label,
        }
    }
}

fn manhattan_distance(left: &[u8], right: &[u8]) -> i32 {
    let value_distance: u32 = left
        .iter()
        .zip(right)
        .map(|(left, right)| left.abs_diff(*right) as u32)
        .sum();
    let length_distance = left.len().abs_diff(right.len()) as u32 * u8::MAX as u32;
    (value_distance + length_distance) as i32
}
