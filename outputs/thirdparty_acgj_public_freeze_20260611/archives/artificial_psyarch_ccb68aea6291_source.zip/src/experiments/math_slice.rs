use std::collections::HashMap;

use serde::{Deserialize, Serialize};

use crate::core::ap::{AuditTrace, Feedback, TeacherMode};
use crate::core::runner::{
    CoreLearner, CorePhaseResult, CoreWorld, run_core_phase, train_core_repeats,
};
use crate::experiments::local_runner::{ExperimentRunConfig, run_no_solver_math_records};
use crate::experiments::records::ExperimentRun;
use crate::experiments::registry::ExperimentRegistryEntry;

const MAX_MATH_ANSWER: u16 = 24;

pub const fn registry_entry() -> ExperimentRegistryEntry {
    ExperimentRegistryEntry::new(40, "math_slice", run_registry_entry)
}

fn run_registry_entry(config: ExperimentRunConfig) -> Vec<ExperimentRun> {
    run_no_solver_math_records(config)
}

inventory::submit! {
    registry_entry()
}

#[repr(usize)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum NoSolverMathSuite {
    AddSub = 0,
    MulDiv = 1,
    VerticalAddSub = 2,
    VerticalMultiply = 3,
    VerticalDivision = 4,
}

impl NoSolverMathSuite {
    pub const ALL: [Self; 5] = [
        Self::AddSub,
        Self::MulDiv,
        Self::VerticalAddSub,
        Self::VerticalMultiply,
        Self::VerticalDivision,
    ];

    pub fn experiment_id(self) -> &'static str {
        SUITE_METADATA[self as usize].experiment_id
    }

    pub fn display_name(self) -> &'static str {
        SUITE_METADATA[self as usize].display_name
    }
}

#[derive(Debug, Clone, Copy)]
struct SuiteMetadata {
    experiment_id: &'static str,
    display_name: &'static str,
    questions: fn() -> (Vec<MathQuestion>, Vec<MathQuestion>),
}

const SUITE_METADATA: [SuiteMetadata; 5] = [
    SuiteMetadata {
        experiment_id: "math_slice_add_sub",
        display_name: "NoSolver-0 ten-within add/sub",
        questions: add_sub_questions,
    },
    SuiteMetadata {
        experiment_id: "math_slice_mul_div",
        display_name: "NoSolver-1 small mul/div",
        questions: mul_div_questions,
    },
    SuiteMetadata {
        experiment_id: "math_slice_vertical_add_sub",
        display_name: "NoSolver-2 vertical add/sub slice",
        questions: vertical_add_sub_questions,
    },
    SuiteMetadata {
        experiment_id: "math_slice_vertical_multiply",
        display_name: "NoSolver-3 vertical multiply slice",
        questions: vertical_multiply_questions,
    },
    SuiteMetadata {
        experiment_id: "math_slice_vertical_division",
        display_name: "NoSolver-4 one-digit vertical division slice",
        questions: vertical_division_questions,
    },
];

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum MathOp {
    Add,
    Sub,
    Mul,
    Div,
    VerticalAdd,
    VerticalSub,
    VerticalMul,
    VerticalDiv,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
pub struct MathAnswer(pub u16);

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct MathQuestion {
    pub id: String,
    pub left: u16,
    pub op: MathOp,
    pub right: u16,
    pub result: u16,
}

#[derive(Debug, Clone)]
pub struct NoSolverMathWorld {
    suite: NoSolverMathSuite,
    train_questions: Vec<MathQuestion>,
    holdout_questions: Vec<MathQuestion>,
    examiner: NoSolverMathExaminer,
}

impl NoSolverMathWorld {
    pub fn canonical() -> Self {
        Self::for_suite(NoSolverMathSuite::AddSub)
    }

    pub fn canonical_suites() -> Vec<Self> {
        NoSolverMathSuite::ALL
            .into_iter()
            .map(Self::for_suite)
            .collect()
    }

    pub fn for_suite(suite: NoSolverMathSuite) -> Self {
        let (train_questions, holdout_questions) = canonical_questions(suite);
        Self {
            suite,
            train_questions,
            holdout_questions,
            examiner: NoSolverMathExaminer,
        }
    }

    pub fn suite(&self) -> NoSolverMathSuite {
        self.suite
    }

    pub fn experiment_id(&self) -> &'static str {
        self.suite.experiment_id()
    }

    pub fn display_name(&self) -> &'static str {
        self.suite.display_name()
    }

    pub fn train_questions(&self) -> &[MathQuestion] {
        &self.train_questions
    }

    pub fn holdout_questions(&self) -> &[MathQuestion] {
        &self.holdout_questions
    }

    pub fn commit_answer(&self, question: &MathQuestion, answer: MathAnswer) -> Feedback {
        self.examiner.score(question, answer)
    }
}

impl CoreWorld for NoSolverMathWorld {
    type Stimulus = MathQuestion;
    type Response = MathAnswer;

    fn commit_response(&self, stimulus: &Self::Stimulus, response: Self::Response) -> Feedback {
        self.commit_answer(stimulus, response)
    }
}

impl MathQuestion {
    fn new(id: impl Into<String>, left: u16, op: MathOp, right: u16, result: u16) -> Self {
        Self {
            id: id.into(),
            left,
            op,
            right,
            result,
        }
    }
}

#[derive(Debug, Clone)]
struct NoSolverMathExaminer;

impl NoSolverMathExaminer {
    fn score(&self, question: &MathQuestion, answer: MathAnswer) -> Feedback {
        if answer.0 == question.result {
            Feedback::Reward
        } else {
            Feedback::Punishment
        }
    }
}

#[derive(Debug, Default, Clone)]
pub struct NoSolverMathLearner {
    processes: HashMap<OperationSlice, MathProcess>,
    successors: HashMap<u16, u16>,
    predecessors: HashMap<u16, u16>,
    question_answer_attempts: HashMap<QuestionAnswer, usize>,
    memory_rows: usize,
}

impl NoSolverMathLearner {
    pub fn select_answer(&self, question: &MathQuestion) -> MathAnswer {
        self.best_scored_answer(question)
    }

    pub fn select_answer_for_mode(&self, question: &MathQuestion, mode: TeacherMode) -> MathAnswer {
        let learned_answer = self.best_scored_answer(question);
        if self.score_answer(question, learned_answer) > 0 {
            return learned_answer;
        }
        if mode.exploration_enabled() {
            self.first_untried_answer(question)
                .unwrap_or(learned_answer)
        } else {
            learned_answer
        }
    }

    pub fn receive_feedback(
        &mut self,
        question: &MathQuestion,
        answer: MathAnswer,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        if mode.memory_write_enabled() {
            *self
                .question_answer_attempts
                .entry(QuestionAnswer::new(question, answer))
                .or_default() += 1;
            if feedback == Feedback::Reward {
                self.learn_rewarded_answer(question, answer);
            }
            self.memory_rows += 1;
        }
        AuditTrace::for_mode(mode)
    }

    pub fn score_answer(&self, question: &MathQuestion, answer: MathAnswer) -> i32 {
        match self.apply_learned_process(question) {
            Some(predicted) if predicted == answer.0 => 1,
            Some(_) => -1,
            None => 0,
        }
    }

    pub fn learned_slice(&self, op: MathOp, right: u16) -> Option<MathSlice> {
        match self.processes.get(&OperationSlice::new(op, right)) {
            Some(MathProcess::Offset(slice)) => Some(*slice),
            _ => None,
        }
    }

    pub fn learned_process(&self, op: MathOp, right: u16) -> Option<MathProcess> {
        self.processes.get(&OperationSlice::new(op, right)).copied()
    }

    pub fn memory_rows(&self) -> usize {
        self.memory_rows
    }

    fn best_scored_answer(&self, question: &MathQuestion) -> MathAnswer {
        candidate_answers()
            .fold((MathAnswer(0), i32::MIN), |(best, best_score), answer| {
                let score = self.score_answer(question, answer);
                if score > best_score {
                    (answer, score)
                } else {
                    (best, best_score)
                }
            })
            .0
    }

    fn first_untried_answer(&self, question: &MathQuestion) -> Option<MathAnswer> {
        candidate_answers().find(|answer| {
            !self
                .question_answer_attempts
                .contains_key(&QuestionAnswer::new(question, *answer))
        })
    }

    fn learn_rewarded_answer(&mut self, question: &MathQuestion, answer: MathAnswer) {
        self.remember_counting_span(0, question.left);
        self.remember_counting_span(question.left, answer.0);
        self.remember_counting_span(0, question.right);
        self.remember_counting_span(0, answer.0);
        self.processes.insert(
            OperationSlice::new(question.op, question.right),
            MathProcess::from_rewarded_pair(question),
        );
    }

    fn remember_counting_span(&mut self, left: u16, right: u16) {
        let lower = left.min(right);
        let higher = left.max(right);
        for value in lower..higher {
            self.successors.insert(value, value + 1);
            self.predecessors.insert(value + 1, value);
        }
    }

    fn apply_learned_process(&self, question: &MathQuestion) -> Option<u16> {
        let process = self.learned_process(question.op, question.right)?;
        match process {
            MathProcess::Offset(slice) => self.apply_offset(question.left, slice),
            MathProcess::Scale { factor } => self.multiply_by_repeated_add(question.left, factor),
            MathProcess::Divide { divisor } => {
                self.divide_by_repeated_subtract(question.left, divisor)
            }
        }
    }

    fn apply_offset(&self, left: u16, slice: MathSlice) -> Option<u16> {
        let mut cursor = left;
        for _ in 0..slice.steps {
            cursor = self.step_once(cursor, slice.direction)?;
        }
        Some(cursor)
    }

    fn multiply_by_repeated_add(&self, left: u16, factor: u16) -> Option<u16> {
        let mut total = 0;
        for _ in 0..factor {
            total = self.advance_forward(total, left)?;
        }
        Some(total)
    }

    fn divide_by_repeated_subtract(&self, left: u16, divisor: u16) -> Option<u16> {
        if divisor == 0 {
            return None;
        }
        let mut remainder = left;
        let mut groups = 0;
        while remainder >= divisor {
            remainder = self.advance_backward(remainder, divisor)?;
            groups = self.step_once(groups, MathDirection::Forward)?;
        }
        (remainder == 0).then_some(groups)
    }

    fn advance_forward(&self, start: u16, steps: u16) -> Option<u16> {
        let mut cursor = start;
        for _ in 0..steps {
            cursor = self.step_once(cursor, MathDirection::Forward)?;
        }
        Some(cursor)
    }

    fn advance_backward(&self, start: u16, steps: u16) -> Option<u16> {
        let mut cursor = start;
        for _ in 0..steps {
            cursor = self.step_once(cursor, MathDirection::Backward)?;
        }
        Some(cursor)
    }

    fn step_once(&self, cursor: u16, direction: MathDirection) -> Option<u16> {
        match direction {
            MathDirection::Forward => self.successors.get(&cursor).copied(),
            MathDirection::Backward => self.predecessors.get(&cursor).copied(),
            MathDirection::Still => Some(cursor),
        }
    }
}

impl CoreLearner<NoSolverMathWorld> for NoSolverMathLearner {
    fn select_response(
        &self,
        _world: &NoSolverMathWorld,
        stimulus: &MathQuestion,
        mode: TeacherMode,
    ) -> MathAnswer {
        self.select_answer_for_mode(stimulus, mode)
    }

    fn receive_feedback(
        &mut self,
        _world: &NoSolverMathWorld,
        stimulus: &MathQuestion,
        response: MathAnswer,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        self.receive_feedback(stimulus, response, feedback, mode)
    }

    fn memory_rows(&self) -> Option<usize> {
        Some(self.memory_rows())
    }
}

pub type NoSolverMathPhaseResult = CorePhaseResult;

pub fn train_no_solver_math(
    world: &NoSolverMathWorld,
    learner: &mut NoSolverMathLearner,
    repeats: usize,
) -> Vec<NoSolverMathPhaseResult> {
    train_core_repeats(world.train_questions(), world, learner, repeats)
}

pub fn run_no_solver_math_phase(
    questions: &[MathQuestion],
    world: &NoSolverMathWorld,
    learner: &mut NoSolverMathLearner,
    mode: TeacherMode,
) -> NoSolverMathPhaseResult {
    run_core_phase(questions, world, learner, mode)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum MathDirection {
    Forward,
    Backward,
    Still,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct MathSlice {
    pub direction: MathDirection,
    pub steps: u16,
}

impl MathSlice {
    fn from_observed_pair(left: u16, result: u16) -> Self {
        let direction = match result.cmp(&left) {
            std::cmp::Ordering::Greater => MathDirection::Forward,
            std::cmp::Ordering::Less => MathDirection::Backward,
            std::cmp::Ordering::Equal => MathDirection::Still,
        };
        Self {
            direction,
            steps: left.abs_diff(result),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum MathProcess {
    Offset(MathSlice),
    Scale { factor: u16 },
    Divide { divisor: u16 },
}

impl MathProcess {
    fn from_rewarded_pair(question: &MathQuestion) -> Self {
        match question.op {
            MathOp::Add | MathOp::Sub | MathOp::VerticalAdd | MathOp::VerticalSub => Self::Offset(
                MathSlice::from_observed_pair(question.left, question.result),
            ),
            MathOp::Mul | MathOp::VerticalMul => Self::Scale {
                factor: question.right,
            },
            MathOp::Div | MathOp::VerticalDiv => Self::Divide {
                divisor: question.right,
            },
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
struct OperationSlice {
    op: MathOp,
    right: u16,
}

impl OperationSlice {
    fn new(op: MathOp, right: u16) -> Self {
        Self { op, right }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct QuestionAnswer {
    question_id: String,
    answer: MathAnswer,
}

impl QuestionAnswer {
    fn new(question: &MathQuestion, answer: MathAnswer) -> Self {
        Self {
            question_id: question.id.clone(),
            answer,
        }
    }
}

fn candidate_answers() -> impl Iterator<Item = MathAnswer> {
    (0..=MAX_MATH_ANSWER).map(MathAnswer)
}

fn canonical_questions(suite: NoSolverMathSuite) -> (Vec<MathQuestion>, Vec<MathQuestion>) {
    (SUITE_METADATA[suite as usize].questions)()
}

fn add_sub_questions() -> (Vec<MathQuestion>, Vec<MathQuestion>) {
    (
        vec![
            MathQuestion::new("AS-T00", 0, MathOp::Add, 1, 1),
            MathQuestion::new("AS-T01", 1, MathOp::Add, 1, 2),
            MathQuestion::new("AS-T02", 2, MathOp::Add, 1, 3),
            MathQuestion::new("AS-T03", 3, MathOp::Add, 1, 4),
            MathQuestion::new("AS-T04", 4, MathOp::Add, 1, 5),
            MathQuestion::new("AS-T05", 5, MathOp::Add, 1, 6),
            MathQuestion::new("AS-T06", 6, MathOp::Add, 1, 7),
            MathQuestion::new("AS-T07", 0, MathOp::Add, 0, 0),
            MathQuestion::new("AS-T08", 0, MathOp::Sub, 0, 0),
            MathQuestion::new("AS-T09", 0, MathOp::Add, 2, 2),
            MathQuestion::new("AS-T10", 1, MathOp::Add, 2, 3),
            MathQuestion::new("AS-T11", 2, MathOp::Add, 2, 4),
            MathQuestion::new("AS-T12", 1, MathOp::Sub, 1, 0),
            MathQuestion::new("AS-T13", 2, MathOp::Sub, 1, 1),
            MathQuestion::new("AS-T14", 3, MathOp::Sub, 1, 2),
            MathQuestion::new("AS-T15", 4, MathOp::Sub, 1, 3),
            MathQuestion::new("AS-T16", 5, MathOp::Sub, 1, 4),
            MathQuestion::new("AS-T17", 2, MathOp::Sub, 2, 0),
            MathQuestion::new("AS-T18", 3, MathOp::Sub, 2, 1),
            MathQuestion::new("AS-T19", 4, MathOp::Sub, 2, 2),
        ],
        vec![
            MathQuestion::new("AS-H00", 3, MathOp::Add, 2, 5),
            MathQuestion::new("AS-H01", 4, MathOp::Add, 2, 6),
            MathQuestion::new("AS-H02", 5, MathOp::Sub, 2, 3),
            MathQuestion::new("AS-H03", 6, MathOp::Sub, 2, 4),
            MathQuestion::new("AS-H04", 4, MathOp::Add, 0, 4),
            MathQuestion::new("AS-H05", 4, MathOp::Sub, 0, 4),
        ],
    )
}

fn mul_div_questions() -> (Vec<MathQuestion>, Vec<MathQuestion>) {
    (
        vec![
            MathQuestion::new("MD-T00", 0, MathOp::Add, 1, 1),
            MathQuestion::new("MD-T01", 1, MathOp::Add, 1, 2),
            MathQuestion::new("MD-T02", 2, MathOp::Add, 1, 3),
            MathQuestion::new("MD-T03", 3, MathOp::Add, 1, 4),
            MathQuestion::new("MD-T04", 4, MathOp::Add, 1, 5),
            MathQuestion::new("MD-T05", 5, MathOp::Add, 1, 6),
            MathQuestion::new("MD-T06", 6, MathOp::Add, 1, 7),
            MathQuestion::new("MD-T07", 1, MathOp::Mul, 2, 2),
            MathQuestion::new("MD-T08", 1, MathOp::Mul, 3, 3),
            MathQuestion::new("MD-T09", 2, MathOp::Mul, 2, 4),
            MathQuestion::new("MD-T10", 2, MathOp::Div, 2, 1),
            MathQuestion::new("MD-T11", 3, MathOp::Div, 3, 1),
            MathQuestion::new("MD-T12", 4, MathOp::Div, 2, 2),
        ],
        vec![
            MathQuestion::new("MD-H00", 3, MathOp::Mul, 2, 6),
            MathQuestion::new("MD-H01", 2, MathOp::Mul, 3, 6),
            MathQuestion::new("MD-H02", 6, MathOp::Div, 2, 3),
            MathQuestion::new("MD-H03", 6, MathOp::Div, 3, 2),
        ],
    )
}

fn vertical_add_sub_questions() -> (Vec<MathQuestion>, Vec<MathQuestion>) {
    (
        vec![
            MathQuestion::new("VA-T00", 0, MathOp::Add, 1, 1),
            MathQuestion::new("VA-T01", 1, MathOp::Add, 1, 2),
            MathQuestion::new("VA-T02", 2, MathOp::Add, 1, 3),
            MathQuestion::new("VA-T03", 3, MathOp::Add, 1, 4),
            MathQuestion::new("VA-T04", 4, MathOp::Add, 1, 5),
            MathQuestion::new("VA-T05", 5, MathOp::Add, 1, 6),
            MathQuestion::new("VA-T06", 6, MathOp::Add, 1, 7),
            MathQuestion::new("VA-T07", 0, MathOp::VerticalAdd, 4, 4),
            MathQuestion::new("VA-T08", 1, MathOp::VerticalAdd, 4, 5),
            MathQuestion::new("VA-T09", 4, MathOp::VerticalSub, 4, 0),
            MathQuestion::new("VA-T10", 5, MathOp::VerticalSub, 4, 1),
        ],
        vec![
            MathQuestion::new("VA-H00", 2, MathOp::VerticalAdd, 4, 6),
            MathQuestion::new("VA-H01", 3, MathOp::VerticalAdd, 4, 7),
            MathQuestion::new("VA-H02", 6, MathOp::VerticalSub, 4, 2),
            MathQuestion::new("VA-H03", 7, MathOp::VerticalSub, 4, 3),
        ],
    )
}

fn vertical_multiply_questions() -> (Vec<MathQuestion>, Vec<MathQuestion>) {
    (
        vec![
            MathQuestion::new("VM-T00", 0, MathOp::Add, 1, 1),
            MathQuestion::new("VM-T01", 1, MathOp::Add, 1, 2),
            MathQuestion::new("VM-T02", 2, MathOp::Add, 1, 3),
            MathQuestion::new("VM-T03", 3, MathOp::Add, 1, 4),
            MathQuestion::new("VM-T04", 4, MathOp::Add, 1, 5),
            MathQuestion::new("VM-T05", 5, MathOp::Add, 1, 6),
            MathQuestion::new("VM-T06", 6, MathOp::Add, 1, 7),
            MathQuestion::new("VM-T07", 1, MathOp::VerticalMul, 2, 2),
            MathQuestion::new("VM-T08", 2, MathOp::VerticalMul, 2, 4),
            MathQuestion::new("VM-T09", 1, MathOp::VerticalMul, 3, 3),
        ],
        vec![
            MathQuestion::new("VM-H00", 3, MathOp::VerticalMul, 2, 6),
            MathQuestion::new("VM-H01", 2, MathOp::VerticalMul, 3, 6),
        ],
    )
}

fn vertical_division_questions() -> (Vec<MathQuestion>, Vec<MathQuestion>) {
    (
        vec![
            MathQuestion::new("VD-T00", 0, MathOp::Add, 1, 1),
            MathQuestion::new("VD-T01", 1, MathOp::Add, 1, 2),
            MathQuestion::new("VD-T02", 2, MathOp::Add, 1, 3),
            MathQuestion::new("VD-T03", 3, MathOp::Add, 1, 4),
            MathQuestion::new("VD-T04", 4, MathOp::Add, 1, 5),
            MathQuestion::new("VD-T05", 5, MathOp::Add, 1, 6),
            MathQuestion::new("VD-T06", 6, MathOp::Add, 1, 7),
            MathQuestion::new("VD-T07", 2, MathOp::VerticalDiv, 2, 1),
            MathQuestion::new("VD-T08", 4, MathOp::VerticalDiv, 2, 2),
            MathQuestion::new("VD-T09", 3, MathOp::VerticalDiv, 3, 1),
        ],
        vec![
            MathQuestion::new("VD-H00", 6, MathOp::VerticalDiv, 2, 3),
            MathQuestion::new("VD-H01", 6, MathOp::VerticalDiv, 3, 2),
        ],
    )
}
