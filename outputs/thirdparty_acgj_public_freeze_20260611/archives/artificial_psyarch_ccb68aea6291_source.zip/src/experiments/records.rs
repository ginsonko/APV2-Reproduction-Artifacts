use serde::{Deserialize, Serialize};

use crate::core::ap::{AuditTrace, Feedback};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ExperimentRecords {
    pub schema_id: &'static str,
    pub status: &'static str,
    pub experiments: Vec<ExperimentRun>,
    pub summary: ExperimentSuiteSummary,
    pub validation_errors: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ExperimentRun {
    pub experiment_id: &'static str,
    pub display_name: &'static str,
    pub train_repeats: usize,
    pub phases: Vec<PhaseRecord>,
    pub summary: ExperimentSummary,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct PhaseRecord {
    pub phase: &'static str,
    pub round_index: Option<usize>,
    pub events: Vec<ExperimentEvent>,
    pub accuracy: f32,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ExperimentEvent {
    pub event_index: usize,
    pub stimulus_id: String,
    pub response: String,
    pub matched: bool,
    pub feedback_to_learner: Option<Feedback>,
    pub learning_enabled: bool,
    pub trace: AuditTrace,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ExperimentSummary {
    pub experiment_id: &'static str,
    pub pretest_accuracy: f32,
    pub train_first_round_accuracy: f32,
    pub train_last_round_accuracy: f32,
    pub holdout_accuracy: f32,
    pub learning_gain: f32,
    pub memory_rows_final: usize,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ExperimentSuiteSummary {
    pub experiment_count: usize,
    pub event_count: usize,
    pub all_holdouts_passed: bool,
}

impl ExperimentRecords {
    pub fn new(experiments: Vec<ExperimentRun>, validation_errors: Vec<String>) -> Self {
        Self {
            schema_id: "experiments_local/v0.1",
            status: "local_core_experiment_records",
            summary: ExperimentSuiteSummary::from_runs(&experiments),
            experiments,
            validation_errors,
        }
    }
}

impl ExperimentRun {
    pub fn event_count(&self) -> usize {
        self.phases
            .iter()
            .map(|phase| phase.events.len())
            .sum::<usize>()
    }
}

impl ExperimentSuiteSummary {
    fn from_runs(experiments: &[ExperimentRun]) -> Self {
        Self {
            experiment_count: experiments.len(),
            event_count: experiments.iter().map(ExperimentRun::event_count).sum(),
            all_holdouts_passed: experiments
                .iter()
                .all(|run| run.summary.holdout_accuracy == 1.0),
        }
    }
}

pub fn validate_experiment_records(records: &ExperimentRecords) -> Vec<String> {
    let mut errors = Vec::new();

    for run in &records.experiments {
        validate_phase_order(run, &mut errors);
        validate_teacher_off_phases(run, &mut errors);
        validate_summary(run, &mut errors);
    }

    errors
}

fn validate_phase_order(run: &ExperimentRun, errors: &mut Vec<String>) {
    let phase_names: Vec<_> = run.phases.iter().map(|phase| phase.phase).collect();
    if phase_names.first() != Some(&"pretest")
        || !phase_names.contains(&"train")
        || phase_names.last() != Some(&"holdout")
    {
        errors.push(format!(
            "experiment {} phases mismatch: expected pretest first, train present, holdout last; got {:?}",
            run.experiment_id, phase_names
        ));
    }
}

fn validate_teacher_off_phases(run: &ExperimentRun, errors: &mut Vec<String>) {
    for phase in run
        .phases
        .iter()
        .filter(|phase| phase.phase == "pretest" || phase.phase == "holdout")
    {
        for event in &phase.events {
            if leaks_teacher_signal(event) {
                errors.push(format!(
                    "experiment {} event {} leaked teacher signal in {}",
                    run.experiment_id, event.event_index, phase.phase
                ));
            }
        }
    }
}

fn leaks_teacher_signal(event: &ExperimentEvent) -> bool {
    event.feedback_to_learner.is_some()
        || event.learning_enabled
        || event.trace.memory_write_enabled
        || event.trace.answer_visible_to_learner
}

fn validate_summary(run: &ExperimentRun, errors: &mut Vec<String>) {
    if run.summary.train_last_round_accuracy != 1.0 || run.summary.holdout_accuracy != 1.0 {
        errors.push(format!(
            "experiment {} failed expected train/holdout thresholds",
            run.experiment_id
        ));
    }
}
