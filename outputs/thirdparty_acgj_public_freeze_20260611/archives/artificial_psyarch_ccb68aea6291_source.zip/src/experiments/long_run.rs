use std::collections::HashMap;

use serde::{Deserialize, Serialize};

use crate::core::ap::{AuditTrace, Feedback, TeacherMode};
use crate::core::runner::{
    CoreLearner, CorePhaseResult, CoreWorld, run_core_phase, train_core_repeats,
};
use crate::experiments::local_runner::{ExperimentRunConfig, run_long_run_records};
use crate::experiments::records::ExperimentRun;
use crate::experiments::registry::ExperimentRegistryEntry;

pub const fn registry_entry() -> ExperimentRegistryEntry {
    ExperimentRegistryEntry::new(60, "long_run", run_registry_entry)
}

fn run_registry_entry(config: ExperimentRunConfig) -> Vec<ExperimentRun> {
    vec![run_long_run_records(config)]
}

inventory::submit! {
    registry_entry()
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
pub enum LongRunLabel {
    Alpha,
    Beta,
    Gamma,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum LongRunAction {
    Alpha,
    Beta,
    Gamma,
    Rest,
}

pub const LONG_RUN_LABEL_ACTIONS: [LongRunAction; 3] = [
    LongRunAction::Alpha,
    LongRunAction::Beta,
    LongRunAction::Gamma,
];

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum LongRunStimulus {
    Sample(LongRunSample),
    SleepTick { id: String, cycle: usize },
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct LongRunSample {
    pub id: String,
    pub bytes: Vec<u8>,
    pub label: LongRunLabel,
}

#[derive(Debug, Clone)]
pub struct LongRunWorld {
    train_stimuli: Vec<LongRunStimulus>,
    rehab_stimuli: Vec<LongRunStimulus>,
    holdout_stimuli: Vec<LongRunStimulus>,
    sleep_ticks: Vec<LongRunStimulus>,
    examiner: LongRunExaminer,
}

impl LongRunWorld {
    pub fn canonical() -> Self {
        Self {
            train_stimuli: vec![
                LongRunStimulus::sample("T00", [10, 12, 11, 9], LongRunLabel::Alpha),
                LongRunStimulus::sample("T01", [13, 11, 10, 12], LongRunLabel::Alpha),
                LongRunStimulus::sample("T02", [80, 82, 79, 81], LongRunLabel::Beta),
                LongRunStimulus::sample("T03", [84, 80, 82, 79], LongRunLabel::Beta),
                LongRunStimulus::sample("T04", [170, 168, 171, 169], LongRunLabel::Gamma),
                LongRunStimulus::sample("T05", [173, 171, 169, 170], LongRunLabel::Gamma),
            ],
            rehab_stimuli: vec![
                LongRunStimulus::sample("R00", [11, 13, 10, 12], LongRunLabel::Alpha),
                LongRunStimulus::sample("R01", [81, 83, 80, 82], LongRunLabel::Beta),
                LongRunStimulus::sample("R02", [171, 169, 172, 170], LongRunLabel::Gamma),
            ],
            holdout_stimuli: vec![
                LongRunStimulus::sample("H00", [12, 10, 11, 13], LongRunLabel::Alpha),
                LongRunStimulus::sample("H01", [79, 83, 80, 82], LongRunLabel::Beta),
                LongRunStimulus::sample("H02", [172, 170, 169, 171], LongRunLabel::Gamma),
            ],
            sleep_ticks: (0..24)
                .map(|cycle| LongRunStimulus::SleepTick {
                    id: format!("S{cycle:02}"),
                    cycle,
                })
                .collect(),
            examiner: LongRunExaminer,
        }
    }

    pub fn train_stimuli(&self) -> &[LongRunStimulus] {
        &self.train_stimuli
    }

    pub fn rehab_stimuli(&self) -> &[LongRunStimulus] {
        &self.rehab_stimuli
    }

    pub fn holdout_stimuli(&self) -> &[LongRunStimulus] {
        &self.holdout_stimuli
    }

    pub fn sleep_ticks(&self) -> &[LongRunStimulus] {
        &self.sleep_ticks
    }

    pub fn commit_action(&self, stimulus: &LongRunStimulus, action: LongRunAction) -> Feedback {
        self.examiner.score(stimulus, action)
    }
}

impl CoreWorld for LongRunWorld {
    type Stimulus = LongRunStimulus;
    type Response = LongRunAction;

    fn commit_response(&self, stimulus: &Self::Stimulus, response: Self::Response) -> Feedback {
        self.commit_action(stimulus, response)
    }
}

impl LongRunStimulus {
    pub fn id(&self) -> &str {
        match self {
            Self::Sample(sample) => &sample.id,
            Self::SleepTick { id, .. } => id,
        }
    }

    fn sample(
        id: impl Into<String>,
        bytes: impl IntoIterator<Item = u8>,
        label: LongRunLabel,
    ) -> Self {
        Self::Sample(LongRunSample {
            id: id.into(),
            bytes: bytes.into_iter().collect(),
            label,
        })
    }
}

#[derive(Debug, Clone)]
struct LongRunExaminer;

impl LongRunExaminer {
    fn score(&self, stimulus: &LongRunStimulus, action: LongRunAction) -> Feedback {
        match stimulus {
            LongRunStimulus::Sample(sample) => {
                if action == LongRunAction::from_label(sample.label) {
                    Feedback::Reward
                } else {
                    Feedback::Punishment
                }
            }
            LongRunStimulus::SleepTick { .. } => {
                if action == LongRunAction::Rest {
                    Feedback::Reward
                } else {
                    Feedback::Punishment
                }
            }
        }
    }
}

impl LongRunAction {
    fn from_label(label: LongRunLabel) -> Self {
        match label {
            LongRunLabel::Alpha => Self::Alpha,
            LongRunLabel::Beta => Self::Beta,
            LongRunLabel::Gamma => Self::Gamma,
        }
    }

    fn label(self) -> Option<LongRunLabel> {
        match self {
            Self::Alpha => Some(LongRunLabel::Alpha),
            Self::Beta => Some(LongRunLabel::Beta),
            Self::Gamma => Some(LongRunLabel::Gamma),
            Self::Rest => None,
        }
    }
}

#[derive(Debug, Default, Clone)]
pub struct LongRunLearner {
    prototypes: HashMap<LongRunLabel, Vec<LongRunPrototype>>,
    stimulus_action_attempts: HashMap<StimulusAction, usize>,
    memory_rows: usize,
    fatigue: i32,
    sleep_cycles: usize,
}

impl LongRunLearner {
    pub fn select_action(&self, stimulus: &LongRunStimulus) -> LongRunAction {
        self.best_scored_action(stimulus)
    }

    pub fn select_action_for_mode(
        &self,
        stimulus: &LongRunStimulus,
        mode: TeacherMode,
    ) -> LongRunAction {
        match stimulus {
            LongRunStimulus::SleepTick { .. } => LongRunAction::Rest,
            LongRunStimulus::Sample(_) if mode.exploration_enabled() => self
                .confident_label_action(stimulus)
                .or_else(|| self.first_untried_label_action(stimulus))
                .unwrap_or_else(|| self.best_scored_action(stimulus)),
            LongRunStimulus::Sample(_) => self.best_scored_action(stimulus),
        }
    }

    pub fn receive_feedback(
        &mut self,
        stimulus: &LongRunStimulus,
        action: LongRunAction,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        match stimulus {
            LongRunStimulus::SleepTick { .. } => self.apply_sleep_tick(),
            LongRunStimulus::Sample(sample) => {
                self.fatigue += 1;
                if mode.memory_write_enabled() {
                    self.record_sample_feedback(sample, action, feedback);
                }
            }
        }
        AuditTrace::for_mode(mode)
    }

    pub fn score_action(&self, stimulus: &LongRunStimulus, action: LongRunAction) -> i32 {
        let LongRunStimulus::Sample(sample) = stimulus else {
            return i32::from(action == LongRunAction::Rest);
        };
        let Some(label) = action.label() else {
            return i32::MIN / 2;
        };
        self.score_label(sample, label)
    }

    pub fn memory_rows(&self) -> usize {
        self.memory_rows
    }

    pub fn fatigue(&self) -> i32 {
        self.fatigue
    }

    pub fn sleep_cycles(&self) -> usize {
        self.sleep_cycles
    }

    pub fn total_memory_strength(&self) -> i32 {
        self.prototypes
            .values()
            .flatten()
            .map(|prototype| prototype.strength)
            .sum()
    }

    pub fn prototype_count(&self, label: LongRunLabel) -> usize {
        self.prototypes
            .get(&label)
            .map(Vec::len)
            .unwrap_or_default()
    }

    fn record_sample_feedback(
        &mut self,
        sample: &LongRunSample,
        action: LongRunAction,
        feedback: Feedback,
    ) {
        *self
            .stimulus_action_attempts
            .entry(StimulusAction::new(&sample.id, action))
            .or_default() += 1;

        if feedback == Feedback::Reward {
            let label = action
                .label()
                .expect("rewarded long-run sample action must be a label");
            self.prototypes
                .entry(label)
                .or_default()
                .push(LongRunPrototype::new(sample.bytes.clone()));
        }
        self.memory_rows += 1;
    }

    fn apply_sleep_tick(&mut self) {
        self.sleep_cycles += 1;
        self.fatigue = self.fatigue.saturating_sub(3);
        for prototype in self.prototypes.values_mut().flatten() {
            prototype.strength = (prototype.strength - 3).max(1);
            prototype.age += 1;
        }
    }

    fn score_label(&self, sample: &LongRunSample, label: LongRunLabel) -> i32 {
        let Some(prototypes) = self.prototypes.get(&label) else {
            return i32::MIN / 2;
        };
        prototypes
            .iter()
            .map(|prototype| {
                prototype.strength - manhattan_distance(&sample.bytes, &prototype.bytes)
            })
            .max()
            .unwrap_or(i32::MIN / 2)
            - self.fatigue
    }

    fn best_scored_action(&self, stimulus: &LongRunStimulus) -> LongRunAction {
        if matches!(stimulus, LongRunStimulus::SleepTick { .. }) {
            return LongRunAction::Rest;
        }
        LONG_RUN_LABEL_ACTIONS
            .into_iter()
            .fold(
                (LONG_RUN_LABEL_ACTIONS[0], i32::MIN),
                |(best, best_score), action| {
                    let score = self.score_action(stimulus, action);
                    if score > best_score {
                        (action, score)
                    } else {
                        (best, best_score)
                    }
                },
            )
            .0
    }

    fn first_untried_label_action(&self, stimulus: &LongRunStimulus) -> Option<LongRunAction> {
        LONG_RUN_LABEL_ACTIONS.into_iter().find(|action| {
            !self
                .stimulus_action_attempts
                .contains_key(&StimulusAction::new(stimulus.id(), *action))
        })
    }

    fn confident_label_action(&self, stimulus: &LongRunStimulus) -> Option<LongRunAction> {
        let action = self.best_scored_action(stimulus);
        (self.score_action(stimulus, action) > 0).then_some(action)
    }
}

impl CoreLearner<LongRunWorld> for LongRunLearner {
    fn select_response(
        &self,
        _world: &LongRunWorld,
        stimulus: &LongRunStimulus,
        mode: TeacherMode,
    ) -> LongRunAction {
        self.select_action_for_mode(stimulus, mode)
    }

    fn receive_feedback(
        &mut self,
        _world: &LongRunWorld,
        stimulus: &LongRunStimulus,
        response: LongRunAction,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        self.receive_feedback(stimulus, response, feedback, mode)
    }

    fn memory_rows(&self) -> Option<usize> {
        Some(self.memory_rows())
    }
}

pub type LongRunPhaseResult = CorePhaseResult;

pub fn train_long_run(
    world: &LongRunWorld,
    learner: &mut LongRunLearner,
    repeats: usize,
) -> Vec<LongRunPhaseResult> {
    train_core_repeats(world.train_stimuli(), world, learner, repeats)
}

pub fn run_long_run_phase(
    stimuli: &[LongRunStimulus],
    world: &LongRunWorld,
    learner: &mut LongRunLearner,
    mode: TeacherMode,
) -> LongRunPhaseResult {
    run_core_phase(stimuli, world, learner, mode)
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct LongRunPrototype {
    bytes: Vec<u8>,
    strength: i32,
    age: usize,
}

impl LongRunPrototype {
    fn new(bytes: Vec<u8>) -> Self {
        Self {
            bytes,
            strength: 120,
            age: 0,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct StimulusAction {
    stimulus_id: String,
    action: LongRunAction,
}

impl StimulusAction {
    fn new(stimulus_id: &str, action: LongRunAction) -> Self {
        Self {
            stimulus_id: stimulus_id.to_owned(),
            action,
        }
    }
}

fn manhattan_distance(left: &[u8], right: &[u8]) -> i32 {
    let value_distance: u32 = left
        .iter()
        .zip(right)
        .map(|(left, right)| left.abs_diff(*right) as u32)
        .sum();
    let length_distance = left.len().abs_diff(right.len()) as u32 * u8::MAX as u32;
    (value_distance + length_distance) as i32
}
