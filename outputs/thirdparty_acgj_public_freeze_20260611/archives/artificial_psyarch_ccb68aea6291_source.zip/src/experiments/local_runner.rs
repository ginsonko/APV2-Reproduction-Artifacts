use crate::core::ap::{Feedback, TeacherMode};
use crate::core::runner::{CoreLearner, CoreWorld};
use crate::experiments::canvas_geometry::{CanvasGeometryLearner, CanvasGeometryWorld};
use crate::experiments::count_loop::{CountLoopLearner, CountLoopWorld};
use crate::experiments::desktop_control::{DesktopControlLearner, DesktopControlWorld};
use crate::experiments::feature_combo::{FeatureComboLearner, FeatureComboWorld};
use crate::experiments::long_run::{LongRunLearner, LongRunStimulus, LongRunWorld};
use crate::experiments::math_fullchain::{MathFullChainLearner, MathFullChainWorld};
use crate::experiments::math_slice::{NoSolverMathLearner, NoSolverMathWorld};
use crate::experiments::multimodal_revision::{MultimodalRevisionLearner, MultimodalRevisionWorld};
use crate::experiments::records::{
    ExperimentEvent, ExperimentRecords, ExperimentRun, ExperimentSummary, PhaseRecord,
    validate_experiment_records,
};
use crate::experiments::registry::registered_experiments;
use crate::experiments::sensor_assoc::{SensorAssocLearner, SensorAssocWorld};
use crate::language_core::{LanguageFrame, LanguageGroundingLearner, LanguageGroundingWorld};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ExperimentRunConfig {
    pub train_repeats: usize,
}

impl Default for ExperimentRunConfig {
    fn default() -> Self {
        Self { train_repeats: 8 }
    }
}

pub fn run_all_experiment_records(config: ExperimentRunConfig) -> ExperimentRecords {
    let experiments = registered_experiments()
        .into_iter()
        .flat_map(|entry| (entry.run)(config))
        .collect();
    let records = ExperimentRecords::new(experiments, Vec::new());
    let validation_errors = validate_experiment_records(&records);
    ExperimentRecords::new(records.experiments, validation_errors)
}

pub fn run_count_loop_records(config: ExperimentRunConfig) -> ExperimentRun {
    let world = CountLoopWorld::canonical();
    let learner = CountLoopLearner::default();
    run_core_experiment(
        ExperimentSpec::new(
            "count_loop",
            "Count loop add/remove transfer",
            world.train_states(),
            world.holdout_states(),
        ),
        &world,
        learner,
        config.train_repeats,
        |state| state.id.clone(),
        |action| format!("{action:?}"),
    )
}

pub fn run_feature_combo_records(config: ExperimentRunConfig) -> ExperimentRun {
    let world = FeatureComboWorld::canonical();
    let learner = FeatureComboLearner::default();
    run_core_experiment(
        ExperimentSpec::new(
            "feature_combo",
            "Feature contribution composition",
            world.train_states(),
            world.holdout_states(),
        ),
        &world,
        learner,
        config.train_repeats,
        |state| state.id.clone(),
        |action| format!("{action:?}"),
    )
}

pub fn run_sensor_assoc_records(config: ExperimentRunConfig) -> ExperimentRun {
    let world = SensorAssocWorld::canonical();
    let learner = SensorAssocLearner::default();
    run_core_experiment(
        ExperimentSpec::new(
            "sensor_assoc",
            "Raw sensor byte association",
            world.train_samples(),
            world.holdout_samples(),
        ),
        &world,
        learner,
        config.train_repeats,
        |sample| sample.id.clone(),
        |label| format!("{label:?}"),
    )
}

pub fn run_no_solver_math_records(config: ExperimentRunConfig) -> Vec<ExperimentRun> {
    NoSolverMathWorld::canonical_suites()
        .into_iter()
        .map(|world| {
            let learner = NoSolverMathLearner::default();
            run_core_experiment(
                ExperimentSpec::new(
                    world.experiment_id(),
                    world.display_name(),
                    world.train_questions(),
                    world.holdout_questions(),
                ),
                &world,
                learner,
                config.train_repeats,
                |question| question.id.clone(),
                |answer| answer.0.to_string(),
            )
        })
        .collect()
}

pub fn run_math_fullchain_records(config: ExperimentRunConfig) -> ExperimentRun {
    let world = MathFullChainWorld::canonical();
    let learner = MathFullChainLearner::with_foundation_skills();
    run_core_experiment(
        ExperimentSpec::new(
            "math_fullchain",
            "Math-FullChain linear equation word problem",
            world.train_problems(),
            world.holdout_problems(),
        ),
        &world,
        learner,
        config.train_repeats,
        |problem| problem.id.clone(),
        |answer| answer.0.to_string(),
    )
}

pub fn run_long_run_records(config: ExperimentRunConfig) -> ExperimentRun {
    let world = LongRunWorld::canonical();
    let learner = LongRunLearner::default();
    run_long_run_experiment(&world, learner, config.train_repeats)
}

pub fn run_canvas_geometry_records(config: ExperimentRunConfig) -> ExperimentRun {
    let world = CanvasGeometryWorld::canonical();
    let learner = CanvasGeometryLearner::default();
    run_core_experiment(
        ExperimentSpec::new(
            "canvas_geometry",
            "Canvas-Geometry coordinate relation drawing",
            world.train_tasks(),
            world.holdout_tasks(),
        ),
        &world,
        learner,
        config.train_repeats,
        |task| task.id.clone(),
        |action| format!("{action:?}"),
    )
}

pub fn run_multimodal_revision_records(config: ExperimentRunConfig) -> ExperimentRun {
    let world = MultimodalRevisionWorld::canonical();
    let learner = MultimodalRevisionLearner::default();
    run_core_experiment(
        ExperimentSpec::new(
            "multimodal_revision",
            "Multimodal readback focus self revision",
            world.train_prompts(),
            world.holdout_prompts(),
        ),
        &world,
        learner,
        config.train_repeats,
        |prompt| prompt.id.clone(),
        |label| format!("{label:?}"),
    )
}

pub fn run_desktop_control_records(config: ExperimentRunConfig) -> ExperimentRun {
    let world = DesktopControlWorld::canonical();
    let learner = DesktopControlLearner::default();
    run_core_experiment(
        ExperimentSpec::new(
            "desktop_control_safety",
            "Desktop-Control dry-run safety protocol",
            world.train_requests(),
            world.holdout_requests(),
        ),
        &world,
        learner,
        config.train_repeats,
        |request| request.id.clone(),
        |action| format!("{action:?}"),
    )
}

pub fn run_language_grounding_records(config: ExperimentRunConfig) -> ExperimentRun {
    let world = LanguageGroundingWorld::canonical();
    let learner = LanguageGroundingLearner::default();
    let train_repeats = config.train_repeats.max(LanguageFrame::all().len() + 2);
    run_core_experiment(
        ExperimentSpec::new(
            "language_grounding",
            "Language-Grounding words to AP state frames",
            world.train_items(),
            world.holdout_items(),
        ),
        &world,
        learner,
        train_repeats,
        |item| item.id.clone(),
        |frame| frame.label().to_owned(),
    )
}

#[derive(Debug, Clone, Copy)]
struct ExperimentSpec<'a, W>
where
    W: CoreWorld,
{
    experiment_id: &'static str,
    display_name: &'static str,
    train_set: &'a [W::Stimulus],
    holdout_set: &'a [W::Stimulus],
}

impl<'a, W> ExperimentSpec<'a, W>
where
    W: CoreWorld,
{
    fn new(
        experiment_id: &'static str,
        display_name: &'static str,
        train_set: &'a [W::Stimulus],
        holdout_set: &'a [W::Stimulus],
    ) -> Self {
        Self {
            experiment_id,
            display_name,
            train_set,
            holdout_set,
        }
    }
}

#[derive(Debug, Clone, Copy)]
struct PhaseSpec<'a, W>
where
    W: CoreWorld,
{
    phase: &'static str,
    round_index: Option<usize>,
    stimuli: &'a [W::Stimulus],
    mode: TeacherMode,
}

impl<'a, W> PhaseSpec<'a, W>
where
    W: CoreWorld,
{
    fn new(
        phase: &'static str,
        round_index: Option<usize>,
        stimuli: &'a [W::Stimulus],
        mode: TeacherMode,
    ) -> Self {
        Self {
            phase,
            round_index,
            stimuli,
            mode,
        }
    }
}

#[derive(Debug, Clone, Copy)]
struct RecordLabels<StimulusId, ResponseLabel> {
    stimulus_id: StimulusId,
    response_label: ResponseLabel,
}

impl<StimulusId, ResponseLabel> RecordLabels<StimulusId, ResponseLabel> {
    fn new(stimulus_id: StimulusId, response_label: ResponseLabel) -> Self {
        Self {
            stimulus_id,
            response_label,
        }
    }
}

fn run_core_experiment<W, L, StimulusId, ResponseLabel>(
    spec: ExperimentSpec<'_, W>,
    world: &W,
    mut learner: L,
    train_repeats: usize,
    stimulus_id: StimulusId,
    response_label: ResponseLabel,
) -> ExperimentRun
where
    W: CoreWorld,
    L: CoreLearner<W>,
    StimulusId: Fn(&W::Stimulus) -> String + Copy,
    ResponseLabel: Fn(W::Response) -> String + Copy,
{
    let labels = RecordLabels::new(stimulus_id, response_label);
    let mut event_index = 0;
    let pretest = run_recorded_phase(
        PhaseSpec::new("pretest", None, spec.holdout_set, TeacherMode::TeacherOff),
        world,
        &mut learner,
        &mut event_index,
        labels,
    );
    let train_rounds = run_recorded_train_rounds(
        spec.train_set,
        world,
        &mut learner,
        train_repeats,
        &mut event_index,
        labels,
    );
    let holdout = run_recorded_phase(
        PhaseSpec::new("holdout", None, spec.holdout_set, TeacherMode::TeacherOff),
        world,
        &mut learner,
        &mut event_index,
        labels,
    );

    let train_first_round_accuracy = train_rounds
        .first()
        .map(|phase| phase.accuracy)
        .unwrap_or_default();
    let train_last_round_accuracy = train_rounds
        .last()
        .map(|phase| phase.accuracy)
        .unwrap_or_default();
    let memory_rows_final = learner.memory_rows().unwrap_or_default();
    let train_events: Vec<_> = train_rounds
        .iter()
        .flat_map(|phase| phase.events.iter().cloned())
        .collect();

    ExperimentRun {
        experiment_id: spec.experiment_id,
        display_name: spec.display_name,
        train_repeats,
        summary: ExperimentSummary {
            experiment_id: spec.experiment_id,
            pretest_accuracy: pretest.accuracy,
            train_first_round_accuracy,
            train_last_round_accuracy,
            holdout_accuracy: holdout.accuracy,
            learning_gain: train_last_round_accuracy - train_first_round_accuracy,
            memory_rows_final,
        },
        phases: vec![
            pretest,
            PhaseRecord {
                phase: "train",
                round_index: None,
                accuracy: accuracy_from_events(&train_events),
                events: train_events,
            },
            holdout,
        ],
    }
}

fn run_long_run_experiment(
    world: &LongRunWorld,
    mut learner: LongRunLearner,
    train_repeats: usize,
) -> ExperimentRun {
    let labels = RecordLabels::new(long_run_stimulus_id, |action| format!("{action:?}"));
    let mut event_index = 0;
    let pretest = run_recorded_phase(
        PhaseSpec::new(
            "pretest",
            None,
            world.holdout_stimuli(),
            TeacherMode::TeacherOff,
        ),
        world,
        &mut learner,
        &mut event_index,
        labels,
    );
    let train_rounds = run_recorded_train_rounds(
        world.train_stimuli(),
        world,
        &mut learner,
        train_repeats,
        &mut event_index,
        labels,
    );
    let sleep = run_recorded_phase(
        PhaseSpec::new(
            "sleep",
            None,
            world.sleep_ticks(),
            TeacherMode::NoAnswerFeedback,
        ),
        world,
        &mut learner,
        &mut event_index,
        labels,
    );
    let wake_probe = run_recorded_phase(
        PhaseSpec::new(
            "wake_probe",
            None,
            world.holdout_stimuli(),
            TeacherMode::TeacherOff,
        ),
        world,
        &mut learner,
        &mut event_index,
        labels,
    );
    let rehab = run_recorded_phase(
        PhaseSpec::new(
            "rehab",
            None,
            world.rehab_stimuli(),
            TeacherMode::FeedbackOnly,
        ),
        world,
        &mut learner,
        &mut event_index,
        labels,
    );
    let holdout = run_recorded_phase(
        PhaseSpec::new(
            "holdout",
            None,
            world.holdout_stimuli(),
            TeacherMode::TeacherOff,
        ),
        world,
        &mut learner,
        &mut event_index,
        labels,
    );

    let train_first_round_accuracy = train_rounds
        .first()
        .map(|phase| phase.accuracy)
        .unwrap_or_default();
    let train_last_round_accuracy = train_rounds
        .last()
        .map(|phase| phase.accuracy)
        .unwrap_or_default();
    let train_events: Vec<_> = train_rounds
        .iter()
        .flat_map(|phase| phase.events.iter().cloned())
        .collect();

    ExperimentRun {
        experiment_id: "long_run_stability",
        display_name: "LongRun-Stability sleep wake rehab retention",
        train_repeats,
        summary: ExperimentSummary {
            experiment_id: "long_run_stability",
            pretest_accuracy: pretest.accuracy,
            train_first_round_accuracy,
            train_last_round_accuracy,
            holdout_accuracy: holdout.accuracy,
            learning_gain: train_last_round_accuracy - train_first_round_accuracy,
            memory_rows_final: learner.memory_rows(),
        },
        phases: vec![
            pretest,
            PhaseRecord {
                phase: "train",
                round_index: None,
                accuracy: accuracy_from_events(&train_events),
                events: train_events,
            },
            sleep,
            wake_probe,
            rehab,
            holdout,
        ],
    }
}

fn run_recorded_train_rounds<W, L, StimulusId, ResponseLabel>(
    train_set: &[W::Stimulus],
    world: &W,
    learner: &mut L,
    train_repeats: usize,
    event_index: &mut usize,
    labels: RecordLabels<StimulusId, ResponseLabel>,
) -> Vec<PhaseRecord>
where
    W: CoreWorld,
    L: CoreLearner<W>,
    StimulusId: Fn(&W::Stimulus) -> String + Copy,
    ResponseLabel: Fn(W::Response) -> String + Copy,
{
    (0..train_repeats)
        .map(|round| {
            run_recorded_phase(
                PhaseSpec::new("train", Some(round), train_set, TeacherMode::FeedbackOnly),
                world,
                learner,
                event_index,
                labels,
            )
        })
        .collect()
}

fn run_recorded_phase<W, L, StimulusId, ResponseLabel>(
    spec: PhaseSpec<'_, W>,
    world: &W,
    learner: &mut L,
    event_index: &mut usize,
    labels: RecordLabels<StimulusId, ResponseLabel>,
) -> PhaseRecord
where
    W: CoreWorld,
    L: CoreLearner<W>,
    StimulusId: Fn(&W::Stimulus) -> String + Copy,
    ResponseLabel: Fn(W::Response) -> String + Copy,
{
    let events = spec
        .stimuli
        .iter()
        .map(|stimulus| {
            let response = learner.select_response(world, stimulus, spec.mode);
            let feedback = world.commit_response(stimulus, response);
            let trace = learner.receive_feedback(world, stimulus, response, feedback, spec.mode);
            let event = ExperimentEvent {
                event_index: *event_index,
                stimulus_id: (labels.stimulus_id)(stimulus),
                response: (labels.response_label)(response),
                matched: feedback == Feedback::Reward,
                feedback_to_learner: trace.feedback_visible_to_learner.then_some(feedback),
                learning_enabled: trace.memory_write_enabled,
                trace,
            };
            *event_index += 1;
            event
        })
        .collect::<Vec<_>>();

    PhaseRecord {
        phase: spec.phase,
        round_index: spec.round_index,
        accuracy: accuracy_from_events(&events),
        events,
    }
}

fn accuracy_from_events(events: &[ExperimentEvent]) -> f32 {
    let correct = events.iter().filter(|event| event.matched).count();
    correct as f32 / events.len() as f32
}

fn long_run_stimulus_id(stimulus: &LongRunStimulus) -> String {
    stimulus.id().to_owned()
}
