use super::local_runner::ExperimentRunConfig;
use super::records::ExperimentRun;

#[derive(Debug, Clone, Copy)]
pub struct ExperimentRegistryEntry {
    pub order: u16,
    pub plugin_id: &'static str,
    pub run: fn(ExperimentRunConfig) -> Vec<ExperimentRun>,
}

impl ExperimentRegistryEntry {
    pub const fn new(
        order: u16,
        plugin_id: &'static str,
        run: fn(ExperimentRunConfig) -> Vec<ExperimentRun>,
    ) -> Self {
        Self {
            order,
            plugin_id,
            run,
        }
    }
}

pub fn registered_experiments() -> Vec<ExperimentRegistryEntry> {
    let mut entries = inventory::iter::<ExperimentRegistryEntry>
        .into_iter()
        .copied()
        .collect::<Vec<_>>();
    entries.sort_by_key(|entry| (entry.order, entry.plugin_id));
    entries
}

inventory::collect!(ExperimentRegistryEntry);
