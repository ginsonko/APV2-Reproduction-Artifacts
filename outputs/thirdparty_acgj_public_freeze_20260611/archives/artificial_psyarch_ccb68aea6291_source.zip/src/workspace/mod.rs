use std::path::{Path, PathBuf};

const DEFAULT_ROOT: &str = ".ap";

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct WorkspacePaths {
    root: PathBuf,
}

impl WorkspacePaths {
    pub fn new(root: impl Into<PathBuf>) -> Self {
        Self { root: root.into() }
    }

    pub fn from_env() -> Self {
        std::env::var("AP_WORKSPACE")
            .map(Self::new)
            .unwrap_or_default()
    }

    pub fn root(&self) -> &Path {
        &self.root
    }

    pub fn interactive_skill_current(&self) -> PathBuf {
        self.root.join("skills/interactive/current.apbin")
    }

    pub fn interactive_skill_history(&self, name: &str) -> PathBuf {
        self.root.join("skills/interactive/history").join(name)
    }

    pub fn external_skill(&self, name: &str) -> PathBuf {
        self.root.join("skills/external").join(name)
    }

    pub fn report(&self, group: &str, name: &str) -> PathBuf {
        self.root.join("reports").join(group).join(name)
    }

    pub fn export_bundle(&self, name: &str) -> PathBuf {
        self.root.join("exports/bundles").join(name)
    }

    pub fn session_trace(&self, name: &str) -> PathBuf {
        self.root.join("sessions/tui/traces").join(name)
    }

    pub fn agent_request(&self, name: &str) -> PathBuf {
        self.root.join("exports/lessons").join(name)
    }

    pub fn language_dataset(&self, name: &str) -> PathBuf {
        self.root.join("exports/language").join(name)
    }
}

impl Default for WorkspacePaths {
    fn default() -> Self {
        Self::new(DEFAULT_ROOT)
    }
}

pub fn ensure_parent(path: &Path) -> std::io::Result<()> {
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    Ok(())
}

pub fn path_string(path: &Path) -> String {
    path.display().to_string()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_workspace_uses_ap_root() {
        let paths = WorkspacePaths::default();

        assert_eq!(paths.root(), Path::new(".ap"));
        assert_eq!(
            paths.interactive_skill_current(),
            PathBuf::from(".ap/skills/interactive/current.apbin")
        );
    }

    #[test]
    fn reports_are_grouped() {
        let paths = WorkspacePaths::new("work");

        assert_eq!(
            paths.report("learning", "status.md"),
            PathBuf::from("work/reports/learning/status.md")
        );
    }
}
