use crate::repeat_map::records::{GroupRun, SeedRun, SeedSummary};

pub fn validate_local_records(
    seed_runs: &[SeedRun],
    seed_summaries: &[SeedSummary],
) -> Vec<String> {
    let mut errors = Vec::new();
    let expected_groups = [
        "G1A_RM_AP_STYLE",
        "G1B_RM_STRICT_CORE_BRIDGE",
        "G2_RM_FIXED_HEURISTIC",
    ];

    for seed_run in seed_runs {
        validate_group_order(seed_run, &expected_groups, &mut errors);
        for group in &seed_run.groups {
            validate_group_no_teacher_leakage(seed_run.seed, group, &mut errors);
            validate_group_summary(seed_run.seed, &group.summary, &mut errors);
        }
    }

    for summary in seed_summaries {
        validate_local_cost_counters(summary, &mut errors);
    }

    errors
}

fn validate_group_order(seed_run: &SeedRun, expected_groups: &[&str], errors: &mut Vec<String>) {
    let actual_groups: Vec<_> = seed_run.groups.iter().map(|group| group.group_id).collect();
    if actual_groups != expected_groups {
        errors.push(format!(
            "seed {} groups mismatch: expected {:?}, got {:?}",
            seed_run.seed, expected_groups, actual_groups
        ));
    }
}

fn validate_local_cost_counters(summary: &SeedSummary, errors: &mut Vec<String>) {
    if has_non_local_cost(summary) {
        errors.push(format!(
            "seed {} group {} has non-local cost counters",
            summary.seed, summary.group_id
        ));
    }
}

fn has_non_local_cost(summary: &SeedSummary) -> bool {
    summary.real_llm_call_count != 0
        || summary.api_error_count != 0
        || summary.parse_failure_count != 0
        || summary.posting_label_count != 0
        || summary.tool_call_count != 0
}

fn validate_group_no_teacher_leakage(seed: u64, group: &GroupRun, errors: &mut Vec<String>) {
    for phase_name in [
        "pretest_alpha",
        "alpha_holdout",
        "package_reload",
        "beta_holdout",
    ] {
        let Some(events) = group.phases.get(phase_name) else {
            errors.push(format!(
                "seed {} group {} missing phase {}",
                seed, group.group_id, phase_name
            ));
            continue;
        };

        for event in events {
            if event_leaks_teacher_signal(event) {
                errors.push(format!(
                    "seed {} group {} event {} leaked teacher signal in {}",
                    seed, group.group_id, event.event_index, phase_name
                ));
            }
        }
    }
}

fn event_leaks_teacher_signal(event: &crate::repeat_map::records::EventRecord) -> bool {
    event.feedback_to_learner.is_some()
        || event.learning_enabled
        || event.trace.audit.memory_write_enabled
        || event.trace.audit.answer_visible_to_learner
}

fn validate_group_summary(seed: u64, summary: &SeedSummary, errors: &mut Vec<String>) {
    let kind = SummaryGroupKind::from_group_id(summary.group_id);
    validate_summary_kind(seed, summary, kind, errors);
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum SummaryGroupKind {
    Learning,
    FixedHeuristic,
    Unknown,
}

impl SummaryGroupKind {
    fn from_group_id(group_id: &str) -> Self {
        if is_learning_group(group_id) {
            return Self::Learning;
        }
        if group_id == "G2_RM_FIXED_HEURISTIC" {
            return Self::FixedHeuristic;
        }
        Self::Unknown
    }
}

fn is_learning_group(group_id: &str) -> bool {
    matches!(group_id, "G1A_RM_AP_STYLE" | "G1B_RM_STRICT_CORE_BRIDGE")
}

fn validate_summary_kind(
    seed: u64,
    summary: &SeedSummary,
    kind: SummaryGroupKind,
    errors: &mut Vec<String>,
) {
    match kind {
        SummaryGroupKind::Learning => validate_learning_summary(seed, summary, errors),
        SummaryGroupKind::FixedHeuristic => validate_fixed_summary(seed, summary, errors),
        SummaryGroupKind::Unknown => push_unknown_group_error(seed, summary.group_id, errors),
    }
}

fn validate_learning_summary(seed: u64, summary: &SeedSummary, errors: &mut Vec<String>) {
    if !meets_learning_thresholds(summary) {
        errors.push(format!(
            "seed {} group {} failed expected local learning/holdout thresholds",
            seed, summary.group_id
        ));
    }
}

fn validate_fixed_summary(seed: u64, summary: &SeedSummary, errors: &mut Vec<String>) {
    if has_learning_gain(summary) {
        errors.push(format!(
            "seed {} group {} should not have learning gain",
            seed, summary.group_id
        ));
    }
}

fn push_unknown_group_error(seed: u64, group_id: &str, errors: &mut Vec<String>) {
    errors.push(format!("seed {} unknown group {}", seed, group_id));
}

fn meets_learning_thresholds(summary: &SeedSummary) -> bool {
    summary.alpha_train_last_round_accuracy == 1.0
        && summary.alpha_holdout_accuracy == 1.0
        && summary.package_reload_accuracy == 1.0
        && summary.beta_train_last_round_accuracy == 1.0
        && summary.beta_holdout_accuracy == 1.0
}

fn has_learning_gain(summary: &SeedSummary) -> bool {
    summary.alpha_learning_gain != 0.0 || summary.beta_relearning_gain != 0.0
}
