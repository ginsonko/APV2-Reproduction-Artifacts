use std::collections::BTreeMap;

use serde::Serialize;

use crate::core::ap::{AuditTrace, Feedback};
use crate::repeat_map::{Action, PublicState};

#[derive(Debug, Serialize)]
pub struct Records {
    pub schema_id: &'static str,
    pub status: &'static str,
    pub seeds: Vec<u64>,
    pub seed_count: usize,
    pub state_count: usize,
    pub action_count: usize,
    pub train_repeats: usize,
    pub participant_identity: Vec<ParticipantIdentity>,
    pub seed_runs: Vec<SeedRun>,
    pub summary: Summary,
    pub validation_errors: Vec<String>,
}

#[derive(Debug, Serialize)]
pub struct ParticipantIdentity {
    pub route_id: &'static str,
    pub model_or_runner: &'static str,
    pub api_mode: &'static str,
    pub memory_tool: &'static str,
}

#[derive(Debug, Serialize)]
pub struct SeedRun {
    pub seed: u64,
    pub state_count: usize,
    pub groups: Vec<GroupRun>,
}

#[derive(Debug, Serialize)]
pub struct GroupRun {
    pub group_id: &'static str,
    pub display_name_zh: &'static str,
    pub seed: u64,
    pub phases: BTreeMap<&'static str, Vec<EventRecord>>,
    pub summary: SeedSummary,
}

#[derive(Debug, Clone, Serialize)]
pub struct EventRecord {
    pub seed: u64,
    pub event_index: usize,
    pub phase: &'static str,
    pub round_index: Option<usize>,
    pub context_label: &'static str,
    pub state_id: String,
    pub features: PublicFeatures,
    pub selected_action: Action,
    pub valid_action: bool,
    pub matched: bool,
    pub feedback_to_learner: Option<Feedback>,
    pub learning_enabled: bool,
    pub memory_write_after_action: usize,
    pub scorer_after_commit: bool,
    pub trace: EventTrace,
}

#[derive(Debug, Clone, Serialize)]
pub struct PublicFeatures {
    pub shape: &'static str,
    pub color: &'static str,
    pub mark: &'static str,
    pub slot: usize,
}

impl From<&PublicState> for PublicFeatures {
    fn from(state: &PublicState) -> Self {
        Self {
            shape: state.shape,
            color: state.color,
            mark: state.mark,
            slot: state.slot,
        }
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct EventTrace {
    pub reason: &'static str,
    pub action_scores: BTreeMap<Action, i32>,
    pub memory_rows: usize,
    pub audit: AuditTrace,
}

#[derive(Debug, Clone, Serialize)]
pub struct SeedSummary {
    pub group_id: &'static str,
    pub display_name_zh: &'static str,
    pub seed: u64,
    pub pretest_accuracy: f64,
    pub alpha_train_first_round_accuracy: f64,
    pub alpha_train_last_round_accuracy: f64,
    pub alpha_learning_gain: f64,
    pub alpha_holdout_accuracy: f64,
    pub package_reload_accuracy: f64,
    pub beta_train_first_round_accuracy: f64,
    pub beta_train_last_round_accuracy: f64,
    pub beta_relearning_gain: f64,
    pub beta_holdout_accuracy: f64,
    pub train_repeats: usize,
    pub real_llm_call_count: usize,
    pub api_error_count: usize,
    pub parse_failure_count: usize,
    pub posting_label_count: usize,
    pub tool_call_count: usize,
    pub memory_rows_final: usize,
}

#[derive(Debug, Serialize)]
pub struct Summary {
    pub seed_summaries: Vec<SeedSummary>,
    pub group_aggregates: Vec<GroupAggregate>,
    pub real_llm_call_count: usize,
    pub total_posting_labels: usize,
    pub validation_passed: bool,
    pub error_count: usize,
}

#[derive(Debug, Serialize)]
pub struct GroupAggregate {
    pub group_id: &'static str,
    pub display_name_zh: &'static str,
    pub seed_count: usize,
    pub metrics: BTreeMap<&'static str, MetricAggregate>,
    pub real_llm_call_count: usize,
    pub api_error_count: usize,
    pub parse_failure_count: usize,
    pub posting_label_count: usize,
    pub tool_call_count: usize,
}

#[derive(Debug, Serialize)]
pub struct MetricAggregate {
    pub n: usize,
    pub values: Vec<f64>,
    pub mean: f64,
    pub sample_std: f64,
    pub ci95: f64,
}
