use std::collections::BTreeMap;

use crate::core::ap::{AuditTrace, Feedback, TeacherMode};
use crate::repeat_map::records::{EventTrace, ParticipantIdentity};
use crate::repeat_map::{ACTIONS, Action, PublicState, RepeatMapLearner};

pub trait Participant {
    fn select_action(&mut self, context: &str, state: &PublicState) -> (Action, EventTrace);
    fn receive_feedback(
        &mut self,
        context: &str,
        state: &PublicState,
        action: Action,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace;
    fn memory_len(&self) -> usize;
    fn export_reload(&self) -> Option<Self>
    where
        Self: Sized;
}

#[derive(Debug, Default, Clone)]
pub struct ApStyleParticipant {
    memory: Vec<FeedbackMemoryRow>,
}

#[derive(Debug, Clone)]
struct FeedbackMemoryRow {
    context: String,
    state_id: String,
    action: Action,
    feedback: Feedback,
}

impl Participant for ApStyleParticipant {
    fn select_action(&mut self, context: &str, state: &PublicState) -> (Action, EventTrace) {
        let action_scores = ap_style_action_scores(context, &state.id, &self.memory);
        let action = best_action_from_scores(&action_scores);
        (
            action,
            EventTrace {
                reason: "best_feedback_memory_action",
                action_scores,
                memory_rows: self.memory.len(),
                audit: AuditTrace::default(),
            },
        )
    }

    fn receive_feedback(
        &mut self,
        context: &str,
        state: &PublicState,
        action: Action,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        if mode.memory_write_enabled() {
            self.memory.push(FeedbackMemoryRow {
                context: context.to_owned(),
                state_id: state.id.clone(),
                action,
                feedback,
            });
        }
        AuditTrace::for_mode(mode)
    }

    fn memory_len(&self) -> usize {
        self.memory.len()
    }

    fn export_reload(&self) -> Option<Self> {
        Some(self.clone())
    }
}

#[derive(Debug, Default, Clone)]
pub struct StrictCoreParticipant {
    learner: RepeatMapLearner,
}

impl Participant for StrictCoreParticipant {
    fn select_action(&mut self, context: &str, state: &PublicState) -> (Action, EventTrace) {
        let memory_before = self.learner.memory_len();
        let action_scores = action_scores(context, &state.id, &self.learner);
        let action = self.learner.select_action(context, state);
        (
            action,
            EventTrace {
                reason: "best_feedback_memory_action",
                action_scores,
                memory_rows: memory_before,
                audit: AuditTrace::default(),
            },
        )
    }

    fn receive_feedback(
        &mut self,
        context: &str,
        state: &PublicState,
        action: Action,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        self.learner
            .receive_feedback(context, state, action, feedback, mode)
    }

    fn memory_len(&self) -> usize {
        self.learner.memory_len()
    }

    fn export_reload(&self) -> Option<Self> {
        let package = self.learner.export_skill_package("repeat-map-local");
        Some(Self {
            learner: RepeatMapLearner::from_skill_package(package),
        })
    }
}

#[derive(Debug, Default, Clone)]
pub struct FixedHeuristicParticipant;

impl Participant for FixedHeuristicParticipant {
    fn select_action(&mut self, context: &str, state: &PublicState) -> (Action, EventTrace) {
        let hash = public_feature_hash(context, state);
        let action = ACTIONS[hash % ACTIONS.len()];
        (
            action,
            EventTrace {
                reason: "fixed_public_feature_hash_action",
                action_scores: ACTIONS.into_iter().map(|action| (action, 0)).collect(),
                memory_rows: 0,
                audit: AuditTrace::default(),
            },
        )
    }

    fn receive_feedback(
        &mut self,
        _context: &str,
        _state: &PublicState,
        _action: Action,
        _feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        AuditTrace {
            memory_write_enabled: false,
            ..AuditTrace::for_mode(mode)
        }
    }

    fn memory_len(&self) -> usize {
        0
    }

    fn export_reload(&self) -> Option<Self> {
        Some(Self)
    }
}

pub fn local_participant_identity() -> Vec<ParticipantIdentity> {
    vec![
        ParticipantIdentity {
            route_id: "G1A_RM_AP_STYLE",
            model_or_runner: "APFeedbackLearner",
            api_mode: "no_api",
            memory_tool: "internal action-feedback memory",
        },
        ParticipantIdentity {
            route_id: "G1B_RM_STRICT_CORE_BRIDGE",
            model_or_runner: "StrictRuntimeBridge + feedback recall policy",
            api_mode: "no_api",
            memory_tool: "DualEnergyStatePool + MemoryStore",
        },
        ParticipantIdentity {
            route_id: "G2_RM_FIXED_HEURISTIC",
            model_or_runner: "FixedHeuristic",
            api_mode: "no_api",
            memory_tool: "none",
        },
    ]
}

fn action_scores(
    context: &str,
    state_id: &str,
    learner: &RepeatMapLearner,
) -> BTreeMap<Action, i32> {
    ACTIONS
        .into_iter()
        .map(|action| (action, learner.score_action(context, state_id, action)))
        .collect()
}

fn ap_style_action_scores(
    context: &str,
    state_id: &str,
    memory: &[FeedbackMemoryRow],
) -> BTreeMap<Action, i32> {
    ACTIONS
        .into_iter()
        .map(|action| {
            let score = memory
                .iter()
                .filter(|row| {
                    row.context == context && row.state_id == state_id && row.action == action
                })
                .map(|row| row.feedback.score())
                .sum();
            (action, score)
        })
        .collect()
}

fn best_action_from_scores(scores: &BTreeMap<Action, i32>) -> Action {
    ACTIONS
        .into_iter()
        .fold((ACTIONS[0], i32::MIN), |(best, best_score), action| {
            let score = *scores.get(&action).unwrap_or(&0);
            if score > best_score {
                (action, score)
            } else {
                (best, best_score)
            }
        })
        .0
}

fn public_feature_hash(context: &str, state: &PublicState) -> usize {
    context
        .bytes()
        .chain(state.shape.bytes())
        .chain(state.color.bytes())
        .chain(state.mark.bytes())
        .fold(state.slot, |acc, byte| {
            acc.wrapping_mul(33).wrapping_add(byte as usize)
        })
}
