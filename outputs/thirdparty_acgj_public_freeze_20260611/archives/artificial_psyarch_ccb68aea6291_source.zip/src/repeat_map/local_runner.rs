use std::collections::BTreeMap;

use crate::core::ap::{Feedback, TeacherMode};
use crate::repeat_map::participants::{
    ApStyleParticipant, FixedHeuristicParticipant, Participant, StrictCoreParticipant,
    local_participant_identity,
};
use crate::repeat_map::records::{EventRecord, GroupRun, Records, SeedRun, SeedSummary, Summary};
use crate::repeat_map::stats::{accuracy, aggregate_groups};
use crate::repeat_map::validation::validate_local_records;
use crate::repeat_map::{ACTIONS, RepeatMapWorld};

pub const DEFAULT_SEEDS: [u64; 5] = [1103, 2207, 3301, 4409, 5501];

#[derive(Debug, Clone)]
pub struct LocalRunConfig {
    pub seeds: Vec<u64>,
    pub state_count: usize,
    pub train_repeats: usize,
}

impl Default for LocalRunConfig {
    fn default() -> Self {
        Self {
            seeds: DEFAULT_SEEDS.to_vec(),
            state_count: 12,
            train_repeats: 4,
        }
    }
}

pub fn run_local_records(config: &LocalRunConfig) -> Records {
    let mut seed_runs = Vec::new();
    let mut seed_summaries = Vec::new();

    for seed in &config.seeds {
        let ap_style = run_group(
            "G1A_RM_AP_STYLE",
            "G1A-RM AP-style 反馈记忆",
            *seed,
            config.state_count,
            config.train_repeats,
            ApStyleParticipant::default(),
        );
        let strict = run_group(
            "G1B_RM_STRICT_CORE_BRIDGE",
            "G1B-RM APV2.1 strict_core bridge",
            *seed,
            config.state_count,
            config.train_repeats,
            StrictCoreParticipant::default(),
        );
        let fixed = run_group(
            "G2_RM_FIXED_HEURISTIC",
            "G2-RM 固定公开启发式",
            *seed,
            config.state_count,
            config.train_repeats,
            FixedHeuristicParticipant,
        );

        seed_summaries.push(ap_style.summary.clone());
        seed_summaries.push(strict.summary.clone());
        seed_summaries.push(fixed.summary.clone());
        seed_runs.push(SeedRun {
            seed: *seed,
            state_count: config.state_count,
            groups: vec![ap_style, strict, fixed],
        });
    }

    let validation_errors = validate_local_records(&seed_runs, &seed_summaries);
    let summary = Summary {
        group_aggregates: aggregate_groups(&seed_summaries),
        seed_summaries,
        real_llm_call_count: 0,
        total_posting_labels: 0,
        validation_passed: validation_errors.is_empty(),
        error_count: validation_errors.len(),
    };

    Records {
        schema_id: "repeatmap_local/v0.1",
        status: "local_three_group_reproduction_not_real_api",
        seeds: config.seeds.clone(),
        seed_count: config.seeds.len(),
        state_count: config.state_count,
        action_count: ACTIONS.len(),
        train_repeats: config.train_repeats,
        participant_identity: local_participant_identity(),
        seed_runs,
        summary,
        validation_errors,
    }
}

fn run_group<P>(
    group_id: &'static str,
    display_name_zh: &'static str,
    seed: u64,
    state_count: usize,
    train_repeats: usize,
    mut participant: P,
) -> GroupRun
where
    P: Participant + Clone,
{
    let alpha = RepeatMapWorld::new("alpha", seed, state_count);
    let beta = RepeatMapWorld::new("beta", seed, state_count);
    let mut event_index = 0;
    let mut phases = BTreeMap::new();

    let pretest = run_phase_records(
        seed,
        &alpha,
        "pretest_alpha",
        None,
        TeacherMode::TeacherOff,
        &mut participant,
        &mut event_index,
    );

    let alpha_train_rounds = run_train_rounds(
        seed,
        &alpha,
        "alpha_train",
        train_repeats,
        &mut participant,
        &mut event_index,
    );
    let alpha_train: Vec<_> = alpha_train_rounds.iter().flatten().cloned().collect();

    let alpha_holdout = run_phase_records(
        seed,
        &alpha,
        "alpha_holdout",
        None,
        TeacherMode::TeacherOff,
        &mut participant,
        &mut event_index,
    );

    let mut reloaded = participant
        .export_reload()
        .expect("local participants must support reload");
    let package_reload = run_phase_records(
        seed,
        &alpha,
        "package_reload",
        None,
        TeacherMode::TeacherOff,
        &mut reloaded,
        &mut event_index,
    );

    let beta_train_rounds = run_train_rounds(
        seed,
        &beta,
        "beta_train",
        train_repeats,
        &mut participant,
        &mut event_index,
    );
    let beta_train: Vec<_> = beta_train_rounds.iter().flatten().cloned().collect();

    let beta_holdout = run_phase_records(
        seed,
        &beta,
        "beta_holdout",
        None,
        TeacherMode::TeacherOff,
        &mut participant,
        &mut event_index,
    );

    let summary = SeedSummary {
        group_id,
        display_name_zh,
        seed,
        pretest_accuracy: accuracy(&pretest),
        alpha_train_first_round_accuracy: accuracy(&alpha_train_rounds[0]),
        alpha_train_last_round_accuracy: accuracy(&alpha_train_rounds[train_repeats - 1]),
        alpha_learning_gain: accuracy(&alpha_train_rounds[train_repeats - 1])
            - accuracy(&alpha_train_rounds[0]),
        alpha_holdout_accuracy: accuracy(&alpha_holdout),
        package_reload_accuracy: accuracy(&package_reload),
        beta_train_first_round_accuracy: accuracy(&beta_train_rounds[0]),
        beta_train_last_round_accuracy: accuracy(&beta_train_rounds[train_repeats - 1]),
        beta_relearning_gain: accuracy(&beta_train_rounds[train_repeats - 1])
            - accuracy(&beta_train_rounds[0]),
        beta_holdout_accuracy: accuracy(&beta_holdout),
        train_repeats,
        real_llm_call_count: 0,
        api_error_count: 0,
        parse_failure_count: 0,
        posting_label_count: 0,
        tool_call_count: 0,
        memory_rows_final: participant.memory_len(),
    };

    phases.insert("pretest_alpha", pretest);
    phases.insert("alpha_train", alpha_train);
    phases.insert("alpha_holdout", alpha_holdout);
    phases.insert("package_reload", package_reload);
    phases.insert("beta_train", beta_train);
    phases.insert("beta_holdout", beta_holdout);

    GroupRun {
        group_id,
        display_name_zh,
        seed,
        phases,
        summary,
    }
}

fn run_train_rounds<P>(
    seed: u64,
    world: &RepeatMapWorld,
    phase: &'static str,
    train_repeats: usize,
    participant: &mut P,
    event_index: &mut usize,
) -> Vec<Vec<EventRecord>>
where
    P: Participant,
{
    (0..train_repeats)
        .map(|round| {
            run_phase_records(
                seed,
                world,
                phase,
                Some(round),
                TeacherMode::FeedbackOnly,
                participant,
                event_index,
            )
        })
        .collect()
}

fn run_phase_records<P>(
    seed: u64,
    world: &RepeatMapWorld,
    phase: &'static str,
    round_index: Option<usize>,
    mode: TeacherMode,
    participant: &mut P,
    event_index: &mut usize,
) -> Vec<EventRecord>
where
    P: Participant,
{
    world
        .states()
        .iter()
        .map(|state| {
            let (selected_action, mut trace) = participant.select_action(world.context(), state);
            let feedback = world.commit_action(state, selected_action);
            let audit = participant.receive_feedback(
                world.context(),
                state,
                selected_action,
                feedback,
                mode,
            );
            let memory_write_after_action = participant.memory_len();
            trace.audit = audit.clone();

            let record = EventRecord {
                seed,
                event_index: *event_index,
                phase,
                round_index,
                context_label: context_label(world.context()),
                state_id: state.id.clone(),
                features: state.into(),
                selected_action,
                valid_action: ACTIONS.contains(&selected_action),
                matched: feedback == Feedback::Reward,
                feedback_to_learner: if audit.feedback_visible_to_learner {
                    Some(feedback)
                } else {
                    None
                },
                learning_enabled: audit.memory_write_enabled,
                memory_write_after_action,
                scorer_after_commit: audit.examiner_private_scoring,
                trace,
            };
            *event_index += 1;
            record
        })
        .collect()
}

fn context_label(context: &str) -> &'static str {
    match context {
        "alpha" => "alpha",
        "beta" => "beta",
        _ => "custom",
    }
}
