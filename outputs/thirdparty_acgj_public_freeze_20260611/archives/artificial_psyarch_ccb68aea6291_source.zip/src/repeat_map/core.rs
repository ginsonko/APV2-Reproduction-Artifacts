use std::collections::HashMap;

use crate::core::ap::{
    AuditTrace, DualEnergyStatePool, Feedback, MemoryEvent, MemoryStore, TeacherMode,
};
use crate::core::prediction::{
    ActionConsequence, ActionConsequenceEvaluator, CognitiveFeeling, CognitiveFeelingFactory,
    ExperienceFrame, PredictionConfig, PredictionPackage, SuccessorMemory,
};
use crate::core::skill_registry::{SkillBoundary, SkillEvidence, SkillManifest};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
pub enum Action {
    A,
    B,
    C,
    D,
}

pub const ACTIONS: [Action; 4] = [Action::A, Action::B, Action::C, Action::D];

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PublicState {
    pub id: String,
    pub shape: &'static str,
    pub color: &'static str,
    pub mark: &'static str,
    pub slot: usize,
}

#[derive(Debug, Clone)]
pub struct RepeatMapWorld {
    context: String,
    states: Vec<PublicState>,
    examiner: PrivateExaminer,
}

impl RepeatMapWorld {
    pub fn new(context: impl Into<String>, seed: u64, state_count: usize) -> Self {
        let context = context.into();
        let states = build_public_states(state_count);
        let examiner = PrivateExaminer::new(seed, &context, &states);
        Self {
            context,
            states,
            examiner,
        }
    }

    pub fn context(&self) -> &str {
        &self.context
    }

    pub fn states(&self) -> &[PublicState] {
        &self.states
    }

    pub fn commit_action(&self, state: &PublicState, action: Action) -> Feedback {
        self.examiner.score(state, action)
    }

    pub fn teacher_action(&self, state: &PublicState) -> Action {
        self.examiner.answer(state)
    }
}

#[derive(Debug, Clone)]
struct PrivateExaminer {
    answer_table: HashMap<String, Action>,
}

impl PrivateExaminer {
    fn new(seed: u64, context: &str, states: &[PublicState]) -> Self {
        let mut answer_table = HashMap::new();
        for state in states {
            let idx = deterministic_answer_index(seed, context, state);
            answer_table.insert(state.id.clone(), ACTIONS[idx]);
        }
        Self { answer_table }
    }

    fn score(&self, state: &PublicState, action: Action) -> Feedback {
        match self.answer_table.get(&state.id).copied() {
            Some(expected) if expected == action => Feedback::Reward,
            Some(_) => Feedback::Punishment,
            None => panic!("unknown state {}", state.id),
        }
    }

    fn answer(&self, state: &PublicState) -> Action {
        self.answer_table
            .get(&state.id)
            .copied()
            .unwrap_or_else(|| panic!("unknown state {}", state.id))
    }
}

#[derive(Debug, Default, Clone)]
pub struct RepeatMapLearner {
    pool: DualEnergyStatePool,
    memory: MemoryStore<Action>,
    successor_memory: SuccessorMemory,
    last_prediction: Option<PredictionPackage>,
    last_feeling: Option<CognitiveFeeling>,
    last_consequence: Option<ActionConsequence>,
}

impl RepeatMapLearner {
    pub fn select_action(&mut self, context: &str, state: &PublicState) -> Action {
        self.pool.clear_tick();
        self.pool.observe(format!("context::{context}"));
        self.pool.observe(format!("state::{}", state.id));
        self.pool.observe(format!("shape::{}", state.shape));
        self.pool.observe(format!("color::{}", state.color));
        self.pool.observe(format!("mark::{}", state.mark));

        let action = self.best_action_by_consequence(context, state);
        self.pool.mark_action(format!("action::{action:?}"));

        let current_keys = repeat_map_state_keys(context, state, action);
        let required_keys = repeat_map_required_keys(context, state, action);
        let prediction = self.successor_memory.predict_cstar_with_required_keys(
            &current_keys,
            &required_keys,
            PredictionConfig::default(),
        );
        self.last_consequence = Some(ActionConsequenceEvaluator::evaluate(&prediction));
        prediction.inject_virtual_energy(&mut self.pool);
        self.last_feeling = Some(CognitiveFeelingFactory::from_prediction(&prediction, None));
        self.last_prediction = Some(prediction);

        let score = self.memory.score_action(context, &state.id, action);
        if score > 0 {
            self.pool.predict("feeling::grasp", score as f32);
        } else if score < 0 {
            self.pool.predict("feeling::mismatch", (-score) as f32);
        }

        action
    }

    pub fn receive_feedback(
        &mut self,
        context: &str,
        state: &PublicState,
        action: Action,
        feedback: Feedback,
        mode: TeacherMode,
    ) -> AuditTrace {
        if mode.feedback_visible_to_learner() {
            self.pool.mark_feedback(format!("feedback::{feedback:?}"));
        }
        if mode.memory_write_enabled() {
            self.memory.write(MemoryEvent {
                context: context.to_owned(),
                state_id: state.id.clone(),
                action,
                feedback,
            });
            self.successor_memory.write(ExperienceFrame::new(
                repeat_map_state_keys(context, state, action),
                repeat_map_successor_keys(feedback),
            ));
            let current_keys = repeat_map_state_keys(context, state, action);
            let required_keys = repeat_map_required_keys(context, state, action);
            let prediction = self.successor_memory.predict_cstar_with_required_keys(
                &current_keys,
                &required_keys,
                PredictionConfig::default(),
            );
            self.last_consequence = Some(ActionConsequenceEvaluator::evaluate(&prediction));
            self.last_feeling = Some(CognitiveFeelingFactory::from_prediction(
                &prediction,
                Some(&format!("feedback::{feedback:?}")),
            ));
            self.last_prediction = Some(prediction);
        }
        AuditTrace::for_mode(mode)
    }

    pub fn export_skill_package(&self, skill_id: impl Into<String>) -> SkillPackage {
        SkillPackage {
            skill_id: skill_id.into(),
            memory_events: self.memory.events().to_vec(),
            successor_frames: self.successor_memory.frames().to_vec(),
        }
    }

    pub fn from_skill_package(package: SkillPackage) -> Self {
        let mut memory = MemoryStore::default();
        for event in package.memory_events {
            memory.write(event);
        }
        let mut successor_memory = SuccessorMemory::default();
        for frame in package.successor_frames {
            successor_memory.write(frame);
        }
        Self {
            pool: DualEnergyStatePool::default(),
            memory,
            successor_memory,
            last_prediction: None,
            last_feeling: None,
            last_consequence: None,
        }
    }

    pub fn memory_len(&self) -> usize {
        self.memory.events().len()
    }

    pub fn score_action(&self, context: &str, state_id: &str, action: Action) -> i32 {
        self.memory.score_action(context, state_id, action)
    }

    pub fn successor_memory_len(&self) -> usize {
        self.successor_memory.frames().len()
    }

    pub fn last_prediction(&self) -> Option<&PredictionPackage> {
        self.last_prediction.as_ref()
    }

    pub fn last_feeling(&self) -> Option<&CognitiveFeeling> {
        self.last_feeling.as_ref()
    }

    pub fn last_consequence(&self) -> Option<ActionConsequence> {
        self.last_consequence
    }

    fn best_action_by_consequence(&self, context: &str, state: &PublicState) -> Action {
        let candidates = self.consequence_candidates(context, state);
        if candidates.iter().any(ConsequenceCandidate::has_signal) {
            candidates
                .into_iter()
                .max_by(|left, right| left.drive.total_cmp(&right.drive))
                .expect("repeat map action set is non-empty")
                .action
        } else {
            self.memory.best_action(context, &state.id, &ACTIONS)
        }
    }

    fn consequence_candidates(
        &self,
        context: &str,
        state: &PublicState,
    ) -> Vec<ConsequenceCandidate> {
        ACTIONS
            .into_iter()
            .map(|action| self.consequence_candidate(context, state, action))
            .collect()
    }

    fn consequence_candidate(
        &self,
        context: &str,
        state: &PublicState,
        action: Action,
    ) -> ConsequenceCandidate {
        let current_keys = repeat_map_state_keys(context, state, action);
        let required_keys = repeat_map_required_keys(context, state, action);
        let prediction = self.successor_memory.predict_cstar_with_required_keys(
            &current_keys,
            &required_keys,
            PredictionConfig::default(),
        );
        let consequence = ActionConsequenceEvaluator::evaluate(&prediction);
        ConsequenceCandidate {
            action,
            drive: consequence.drive,
            expected_reward: consequence.expected_reward,
            expected_punishment: consequence.expected_punishment,
        }
    }
}

#[derive(Debug, Clone, Copy)]
struct ConsequenceCandidate {
    action: Action,
    drive: f32,
    expected_reward: f32,
    expected_punishment: f32,
}

impl ConsequenceCandidate {
    fn has_signal(&self) -> bool {
        self.expected_reward > 0.0 || self.expected_punishment > 0.0
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SkillPackage {
    pub skill_id: String,
    pub memory_events: Vec<MemoryEvent<Action>>,
    pub successor_frames: Vec<ExperienceFrame>,
}

impl SkillPackage {
    pub fn manifest(
        &self,
        domain: impl Into<String>,
        evidence: SkillEvidence,
        boundary: SkillBoundary,
    ) -> SkillManifest {
        SkillManifest::new(self.skill_id.clone(), domain, evidence, boundary)
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct PhaseResult {
    pub correct: usize,
    pub total: usize,
    pub accuracy: f32,
    pub traces: Vec<AuditTrace>,
}

pub fn run_phase(
    world: &RepeatMapWorld,
    learner: &mut RepeatMapLearner,
    mode: TeacherMode,
) -> PhaseResult {
    let mut correct = 0;
    let mut traces = Vec::with_capacity(world.states().len());

    for state in world.states() {
        let selected = if mode.answer_visible_to_learner() {
            world.teacher_action(state)
        } else {
            learner.select_action(world.context(), state)
        };
        let feedback = world.commit_action(state, selected);
        if feedback == Feedback::Reward {
            correct += 1;
        }
        traces.push(learner.receive_feedback(world.context(), state, selected, feedback, mode));
    }

    let total = world.states().len();
    PhaseResult {
        correct,
        total,
        accuracy: correct as f32 / total as f32,
        traces,
    }
}

pub fn train_repeats(
    world: &RepeatMapWorld,
    learner: &mut RepeatMapLearner,
    repeats: usize,
) -> Vec<PhaseResult> {
    (0..repeats)
        .map(|_| run_phase(world, learner, TeacherMode::FeedbackOnly))
        .collect()
}

fn build_public_states(state_count: usize) -> Vec<PublicState> {
    const SHAPES: [&str; 6] = ["circle", "square", "triangle", "diamond", "hexagon", "star"];
    const COLORS: [&str; 4] = ["orange", "blue", "yellow", "green"];
    const MARKS: [&str; 2] = ["edge", "top"];

    (0..state_count)
        .map(|slot| PublicState {
            id: format!("U{slot:02}"),
            shape: SHAPES[slot % SHAPES.len()],
            color: COLORS[(slot * 3 + 1) % COLORS.len()],
            mark: MARKS[slot % MARKS.len()],
            slot,
        })
        .collect()
}

fn deterministic_answer_index(seed: u64, context: &str, state: &PublicState) -> usize {
    let context_bias = context.bytes().fold(0_u64, |acc, byte| {
        acc.wrapping_mul(31).wrapping_add(byte as u64)
    });
    let mixed = seed
        .wrapping_mul(1_103_515_245)
        .wrapping_add(context_bias)
        .wrapping_add((state.slot as u64).wrapping_mul(2_654_435_761));
    (mixed % ACTIONS.len() as u64) as usize
}

fn repeat_map_state_keys(context: &str, state: &PublicState, action: Action) -> Vec<String> {
    vec![
        format!("context::{context}"),
        format!("state::{}", state.id),
        format!("shape::{}", state.shape),
        format!("color::{}", state.color),
        format!("mark::{}", state.mark),
        format!("action::{action:?}"),
    ]
}

fn repeat_map_successor_keys(feedback: Feedback) -> Vec<String> {
    match feedback {
        Feedback::Reward => vec!["feedback::Reward".to_owned(), "feeling::grasp".to_owned()],
        Feedback::Punishment => vec![
            "feedback::Punishment".to_owned(),
            "feeling::mismatch".to_owned(),
        ],
    }
}

fn repeat_map_required_keys(context: &str, state: &PublicState, action: Action) -> Vec<String> {
    vec![
        format!("context::{context}"),
        format!("state::{}", state.id),
        format!("action::{action:?}"),
    ]
}
