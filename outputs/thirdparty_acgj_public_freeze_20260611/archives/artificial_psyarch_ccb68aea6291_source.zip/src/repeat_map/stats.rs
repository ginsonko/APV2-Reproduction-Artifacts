use std::collections::BTreeMap;

use crate::repeat_map::records::{EventRecord, GroupAggregate, MetricAggregate, SeedSummary};

pub fn accuracy(events: &[EventRecord]) -> f64 {
    let correct = events.iter().filter(|event| event.matched).count();
    correct as f64 / events.len() as f64
}

pub fn aggregate_groups(seed_summaries: &[SeedSummary]) -> Vec<GroupAggregate> {
    let mut grouped: BTreeMap<&'static str, Vec<&SeedSummary>> = BTreeMap::new();
    for summary in seed_summaries {
        grouped.entry(summary.group_id).or_default().push(summary);
    }

    grouped
        .into_values()
        .map(|summaries| {
            let first = summaries[0];
            GroupAggregate {
                group_id: first.group_id,
                display_name_zh: first.display_name_zh,
                seed_count: summaries.len(),
                metrics: aggregate_metrics(&summaries),
                real_llm_call_count: summaries
                    .iter()
                    .map(|summary| summary.real_llm_call_count)
                    .sum(),
                api_error_count: summaries
                    .iter()
                    .map(|summary| summary.api_error_count)
                    .sum(),
                parse_failure_count: summaries
                    .iter()
                    .map(|summary| summary.parse_failure_count)
                    .sum(),
                posting_label_count: summaries
                    .iter()
                    .map(|summary| summary.posting_label_count)
                    .sum(),
                tool_call_count: summaries
                    .iter()
                    .map(|summary| summary.tool_call_count)
                    .sum(),
            }
        })
        .collect()
}

fn aggregate_metrics(summaries: &[&SeedSummary]) -> BTreeMap<&'static str, MetricAggregate> {
    let mut metrics = BTreeMap::new();
    metrics.insert(
        "pretest_accuracy",
        aggregate_metric(summaries.iter().map(|summary| summary.pretest_accuracy)),
    );
    metrics.insert(
        "alpha_train_first_round_accuracy",
        aggregate_metric(
            summaries
                .iter()
                .map(|summary| summary.alpha_train_first_round_accuracy),
        ),
    );
    metrics.insert(
        "alpha_train_last_round_accuracy",
        aggregate_metric(
            summaries
                .iter()
                .map(|summary| summary.alpha_train_last_round_accuracy),
        ),
    );
    metrics.insert(
        "alpha_learning_gain",
        aggregate_metric(summaries.iter().map(|summary| summary.alpha_learning_gain)),
    );
    metrics.insert(
        "alpha_holdout_accuracy",
        aggregate_metric(
            summaries
                .iter()
                .map(|summary| summary.alpha_holdout_accuracy),
        ),
    );
    metrics.insert(
        "package_reload_accuracy",
        aggregate_metric(
            summaries
                .iter()
                .map(|summary| summary.package_reload_accuracy),
        ),
    );
    metrics.insert(
        "beta_train_first_round_accuracy",
        aggregate_metric(
            summaries
                .iter()
                .map(|summary| summary.beta_train_first_round_accuracy),
        ),
    );
    metrics.insert(
        "beta_train_last_round_accuracy",
        aggregate_metric(
            summaries
                .iter()
                .map(|summary| summary.beta_train_last_round_accuracy),
        ),
    );
    metrics.insert(
        "beta_relearning_gain",
        aggregate_metric(summaries.iter().map(|summary| summary.beta_relearning_gain)),
    );
    metrics.insert(
        "beta_holdout_accuracy",
        aggregate_metric(
            summaries
                .iter()
                .map(|summary| summary.beta_holdout_accuracy),
        ),
    );
    metrics
}

fn aggregate_metric(values: impl Iterator<Item = f64>) -> MetricAggregate {
    let values: Vec<_> = values.map(round4).collect();
    let n = values.len();
    let mean = round4(values.iter().sum::<f64>() / n as f64);
    let sample_std = if n > 1 {
        let variance = values
            .iter()
            .map(|value| (value - mean).powi(2))
            .sum::<f64>()
            / (n - 1) as f64;
        round4(variance.sqrt())
    } else {
        0.0
    };
    let ci95 = round4(1.96 * sample_std / (n as f64).sqrt());

    MetricAggregate {
        n,
        values,
        mean,
        sample_std,
        ci95,
    }
}

fn round4(value: f64) -> f64 {
    (value * 10_000.0).round() / 10_000.0
}
