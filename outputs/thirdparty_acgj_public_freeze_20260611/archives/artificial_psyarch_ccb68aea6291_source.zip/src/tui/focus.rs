#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FocusPane {
    Chat,
    Queue,
    State,
    Trace,
    Artifacts,
}

const FOCUS_PANES: [FocusPane; 5] = [
    FocusPane::Chat,
    FocusPane::Queue,
    FocusPane::State,
    FocusPane::Trace,
    FocusPane::Artifacts,
];

impl FocusPane {
    pub fn next(self) -> Self {
        let current = FOCUS_PANES
            .iter()
            .position(|pane| *pane == self)
            .unwrap_or_default();
        FOCUS_PANES[(current + 1) % FOCUS_PANES.len()]
    }

    pub(crate) fn index(self) -> usize {
        FOCUS_PANES
            .iter()
            .position(|pane| *pane == self)
            .unwrap_or_default()
    }
}
