use crate::experiments::local_runner::ExperimentRunConfig;
use crate::experiments::records::ExperimentRecords;
use crate::gl::{GlExecutionResult, GlPlan, GlRequest, GlRequestKind};
use crate::learning::{LessonRunReport, MediaOutput, write_lesson_bundle};

use super::app::AppState;
use super::learning_commands;
use super::worker::{
    MathReportJob, MathReportResult, QueuedLessonsJob, QueuedLessonsResult, WorkerRequest,
};

impl AppState {
    pub fn plan_gl_request(&self, kind: GlRequestKind, text: String) -> GlPlan {
        self.gl.plan(GlRequest {
            request_id: format!("gl-{}", self.trace.len()),
            kind,
            text,
            desired_outputs: vec![MediaOutput::Text],
            artifacts: Vec::new(),
        })
    }

    pub fn execute_gl_plan(&mut self, plan: GlPlan) -> GlExecutionResult {
        let result = self.gl.execute(&mut self.runtime, plan);
        self.trace.extend(
            result
                .outcomes
                .iter()
                .map(|outcome| format!("gl outcome: {outcome:?}")),
        );
        self.artifacts.extend(result.message.artifacts.clone());
        result
    }

    pub fn plan_reserved_media(&mut self) {
        let request = GlRequest {
            request_id: format!("gl-media-{}", self.artifacts.len()),
            kind: GlRequestKind::RenderMedia,
            text: "render reserved media artifacts".to_owned(),
            desired_outputs: vec![MediaOutput::Image, MediaOutput::Audio],
            artifacts: self.artifacts.clone(),
        };
        let plan = self.gl.plan(request);
        let result = self.execute_gl_plan(plan);
        self.trace.push(format!(
            "media render plan completed with {} outcome(s)",
            result.outcomes.len()
        ));
    }

    pub fn run_math_report_command(&mut self) {
        self.submit_worker_job(WorkerRequest::RunMathReport(MathReportJob {
            learning: self.learning.clone(),
        }));
    }

    pub fn push_learning_status(&mut self) {
        learning_commands::push_learning_status(self);
    }

    pub(super) fn run_queued_lessons(&mut self) {
        if self.queue.is_empty() {
            self.trace.push("no queued lesson to run".to_owned());
            return;
        }
        self.submit_worker_job(WorkerRequest::RunQueuedLessons(QueuedLessonsJob {
            learning: self.learning.clone(),
            lessons: self.queue.clone(),
        }));
    }

    pub(super) fn finish_queued_lessons(&mut self, result: QueuedLessonsResult) {
        self.learning = result.learning;
        self.chat
            .push(format!("ran {} queued lesson(s)", result.reports.len()));
        self.sync_learning_outputs(&result.reports);
        self.save_learning_session(&result.reports);
    }

    pub(super) fn finish_math_report(&mut self, result: MathReportResult) {
        self.learning = result.learning;
        learning_commands::push_math_summary(self, &result.train_reports[0], &result.probe_report);
        self.trace
            .push(format!("math generalization answers: {:?}", result.answers));
        self.sync_learning_outputs(&result.train_reports);
        self.sync_learning_outputs(std::slice::from_ref(&result.probe_report));
        self.save_learning_session(&result.train_reports);
    }

    pub(super) fn export_last_report(&mut self) {
        match self.reports.last().cloned() {
            Some(report) => self.write_last_report(report),
            None => self
                .trace
                .push(self.text().no_report_to_export().to_owned()),
        }
    }

    pub(super) fn run_local_records(&mut self) {
        self.submit_worker_job(WorkerRequest::RunLocalRecords(ExperimentRunConfig {
            train_repeats: 8,
        }));
    }

    pub(super) fn finish_local_records(&mut self, records: ExperimentRecords) {
        self.summary = format!(
            "{} experiments, {} events, holdouts_passed={}, validation_errors={}",
            records.summary.experiment_count,
            records.summary.event_count,
            records.summary.all_holdouts_passed,
            records.validation_errors.len()
        );
        self.chat.push("local AP-Core records refreshed".to_owned());
        self.trace.push(self.summary.clone());
    }

    fn write_last_report(&mut self, report: LessonRunReport) {
        let bundle_path = self.workspace.export_bundle("ap-tui-last-run.json");
        match write_lesson_bundle(&bundle_path, &report) {
            Ok(()) => self
                .trace
                .push(format!("exported {}", bundle_path.display())),
            Err(error) => self.trace.push(format!("export failed: {error}")),
        }
    }
}
