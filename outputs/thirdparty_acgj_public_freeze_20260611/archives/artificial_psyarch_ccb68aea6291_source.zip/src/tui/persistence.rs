use std::path::PathBuf;

use crate::learning::{LearningSession, LessonRunReport};
use crate::workspace::ensure_parent;

use super::app::AppState;
use super::i18n::UiText;

impl AppState {
    pub(crate) fn save_learning_session(&mut self, reports: &[LessonRunReport]) {
        let Some(lesson_id) = reports.last().map(|report| report.lesson_id.as_str()) else {
            return;
        };
        self.archive_current_skill();
        if let Err(error) = ensure_parent(&self.skill_path) {
            self.trace.push(format!("skill directory failed: {error}"));
            return;
        }
        match self
            .learning
            .save_skill_package(&self.skill_path, "ap-tui", lesson_id)
        {
            Ok(()) => self
                .trace
                .push(format!("saved skill package {}", self.skill_path.display())),
            Err(error) => self.trace.push(format!("skill save failed: {error}")),
        }
    }

    fn archive_current_skill(&mut self) {
        if !self.skill_path.exists() {
            return;
        }
        let archive_path = self
            .workspace
            .interactive_skill_history(&format!("skill-{}.apbin", self.reports.len()));
        if let Err(error) = copy_existing_skill(&self.skill_path, &archive_path) {
            self.trace.push(format!("skill archive failed: {error}"));
        }
    }
}

pub(super) fn load_learning_session(path: &PathBuf) -> (LearningSession, String) {
    match LearningSession::load_or_new("interactive", path) {
        Ok(session) => {
            let message = if path.exists() {
                format!("loaded skill package {}", path.display())
            } else {
                format!("skill package will be saved to {}", path.display())
            };
            (session, message)
        }
        Err(error) => (
            LearningSession::new("interactive"),
            format!("skill load failed: {error}; starting empty session"),
        ),
    }
}

pub(super) fn initial_trace(persistence_trace: String, text: UiText) -> Vec<String> {
    vec![
        text.teacher_off_audit().to_owned(),
        persistence_trace,
        text.runtime_commands().to_owned(),
    ]
}

fn copy_existing_skill(from: &std::path::Path, to: &std::path::Path) -> std::io::Result<()> {
    ensure_parent(to)?;
    std::fs::copy(from, to).map(|_| ())
}
