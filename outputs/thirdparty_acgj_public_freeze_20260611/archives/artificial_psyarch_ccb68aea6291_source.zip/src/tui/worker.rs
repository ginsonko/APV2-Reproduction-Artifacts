use std::sync::mpsc::{self, Receiver, Sender, TryRecvError};
use std::thread;

use crate::experiments::local_runner::{ExperimentRunConfig, run_all_experiment_records};
use crate::experiments::records::ExperimentRecords;
use crate::learning::{
    LearningSession, Lesson, LessonRunReport, MathDifficulty, ScaffoldSpecRunBundle,
    SkillScaffoldSpec, generated_generalization_probe, generated_math_lesson_for_level,
    probe_answers,
};

use super::app::AppState;

#[derive(Debug)]
pub struct TuiWorker {
    tx: Sender<WorkerRequest>,
    rx: Receiver<WorkerEvent>,
}

impl TuiWorker {
    pub fn start() -> Self {
        let (request_tx, request_rx) = mpsc::channel();
        let (event_tx, event_rx) = mpsc::channel();
        thread::spawn(move || worker_loop(request_rx, event_tx));
        Self {
            tx: request_tx,
            rx: event_rx,
        }
    }

    pub fn submit(&self, request: WorkerRequest) -> Result<(), WorkerSubmitError> {
        self.tx.send(request).map_err(|_| WorkerSubmitError)
    }

    pub fn drain_events(&self) -> Vec<WorkerEvent> {
        let mut events = Vec::new();
        loop {
            match self.rx.try_recv() {
                Ok(event) => events.push(event),
                Err(TryRecvError::Empty) => return events,
                Err(TryRecvError::Disconnected) => {
                    events.push(WorkerEvent::Stopped);
                    return events;
                }
            }
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct WorkerSubmitError;

impl std::fmt::Display for WorkerSubmitError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(formatter, "tui worker is not available")
    }
}

impl std::error::Error for WorkerSubmitError {}

#[derive(Debug)]
pub enum WorkerRequest {
    RunQueuedLessons(QueuedLessonsJob),
    RunMathReport(MathReportJob),
    RunLocalRecords(ExperimentRunConfig),
    RunScaffoldSpec(Box<ScaffoldSpecJob>),
}

#[derive(Debug)]
pub enum WorkerEvent {
    QueuedLessonsFinished(Box<QueuedLessonsResult>),
    MathReportFinished(Box<MathReportResult>),
    LocalRecordsFinished(Box<ExperimentRecords>),
    ScaffoldSpecFinished(Box<ScaffoldSpecResult>),
    Stopped,
}

impl WorkerEvent {
    pub fn apply_to(self, app: &mut AppState) {
        let event = pass_if_unhandled(self, app, Self::apply_stopped);
        let event = pass_if_unhandled(event, app, Self::apply_queued_lessons);
        let event = pass_if_unhandled(event, app, Self::apply_math_report);
        let event = pass_if_unhandled(event, app, Self::apply_local_records);
        event.apply_scaffold_spec(app);
    }

    fn apply_stopped(self, app: &mut AppState) -> Result<(), Self> {
        match self {
            Self::Stopped => {
                app.trace.push("background worker stopped".to_owned());
                Ok(())
            }
            event => Err(event),
        }
    }

    fn apply_queued_lessons(self, app: &mut AppState) -> Result<(), Self> {
        match self {
            Self::QueuedLessonsFinished(result) => {
                app.finish_queued_lessons(*result);
                Ok(())
            }
            event => Err(event),
        }
    }

    fn apply_math_report(self, app: &mut AppState) -> Result<(), Self> {
        match self {
            Self::MathReportFinished(result) => {
                app.finish_math_report(*result);
                Ok(())
            }
            event => Err(event),
        }
    }

    fn apply_local_records(self, app: &mut AppState) -> Result<(), Self> {
        match self {
            Self::LocalRecordsFinished(records) => {
                app.finish_local_records(*records);
                Ok(())
            }
            event => Err(event),
        }
    }

    fn apply_scaffold_spec(self, app: &mut AppState) {
        if let Self::ScaffoldSpecFinished(result) = self {
            app.finish_scaffold_spec(*result);
        }
    }
}

type EventApplicator = fn(WorkerEvent, &mut AppState) -> Result<(), WorkerEvent>;

fn pass_if_unhandled(
    event: WorkerEvent,
    app: &mut AppState,
    apply: EventApplicator,
) -> WorkerEvent {
    match apply(event, app) {
        Ok(()) => WorkerEvent::Stopped,
        Err(event) => event,
    }
}

#[derive(Debug, Clone)]
pub struct QueuedLessonsJob {
    pub learning: LearningSession,
    pub lessons: Vec<Lesson>,
}

#[derive(Debug, Clone)]
pub struct QueuedLessonsResult {
    pub learning: LearningSession,
    pub reports: Vec<LessonRunReport>,
}

#[derive(Debug, Clone)]
pub struct MathReportJob {
    pub learning: LearningSession,
}

#[derive(Debug, Clone)]
pub struct MathReportResult {
    pub learning: LearningSession,
    pub train_reports: Vec<LessonRunReport>,
    pub probe_report: LessonRunReport,
    pub answers: Vec<String>,
}

#[derive(Debug, Clone)]
pub struct ScaffoldSpecJob {
    pub learning: LearningSession,
    pub spec: SkillScaffoldSpec,
}

#[derive(Debug, Clone)]
pub struct ScaffoldSpecResult {
    pub learning: LearningSession,
    pub bundle: ScaffoldSpecRunBundle,
}

fn worker_loop(rx: Receiver<WorkerRequest>, tx: Sender<WorkerEvent>) {
    for request in rx {
        if tx.send(run_request(request)).is_err() {
            break;
        }
    }
}

fn run_request(request: WorkerRequest) -> WorkerEvent {
    match request {
        WorkerRequest::RunQueuedLessons(job) => {
            WorkerEvent::QueuedLessonsFinished(Box::new(run_queued_lessons(job)))
        }
        WorkerRequest::RunMathReport(job) => {
            WorkerEvent::MathReportFinished(Box::new(run_math_report(job)))
        }
        WorkerRequest::RunLocalRecords(config) => {
            WorkerEvent::LocalRecordsFinished(Box::new(run_all_experiment_records(config)))
        }
        WorkerRequest::RunScaffoldSpec(job) => {
            WorkerEvent::ScaffoldSpecFinished(Box::new(run_scaffold_spec(*job)))
        }
    }
}

fn run_queued_lessons(mut job: QueuedLessonsJob) -> QueuedLessonsResult {
    let reports = job.learning.run_lessons(&job.lessons);
    QueuedLessonsResult {
        learning: job.learning,
        reports,
    }
}

fn run_math_report(mut job: MathReportJob) -> MathReportResult {
    let train = generated_math_lesson_for_level("tui-math-mixed", MathDifficulty::Mixed);
    let train_reports = job.learning.run_lessons(std::slice::from_ref(&train));
    let probe = generated_generalization_probe("tui-math-generalization");
    let probe_report = job.learning.probe_lesson(&probe);
    let answers = probe_answers(&probe_report);
    MathReportResult {
        learning: job.learning,
        train_reports,
        probe_report,
        answers,
    }
}

fn run_scaffold_spec(mut job: ScaffoldSpecJob) -> ScaffoldSpecResult {
    let bundle = job.learning.run_scaffold_spec(&job.spec);
    ScaffoldSpecResult {
        learning: job.learning,
        bundle,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::learning::LlmBridge;
    use crate::learning::{FeedbackPolicy, LearningMaterial, LearningSource};

    #[test]
    fn worker_runs_queued_lessons_without_main_thread_session_mutation() {
        let worker = TuiWorker::start();
        let original = LearningSession::new("worker-test");
        let lesson = crate::learning::PlannedLesson
            .plan_lesson(crate::learning::AgentLearningRequest::user_text(
                "worker-lesson",
                "learn worker path",
            ))
            .lesson;

        worker
            .submit(WorkerRequest::RunQueuedLessons(QueuedLessonsJob {
                learning: original.clone(),
                lessons: vec![lesson],
            }))
            .unwrap();
        let event = wait_for_event(&worker);

        match event {
            WorkerEvent::QueuedLessonsFinished(result) => {
                assert_eq!(original.agent().memory_rows(), 0);
                assert_eq!(result.reports.len(), 1);
                assert!(result.learning.agent().memory_rows() > 0);
            }
            other => panic!("unexpected worker event: {other:?}"),
        }
    }

    #[test]
    fn worker_runs_math_report() {
        let worker = TuiWorker::start();
        worker
            .submit(WorkerRequest::RunMathReport(MathReportJob {
                learning: LearningSession::new("math-worker-test"),
            }))
            .unwrap();
        let event = wait_for_event(&worker);

        match event {
            WorkerEvent::MathReportFinished(result) => {
                assert_eq!(result.train_reports.len(), 1);
                assert!(!result.answers.is_empty());
            }
            other => panic!("unexpected worker event: {other:?}"),
        }
    }

    fn wait_for_event(worker: &TuiWorker) -> WorkerEvent {
        for _ in 0..100 {
            if let Some(event) = worker.drain_events().into_iter().next() {
                return event;
            }
            std::thread::sleep(std::time::Duration::from_millis(20));
        }
        panic!("worker event timed out")
    }

    #[allow(dead_code)]
    fn _lesson_material_is_send() {
        let _ = LearningMaterial::text("send");
        let _ = LearningSource::User;
        let _ = FeedbackPolicy::UserScored;
    }
}
