use crate::language_core::{language_world_from_json_text, response_policy_world_from_json_text};

use super::app::AppState;
use super::language_bridge::LanguageDialogBridge;

const IMPORT_LANGUAGE_COMMAND: &str = "/import-language";
const IMPORT_RESPONSE_POLICY_COMMAND: &str = "/import-response-policy";
const DEFAULT_LANGUAGE_DATASET: &str = "language-grounding.jsonl";
const DEFAULT_RESPONSE_POLICY_DATASET: &str = "response-policy.jsonl";

pub fn apply_language_command(app: &mut AppState, text: &str) -> bool {
    language_command(text).is_some_and(|command| {
        apply_command(app, command);
        true
    })
}

fn apply_command(app: &mut AppState, command: LanguageCommand<'_>) {
    match command {
        LanguageCommand::ImportLanguage(path) => import_language_dataset(app, path),
        LanguageCommand::ImportResponsePolicy(path) => import_response_policy_dataset(app, path),
    }
}

fn import_language_dataset(app: &mut AppState, path_arg: Option<&str>) {
    let path = path_arg
        .filter(|value| !value.is_empty())
        .map(std::path::PathBuf::from)
        .unwrap_or_else(|| app.workspace.language_dataset(DEFAULT_LANGUAGE_DATASET));
    match std::fs::read_to_string(&path)
        .map_err(|error| error.to_string())
        .and_then(|text| language_world_from_json_text(&text).map_err(|error| error.to_string()))
    {
        Ok(world) => install_language_world(app, world, &path),
        Err(error) => app.trace.push(format!(
            "language import failed from {}: {error}",
            path.display()
        )),
    }
}

fn install_language_world(
    app: &mut AppState,
    world: crate::language_core::LanguageGroundingWorld,
    path: &std::path::Path,
) {
    let train = world.train_items().len();
    let holdout = world.holdout_items().len();
    app.language_dialog = LanguageDialogBridge::train_from_world(&world, 5);
    app.trace.push(format!(
        "language dataset imported from {} train={} holdout={} rows={}",
        path.display(),
        train,
        holdout,
        app.language_dialog.learned_rows()
    ));
    app.chat.push(format!(
        "language grounding dataset loaded: {train} train / {holdout} holdout"
    ));
}

fn import_response_policy_dataset(app: &mut AppState, path_arg: Option<&str>) {
    let path = path_arg
        .filter(|value| !value.is_empty())
        .map(std::path::PathBuf::from)
        .unwrap_or_else(|| {
            app.workspace
                .language_dataset(DEFAULT_RESPONSE_POLICY_DATASET)
        });
    match std::fs::read_to_string(&path)
        .map_err(|error| error.to_string())
        .and_then(|text| {
            response_policy_world_from_json_text(&text).map_err(|error| error.to_string())
        }) {
        Ok(world) => install_response_policy_world(app, world, &path),
        Err(error) => app.trace.push(format!(
            "response policy import failed from {}: {error}",
            path.display()
        )),
    }
}

fn install_response_policy_world(
    app: &mut AppState,
    world: crate::language_core::ResponsePolicyWorld,
    path: &std::path::Path,
) {
    let train = world.train_items().len();
    let holdout = world.holdout_items().len();
    app.language_dialog.train_response_policy(&world, 5);
    app.trace.push(format!(
        "response policy dataset imported from {} train={} holdout={} rows={}",
        path.display(),
        train,
        holdout,
        app.language_dialog.response_policy_rows()
    ));
    app.chat.push(format!(
        "response policy dataset loaded: {train} train / {holdout} holdout"
    ));
}

fn language_command(text: &str) -> Option<LanguageCommand<'_>> {
    parse_command(text, IMPORT_LANGUAGE_COMMAND)
        .map(LanguageCommand::ImportLanguage)
        .or_else(|| {
            parse_command(text, IMPORT_RESPONSE_POLICY_COMMAND)
                .map(LanguageCommand::ImportResponsePolicy)
        })
}

fn parse_command<'a>(text: &'a str, command: &str) -> Option<Option<&'a str>> {
    text.strip_prefix(command)
        .filter(|rest| rest.is_empty() || rest.starts_with(' '))
        .map(str::trim)
        .map(|rest| (!rest.is_empty()).then_some(rest))
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum LanguageCommand<'a> {
    ImportLanguage(Option<&'a str>),
    ImportResponsePolicy(Option<&'a str>),
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn import_language_command_accepts_optional_path() {
        assert_eq!(
            language_command("/import-language"),
            Some(LanguageCommand::ImportLanguage(None))
        );
        assert_eq!(
            language_command("/import-language data.jsonl"),
            Some(LanguageCommand::ImportLanguage(Some("data.jsonl")))
        );
        assert_eq!(language_command("/import-languagex"), None);
    }

    #[test]
    fn import_response_policy_command_accepts_optional_path() {
        assert_eq!(
            language_command("/import-response-policy"),
            Some(LanguageCommand::ImportResponsePolicy(None))
        );
        assert_eq!(
            language_command("/import-response-policy policy.jsonl"),
            Some(LanguageCommand::ImportResponsePolicy(Some("policy.jsonl")))
        );
    }
}
