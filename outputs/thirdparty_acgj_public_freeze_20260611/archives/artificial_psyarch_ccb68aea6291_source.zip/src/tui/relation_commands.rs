use crate::learning::{DEFAULT_RELATION_SKILL, probe_relation_scene_json};

use super::app::AppState;

pub fn apply_relation_command(app: &mut AppState, text: &str) -> bool {
    let Some(scene_json) = relation_scene_json(text) else {
        return false;
    };
    match probe_relation_scene_json(
        app.workspace.external_skill(DEFAULT_RELATION_SKILL),
        scene_json,
    ) {
        Ok(report) => {
            app.chat.push(format!("AP: {}", report.text));
            app.trace.push(format!(
                "relation probe action={} state_items={}",
                report.action,
                report.state_items.len()
            ));
        }
        Err(error) => app.trace.push(format!("relation probe failed: {error}")),
    }
    true
}

fn relation_scene_json(text: &str) -> Option<&str> {
    text.strip_prefix("/relation ")
        .map(str::trim)
        .filter(|body| !body.is_empty())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::workspace::WorkspacePaths;

    #[test]
    fn relation_command_requires_body() {
        assert_eq!(relation_scene_json("/relation "), None);
        assert_eq!(
            relation_scene_json("/relation {\"objects\":[]}"),
            Some("{\"objects\":[]}")
        );
    }

    #[test]
    fn relation_command_probes_saved_skill() {
        let root = temp_workspace("ap-relation-tui");
        let mut app = AppState::new();
        app.workspace = WorkspacePaths::new(&root);
        write_relation_skill(&app.workspace);

        apply_relation_command(
            &mut app,
            r#"/relation {"objects":[{"id":"p","center":[10,50]},{"id":"q","center":[90,50]}]}"#,
        );
        let _ = std::fs::remove_dir_all(&root);

        assert!(app.chat.iter().any(|line| line == "AP: 在左边"));
        assert!(
            app.trace
                .iter()
                .any(|line| line.contains("relation probe action=RelationWordLeft"))
        );
    }

    fn temp_workspace(name: &str) -> std::path::PathBuf {
        std::env::temp_dir().join(format!("{name}-{}", std::process::id()))
    }

    fn write_relation_skill(paths: &WorkspacePaths) {
        let mut agent =
            crate::learning::LearnableAgent::new(crate::learning::DEFAULT_RELATION_DOMAIN);
        let spec = relation_skill_spec();
        crate::learning::ScaffoldSpecRunner::new(crate::learning::DEFAULT_RELATION_DOMAIN)
            .run(&mut agent, &spec);
        crate::learning::write_skill_package(
            paths.external_skill(crate::learning::DEFAULT_RELATION_SKILL),
            &agent.export_skill_package(crate::learning::DEFAULT_RELATION_SKILL_ID, "tui-test"),
        )
        .unwrap();
    }

    fn relation_skill_spec() -> crate::learning::SkillScaffoldSpec {
        let mut spec = crate::learning::SkillScaffoldSpec::new("skill.relation.test");
        spec.phases = vec![
            crate::learning::ScaffoldPhase::new(
                crate::learning::ScaffoldPhaseId::FeedbackOnly,
                1.0,
            ),
            crate::learning::ScaffoldPhase::new(crate::learning::ScaffoldPhaseId::TeacherOff, 0.0),
        ];
        let mut step = crate::learning::ScaffoldStep::new("left");
        step.state_items = vec![
            "object::a center=(20,50)".to_owned(),
            "object::b center=(80,50)".to_owned(),
            "axis::x_delta(a,b)=-60".to_owned(),
            "axis::abs_y_delta(a,b)=0".to_owned(),
        ];
        step.action_biases = vec![crate::learning::StepActionBias::new(
            "RelationWordLeft",
            1.0,
        )];
        spec.steps = vec![step];
        spec
    }
}
