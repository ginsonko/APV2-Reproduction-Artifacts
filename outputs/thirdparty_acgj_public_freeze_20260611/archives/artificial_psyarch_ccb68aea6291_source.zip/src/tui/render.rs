use ratatui::Frame;
use ratatui::layout::{Constraint, Direction, Layout, Margin, Rect};
use ratatui::style::{Color, Modifier, Style};
use ratatui::text::{Line, Span};
use ratatui::widgets::{Block, Borders, Paragraph, Wrap};

use super::app::AppState;
use super::editor::TextInput;
use super::focus::FocusPane;
use super::panel_text::{borrowed_lines, borrowed_lines_rev, owned_lines};
use super::text::{fit_owned, fit_text};

type PaneRenderer = fn(&mut Frame<'_>, Rect, &AppState);

const PANE_RENDERERS: [PaneRenderer; 5] = [
    render_chat,
    render_queue,
    render_state,
    render_trace,
    render_artifacts,
];

pub fn render(frame: &mut Frame<'_>, app: &AppState) {
    let layout = AppLayout::new(frame.area(), app);

    render_focus_panel(frame, layout.main, app);
    render_input(frame, layout.input, app);
    render_status(frame, layout.status, app);
    render_key_hints(frame, layout.hints, app);
    set_input_cursor(frame, layout.input, &app.input);
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct AppLayout {
    main: Rect,
    input: Rect,
    status: Rect,
    hints: Rect,
}

impl AppLayout {
    fn new(area: Rect, app: &AppState) -> Self {
        let input_height = input_box_height(area, &app.input);
        let root = Layout::default()
            .direction(Direction::Vertical)
            .constraints([
                Constraint::Min(8),
                Constraint::Length(input_height),
                Constraint::Length(1),
                Constraint::Length(1),
            ])
            .split(area);
        Self {
            main: root[0],
            input: root[1],
            status: root[2],
            hints: root[3],
        }
    }
}

fn input_box_height(area: Rect, input: &TextInput) -> u16 {
    let body_width = area.width.saturating_sub(2).max(1) as usize;
    let lines = input.wrapped_line_count(body_width);
    let capped_lines = lines.min(max_input_body_lines(area.height as usize));
    capped_lines as u16 + 2
}

fn max_input_body_lines(height: usize) -> usize {
    if height < 14 { 1 } else { 5.min(height / 4) }
}

fn render_focus_panel(frame: &mut Frame<'_>, area: Rect, app: &AppState) {
    PANE_RENDERERS[app.focus.index()](frame, area, app);
}

fn render_chat(frame: &mut Frame<'_>, area: Rect, app: &AppState) {
    render_wrapped_panel(frame, area, FocusPane::Chat, app, borrowed_lines(&app.chat));
}

fn render_queue(frame: &mut Frame<'_>, area: Rect, app: &AppState) {
    let lines = app.queue.iter().enumerate().map(|(index, input)| {
        format!(
            "{}. {:?} | {:?} | {}",
            index + 1,
            input.source,
            input.feedback_policy,
            input.goal
        )
    });
    render_wrapped_panel(frame, area, FocusPane::Queue, app, owned_lines(lines));
}

fn render_state(frame: &mut Frame<'_>, area: Rect, app: &AppState) {
    let lines = vec![
        Line::from(vec![
            Span::styled(
                label(app, "focus: ", "焦点: "),
                Style::default().fg(Color::Gray),
            ),
            Span::raw(app.text().pane_title(app.focus)),
        ]),
        Line::from(label_value(
            app,
            "queued lessons",
            "课程队列",
            app.queue.len(),
        )),
        Line::from(label_value(
            app,
            "lesson reports",
            "课程报告",
            app.reports.len(),
        )),
        Line::from(label_value(
            app,
            "background jobs",
            "后台任务",
            app.busy_jobs,
        )),
        Line::from(format!(
            "{}: {}",
            label(app, "memory rows", "记忆行数"),
            app.learning.agent().memory_rows()
        )),
        Line::from(format!(
            "{}: {}",
            label(app, "runtime ticks", "runtime ticks"),
            app.runtime.trace_log().entries().len()
        )),
        Line::from(format!(
            "{}: {}",
            label(app, "runtime frames", "runtime frames"),
            app.runtime.memory().frames().len()
        )),
        Line::from(format!(
            "{}: {}",
            label(app, "runtime actions", "runtime actions"),
            app.runtime_actions.join(", ")
        )),
        Line::from(format!(
            "{}: {}",
            label(app, "runtime feeling", "runtime feeling"),
            latest_runtime_feeling(app)
        )),
        Line::from(format!(
            "{}: {}",
            label(app, "language", "语言"),
            app.language.label()
        )),
        Line::from(format!(
            "{}: {}",
            label(app, "skill file", "技能文件"),
            app.skill_path.display()
        )),
        Line::from(format!(
            "{}: {}",
            label(app, "summary", "摘要"),
            app.summary
        )),
        Line::from(label(
            app,
            "agent bridge: JSON request -> planned lesson -> runner -> report",
            "agent 桥接: JSON 请求 -> 课程计划 -> runner -> 报告",
        )),
        Line::from(label(
            app,
            "media outputs: termwiz render plans for image/audio refs",
            "媒体输出: termwiz 图像/音频引用渲染计划",
        )),
    ];
    frame.render_widget(
        Paragraph::new(lines)
            .wrap(Wrap { trim: true })
            .block(block(FocusPane::State, app)),
        area,
    );
}

fn latest_runtime_feeling(app: &AppState) -> String {
    app.runtime_traces
        .last()
        .map(|trace| {
            format!(
                "{:?} pressure={:.2} gap={:.2}",
                trace.feeling.kind,
                trace.feeling_trace.channels.computation_pressure,
                trace.feeling_trace.expectation.expectation_gap
            )
        })
        .unwrap_or_else(|| "none".to_owned())
}

fn render_trace(frame: &mut Frame<'_>, area: Rect, app: &AppState) {
    render_wrapped_panel(
        frame,
        area,
        FocusPane::Trace,
        app,
        borrowed_lines_rev(&app.trace),
    );
}

fn render_artifacts(frame: &mut Frame<'_>, area: Rect, app: &AppState) {
    let lines = app.artifacts.iter().map(|artifact| {
        format!(
            "{} | {:?} | {} | {}",
            artifact.artifact_id,
            artifact.kind,
            artifact.mime_type.as_deref().unwrap_or("unknown"),
            artifact.uri
        )
    });
    render_wrapped_panel(frame, area, FocusPane::Artifacts, app, owned_lines(lines));
}

fn render_input(frame: &mut Frame<'_>, area: Rect, app: &AppState) {
    let input = visible_input_text(app);
    frame.render_widget(
        Paragraph::new(input).wrap(Wrap { trim: false }).block(
            Block::default()
                .borders(Borders::ALL)
                .title(app.text().input_title()),
        ),
        area,
    );
}

fn visible_input_text(app: &AppState) -> String {
    if app.input.is_empty() {
        app.text().input_placeholder().to_owned()
    } else {
        app.input.text().to_owned()
    }
}

fn render_status(frame: &mut Frame<'_>, area: Rect, app: &AppState) {
    let status = fit_owned(status_text(app, area.width), area.width as usize);
    frame.render_widget(Paragraph::new(status).style(Color::DarkGray), area);
}

fn status_text(app: &AppState, width: u16) -> String {
    if width < 64 {
        return compact_status_text(app);
    }
    app.text().status_line(
        app.text().pane_title(app.focus),
        app.queue.len(),
        app.artifacts.len(),
        app.busy_jobs,
        short_path(app.workspace.root()),
        short_path(&app.skill_path),
    )
}

fn compact_status_text(app: &AppState) -> String {
    match app.language {
        super::i18n::UiLanguage::Zh => format!(
            "{} | 课程={} | 产物={} | 后台={}",
            app.text().pane_title(app.focus),
            app.queue.len(),
            app.artifacts.len(),
            app.busy_jobs
        ),
        super::i18n::UiLanguage::En => format!(
            "{} | lessons={} | artifacts={} | jobs={}",
            app.text().pane_title(app.focus),
            app.queue.len(),
            app.artifacts.len(),
            app.busy_jobs
        ),
    }
}

fn render_key_hints(frame: &mut Frame<'_>, area: Rect, app: &AppState) {
    let hints = fit_owned(app.text().key_hint_line().to_owned(), area.width as usize);
    let style = Style::default().fg(Color::Black).bg(Color::Gray);
    frame.render_widget(Paragraph::new(hints).style(style), area);
}

fn set_input_cursor(frame: &mut Frame<'_>, area: Rect, input: &TextInput) {
    let inner = area.inner(Margin::new(1, 1));
    if inner.is_empty() || input.is_empty() {
        return;
    }
    let Some(cursor) = input_cursor_position(inner, input) else {
        return;
    };
    frame.set_cursor_position((cursor.x, cursor.y));
}

fn input_cursor_position(area: Rect, input: &TextInput) -> Option<Rect> {
    let width = area.width.max(1) as usize;
    let cursor = input.wrapped_cursor(width)?;
    let col = cursor.col as u16;
    let row = cursor.row as u16;
    Some(Rect::new(
        area.x.saturating_add(col),
        area.y
            .saturating_add(row.min(area.height.saturating_sub(1))),
        1,
        1,
    ))
}

fn block<'a>(pane: FocusPane, app: &'a AppState) -> Block<'a> {
    let style = if pane == app.focus {
        Style::default()
            .fg(Color::Cyan)
            .add_modifier(Modifier::BOLD)
    } else {
        Style::default().fg(Color::Gray)
    };
    Block::default()
        .borders(Borders::ALL)
        .title(app.text().pane_title(pane))
        .border_style(style)
}

fn render_wrapped_panel<'a>(
    frame: &mut Frame<'_>,
    area: Rect,
    pane: FocusPane,
    app: &'a AppState,
    lines: Vec<Line<'a>>,
) {
    frame.render_widget(
        Paragraph::new(lines)
            .wrap(Wrap { trim: true })
            .block(block(pane, app)),
        area,
    );
}

fn label<'a>(app: &AppState, en: &'a str, zh: &'a str) -> &'a str {
    match app.language {
        super::i18n::UiLanguage::Zh => zh,
        super::i18n::UiLanguage::En => en,
    }
}

fn label_value(app: &AppState, en: &str, zh: &str, value: impl std::fmt::Display) -> String {
    format!("{}: {value}", label(app, en, zh))
}

fn short_path(path: &std::path::Path) -> String {
    let name = path
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or_else(|| path.to_str().unwrap_or("."));
    fit_text(name, 24)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn input_box_height_grows_with_wrapped_text() {
        let mut input = TextInput::default();
        input.insert_str("abcdefghijkl");
        assert_eq!(input_box_height(Rect::new(0, 0, 6, 20), &input), 6);
    }

    #[test]
    fn layout_uses_one_focus_panel() {
        let app = AppState::new();
        let layout = AppLayout::new(Rect::new(0, 0, 80, 24), &app);

        assert_eq!(layout.main, Rect::new(0, 0, 80, 19));
        assert_eq!(layout.status.height, 1);
        assert_eq!(layout.hints.height, 1);
    }

    #[test]
    fn cursor_wraps_inside_input_area() {
        let mut input = TextInput::default();
        input.insert_str("abcdef");
        let cursor = input_cursor_position(Rect::new(10, 5, 4, 1), &input).unwrap();
        assert_eq!(cursor.x, 12);
        assert_eq!(cursor.y, 5);
    }

    #[test]
    fn cursor_uses_chinese_display_width() {
        let mut input = TextInput::default();
        input.insert_str("你好");
        let cursor = input_cursor_position(Rect::new(10, 5, 10, 1), &input).unwrap();
        assert_eq!(cursor.x, 14);
    }

    #[test]
    fn empty_input_hides_cursor() {
        assert!(input_cursor_position(Rect::new(10, 5, 4, 1), &TextInput::default()).is_none());
    }

    #[test]
    fn chat_render_wraps_instead_of_truncating() {
        let mut app = AppState::new();
        app.chat = vec!["abcdefghijk".to_owned()];
        let backend = ratatui::backend::TestBackend::new(12, 8);
        let mut terminal = ratatui::Terminal::new(backend).unwrap();

        terminal.draw(|frame| render(frame, &app)).unwrap();
        let buffer = terminal.backend().buffer();
        let rendered = buffer
            .content()
            .iter()
            .map(|cell| cell.symbol())
            .collect::<String>();

        assert!(rendered.contains("abcdefgh"));
        assert!(!rendered.contains('…'));
    }

    #[test]
    fn queue_is_hidden_until_focused() {
        let mut app = AppState::new();
        app.chat = vec!["chat-visible".to_owned()];
        app.queue.push(test_lesson("queue-hidden"));
        let rendered = render_to_string(&app, 60, 16);

        assert!(rendered.contains("chat-visible"));
        assert!(!rendered.contains("queue-hidden"));
    }

    #[test]
    fn queue_renders_when_focused() {
        let mut app = AppState::new();
        app.queue.push(test_lesson("queue-visible"));
        app.focus = FocusPane::Queue;
        let rendered = render_to_string(&app, 60, 16);

        assert!(rendered.contains("queue-visible"));
    }

    #[test]
    fn key_hints_are_rendered_at_bottom() {
        let app = AppState::new();
        let rendered = render_to_string(&app, 80, 16);

        assert!(rendered.contains("Ctrl-Q"));
        assert!(rendered.contains("Enter"));
    }

    #[test]
    fn status_uses_short_paths_to_keep_counts_visible() {
        let app = AppState::new();
        let status = status_text(&app, 48);

        assert!(status.contains("课程=") || status.contains("lessons="));
        assert!(!status.contains("current.apbin"));
    }

    fn test_lesson(goal: &str) -> crate::learning::Lesson {
        crate::learning::LearningInput::new(
            crate::learning::LearningSource::User,
            crate::learning::LearningMaterial::text(goal),
            goal,
            crate::ap::TeacherMode::FeedbackOnly,
            crate::learning::FeedbackPolicy::UserScored,
        )
        .into_lesson(format!("test-{goal}"))
    }

    fn render_to_string(app: &AppState, width: u16, height: u16) -> String {
        let backend = ratatui::backend::TestBackend::new(width, height);
        let mut terminal = ratatui::Terminal::new(backend).unwrap();
        terminal.draw(|frame| render(frame, app)).unwrap();
        terminal
            .backend()
            .buffer()
            .content()
            .iter()
            .map(|cell| cell.symbol())
            .collect()
    }
}
