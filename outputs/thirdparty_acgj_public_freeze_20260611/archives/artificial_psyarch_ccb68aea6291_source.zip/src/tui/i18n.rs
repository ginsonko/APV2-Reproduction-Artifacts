use super::focus::FocusPane;

const ZH_PANE_TITLES: [&str; 5] = ["聊天", "学习队列", "AP 状态", "追踪 / 审计", "产物"];
const EN_PANE_TITLES: [&str; 5] = [
    "Chat",
    "Learning Queue",
    "AP State",
    "Trace / Audit",
    "Artifacts",
];

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum UiLanguage {
    Zh,
    En,
}

impl UiLanguage {
    pub fn detect() -> Self {
        std::env::var("AP_TUI_LANG")
            .ok()
            .or_else(|| std::env::var("LANG").ok())
            .as_deref()
            .map(Self::from_locale)
            .unwrap_or(Self::Zh)
    }

    pub fn toggle(self) -> Self {
        match self {
            Self::Zh => Self::En,
            Self::En => Self::Zh,
        }
    }

    pub fn label(self) -> &'static str {
        match self {
            Self::Zh => "中文",
            Self::En => "English",
        }
    }

    fn from_locale(locale: &str) -> Self {
        if locale.to_ascii_lowercase().starts_with("en") {
            Self::En
        } else {
            Self::Zh
        }
    }
}

#[derive(Debug, Clone, Copy)]
pub struct UiText {
    language: UiLanguage,
}

impl UiText {
    pub fn new(language: UiLanguage) -> Self {
        Self { language }
    }

    pub fn app_title(self) -> &'static str {
        match self.language {
            UiLanguage::Zh => "AP TUI 学习控制台",
            UiLanguage::En => "AP TUI learning console",
        }
    }

    pub fn help_line(self) -> &'static str {
        match self.language {
            UiLanguage::Zh => "普通输入会作为对话发送；用 /learn <目标> 教我。",
            UiLanguage::En => "Plain input sends chat; use /learn <goal> to teach me.",
        }
    }

    pub fn resized(self) -> &'static str {
        match self.language {
            UiLanguage::Zh => "终端尺寸已变化",
            UiLanguage::En => "terminal resized",
        }
    }

    pub fn language_switched(self) -> String {
        match self.language {
            UiLanguage::Zh => "语言已切换为中文".to_owned(),
            UiLanguage::En => "language switched to English".to_owned(),
        }
    }

    pub fn input_placeholder(self) -> &'static str {
        match self.language {
            UiLanguage::Zh => "输入消息，Enter 发送；/learn <内容> 教我",
            UiLanguage::En => "type a message, Enter to send; /learn <goal> teaches me",
        }
    }

    pub fn input_title(self) -> &'static str {
        match self.language {
            UiLanguage::Zh => "输入",
            UiLanguage::En => "Input",
        }
    }

    pub fn no_experiment_yet(self) -> &'static str {
        match self.language {
            UiLanguage::Zh => "尚未运行实验",
            UiLanguage::En => "No experiment run yet",
        }
    }

    pub fn status_line(
        self,
        focus: &str,
        lessons: usize,
        artifacts: usize,
        busy_jobs: usize,
        workspace: impl std::fmt::Display,
        skill: impl std::fmt::Display,
    ) -> String {
        match self.language {
            UiLanguage::Zh => {
                format!(
                    "termwiz | {focus} | 课程={lessons} | 产物={artifacts} | 后台={busy_jobs} | 工作区={workspace} | skill={skill}"
                )
            }
            UiLanguage::En => {
                format!(
                    "termwiz | {focus} | lessons={lessons} | artifacts={artifacts} | jobs={busy_jobs} | workspace={workspace} | skill={skill}"
                )
            }
        }
    }

    pub fn key_hint_line(self) -> &'static str {
        match self.language {
            UiLanguage::Zh => {
                "Ctrl-Q 退出 | Tab 面板 | Enter 发送 | /learn 教学 | Ctrl-X 运行课程 | Ctrl-G 语言"
            }
            UiLanguage::En => {
                "Ctrl-Q Quit | Tab Panes | Enter Send | /learn Teach | Ctrl-X Run lessons | Ctrl-G Lang"
            }
        }
    }

    pub fn user_message(self, text: &str) -> String {
        match self.language {
            UiLanguage::Zh => format!("你: {text}"),
            UiLanguage::En => format!("you: {text}"),
        }
    }

    pub fn ap_message(self, text: &str) -> String {
        match self.language {
            UiLanguage::Zh => format!("AP: {text}"),
            UiLanguage::En => format!("AP: {text}"),
        }
    }

    pub fn queued_lesson(self, goal: &str) -> String {
        match self.language {
            UiLanguage::Zh => format!("用户课程已加入: {goal}"),
            UiLanguage::En => format!("user lesson queued: {goal}"),
        }
    }

    pub fn queued_feedback_lesson(self) -> &'static str {
        match self.language {
            UiLanguage::Zh => "已加入用户评分的 feedback-only 课程",
            UiLanguage::En => "queued user-scored feedback-only lesson",
        }
    }

    pub fn llm_lesson_queued(self) -> &'static str {
        match self.language {
            UiLanguage::Zh => "LLM 课程适配器已加入队列",
            UiLanguage::En => "llm lesson adapter queued",
        }
    }

    pub fn runtime_commands(self) -> &'static str {
        match self.language {
            UiLanguage::Zh => {
                "runtime 命令: /train obs => action | /probe obs | /relation scene-json | /trace | /export-trace | /media | /math-report | /learning-status"
            }
            UiLanguage::En => {
                "runtime commands: /train obs => action | /probe obs | /relation scene-json | /trace | /export-trace | /media | /math-report | /learning-status"
            }
        }
    }

    pub fn teacher_off_audit(self) -> &'static str {
        match self.language {
            UiLanguage::Zh => "teacher-off 阶段会审计无反馈、无记忆写入",
            UiLanguage::En => "teacher-off phases are audited for no feedback and no memory writes",
        }
    }

    pub fn no_report_to_export(self) -> &'static str {
        match self.language {
            UiLanguage::Zh => "没有可导出的课程报告",
            UiLanguage::En => "no lesson report to export",
        }
    }

    pub fn pane_title(self, pane: FocusPane) -> &'static str {
        self.pane_titles()[pane.index()]
    }

    fn pane_titles(self) -> &'static [&'static str; 5] {
        match self.language {
            UiLanguage::Zh => &ZH_PANE_TITLES,
            UiLanguage::En => &EN_PANE_TITLES,
        }
    }
}
