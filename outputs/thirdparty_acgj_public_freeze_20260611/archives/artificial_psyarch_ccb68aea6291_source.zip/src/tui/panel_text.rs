use ratatui::text::Line;

pub fn borrowed_lines(lines: &[String]) -> Vec<Line<'_>> {
    lines.iter().map(|line| Line::from(line.as_str())).collect()
}

pub fn borrowed_lines_rev(lines: &[String]) -> Vec<Line<'_>> {
    lines
        .iter()
        .rev()
        .map(|line| Line::from(line.as_str()))
        .collect()
}

pub fn owned_lines(lines: impl IntoIterator<Item = String>) -> Vec<Line<'static>> {
    lines.into_iter().map(Line::from).collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn borrowed_lines_preserve_full_text_for_wrapping() {
        let lines = vec!["abcdef".to_owned()];

        let rendered = borrowed_lines(&lines);

        assert_eq!(rendered[0].to_string(), "abcdef");
    }

    #[test]
    fn borrowed_lines_rev_keeps_newest_first() {
        let lines = vec!["old".to_owned(), "new".to_owned()];

        let rendered = borrowed_lines_rev(&lines);

        assert_eq!(rendered[0].to_string(), "new");
    }
}
