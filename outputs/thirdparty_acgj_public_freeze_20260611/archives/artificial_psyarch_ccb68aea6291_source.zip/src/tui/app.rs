use crate::ap::TeacherMode;
use crate::gl::GlOrchestrator;
use crate::learning::{
    AgentLearningRequest, ArtifactRef, FeedbackPolicy, LearningInput, LearningMaterial,
    LearningSession, LearningSource, Lesson, LessonRunReport, LlmAdapter, LlmBridge, PlannedLesson,
    read_learning_request, read_scaffold_spec, reserved_media_artifacts,
};
use crate::runtime::{APV21Runtime, RuntimeTickTrace};
use crate::workspace::WorkspacePaths;
use ratatui::termwiz::input::InputEvent;
use std::path::PathBuf;

use super::editor::TextInput;
use super::focus::FocusPane;
use super::i18n::{UiLanguage, UiText};
use super::input::{AppCommand, InputFilter};
use super::language_bridge::LanguageDialogBridge;
use super::language_commands::apply_language_command;
use super::persistence::{initial_trace, load_learning_session};
use super::relation_commands::apply_relation_command;
use super::runtime_bridge::{apply_text_command_line, default_runtime_actions};
use super::worker::{ScaffoldSpecJob, ScaffoldSpecResult, TuiWorker, WorkerEvent, WorkerRequest};

type AppAction = fn(&mut AppState);
type CursorAction = fn(&mut TextInput, usize);

const CURSOR_COMMANDS: [(AppCommand, CursorAction); 7] = [
    (AppCommand::Delete, delete_input),
    (AppCommand::MoveLeft, move_input_left),
    (AppCommand::MoveRight, move_input_right),
    (AppCommand::MoveUp, move_input_up),
    (AppCommand::MoveDown, move_input_down),
    (AppCommand::MoveHome, move_input_home),
    (AppCommand::MoveEnd, move_input_end),
];

const APP_ACTIONS: [(AppCommand, AppAction); 4] = [
    (AppCommand::RunQueuedLessons, AppState::run_queued_lessons),
    (AppCommand::ProbeAgent, AppState::probe_input),
    (AppCommand::ExportLastReport, AppState::export_last_report),
    (AppCommand::RunLocalRecords, AppState::run_local_records),
];

#[derive(Debug)]
pub struct AppState {
    pub focus: FocusPane,
    pub input: TextInput,
    pub chat: Vec<String>,
    pub queue: Vec<Lesson>,
    pub reports: Vec<LessonRunReport>,
    pub trace: Vec<String>,
    pub artifacts: Vec<ArtifactRef>,
    pub summary: String,
    pub input_filter: InputFilter,
    pub learning: LearningSession,
    pub runtime: APV21Runtime,
    pub runtime_traces: Vec<RuntimeTickTrace>,
    pub runtime_actions: Vec<String>,
    pub gl: GlOrchestrator,
    pub language_dialog: LanguageDialogBridge,
    pub language: UiLanguage,
    pub workspace: WorkspacePaths,
    pub skill_path: PathBuf,
    pub should_quit: bool,
    pub busy_jobs: usize,
    worker: TuiWorker,
}

impl AppState {
    pub fn new() -> Self {
        let workspace = WorkspacePaths::from_env();
        let skill_path = workspace.interactive_skill_current();
        let (learning, persistence_trace) = load_learning_session(&skill_path);
        let language = UiLanguage::detect();
        let text = UiText::new(language);
        Self {
            focus: FocusPane::Chat,
            input: TextInput::default(),
            chat: vec![text.app_title().to_owned(), text.help_line().to_owned()],
            queue: Vec::new(),
            reports: Vec::new(),
            trace: initial_trace(persistence_trace, text),
            artifacts: reserved_media_artifacts(),
            summary: text.no_experiment_yet().to_owned(),
            input_filter: InputFilter::default(),
            learning,
            runtime: APV21Runtime::default(),
            runtime_traces: Vec::new(),
            runtime_actions: default_runtime_actions(),
            gl: GlOrchestrator::default(),
            language_dialog: LanguageDialogBridge::default(),
            language,
            workspace,
            skill_path,
            should_quit: false,
            busy_jobs: 0,
            worker: TuiWorker::start(),
        }
    }

    pub fn poll_worker(&mut self) {
        for event in self.worker.drain_events() {
            self.handle_worker_event(event);
        }
    }

    pub fn handle_input(&mut self, input: InputEvent, input_width: usize) {
        match input {
            InputEvent::Key(event) => self.handle_command(AppCommand::from_key(event), input_width),
            InputEvent::Paste(text) => self.input_filter.push_paste(&mut self.input, &text),
            InputEvent::Resized { .. } => self.handle_resize(),
            _ => {}
        }
    }

    pub fn handle_resize(&mut self) {
        self.trace.push(self.text().resized().to_owned());
    }

    fn handle_command(&mut self, command: AppCommand, input_width: usize) {
        match command {
            command if self.apply_session_command(command) => {}
            command if self.apply_queue_command(command) => {}
            command if self.apply_action_command(command) => {}
            command => self.apply_edit_command(command, input_width),
        }
    }

    fn apply_session_command(&mut self, command: AppCommand) -> bool {
        match command {
            AppCommand::Quit => self.should_quit = true,
            AppCommand::NextFocus => self.focus = self.focus.next(),
            AppCommand::ToggleLanguage => self.toggle_language(),
            _ => return false,
        }
        true
    }

    pub fn text(&self) -> UiText {
        UiText::new(self.language)
    }

    fn toggle_language(&mut self) {
        self.language = self.language.toggle();
        self.chat.push(self.text().language_switched());
    }

    fn apply_queue_command(&mut self, command: AppCommand) -> bool {
        match command {
            AppCommand::SubmitInput => self.submit_input(),
            AppCommand::QueueLlmLesson => self.enqueue_llm_lesson(),
            AppCommand::ImportAgentRequest => self.import_agent_request(),
            _ => return false,
        }
        true
    }

    fn apply_action_command(&mut self, command: AppCommand) -> bool {
        app_action(command).is_some_and(|action| {
            action(self);
            true
        })
    }

    fn apply_edit_command(&mut self, command: AppCommand, input_width: usize) {
        if self.apply_cursor_command(command, input_width) {
            return;
        }
        self.apply_text_command(command);
    }

    fn apply_cursor_command(&mut self, command: AppCommand, input_width: usize) -> bool {
        cursor_action(command).is_some_and(|action| {
            action(&mut self.input, input_width);
            true
        })
    }

    fn apply_text_command(&mut self, command: AppCommand) {
        match command {
            AppCommand::Backspace => self.input_filter.backspace(&mut self.input),
            AppCommand::Insert(c) => self.input_filter.push_key_char(&mut self.input, c),
            AppCommand::StartEscapeSequence => self.input_filter.start_escape_sequence(),
            _ => {}
        }
    }

    fn submit_input(&mut self) {
        let Some(text) = self.submitted_text() else {
            return;
        };
        self.input.clear();
        self.dispatch_submitted_text(text);
    }

    fn submitted_text(&mut self) -> Option<String> {
        self.input_filter.flush_pending_text(&mut self.input);
        let text = self.input.text().trim().to_owned();
        (!text.is_empty()).then_some(text)
    }

    fn dispatch_submitted_text(&mut self, text: String) {
        if !self.apply_submitted_command(&text) {
            self.dispatch_plain_or_learn(text);
        }
    }

    fn apply_submitted_command(&mut self, text: &str) -> bool {
        if apply_text_command_line(self, text) {
            return true;
        }
        if apply_language_command(self, text) {
            return true;
        }
        if apply_relation_command(self, text) {
            return true;
        }
        self.apply_scaffold_command(text)
    }

    fn dispatch_plain_or_learn(&mut self, text: String) {
        match learn_command_goal(&text) {
            Some(goal) => self.queue_user_lesson_goal(goal),
            None => self.answer_submitted_text(text),
        }
    }

    fn apply_scaffold_command(&mut self, text: &str) -> bool {
        let Some(path) = scaffold_command_path(text, &self.workspace) else {
            return false;
        };
        match read_scaffold_spec(&path) {
            Ok(spec) => {
                self.chat
                    .push(format!("queued scaffold spec: {}", spec.skill_id));
                self.submit_worker_job(WorkerRequest::RunScaffoldSpec(Box::new(ScaffoldSpecJob {
                    learning: self.learning.clone(),
                    spec,
                })));
            }
            Err(error) => self.trace.push(format!(
                "scaffold import failed from {}: {error}",
                path.display()
            )),
        }
        true
    }

    fn queue_user_lesson_goal(&mut self, goal: String) {
        let request =
            AgentLearningRequest::user_text(format!("tui-{}", self.queue.len()), goal.clone());
        self.queue_response(PlannedLesson.plan_lesson(request));
        self.chat.push(self.text().queued_lesson(&goal));
        self.trace
            .push(self.text().queued_feedback_lesson().to_owned());
    }

    fn enqueue_llm_lesson(&mut self) {
        let input = LearningInput::new(
            LearningSource::Llm {
                provider: "adapter".to_owned(),
                model: "pending".to_owned(),
            },
            LearningMaterial::text(
                "LLM will transform source material into AP lesson tasks".to_owned(),
            ),
            "prepare AP learning curriculum",
            TeacherMode::FeedbackOnly,
            FeedbackPolicy::LlmScored,
        );
        let response = PlannedLesson.generate_curriculum(AgentLearningRequest {
            request_id: format!("llm-{}", self.queue.len()),
            source: input.source,
            intent: crate::learning::LearningIntent::Learn,
            goal: input.goal,
            material: input.material,
            teacher_mode: input.teacher_mode,
            feedback_policy: input.feedback_policy,
            holdout: crate::learning::HoldoutSpec::default(),
            desired_outputs: vec![crate::learning::MediaOutput::Text],
            conversation: Vec::new(),
        });
        self.queue.push(response.lesson);
        self.trace.extend(response.notes);
        self.chat.push(self.text().llm_lesson_queued().to_owned());
        self.trace
            .push("LLM role: curriculum/feedback helper, not teacher-off answer path".to_owned());
    }

    fn import_agent_request(&mut self) {
        let request_path = self.workspace.agent_request("ap-learning-request.json");
        match read_learning_request(&request_path) {
            Ok(request) => self.queue_response(PlannedLesson.plan_lesson(request)),
            Err(error) => self.trace.push(format!(
                "agent import failed from {}: {error}",
                request_path.display()
            )),
        }
    }

    fn queue_response(&mut self, response: crate::learning::AgentLearningResponse) {
        self.trace.push(format!(
            "planned lesson from request {}",
            response.request_id
        ));
        self.artifacts.extend(response.artifacts);
        self.queue.push(response.lesson);
    }

    fn probe_input(&mut self) {
        self.input_filter.flush_pending_text(&mut self.input);
        let question = self.input.text().trim().to_owned();
        if question.is_empty() {
            return;
        }
        let report = self.probe_question(&question);
        let answer = super::chat::probe_answer(&report);
        self.chat.push(self.text().user_message(&question));
        self.chat.push(self.text().ap_message(&answer));
        self.trace.push("teacher-off probe completed".to_owned());
        self.input.clear();
        self.sync_learning_outputs(std::slice::from_ref(&report));
    }

    pub(crate) fn sync_learning_outputs(&mut self, reports: &[LessonRunReport]) {
        self.artifacts
            .extend(super::chat::report_artifacts(reports));
        self.trace
            .extend(reports.iter().map(super::chat::report_summary));
        self.reports.extend(reports.iter().cloned());
    }

    pub(super) fn submit_worker_job(&mut self, request: WorkerRequest) {
        match self.worker.submit(request) {
            Ok(()) => {
                self.busy_jobs += 1;
                self.trace
                    .push(format!("queued background job; pending={}", self.busy_jobs));
            }
            Err(error) => self.trace.push(format!("background job failed: {error}")),
        }
    }

    fn handle_worker_event(&mut self, event: WorkerEvent) {
        self.busy_jobs = self.busy_jobs.saturating_sub(1);
        event.apply_to(self);
    }

    pub(crate) fn finish_scaffold_spec(&mut self, result: ScaffoldSpecResult) {
        self.learning = result.learning;
        let report = &result.bundle.report;
        self.chat.push(format!(
            "scaffold {} teacher_off={:.2} cold_retest={:.2}",
            report.skill_id,
            report.teacher_off_accuracy(),
            report.cold_retest_accuracy()
        ));
        self.trace.push(format!(
            "scaffold mastery: skill={} mastery={:.2} success={} failure={}",
            result.bundle.mastery.skill_id,
            result.bundle.mastery.mastery_estimate,
            result.bundle.mastery.success_steps,
            result.bundle.mastery.failure_steps
        ));
    }
}

fn learn_command_goal(text: &str) -> Option<String> {
    text.strip_prefix("/learn ")
        .map(str::trim)
        .filter(|goal| !goal.is_empty())
        .map(str::to_owned)
}

fn scaffold_command_path(text: &str, workspace: &WorkspacePaths) -> Option<PathBuf> {
    let command = text.strip_prefix("/scaffold")?;
    let path = command.trim();
    Some(if path.is_empty() {
        workspace.agent_request("scaffold.json")
    } else {
        PathBuf::from(path)
    })
}

fn cursor_action(command: AppCommand) -> Option<CursorAction> {
    CURSOR_COMMANDS
        .iter()
        .find(|(candidate, _)| *candidate == command)
        .map(|(_, action)| *action)
}

fn app_action(command: AppCommand) -> Option<AppAction> {
    APP_ACTIONS
        .iter()
        .find(|(candidate, _)| *candidate == command)
        .map(|(_, action)| *action)
}

fn delete_input(input: &mut TextInput, _width: usize) {
    input.delete();
}

fn move_input_left(input: &mut TextInput, _width: usize) {
    input.move_left();
}

fn move_input_right(input: &mut TextInput, _width: usize) {
    input.move_right();
}

fn move_input_up(input: &mut TextInput, width: usize) {
    input.move_up(width);
}

fn move_input_down(input: &mut TextInput, width: usize) {
    input.move_down(width);
}

fn move_input_home(input: &mut TextInput, _width: usize) {
    input.move_home();
}

fn move_input_end(input: &mut TextInput, _width: usize) {
    input.move_end();
}

impl Default for AppState {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn plain_text_sends_chat_without_queueing_lesson() {
        let mut app = AppState::new();

        app.input.insert_str("red circle");
        app.submit_input();

        assert!(app.queue.is_empty());
        assert!(app.chat.iter().any(|line| line.contains("red circle")));
        assert_eq!(app.reports.len(), 1);
    }

    #[test]
    fn plain_chat_records_language_grounding_trace() {
        let mut app = AppState::new();

        app.input.insert_str("帮我检查一下");
        app.submit_input();

        assert!(app.queue.is_empty());
        assert!(
            app.trace
                .iter()
                .any(|line| line.contains("dialog:serve-request"))
        );
        assert!(
            app.trace
                .iter()
                .any(|line| line.contains("frame:request/service/help"))
        );
        assert!(
            app.trace
                .iter()
                .any(|line| line.contains("response policy response:task-plan"))
        );
        assert!(app.chat.iter().any(|line| line.contains("可执行的下一步")));
        assert!(!app.chat.iter().any(|line| line.contains("policy=")));
        assert!(!app.chat.iter().any(|line| line.contains("grounded=")));
        assert!(!app.chat.iter().any(|line| line.contains("ObserveText")));
        assert!(
            app.trace
                .iter()
                .any(|line| line.contains("teacher-off probe raw response=ObserveText"))
        );
    }

    #[test]
    fn greeting_chat_uses_learned_response_policy_label() {
        let mut app = AppState::new();

        app.input.insert_str("你好");
        app.submit_input();

        assert!(
            app.trace
                .iter()
                .any(|line| line.contains("response policy response:brief-acknowledge"))
        );
        assert!(!app.chat.iter().any(|line| line.contains("policy=")));
        assert!(!app.chat.iter().any(|line| line.contains("你好，我在")));
        assert!(app.chat.iter().any(|line| line.contains("继续说")));
    }

    #[test]
    fn untrained_math_expression_does_not_fall_through_to_chat_surface() {
        let mut app = AppState::new();
        app.learning = LearningSession::new("empty-math-route-test");

        app.input.insert_str("1+1");
        app.submit_input();

        assert!(
            app.chat
                .iter()
                .any(|line| line.contains("数学 skill 还没有命中"))
        );
        assert!(!app.chat.iter().any(|line| line.contains("可执行的下一步")));
        assert!(
            app.trace
                .iter()
                .any(|line| line.contains("math expression routed"))
        );
    }

    #[test]
    fn trained_math_expression_uses_teacher_off_math_answer() {
        let mut app = AppState::new();
        app.learning = LearningSession::new("trained-math-route-test");
        let lesson = LearningInput::new(
            LearningSource::User,
            LearningMaterial::TaskSet(vec![
                crate::learning::LessonTask::new(
                    "add-0",
                    crate::learning::MaterialStimulus::Text("1 + 1".to_owned()),
                )
                .with_expected_action("2"),
            ]),
            "learn add",
            TeacherMode::FeedbackOnly,
            FeedbackPolicy::AutomaticExaminer,
        )
        .into_lesson("math-add");

        app.learning.run_lessons(&[lesson]);
        app.input.insert_str("1+1");
        app.submit_input();

        assert!(app.chat.iter().any(|line| line == "AP: 2"));
    }

    #[test]
    fn learn_command_queues_lesson() {
        let mut app = AppState::new();

        app.input.insert_str("/learn learn shape");
        app.submit_input();

        assert_eq!(app.queue.len(), 1);
        assert!(app.chat.iter().any(|line| line.contains("learn shape")));
    }

    #[test]
    fn scaffold_command_runs_spec_in_worker() {
        let mut app = AppState::new();
        let path = std::env::temp_dir().join(format!("ap-scaffold-{}.json", std::process::id()));
        std::fs::write(&path, scaffold_spec_json()).unwrap();

        app.input
            .insert_str(&format!("/scaffold {}", path.display()));
        app.submit_input();
        wait_for_worker(&mut app);
        let _ = std::fs::remove_file(&path);

        assert!(app.chat.iter().any(|line| {
            line.contains("scaffold skill.relation.left") && line.contains("cold_retest=1.00")
        }));
        assert!(
            app.trace
                .iter()
                .any(|line| line.contains("scaffold mastery: skill=skill.relation.left"))
        );
    }

    #[test]
    fn import_language_command_retrains_dialog_bridge() {
        let mut app = AppState::new();
        let path = std::env::temp_dir().join(format!("ap-language-{}.jsonl", std::process::id()));
        std::fs::write(
            &path,
            r#"{"text":"请你帮我处理","context":"用户请求帮助","expected_frame":"frame:request/service/help","split":"train"}
{"text":"为什么这样","context":"需要解释","expected_frame":"frame:question/reason/explain","split":"train"}
"#,
        )
        .unwrap();

        app.input
            .insert_str(&format!("/import-language {}", path.display()));
        app.submit_input();
        let _ = std::fs::remove_file(&path);

        assert!(
            app.trace
                .iter()
                .any(|line| line.contains("language dataset imported"))
        );
        assert!(
            app.chat
                .iter()
                .any(|line| line.contains("language grounding dataset loaded"))
        );
    }

    #[test]
    fn math_report_command_runs_training_and_probe() {
        let mut app = AppState::new();

        app.run_math_report_command();
        wait_for_worker(&mut app);

        assert!(app.reports.len() >= 2);
        assert!(
            app.chat
                .iter()
                .any(|line| line.starts_with("math report: train=1.00"))
        );
        assert!(
            app.trace
                .iter()
                .any(|line| line.contains("math generalization answers"))
        );
    }

    #[test]
    fn learning_status_reports_current_session() {
        let mut app = AppState::new();

        app.push_learning_status();

        assert!(
            app.trace
                .iter()
                .any(|line| line.starts_with("learning status:"))
        );
    }

    #[test]
    fn default_skill_path_uses_workspace() {
        let app = AppState::new();

        assert_eq!(
            app.skill_path,
            std::path::PathBuf::from(".ap/skills/interactive/current.apbin")
        );
    }

    #[test]
    fn skill_archive_uses_internal_bincode_extension() {
        let app = AppState::new();

        assert_eq!(
            app.workspace.interactive_skill_history("skill-1.apbin"),
            std::path::PathBuf::from(".ap/skills/interactive/history/skill-1.apbin")
        );
    }

    fn wait_for_worker(app: &mut AppState) {
        for _ in 0..100 {
            app.poll_worker();
            if app.busy_jobs == 0 {
                return;
            }
            std::thread::sleep(std::time::Duration::from_millis(20));
        }
        panic!("worker job timed out");
    }

    fn scaffold_spec_json() -> &'static str {
        r#"{
  "skill_id": "skill.relation.left",
  "title": "relation word left",
  "goal": "learn relation word 在左边",
  "domain_tags": ["language", "relation_word"],
  "building_blocks": [
    {"block_id":"relation.left", "label":"在左边", "modality":"text", "role":"relation_word", "notes":[]}
  ],
  "phases": [
    {"phase_id":"demonstrate","strength":1.0,"teacher_signal":{"state_items":true,"action_biases":true,"feedback":true}},
    {"phase_id":"strong_scaffold","strength":0.86,"teacher_signal":{"state_items":true,"action_biases":true,"feedback":true}},
    {"phase_id":"weak_scaffold","strength":0.38,"teacher_signal":{"state_items":true,"action_biases":true,"feedback":true}},
    {"phase_id":"feedback_only","strength":0.72,"teacher_signal":{"state_items":false,"action_biases":false,"feedback":true}},
    {"phase_id":"teacher_off","strength":0.0,"teacher_signal":{"state_items":false,"action_biases":false,"feedback":false}},
    {"phase_id":"cold_retest","strength":0.0,"teacher_signal":{"state_items":false,"action_biases":false,"feedback":false}}
  ],
  "steps": [
    {
      "step_id":"left-0",
      "title":"红点在蓝点左边",
      "scenario_tags":["relation_word"],
      "state_items":["text::红点在蓝点左边","relation::left_of(red,blue)"],
      "action_biases":[{"action":"RelationWordLeft","strength":1.0}],
      "feedback":"Reward",
      "expected_evidence":["teacher-off recalls RelationWordLeft"],
      "notes":[]
    }
  ],
  "mastery":{"success_threshold":0.42,"update_rate":0.3,"decay_per_mastery":0.72,"warmup_successes":1},
  "guardrails":[],
  "notes":[]
}"#
    }
}
