use crate::learning::is_arithmetic_expression;
use crate::learning::{
    AgentLearningRequest, ArtifactRef, LessonRunReport, LlmBridge, PlannedLesson,
};

use super::app::AppState;

impl AppState {
    pub(super) fn answer_submitted_text(&mut self, question: String) {
        if is_arithmetic_expression(&question) {
            self.answer_math_expression(question);
        } else {
            self.answer_chat_message(question);
        }
    }

    fn answer_math_expression(&mut self, question: String) {
        let report = self.probe_question(&question);
        let answer = probe_answer(&report);
        self.chat.push(self.text().user_message(&question));
        self.chat
            .push(self.text().ap_message(&math_chat_answer(&answer)));
        self.trace
            .push(format!("teacher-off math probe raw response={answer}"));
        self.trace
            .push("math expression routed before language dialog".to_owned());
        self.sync_learning_outputs(std::slice::from_ref(&report));
    }

    pub(super) fn answer_chat_message(&mut self, question: String) {
        let understanding = self.language_dialog.understand(&question);
        let policy = self
            .language_dialog
            .response_policy(&understanding, &question);
        let surface = self
            .language_dialog
            .response_surface(&understanding, &policy, &question);
        let report = self.probe_question(&question);
        let answer = probe_answer(&report);
        self.chat.push(self.text().user_message(&question));
        self.chat.push(self.text().ap_message(&surface.text));
        self.trace.push(understanding.trace_line());
        self.trace.push(format!(
            "response policy {} evidence={}",
            policy.policy_label,
            policy.evidence.join(",")
        ));
        self.trace.push(format!(
            "response surface {} evidence={}",
            surface.surface_id,
            surface.evidence.join(",")
        ));
        self.trace
            .push(format!("teacher-off probe raw response={answer}"));
        self.trace.push(format!(
            "language grounding rows={}",
            self.language_dialog.learned_rows()
        ));
        self.trace
            .push("teacher-off chat probe completed".to_owned());
        self.language_dialog.record_turn("user", &question);
        self.language_dialog.record_turn("ap", &surface.text);
        self.sync_learning_outputs(std::slice::from_ref(&report));
    }

    pub(super) fn probe_question(&mut self, question: &str) -> LessonRunReport {
        let response = PlannedLesson.plan_lesson(AgentLearningRequest::probe_text(
            format!("probe-{}", self.reports.len()),
            question.to_owned(),
        ));
        self.learning.probe_lesson(&response.lesson)
    }
}

pub(super) fn report_summary(report: &LessonRunReport) -> String {
    format!(
        "{} train={:.2} holdout={:.2} status={:?}",
        report.lesson_id,
        report.skill_report.train_accuracy(),
        report.skill_report.holdout_accuracy(),
        report.skill_report.status
    )
}

pub(super) fn probe_answer(report: &LessonRunReport) -> String {
    report
        .holdout_attempts
        .first()
        .map(|attempt| attempt.response.clone())
        .unwrap_or_else(|| "NoAnswer".to_owned())
}

fn math_chat_answer(answer: &str) -> String {
    if is_probe_miss(answer) {
        "当前数学 skill 还没有命中这个表达式；请先训练对应运算，或运行 /math-report 检查训练状态。"
            .to_owned()
    } else {
        answer.to_owned()
    }
}

fn is_probe_miss(answer: &str) -> bool {
    matches!(answer, "ObserveText" | "NoAnswer")
}

pub(super) fn report_artifacts(reports: &[LessonRunReport]) -> Vec<ArtifactRef> {
    reports
        .iter()
        .flat_map(|report| report.skill_report.artifacts.iter().cloned())
        .collect()
}
