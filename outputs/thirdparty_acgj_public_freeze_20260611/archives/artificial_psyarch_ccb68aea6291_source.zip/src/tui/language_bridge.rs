use crate::language_core::{
    DialogUnderstanding, LanguageGroundingLearner, LanguageGroundingWorld, ResponsePolicyDecision,
    ResponsePolicyLearner, ResponsePolicyWorld, ResponseSurfaceDecision, ResponseSurfaceLearner,
    train_language_grounding, train_response_policy, understand_dialog,
};

#[derive(Debug, Clone)]
pub struct LanguageDialogBridge {
    learner: LanguageGroundingLearner,
    response_policy: ResponsePolicyLearner,
    response_surface: ResponseSurfaceLearner,
    context_lines: Vec<String>,
}

impl Default for LanguageDialogBridge {
    fn default() -> Self {
        let world = LanguageGroundingWorld::canonical();
        Self::train_from_world(&world, 5)
    }
}

impl LanguageDialogBridge {
    pub fn train_from_world(world: &LanguageGroundingWorld, repeats: usize) -> Self {
        let mut learner = LanguageGroundingLearner::default();
        train_language_grounding(world, &mut learner, repeats);
        Self {
            learner,
            response_policy: ResponsePolicyLearner::canonical_trained(),
            response_surface: ResponseSurfaceLearner::canonical_trained(),
            context_lines: Vec::new(),
        }
    }

    pub fn train_response_policy(&mut self, world: &ResponsePolicyWorld, repeats: usize) {
        train_response_policy(world, &mut self.response_policy, repeats);
    }

    pub fn understand(&self, text: &str) -> DialogUnderstanding {
        understand_dialog(&self.learner, text, &self.context())
    }

    pub fn response_policy(
        &self,
        understanding: &DialogUnderstanding,
        text: &str,
    ) -> ResponsePolicyDecision {
        self.response_policy
            .predict(understanding, text, &self.context())
    }

    pub fn response_surface(
        &self,
        understanding: &DialogUnderstanding,
        policy: &ResponsePolicyDecision,
        text: &str,
    ) -> ResponseSurfaceDecision {
        self.response_surface
            .predict(understanding, policy, text, &self.context())
    }

    pub fn record_turn(&mut self, role: &str, text: &str) {
        self.context_lines.push(format!("{role}: {text}"));
        trim_context(&mut self.context_lines, 6);
    }

    pub fn learned_rows(&self) -> usize {
        self.learner.memory_rows()
            + self.response_policy.memory_rows()
            + self.response_surface.memory_rows()
    }

    pub fn response_policy_rows(&self) -> usize {
        self.response_policy.memory_rows()
    }

    fn context(&self) -> String {
        self.context_lines.join("\n")
    }
}

fn trim_context(lines: &mut Vec<String>, max_lines: usize) {
    let overflow = lines.len().saturating_sub(max_lines);
    if overflow > 0 {
        lines.drain(0..overflow);
    }
}

#[cfg(test)]
mod tests {
    use crate::language_core::DialogAct;

    use super::*;

    #[test]
    fn bridge_learns_dialog_acts_from_grounded_frames() {
        let bridge = LanguageDialogBridge::default();

        assert_eq!(
            bridge.understand("帮我跑一下检查").act,
            DialogAct::ServeRequest
        );
        assert_eq!(
            bridge.understand("不是这个意思，改一下").act,
            DialogAct::AlignCorrection
        );
        assert_eq!(
            bridge.understand("我不确定下一步").act,
            DialogAct::AskClarification
        );
    }

    #[test]
    fn bridge_keeps_bounded_context() {
        let mut bridge = LanguageDialogBridge::default();

        (0..10).for_each(|index| bridge.record_turn("user", &format!("turn-{index}")));

        assert_eq!(bridge.context_lines.len(), 6);
        assert!(bridge.context().contains("turn-9"));
        assert!(!bridge.context().contains("turn-0"));
    }
}
