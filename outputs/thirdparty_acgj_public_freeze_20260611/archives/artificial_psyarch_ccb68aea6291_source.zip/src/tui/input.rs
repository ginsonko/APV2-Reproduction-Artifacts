use ratatui::termwiz::input::{KeyCode, KeyEvent, Modifiers};

use super::editor::TextInput;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AppCommand {
    Quit,
    NextFocus,
    SubmitInput,
    Backspace,
    Delete,
    MoveLeft,
    MoveRight,
    MoveUp,
    MoveDown,
    MoveHome,
    MoveEnd,
    QueueLlmLesson,
    ImportAgentRequest,
    RunQueuedLessons,
    ProbeAgent,
    ExportLastReport,
    RunLocalRecords,
    ToggleLanguage,
    Insert(char),
    StartEscapeSequence,
    Ignore,
}

impl AppCommand {
    pub fn from_key(event: KeyEvent) -> Self {
        if let Some(command) = control_command(&event) {
            return command;
        }
        editing_command(event.key, event.modifiers)
    }
}

fn editing_command(key: KeyCode, modifiers: Modifiers) -> AppCommand {
    if modified_text_key(modifiers) {
        return AppCommand::Ignore;
    }
    if let Some(command) = command_for_key(key, &EDIT_CONTROL_COMMANDS) {
        return command;
    }
    insert_command(key)
}

fn modified_text_key(modifiers: Modifiers) -> bool {
    modifiers.intersects(
        Modifiers::CTRL
            | Modifiers::LEFT_CTRL
            | Modifiers::RIGHT_CTRL
            | Modifiers::ALT
            | Modifiers::LEFT_ALT
            | Modifiers::RIGHT_ALT,
    )
}

fn control_command(event: &KeyEvent) -> Option<AppCommand> {
    if !has_control_modifier(event.modifiers) {
        return None;
    }
    control_char(event).and_then(command_for_control_char)
}

fn insert_command(key: KeyCode) -> AppCommand {
    match key {
        KeyCode::Char(c) if is_text_char(c) => AppCommand::Insert(c),
        _ => AppCommand::Ignore,
    }
}

const EDIT_CONTROL_COMMANDS: [(KeyCode, AppCommand); 11] = [
    (KeyCode::Tab, AppCommand::NextFocus),
    (KeyCode::Enter, AppCommand::SubmitInput),
    (KeyCode::Backspace, AppCommand::Backspace),
    (KeyCode::Delete, AppCommand::Delete),
    (KeyCode::LeftArrow, AppCommand::MoveLeft),
    (KeyCode::RightArrow, AppCommand::MoveRight),
    (KeyCode::UpArrow, AppCommand::MoveUp),
    (KeyCode::DownArrow, AppCommand::MoveDown),
    (KeyCode::Home, AppCommand::MoveHome),
    (KeyCode::End, AppCommand::MoveEnd),
    (KeyCode::Escape, AppCommand::StartEscapeSequence),
];

const CONTROL_CHAR_COMMANDS: [(char, AppCommand); 9] = [
    ('q', AppCommand::Quit),
    ('c', AppCommand::Quit),
    ('l', AppCommand::QueueLlmLesson),
    ('o', AppCommand::ImportAgentRequest),
    ('x', AppCommand::RunQueuedLessons),
    ('p', AppCommand::ProbeAgent),
    ('e', AppCommand::ExportLastReport),
    ('r', AppCommand::RunLocalRecords),
    ('g', AppCommand::ToggleLanguage),
];

fn command_for_key(key: KeyCode, commands: &[(KeyCode, AppCommand)]) -> Option<AppCommand> {
    commands
        .iter()
        .find(|(candidate, _)| *candidate == key)
        .map(|(_, command)| *command)
}

fn command_for_control_char(c: char) -> Option<AppCommand> {
    CONTROL_CHAR_COMMANDS
        .iter()
        .find(|(candidate, _)| *candidate == c)
        .map(|(_, command)| *command)
}

fn control_char(event: &KeyEvent) -> Option<char> {
    match event.key {
        KeyCode::Char(c) => Some(c),
        _ => None,
    }
}

fn has_control_modifier(modifiers: Modifiers) -> bool {
    modifiers.intersects(Modifiers::CTRL | Modifiers::LEFT_CTRL | Modifiers::RIGHT_CTRL)
}

fn is_text_char(c: char) -> bool {
    !c.is_control()
}

#[derive(Debug, Default, Clone, PartialEq, Eq)]
pub struct InputFilter {
    state: InputFilterState,
}

impl InputFilter {
    pub fn push_key_char(&mut self, input: &mut TextInput, c: char) {
        STATE_HANDLERS[self.state.index()](self, input, c);
    }

    pub fn push_paste(&mut self, input: &mut TextInput, text: &str) {
        input.insert_str(&sanitized_text(text));
    }

    pub fn start_escape_sequence(&mut self) {
        self.state = InputFilterState::SawEscape;
    }

    pub fn backspace(&mut self, input: &mut TextInput) {
        if self.state == InputFilterState::Normal {
            input.backspace();
        } else {
            self.state = InputFilterState::Normal;
        }
    }

    pub fn flush_pending_text(&mut self, input: &mut TextInput) {
        if let Some(prefix) = self.state.pending_prefix() {
            input.insert_char(prefix);
        }
        self.state = InputFilterState::Normal;
    }

    fn push_normal(&mut self, input: &mut TextInput, c: char) {
        if self.capture_marker(c) {
            return;
        }
        push_visible_char(input, c);
    }

    fn capture_marker(&mut self, c: char) -> bool {
        match marker_state(c) {
            Some(state) => {
                self.state = state;
                true
            }
            None => false,
        }
    }

    fn after_escape(&mut self, input: &mut TextInput, c: char) {
        if c == '[' {
            self.state = InputFilterState::DiscardCsi;
        } else {
            self.replay_without_prefix(input, c);
        }
    }

    fn after_bracket(&mut self, input: &mut TextInput, c: char) {
        if c == '<' {
            self.state = InputFilterState::DiscardCsi;
        } else {
            replay_with_prefix(self, input, '[', c);
        }
    }

    fn after_mouse_marker(&mut self, input: &mut TextInput, c: char) {
        if is_mouse_report_body(c) {
            self.state = InputFilterState::DiscardCsi;
        } else {
            replay_with_prefix(self, input, '<', c);
        }
    }

    fn replay_without_prefix(&mut self, input: &mut TextInput, c: char) {
        self.state = InputFilterState::Normal;
        self.push_key_char(input, c);
    }

    fn discard_csi(&mut self, c: char) {
        if is_csi_final_byte(c) {
            self.state = InputFilterState::Normal;
        }
    }
}

type InputHandler = fn(&mut InputFilter, &mut TextInput, char);

const STATE_HANDLERS: [InputHandler; 5] = [
    InputFilter::push_normal,
    InputFilter::after_escape,
    InputFilter::after_bracket,
    InputFilter::after_mouse_marker,
    discard_csi_input,
];

fn discard_csi_input(filter: &mut InputFilter, _input: &mut TextInput, c: char) {
    filter.discard_csi(c);
}

fn replay_with_prefix(filter: &mut InputFilter, input: &mut TextInput, prefix: char, c: char) {
    input.insert_char(prefix);
    filter.state = InputFilterState::Normal;
    filter.push_key_char(input, c);
}

fn push_visible_char(input: &mut TextInput, c: char) {
    if is_text_char(c) {
        input.insert_char(c);
    }
}

fn marker_state(c: char) -> Option<InputFilterState> {
    match c {
        '[' => Some(InputFilterState::SawBracket),
        '<' => Some(InputFilterState::SawMouseMarker),
        _ => None,
    }
}

fn is_mouse_report_body(c: char) -> bool {
    c.is_ascii_digit() || c == ';'
}

#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
enum InputFilterState {
    #[default]
    Normal,
    SawEscape,
    SawBracket,
    SawMouseMarker,
    DiscardCsi,
}

impl InputFilterState {
    fn index(self) -> usize {
        self as usize
    }

    fn pending_prefix(self) -> Option<char> {
        match self {
            Self::SawBracket => Some('['),
            Self::SawMouseMarker => Some('<'),
            _ => None,
        }
    }
}

pub fn sanitized_text(text: &str) -> String {
    let mut input = TextInput::default();
    let mut filter = InputFilter::default();
    for c in text.chars() {
        if c == '\x1b' {
            filter.start_escape_sequence();
        } else {
            filter.push_key_char(&mut input, c);
        }
    }
    filter.flush_pending_text(&mut input);
    input.text().to_owned()
}

fn is_csi_final_byte(c: char) -> bool {
    matches!(c, '@'..='~')
}

#[cfg(test)]
mod tests {
    use super::*;

    fn key(key: KeyCode) -> KeyEvent {
        KeyEvent {
            key,
            modifiers: Modifiers::NONE,
        }
    }

    fn modified_key(c: char, modifiers: Modifiers) -> KeyEvent {
        KeyEvent {
            key: KeyCode::Char(c),
            modifiers,
        }
    }

    #[test]
    fn plain_q_is_text_and_ctrl_q_quits() {
        assert_eq!(
            AppCommand::from_key(key(KeyCode::Char('q'))),
            AppCommand::Insert('q')
        );
        assert_eq!(
            AppCommand::from_key(modified_key('q', Modifiers::CTRL)),
            AppCommand::Quit
        );
    }

    #[test]
    fn plain_command_letters_are_text() {
        for c in ['l', 'o', 'x', 'e', 'r', 'g'] {
            assert_eq!(
                AppCommand::from_key(key(KeyCode::Char(c))),
                AppCommand::Insert(c)
            );
        }
    }

    #[test]
    fn ctrl_g_toggles_language() {
        assert_eq!(
            AppCommand::from_key(modified_key('g', Modifiers::CTRL)),
            AppCommand::ToggleLanguage
        );
    }

    #[test]
    fn modified_unmapped_text_keys_are_ignored() {
        assert_eq!(
            AppCommand::from_key(modified_key('v', Modifiers::CTRL | Modifiers::SHIFT)),
            AppCommand::Ignore
        );
    }

    #[test]
    fn filters_mouse_escape_fragments_from_input() {
        assert_eq!(sanitized_text("\x1b[<35;57;38Mhello"), "hello");
        assert_eq!(sanitized_text("<35;57;38Mhello"), "hello");
    }

    #[test]
    fn filters_mouse_fragments_after_existing_text() {
        assert_eq!(sanitized_text("abc<35;57;38Mdef"), "abcdef");
        assert_eq!(sanitized_text("abc[<35;57;38Mdef"), "abcdef");
    }

    #[test]
    fn keeps_normal_angle_and_bracket_text() {
        assert_eq!(sanitized_text("<hello [world]"), "<hello [world]");
    }
}
