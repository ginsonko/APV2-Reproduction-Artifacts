use crate::ap::{Feedback, TeacherMode};
use crate::gl::GlRequestKind;
use crate::runtime::{RuntimeObservation, RuntimeTickInput, RuntimeTickTrace, TeacherSignal};
use crate::workspace::ensure_parent;

use super::app::AppState;

type RuntimeCommandHandler = fn(&mut AppState, RuntimeTextCommand<'_>);

pub fn default_runtime_actions() -> Vec<String> {
    vec!["answer".to_owned(), "observe".to_owned(), "act".to_owned()]
}

pub fn apply_text_command_line(app: &mut AppState, text: &str) -> bool {
    let Some(command) = RuntimeTextCommand::parse(text) else {
        return false;
    };
    (command.handler)(app, command);
    true
}

pub fn runtime_trace_summary(trace: &RuntimeTickTrace) -> String {
    format!(
        "runtime tick={} action={:?} feeling={:?} bn={} cstar={} gap={:.2}",
        trace.tick,
        trace.selected_action,
        trace.feeling.kind,
        trace.prediction.bn_trace.recall_count,
        trace.prediction.cstar_trace.candidate_count,
        trace.prediction_validation.mismatch_ratio
    )
}

pub fn runtime_trace_details(trace: &RuntimeTickTrace) -> Vec<String> {
    vec![
        runtime_trace_summary(trace),
        format!("r-state keys: {}", trace.r_state.selected_keys.join(", ")),
        format!(
            "cstar strongest: {:?}",
            trace.prediction.cstar_trace.strongest_key
        ),
        format!(
            "feeling channels: pressure={:.2} clarity={:.2} closure={:.2} expectation_gap={:.2}",
            trace.feeling_trace.channels.computation_pressure,
            trace.feeling_trace.channels.sensory_clarity,
            trace.feeling_trace.channels.step_closure,
            trace.feeling_trace.expectation.expectation_gap
        ),
        format!(
            "modulation: valence={:.2} arousal={:.2} drive_bias={:.2}",
            trace.modulation_trace.valence,
            trace.modulation_trace.arousal,
            trace.modulation_trace.drive_bias
        ),
        format!(
            "anchor: {:?} expectation={:?} actual={:?}",
            trace.anchor_trace.status, trace.anchor_trace.expectation, trace.anchor_trace.actual
        ),
        format!(
            "audit: feedback_visible={} memory_write={} answer_visible={}",
            trace.teacher_audit.feedback_visible_to_learner,
            trace.teacher_audit.memory_write_enabled,
            trace.teacher_audit.answer_visible_to_learner
        ),
    ]
}

fn handle_train(app: &mut AppState, command: RuntimeTextCommand<'_>) {
    let RuntimeTextCommandKind::Train {
        observation,
        action,
    } = command.kind
    else {
        return;
    };
    train_runtime(app, observation, action);
}

fn handle_probe(app: &mut AppState, command: RuntimeTextCommand<'_>) {
    let RuntimeTextCommandKind::Probe { observation } = command.kind else {
        return;
    };
    probe_runtime(app, observation);
}

fn handle_trace(app: &mut AppState, _command: RuntimeTextCommand<'_>) {
    push_last_runtime_trace_summary(app);
}

fn handle_export_trace(app: &mut AppState, _command: RuntimeTextCommand<'_>) {
    let plan = app.plan_gl_request(
        GlRequestKind::ExportTrace,
        "export runtime trace".to_owned(),
    );
    app.execute_gl_plan(plan);
    export_runtime_trace(app);
}

fn handle_help(app: &mut AppState, _command: RuntimeTextCommand<'_>) {
    push_runtime_help(app);
}

fn handle_media(app: &mut AppState, _command: RuntimeTextCommand<'_>) {
    app.plan_reserved_media();
}

fn handle_math_report(app: &mut AppState, _command: RuntimeTextCommand<'_>) {
    app.run_math_report_command();
}

fn handle_learning_status(app: &mut AppState, _command: RuntimeTextCommand<'_>) {
    app.push_learning_status();
}

fn train_runtime(app: &mut AppState, observation_text: &str, action: &str) {
    remember_runtime_action(app, action);
    let trace = app.runtime.train_feedback(
        runtime_observation(observation_text),
        action,
        Feedback::Reward,
    );
    app.chat
        .push(format!("runtime train: {observation_text} -> {action}"));
    record_runtime_trace(app, trace);
}

fn probe_runtime(app: &mut AppState, observation_text: &str) {
    let trace = app.runtime.tick(RuntimeTickInput {
        observation: runtime_observation(observation_text),
        actions: app.runtime_actions.clone(),
        teacher: TeacherSignal::new(TeacherMode::TeacherOff),
        feedback: None,
        actual_successor: None,
    });
    let answer = trace
        .selected_action
        .clone()
        .unwrap_or_else(|| "NoAction".to_owned());
    app.chat.push(format!("runtime probe: {observation_text}"));
    app.chat.push(format!("ap-runtime: {answer}"));
    record_runtime_trace(app, trace);
}

fn record_runtime_trace(app: &mut AppState, trace: RuntimeTickTrace) {
    app.trace.push(runtime_trace_summary(&trace));
    app.runtime_traces.push(trace);
}

fn push_last_runtime_trace_summary(app: &mut AppState) {
    match app.runtime_traces.last() {
        Some(trace) => app.trace.extend(runtime_trace_details(trace)),
        None => app.trace.push("runtime trace is empty".to_owned()),
    }
}

fn export_runtime_trace(app: &mut AppState) {
    match app.runtime.export_trace_log_json() {
        Ok(json) => write_runtime_trace_json(app, json),
        Err(error) => app
            .trace
            .push(format!("runtime trace export failed: {error}")),
    }
}

fn write_runtime_trace_json(app: &mut AppState, json: String) {
    let trace_path = app.workspace.session_trace("runtime-trace.json");
    match write_trace_file(&trace_path, json) {
        Ok(()) => app.trace.push(format!("exported {}", trace_path.display())),
        Err(error) => app
            .trace
            .push(format!("runtime trace write failed: {error}")),
    }
}

fn write_trace_file(path: &std::path::Path, json: String) -> std::io::Result<()> {
    ensure_parent(path)?;
    std::fs::write(path, json)
}

fn push_runtime_help(app: &mut AppState) {
    app.trace.extend([
        "/train <observation> => <action>".to_owned(),
        "/probe <observation>".to_owned(),
        "/trace".to_owned(),
        "/export-trace".to_owned(),
        "/media".to_owned(),
        "/math-report".to_owned(),
        "/learning-status".to_owned(),
        "/relation <scene-json>".to_owned(),
    ]);
}

fn remember_runtime_action(app: &mut AppState, action: &str) {
    if action.is_empty() || app.runtime_actions.iter().any(|known| known == action) {
        return;
    }
    app.runtime_actions.push(action.to_owned());
}

#[derive(Debug, Clone, Copy)]
struct RuntimeTextCommand<'a> {
    kind: RuntimeTextCommandKind<'a>,
    handler: RuntimeCommandHandler,
}

impl<'a> RuntimeTextCommand<'a> {
    fn new(kind: RuntimeTextCommandKind<'a>, handler: RuntimeCommandHandler) -> Self {
        Self { kind, handler }
    }

    fn parse(text: &'a str) -> Option<Self> {
        FIXED_TEXT_COMMANDS
            .iter()
            .find_map(|command| command.parse(text))
            .or_else(|| parse_train_command(text))
            .or_else(|| parse_probe_command(text))
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum RuntimeTextCommandKind<'a> {
    Train {
        observation: &'a str,
        action: &'a str,
    },
    Probe {
        observation: &'a str,
    },
    Trace,
    ExportTrace,
    Help,
    MathReport,
    LearningStatus,
}

#[derive(Debug, Clone, Copy)]
struct FixedRuntimeTextCommand {
    text: &'static str,
    kind: RuntimeTextCommandKind<'static>,
    handler: RuntimeCommandHandler,
}

impl FixedRuntimeTextCommand {
    fn parse<'a>(self, text: &'a str) -> Option<RuntimeTextCommand<'a>> {
        (text == self.text).then_some(RuntimeTextCommand::new(self.kind, self.handler))
    }
}

const FIXED_TEXT_COMMANDS: [FixedRuntimeTextCommand; 6] = [
    FixedRuntimeTextCommand {
        text: "/trace",
        kind: RuntimeTextCommandKind::Trace,
        handler: handle_trace,
    },
    FixedRuntimeTextCommand {
        text: "/export-trace",
        kind: RuntimeTextCommandKind::ExportTrace,
        handler: handle_export_trace,
    },
    FixedRuntimeTextCommand {
        text: "/help",
        kind: RuntimeTextCommandKind::Help,
        handler: handle_help,
    },
    FixedRuntimeTextCommand {
        text: "/media",
        kind: RuntimeTextCommandKind::Help,
        handler: handle_media,
    },
    FixedRuntimeTextCommand {
        text: "/math-report",
        kind: RuntimeTextCommandKind::MathReport,
        handler: handle_math_report,
    },
    FixedRuntimeTextCommand {
        text: "/learning-status",
        kind: RuntimeTextCommandKind::LearningStatus,
        handler: handle_learning_status,
    },
];

fn parse_train_command(text: &str) -> Option<RuntimeTextCommand<'_>> {
    let body = text.strip_prefix("/train ")?;
    let (observation, action) = body.split_once("=>")?;
    Some(RuntimeTextCommand::new(
        RuntimeTextCommandKind::Train {
            observation: observation.trim(),
            action: action.trim(),
        },
        handle_train,
    ))
}

fn parse_probe_command(text: &str) -> Option<RuntimeTextCommand<'_>> {
    let observation = text.strip_prefix("/probe ")?.trim();
    Some(RuntimeTextCommand::new(
        RuntimeTextCommandKind::Probe { observation },
        handle_probe,
    ))
}

fn runtime_observation(text: &str) -> RuntimeObservation {
    RuntimeObservation::new("tui", stable_state_id(text), observation_items(text))
}

fn stable_state_id(text: &str) -> String {
    text.split_whitespace()
        .next()
        .filter(|part| !part.is_empty())
        .unwrap_or("input")
        .to_owned()
}

fn observation_items(text: &str) -> Vec<String> {
    text.split_whitespace()
        .map(|part| format!("text::{part}"))
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn runtime_train_and_probe_commands_share_runtime_state() {
        let mut app = AppState::new();

        assert!(apply_text_command_line(
            &mut app,
            "/train red circle => classify_red"
        ));
        assert!(apply_text_command_line(&mut app, "/probe red circle"));

        assert_eq!(app.runtime.memory().frames().len(), 1);
        assert_eq!(app.runtime_traces.len(), 2);
        assert!(
            app.chat
                .iter()
                .any(|line| line.contains("ap-runtime: classify_red"))
        );
    }

    #[test]
    fn runtime_trace_command_adds_diagnostics() {
        let mut app = AppState::new();

        apply_text_command_line(&mut app, "/train blue square => classify_blue");
        let before = app.trace.len();
        assert!(apply_text_command_line(&mut app, "/trace"));

        assert!(app.trace.len() > before);
        assert!(app.trace.iter().any(|line| line.contains("r-state keys")));
    }
}
