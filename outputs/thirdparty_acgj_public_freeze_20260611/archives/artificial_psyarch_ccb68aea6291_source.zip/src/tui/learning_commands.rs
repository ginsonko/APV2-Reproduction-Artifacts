use crate::learning::LessonRunReport;

use super::app::AppState;

pub fn push_learning_status(app: &mut AppState) {
    let latest = app
        .reports
        .last()
        .map(report_summary)
        .unwrap_or_else(|| "no lesson report yet".to_owned());
    app.trace.push(format!(
        "learning status: memory_rows={} reports={} skill_path={} latest={}",
        app.learning.agent().memory_rows(),
        app.reports.len(),
        app.skill_path.display(),
        latest
    ));
}

pub fn push_math_summary(app: &mut AppState, train: &LessonRunReport, probe: &LessonRunReport) {
    app.chat.push(format!(
        "math report: train={:.2} holdout={:.2} generalization={:.2}",
        train.skill_report.train_accuracy(),
        train.skill_report.holdout_accuracy(),
        probe.skill_report.holdout_accuracy()
    ));
}

fn report_summary(report: &LessonRunReport) -> String {
    format!(
        "{} train={:.2} holdout={:.2} status={:?}",
        report.lesson_id,
        report.skill_report.train_accuracy(),
        report.skill_report.holdout_accuracy(),
        report.skill_report.status
    )
}
