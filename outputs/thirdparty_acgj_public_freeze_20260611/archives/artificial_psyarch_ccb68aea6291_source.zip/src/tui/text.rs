use unicode_width::{UnicodeWidthChar, UnicodeWidthStr};

pub fn fit_text(text: &str, width: usize) -> String {
    if width == 0 {
        return String::new();
    }
    if UnicodeWidthStr::width(text) <= width {
        return text.to_owned();
    }
    if width == 1 {
        return "…".to_owned();
    }
    format!("{}…", prefix_by_width(text, width - 1))
}

pub fn fit_owned(text: String, width: usize) -> String {
    fit_text(&text, width)
}

fn prefix_by_width(text: &str, width: usize) -> String {
    let mut used = 0;
    let mut output = String::new();
    for ch in text.chars() {
        let ch_width = UnicodeWidthChar::width(ch).unwrap_or(0);
        if used + ch_width > width {
            break;
        }
        used += ch_width;
        output.push(ch);
    }
    output
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn fit_text_preserves_short_text() {
        assert_eq!(fit_text("abc", 5), "abc");
    }

    #[test]
    fn fit_text_truncates_ascii() {
        assert_eq!(fit_text("abcdef", 4), "abc…");
    }

    #[test]
    fn fit_text_truncates_chinese_by_display_width() {
        assert_eq!(fit_text("你好世界", 5), "你好…");
    }
}
