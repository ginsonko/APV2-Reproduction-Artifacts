use std::time::Duration;

use ratatui::Terminal;
use ratatui::backend::TermwizBackend;
use ratatui::termwiz::input::InputEvent;
use ratatui::termwiz::surface::{Change, CursorShape};
use ratatui::termwiz::terminal::Terminal as TermwizTerminal;

use super::app::AppState;
use super::render::render;

pub type TuiTerminal = Terminal<TermwizBackend>;

pub fn new_terminal() -> Result<TuiTerminal, Box<dyn std::error::Error>> {
    Ok(Terminal::new(TermwizBackend::new()?)?)
}

pub fn prepare_terminal(terminal: &mut TuiTerminal) -> Result<(), Box<dyn std::error::Error>> {
    set_cursor_shape(terminal, CursorShape::SteadyBar)
}

pub fn restore_terminal(terminal: &mut TuiTerminal) -> Result<(), Box<dyn std::error::Error>> {
    set_cursor_shape(terminal, CursorShape::Default)?;
    terminal.show_cursor()?;
    Ok(())
}

pub fn run_frame(
    terminal: &mut TuiTerminal,
    app: &mut AppState,
) -> Result<bool, Box<dyn std::error::Error>> {
    app.poll_worker();
    draw_current_frame(terminal, app)?;
    let Some(input) = poll_input(terminal)? else {
        return Ok(false);
    };
    handle_terminal_event(terminal, app, input)?;
    redraw_after_event(terminal, app)
}

fn draw_current_frame(
    terminal: &mut TuiTerminal,
    app: &AppState,
) -> Result<(), Box<dyn std::error::Error>> {
    terminal.autoresize()?;
    terminal.draw(|frame| render(frame, app))?;
    Ok(())
}

fn redraw_after_event(
    terminal: &mut TuiTerminal,
    app: &AppState,
) -> Result<bool, Box<dyn std::error::Error>> {
    if app.should_quit {
        return Ok(true);
    }
    draw_current_frame(terminal, app)?;
    Ok(false)
}

fn handle_terminal_event(
    terminal: &mut TuiTerminal,
    app: &mut AppState,
    input: InputEvent,
) -> Result<(), Box<dyn std::error::Error>> {
    if let Some((cols, rows)) = resized_size(&input) {
        resize_terminal(terminal, app, cols, rows)?;
    } else {
        app.handle_input(input, input_width(terminal)?);
    }
    Ok(())
}

fn resized_size(input: &InputEvent) -> Option<(usize, usize)> {
    match input {
        InputEvent::Resized { cols, rows } => Some((*cols, *rows)),
        _ => None,
    }
}

fn resize_terminal(
    terminal: &mut TuiTerminal,
    app: &mut AppState,
    cols: usize,
    rows: usize,
) -> Result<(), Box<dyn std::error::Error>> {
    terminal
        .backend_mut()
        .buffered_terminal_mut()
        .resize(cols, rows);
    terminal.resize(ratatui::layout::Rect::new(0, 0, cols as u16, rows as u16))?;
    terminal.clear()?;
    app.handle_resize();
    Ok(())
}

fn poll_input(
    terminal: &mut TuiTerminal,
) -> Result<Option<InputEvent>, Box<dyn std::error::Error>> {
    Ok(terminal
        .backend_mut()
        .buffered_terminal_mut()
        .terminal()
        .poll_input(Some(Duration::from_millis(200)))?)
}

fn input_width(terminal: &TuiTerminal) -> Result<usize, Box<dyn std::error::Error>> {
    let size = terminal.size()?;
    Ok(size.width.saturating_sub(2).max(1) as usize)
}

fn set_cursor_shape(
    terminal: &mut TuiTerminal,
    shape: CursorShape,
) -> Result<(), Box<dyn std::error::Error>> {
    let buffered = terminal.backend_mut().buffered_terminal_mut();
    buffered.add_change(Change::CursorShape(shape));
    buffered.flush()?;
    Ok(())
}
