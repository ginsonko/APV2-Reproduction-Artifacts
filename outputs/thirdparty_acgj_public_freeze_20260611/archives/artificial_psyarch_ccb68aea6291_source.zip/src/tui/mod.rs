pub mod actions;
pub mod app;
pub mod chat;
pub mod editor;
pub mod focus;
pub mod i18n;
pub mod input;
pub mod language_bridge;
pub mod language_commands;
pub mod learning_commands;
pub mod panel_text;
pub mod persistence;
pub mod relation_commands;
pub mod render;
pub mod runtime_bridge;
pub mod terminal_io;
pub mod text;
pub mod worker;

use self::app::AppState;
use self::terminal_io::{TuiTerminal, new_terminal, prepare_terminal, restore_terminal, run_frame};

pub fn run() -> Result<(), Box<dyn std::error::Error>> {
    let mut terminal = new_terminal()?;
    prepare_terminal(&mut terminal)?;
    let result = run_app(&mut terminal);
    let restore = restore_terminal(&mut terminal);
    result.and(restore)
}

fn run_app(terminal: &mut TuiTerminal) -> Result<(), Box<dyn std::error::Error>> {
    let mut app = AppState::new();

    loop {
        if run_frame(terminal, &mut app)? {
            break;
        }
    }

    Ok(())
}
