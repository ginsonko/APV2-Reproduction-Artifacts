use unicode_width::UnicodeWidthChar;

#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct TextInput {
    text: String,
    cursor: usize,
    preferred_column: Option<usize>,
}

impl TextInput {
    pub fn text(&self) -> &str {
        &self.text
    }

    pub fn cursor(&self) -> usize {
        self.cursor
    }

    pub fn is_empty(&self) -> bool {
        self.text.is_empty()
    }

    pub fn clear(&mut self) {
        self.text.clear();
        self.cursor = 0;
        self.preferred_column = None;
    }

    pub fn insert_char(&mut self, c: char) {
        self.text.insert(self.cursor, c);
        self.cursor += c.len_utf8();
        self.reset_vertical_column();
    }

    pub fn insert_str(&mut self, text: &str) {
        self.text.insert_str(self.cursor, text);
        self.cursor += text.len();
        self.reset_vertical_column();
    }

    pub fn backspace(&mut self) {
        if let Some(previous) = self.previous_boundary() {
            self.text.drain(previous..self.cursor);
            self.cursor = previous;
            self.reset_vertical_column();
        }
    }

    pub fn delete(&mut self) {
        if let Some(next) = self.next_boundary() {
            self.text.drain(self.cursor..next);
            self.reset_vertical_column();
        }
    }

    pub fn move_left(&mut self) {
        if let Some(previous) = self.previous_boundary() {
            self.cursor = previous;
        }
        self.reset_vertical_column();
    }

    pub fn move_right(&mut self) {
        if let Some(next) = self.next_boundary() {
            self.cursor = next;
        }
        self.reset_vertical_column();
    }

    pub fn move_home(&mut self) {
        self.cursor = 0;
        self.reset_vertical_column();
    }

    pub fn move_end(&mut self) {
        self.cursor = self.text.len();
        self.reset_vertical_column();
    }

    pub fn move_up(&mut self, width: usize) {
        self.move_vertical(width, VerticalDirection::Up);
    }

    pub fn move_down(&mut self, width: usize) {
        self.move_vertical(width, VerticalDirection::Down);
    }

    pub fn wrapped_line_count(&self, width: usize) -> usize {
        let width = width.max(1);
        self.text_line_count(width)
            .max(self.cursor_line_count(width))
    }

    pub fn wrapped_cursor(&self, width: usize) -> Option<WrappedCursor> {
        if self.text.is_empty() {
            return None;
        }
        Some(wrapped_position(&self.text[..self.cursor], width))
    }

    fn text_line_count(&self, width: usize) -> usize {
        display_width(&self.text).div_ceil(width).max(1)
    }

    fn cursor_line_count(&self, width: usize) -> usize {
        self.wrapped_cursor(width)
            .map(|cursor| cursor.row + 1)
            .unwrap_or(1)
    }

    fn move_vertical(&mut self, width: usize, direction: VerticalDirection) {
        let width = width.max(1);
        let current = self.cursor_grid(width);
        let Some(row) = self.target_vertical_row(width, current.row, direction) else {
            return;
        };
        self.cursor = self.cursor_at_grid(width, row, current.col);
    }

    fn target_vertical_row(
        &self,
        width: usize,
        current: usize,
        direction: VerticalDirection,
    ) -> Option<usize> {
        match direction {
            VerticalDirection::Up => current.checked_sub(1),
            VerticalDirection::Down => {
                (current + 1 < self.wrapped_line_count(width)).then_some(current + 1)
            }
        }
    }

    fn cursor_grid(&mut self, width: usize) -> WrappedCursor {
        let cursor = self.wrapped_cursor(width).unwrap_or_default();
        cursor.with_col(*self.preferred_column.get_or_insert(cursor.col))
    }

    fn cursor_at_grid(&self, width: usize, row: usize, col: usize) -> usize {
        let target = row.saturating_mul(width).saturating_add(col);
        byte_index_at_display_width(&self.text, target)
    }

    fn previous_boundary(&self) -> Option<usize> {
        self.text[..self.cursor]
            .char_indices()
            .next_back()
            .map(|(index, _)| index)
    }

    fn next_boundary(&self) -> Option<usize> {
        self.text[self.cursor..]
            .char_indices()
            .nth(1)
            .map(|(index, _)| self.cursor + index)
            .or_else(|| (self.cursor < self.text.len()).then_some(self.text.len()))
    }

    fn reset_vertical_column(&mut self) {
        self.preferred_column = None;
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct WrappedCursor {
    pub col: usize,
    pub row: usize,
}

impl WrappedCursor {
    fn with_col(self, col: usize) -> Self {
        Self { col, row: self.row }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum VerticalDirection {
    Up,
    Down,
}

fn display_width(text: &str) -> usize {
    text.chars().map(char_width).sum()
}

fn wrapped_position(text: &str, width: usize) -> WrappedCursor {
    let width = width.max(1);
    let offset = display_width(text);
    WrappedCursor {
        col: offset % width,
        row: offset / width,
    }
}

fn byte_index_at_display_width(text: &str, target: usize) -> usize {
    let mut width = 0;
    for (index, c) in text.char_indices() {
        let next = width + char_width(c);
        if next > target {
            return index;
        }
        width = next;
    }
    text.len()
}

fn char_width(c: char) -> usize {
    c.width().unwrap_or(0)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cursor_uses_display_width_for_chinese() {
        let mut input = TextInput::default();
        input.insert_str("你好");
        assert_eq!(
            input.wrapped_cursor(20).unwrap(),
            WrappedCursor { col: 4, row: 0 }
        );
    }

    #[test]
    fn left_and_right_stay_on_utf8_boundaries() {
        let mut input = TextInput::default();
        input.insert_str("你a");
        input.move_left();
        assert_eq!(input.cursor(), "你".len());
        input.move_left();
        assert_eq!(input.cursor(), 0);
        input.move_right();
        assert_eq!(input.cursor(), "你".len());
    }

    #[test]
    fn vertical_movement_tracks_wrapped_columns() {
        let mut input = TextInput::default();
        input.insert_str("abcdef");
        input.move_left();
        input.move_left();
        input.move_up(3);
        assert_eq!(input.cursor(), 1);
        input.move_down(3);
        assert_eq!(input.cursor(), 4);
    }

    #[test]
    fn down_on_last_wrapped_line_keeps_cursor() {
        let mut input = TextInput::default();
        input.insert_str("abc");
        input.move_left();
        input.move_down(3);
        assert_eq!(input.cursor(), 2);
    }

    #[test]
    fn empty_input_has_no_cursor() {
        assert_eq!(TextInput::default().wrapped_cursor(10), None);
    }
}
