# artificial_psyarch

一个用 Rust 写的人工心智架构原型。现在它还不是一个完整智能体，更像是一套可跑、可测、可慢慢加能力的 AP-Core 实验台。

目前重点在这些事：

- 复现论文里的核心闭环：预测、行动、反馈、记忆、教师开关、审计。
- 做本地实验，不依赖线上 API 也能验证能力切片。
- 给外部 agent / LLM 留学习接口，让它们可以提交训练材料或 probe 请求。
- 提供一个 TUI 入口，后面用来做人机交互、训练、对话和多模态输出。

## 现在能做什么

已经有的能力大概是：

- AP-Core 基础运行结构。
- TeacherOn / TeacherOff / Fade 等教师模式。
- 反馈记忆和技能包导入导出。
- 本地实验记录和论文 key suite 输出。
- TUI 交互入口，支持中英文界面切换、输入过滤、基本训练/探针命令。
- 外部 agent 可通过 JSON 调用 `ap_learn`。
- 外部 agent 可提交 scaffold spec，让 AP 按 demonstrate/strong/weak/feedback-only/teacher-off/cold-retest 退火训练。
- 生成数学训练闭环：能从四则运算样本里学到运算符，并对未见过的新题做有限泛化。
- 通用语言接地：把文本和语境训练成 `LanguageFrame` / 对话动作，可从 JSONL/JSON 数据导入。

注意：现在的“学习”是白箱、可审计的工程闭环，不是大模型式的开放世界学习。它能在已经实现的能力切片里泛化，但不能直接当通用数学模型或通用聊天模型用。

## 快速运行

需要 Rust 工具链，项目使用 edition 2024。

完整使用说明看 [docs/user_guide.md](docs/user_guide.md)。里面分了普通用户部分和外部 AI/agent 训练部分。

```bash
cargo run
```

`Cargo.toml` 里默认运行的是 `ap_tui`，所以这等价于：

```bash
cargo run --bin ap_tui
```

Release 运行：

```bash
cargo run --release
```

## 常用命令

跑全部测试：

```bash
cargo test
```

检查代码：

```bash
cargo check
cargo clippy --all-targets --all-features -- -D warnings
cargo crap
```

生成基础数学学习报告：

```bash
cargo run --bin generated_math_report
```

报告会写到：

```text
.ap/reports/learning/generated_math_training_report.md
```

跑本地论文相关实验：

```bash
cargo run --bin experiments_local
cargo run --bin paper_key_suite
```

验证外部语言接地数据：

```bash
cargo run --bin language_grounding_report -- \
  --input .ap/exports/language/language-grounding.jsonl \
  --output .ap/reports/language/grounding-report.json
```

## 外部 agent 怎么调用

外部 agent 可以用 `ap_learn` 走 JSON 输入输出：

```bash
cargo run --bin ap_learn -- \
  --input request.json \
  --domain demo \
  --mode learn
```

scaffold 课程：

```bash
cargo run --bin ap_learn -- \
  --input docs/examples/learning/scaffold-relation-word.json \
  --input-kind scaffold \
  --domain relation_words
```

严格视觉关系词训练报告：

```bash
cargo run --bin relation_word_report
```

默认读取 `.ap/exports/lessons/scaffold-relation-zh-v1-strict.json`，审计图片文件名/路径和 state items 是否泄漏答案，再训练并写出 `.ap/reports/learning/relation-word-report.json`。给外部 AI/agent 的完整提示词在 [docs/relation_word_training_prompt.md](docs/relation_word_training_prompt.md)。
同时会读取 `.ap/exports/lessons/scaffold-relation-zh-v1-holdout.json` 做独立 teacher-off holdout probe；如果暂时只想跑训练 spec，可显式加 `--no-holdout-probe`。
默认还会生成 control probes：只保留几何特征应通过，去掉几何特征/打乱期望答案应失败，用来排除文件名、对象名或评分路径污染。

训练完成后可以直接用结构化 scene JSON 调用已保存的关系词 skill：

```bash
cargo run --bin relation_probe -- \
  --scene '{"objects":[{"id":"p","center":[10,50]},{"id":"q","center":[90,50]}]}'
```

TUI 内也可以输入 `/relation <scene-json>`，同样走 `.ap/skills/external/skill.relation.spatial_words.zh.v1.apbin` 的 teacher-off probe。

默认会写到 `.ap/exports/bundles/ap-learning-bundle.json`，并把 skill 保存到 `.ap/skills/external/demo-current.apbin`。

之后可以加载同一个技能包做 probe：

```bash
cargo run --bin ap_learn -- \
  --input probe.json \
  --domain demo \
  --agent-in .ap/skills/external/demo-current.apbin \
  --mode probe
```

也支持用 `-` 从 stdin/stdout 走管道：

```bash
cat request.json | cargo run --bin ap_learn -- --input - --output -
```

## 目录结构

```text
src/core/          AP-Core、预测、运行时、技能注册等基础结构
src/learning/      学习请求、课程、agent、报告、技能包读写
src/language/      语言接地 frame、特征、导入和对话解释
src/experiments/   论文相关实验切片
src/repeat_map/    repeat map 相关实现和本地记录
src/gl/            面向外部 agent / 工具 / 媒体输出的胶水层
src/tui/           终端交互界面
src/bin/           可执行入口
tests/             集成测试和能力闭环测试
docs/              论文和笔记，本仓库默认不强制纳入输出文件
.ap/               本地 skill、报告、导出 bundle、TUI session，通常不进 git
```

可以用 `AP_WORKSPACE=/path/to/workspace` 改 `.ap/` 的位置。

## 目前的数学闭环状态

可以运行：

```bash
cargo run --bin generated_math_report
```

当前报告验证的是：

- TeacherOn 训练写入记忆。
- TeacherOff holdout 不写记忆。
- 学过 `+ - * /` 后，可以回答未见过的新表达式。
- 技能包保存再加载后，仍然能回答未见题。
- 未训练过的运算符不会强行猜答案。

这说明“生成基础数学”这条能力链已经闭环，但范围仍然有限：表达式格式目前是类似 `9 + 4` 这种简单文本，泛化依据是已奖励样本中出现过的运算符。

## 开发习惯

提交前建议至少跑：

```bash
cargo fmt --check
cargo check
cargo test
cargo clippy --all-targets --all-features -- -D warnings
```

如果改了实验、报告、学习逻辑，也跑：

```bash
cargo crap
```

这个项目比较容易长成“大文件”，所以新增功能尽量按功能放模块里，不要把所有逻辑堆到一个入口文件里。
