# AP Learning Quickstart

The current learning bridge trains discrete AP skills: a stimulus maps to an
action label or fixed text response. TeacherOff probes must recall from AP
memory and must not read `expected_action` as the answer.

## Train From JSON

```bash
cargo run --bin ap_learn -- \
  --input docs/examples/learning/train-shapes.json \
  --domain shapes \
  --mode learn
```

The training request uses `FeedbackOnly` with `AutomaticExaminer`. Each
`TaskSet` item provides a `stimulus` and the `expected_action` used for scoring.
The exported skill package is written to `.ap/skills/external/shapes-current.apbin`.
The lesson bundle is written to `.ap/exports/bundles/ap-learning-bundle.json`.

## Probe Without Teacher Answers

```bash
cargo run --bin ap_learn -- \
  --input docs/examples/learning/probe-red-circle.json \
  --agent-in .ap/skills/external/shapes-current.apbin \
  --mode probe
```

```bash
cargo run --bin ap_learn -- \
  --input docs/examples/learning/probe-blue-square.json \
  --agent-in .ap/skills/external/shapes-current.apbin \
  --mode probe
```

Probe requests use `TeacherOff` and `NoFeedback`, so they do not write memory.
The response in the output bundle should come from the previously saved skill
package.

## TUI Persistence

```bash
cargo run --release
```

The TUI uses `.ap/skills/interactive/current.apbin` as its default skill package.
On startup it loads that file if present. After running queued lessons with
`Ctrl-X`, it archives the previous current skill under
`.ap/skills/interactive/history/` and saves the current AP memory back to
`current.apbin`.

The TUI status line shows the current workspace and skill file path. Set
`AP_WORKSPACE=/path/to/workspace` to move local AP data out of `.ap/`.
