# AP 用户与 Agent 指南

这份指南分两部分：

- 用户指南：怎么运行、怎么用 TUI、文件放在哪里、遇到问题怎么查。
- AI/agent 指南：外部 agent 或 LLM 怎么给 AP 准备训练数据、怎么调用训练接口、怎么做 teacher-off 验证。

当前项目是白箱 AP 原型，不是传统神经网络模型，也不是 LLM API 包装层。它的学习来自显式课程、反馈、记忆写入和 teacher-off 审计。

## 用户指南

### 1. 安装和检查

需要 Rust 工具链。进入项目根目录后先检查：

```bash
cargo check
cargo test
```

常用质量检查：

```bash
cargo fmt --check
cargo clippy --all-targets --all-features -- -D warnings
cargo crap
```

### 2. 启动 TUI

项目默认运行 `ap_tui`：

```bash
cargo run
```

Release 运行：

```bash
cargo run --release
```

等价命令：

```bash
cargo run --bin ap_tui
```

TUI 使用 termwiz 后端。启动后默认进入纯对话输入框，普通文字会作为 teacher-off probe 发送给 AP。

### 3. TUI 快捷键

常用键：

```text
Enter      发送输入
Tab        切换面板
Ctrl-Q     退出
Ctrl-C     退出
Ctrl-G     切换中文/英文
Ctrl-X     运行已排队课程
Ctrl-P     用当前输入做 probe
Ctrl-E     导出最后一次课程报告
Ctrl-R     刷新本地 AP-Core 实验记录
Ctrl-L     加入一条 LLM 课程适配器占位课程
Ctrl-O     从 .ap/exports/lessons/ap-learning-request.json 导入外部请求
```

普通 `q`、`x`、`r` 等字母会进入输入框，不会触发快捷键。快捷键必须使用 Ctrl 组合。

输入框支持中文宽度、左右移动、上下移动、Home/End、粘贴过滤和鼠标 escape 序列过滤。空输入时不显示光标。

### 4. TUI 文字命令

在输入框里输入这些命令后按 Enter：

```text
/learn <目标或材料>
/train <observation> => <action>
/probe <observation>
/trace
/export-trace
/media
/math-report
/scaffold <path>
/learning-status
/help
```

用途：

- `/learn <目标>`：把用户文字变成一条 feedback-only 学习课程，加入队列。
- `Ctrl-X`：运行队列里的课程。运行在后台 worker 中，不阻塞界面。
- `/train obs => action`：训练 APV21 runtime 的动作反馈记忆。
- `/probe obs`：在 teacher-off 下探测 runtime 会选什么动作。
- `/trace`：展开最近一次 runtime tick 的审计信息。
- `/math-report`：运行生成数学训练与泛化 probe。
- `/scaffold <path>`：导入并运行 `skill_scaffold_spec/v2` 风格课程；不带 path 时读取 `.ap/exports/lessons/scaffold.json`。
- `/learning-status`：显示当前学习 session、报告数、记忆行数、技能路径。

### 5. 本地工作区

默认工作区是 `.ap/`：

```text
.ap/skills/interactive/current.apbin
.ap/skills/interactive/history/
.ap/skills/external/
.ap/exports/bundles/
.ap/exports/lessons/
.ap/reports/
.ap/sessions/
```

可以用环境变量换位置：

```bash
AP_WORKSPACE=/tmp/ap-work cargo run --release
```

约定：

- 内部技能包默认用 bincode，后缀是 `.apbin`。
- 导出给人或外部系统看的报告、bundle、请求默认用 JSON 或 Markdown。
- `.ap/`、`outputs/`、`target/` 通常不进 git。

### 6. 训练和 probe 的最短流程

用已有示例训练：

```bash
cargo run --bin ap_learn -- \
  --input docs/examples/learning/train-shapes.json \
  --domain shapes \
  --mode learn
```

默认输出：

```text
.ap/exports/bundles/ap-learning-bundle.json
.ap/skills/external/shapes-current.apbin
```

加载技能包做 teacher-off probe：

```bash
cargo run --bin ap_learn -- \
  --input docs/examples/learning/probe-red-circle.json \
  --domain shapes \
  --agent-in .ap/skills/external/shapes-current.apbin \
  --mode probe
```

也可以通过 stdin/stdout 调用：

```bash
cat docs/examples/learning/probe-red-circle.json | \
  cargo run --bin ap_learn -- --input - --output - \
  --agent-in .ap/skills/external/shapes-current.apbin \
  --mode probe
```

运行 scaffold 课程：

```bash
cargo run --bin ap_learn -- \
  --input docs/examples/learning/scaffold-relation-word.json \
  --input-kind scaffold \
  --domain relation_words \
  --mode learn
```

TUI 中也可以输入：

```text
/scaffold docs/examples/learning/scaffold-relation-word.json
```

scaffold 报告会记录每个 phase 的 teacher packet、teacher-off/cold-retest accuracy 和 mastery 退火状态。

严格视觉关系词训练建议使用专门入口：

```bash
cargo run --bin relation_word_report
```

默认输入：

```text
.ap/exports/lessons/scaffold-relation-zh-v1-strict.json
.ap/exports/lessons/scaffold-relation-zh-v1-holdout.json
```

默认输出：

```text
.ap/exports/bundles/scaffold-relation-zh-v1-strict-bundle.json
.ap/skills/external/skill.relation.spatial_words.zh.v1.apbin
.ap/reports/learning/relation-word-report.json
```

这个入口会先审计课程：每个 step 必须有唯一 `image::` 引用，图片文件名和 state items 不能包含 `left/right/parallel/perp/above/below`、`RelationWord...`、`answer::` 等答案泄漏信号。完整外部 AI 提示词见 `docs/relation_word_training_prompt.md`。
训练完成后会加载 `.ap/skills/external/skill.relation.spatial_words.zh.v1.apbin`，对 holdout spec 执行纯 TeacherOff probe，不再运行 demonstrate/strong/weak/feedback-only 阶段。这个 `holdout_probe` 才是关系词训练的主要泛化指标。
默认还会执行 control probes：`geometry_only` 应通过，`no_geometry` 和 `shuffled_expected` 应失败，用于证明结果依赖几何数值特征而不是图片路径、对象名或评分路径。

训练后可以用结构化 scene JSON 调用关系词 skill：

```bash
cargo run --bin relation_probe -- \
  --scene '{"objects":[{"id":"p","center":[10,50]},{"id":"q","center":[90,50]}]}'
```

TUI 内输入 `/relation <scene-json>` 会走同一个 teacher-off probe，并把内部 action 转成中文关系词。

### 7. 数学训练报告

运行：

```bash
cargo run --bin generated_math_report
```

报告写到：

```text
.ap/reports/learning/generated_math_training_report.md
```

当前数学能力不是计算器直连。训练时依赖 rewarded examples 学到运算符和计数过程；teacher-off probe 不允许读取答案或写入记忆。已实现范围主要是简单整数四则表达式、括号和优先级的有限泛化。

### 8. 实验和论文复现入口

本地实验：

```bash
cargo run --bin experiments_local
```

论文 key suite：

```bash
cargo run --bin paper_key_suite
```

这些入口会运行 AP-Core 相关实验切片，例如 count loop、feature combo、sensor assoc、math slice、math fullchain、long-run、canvas geometry、multimodal revision、desktop safety 等。

### 9. 常见问题

`cargo run` 不知道运行哪个 binary：

- 当前 `Cargo.toml` 已设置 `default-run = "ap_tui"`。
- 如果仍遇到问题，直接用 `cargo run --bin ap_tui`。

TUI 终端显示错位：

- 先更新到最新代码。
- 调整终端大小后 TUI 会处理 resize 事件并清屏重绘。
- 如果仍错位，退出后重新运行。

TUI 某些内容看不全：

- 主面板内容默认换行。
- 底部状态栏是单行，窄屏时只显示核心计数，不显示长路径。

probe 没学会：

- 确认训练请求是 `intent: "Learn"`。
- 确认训练模式允许写记忆：`TeacherOn`、`FeedbackOnly` 或 `Fade`。
- 确认任务有 `expected_action`，并且反馈策略能评分。
- 确认 probe 时传入了之前保存的 `.apbin` 技能包。

## AI/Agent 训练指南

这一部分给外部 agent、LLM wrapper、脚本和自动课程生成器看。

### 1. 你的角色

外部 AI 不应该直接替 AP 回答 teacher-off 问题。更合适的角色是：

- 把用户材料整理成 `AgentLearningRequest`。
- 生成训练课程和 holdout 课程。
- 在训练阶段提供 rubric 或 expected action。
- 帮用户选择数据文件、调用 CLI、阅读报告。
- 在 teacher-off 阶段只提交 probe，不泄露答案给 AP 记忆路径。

AP 的核心学习路径是：

```text
AgentLearningRequest
-> PlannedLesson
-> LessonRunner
-> LearnableAgent
-> LessonRunReport
-> LearnedSkillPackage
```

如果要走脚手架退火协议，则使用：

```text
SkillScaffoldSpec
-> SkillScaffoldController
-> ScaffoldSpecRunner
-> LearnableAgent
-> ScaffoldRunReport
```

### 2. 最重要的安全边界

训练和验证必须分开：

- `Learn` 可以写记忆。
- `Probe` 不写记忆。
- `TeacherOff` 不应暴露答案给 learner。
- teacher-off holdout 里如果发生记忆写入或反馈泄漏，就是失败。

不要这样做：

- 不要把 holdout 答案塞进 teacher-off 训练路径。
- 不要把 LLM 生成的答案当成 AP 已学会的结果。
- 不要在 probe 时使用 `--mode learn`。
- 不要把当前未验证的输出当作技能包证据。

### 3. 请求格式

`ap_learn` 输入是 `AgentLearningRequest` JSON。

顶层字段：

```json
{
  "request_id": "shape-train-0",
  "source": "User",
  "intent": "Learn",
  "goal": "learn simple shape labels",
  "material": {
    "TaskSet": []
  },
  "teacher_mode": "FeedbackOnly",
  "feedback_policy": "AutomaticExaminer",
  "holdout": {
    "teacher_off": true,
    "split": "MirrorTasks"
  },
  "desired_outputs": ["Text", "Trace", "SkillPackage"],
  "conversation": []
}
```

`source` 可用：

```text
"User"
{"Llm": {"provider": "name", "model": "model"}}
{"File": {"path": "path/to/file"}}
{"Script": {"name": "script-name"}}
{"Experiment": {"experiment_id": "count_loop"}}
```

`intent` 可用：

```text
Learn
Probe
Chat
Export
```

`teacher_mode` 可用：

```text
TeacherOn          可见答案、可见反馈、写记忆
FeedbackOnly       不直接给答案、可见反馈、写记忆
Fade               淡出/过渡模式：可见反馈、写记忆、不直接给答案
NoAnswerFeedback   可见反馈、不写记忆
TeacherOff         不写记忆，用于 probe/holdout
```

`feedback_policy` 可用：

```text
UserScored
LlmScored
AutomaticExaminer
NoFeedback
```

`material` 支持两类：

```json
{
  "Stimulus": {
    "Text": "red circle"
  }
}
```

```json
{
  "TaskSet": [
    {
      "task_id": "shape-0",
      "stimulus": {
        "Text": "red circle"
      },
      "expected_action": "ClassifyRedCircle",
      "rubric": "reward only if exact"
    }
  ]
}
```

`stimulus` 可用：

```text
{"Text": "..."}
{"Json": {...}}
{"ImageRef": {"artifact_id": "...", "kind": "Image", "uri": "...", "mime_type": "..."}}
{"AudioRef": {"artifact_id": "...", "kind": "Audio", "uri": "...", "mime_type": "..."}}
```

### 4. 训练请求示例

```json
{
  "request_id": "shape-train-0",
  "source": "User",
  "intent": "Learn",
  "goal": "learn simple shape labels",
  "material": {
    "TaskSet": [
      {
        "task_id": "shape-0",
        "stimulus": {
          "Text": "red circle"
        },
        "expected_action": "ClassifyRedCircle",
        "rubric": "exact label"
      },
      {
        "task_id": "shape-1",
        "stimulus": {
          "Text": "blue square"
        },
        "expected_action": "ClassifyBlueSquare",
        "rubric": "exact label"
      }
    ]
  },
  "teacher_mode": "FeedbackOnly",
  "feedback_policy": "AutomaticExaminer",
  "holdout": {
    "teacher_off": true,
    "split": "MirrorTasks"
  },
  "desired_outputs": ["Text", "Trace", "SkillPackage"],
  "conversation": []
}
```

调用：

```bash
cargo run --bin ap_learn -- \
  --input request.json \
  --domain shapes \
  --mode learn
```

显式指定技能包输出：

```bash
cargo run --bin ap_learn -- \
  --input request.json \
  --domain shapes \
  --agent-out .ap/skills/external/shapes-current.apbin \
  --mode learn
```

### 5. Probe 请求示例

```json
{
  "request_id": "shape-probe-0",
  "source": "User",
  "intent": "Probe",
  "goal": "red circle",
  "material": {
    "Stimulus": {
      "Text": "red circle"
    }
  },
  "teacher_mode": "TeacherOff",
  "feedback_policy": "NoFeedback",
  "holdout": {
    "teacher_off": true,
    "split": "AllProbe"
  },
  "desired_outputs": ["Text", "Trace"],
  "conversation": []
}
```

调用：

```bash
cargo run --bin ap_learn -- \
  --input probe.json \
  --domain shapes \
  --agent-in .ap/skills/external/shapes-current.apbin \
  --mode probe
```

### 6. 输出 bundle 怎么读

`ap_learn` 输出的是 JSON bundle：

```json
{
  "response": {
    "request_id": "...",
    "lesson": {},
    "notes": [],
    "artifacts": []
  },
  "report": {
    "lesson_id": "...",
    "train_attempts": [],
    "holdout_attempts": [],
    "taint_audit": {},
    "skill_report": {}
  }
}
```

重点看：

- `report.train_attempts`: 训练阶段尝试、反馈、是否写记忆。
- `report.holdout_attempts`: teacher-off 阶段回答。
- `report.taint_audit`: 是否存在教师泄漏风险。
- `report.skill_report.status`: `Verified` 才说明该课程证据通过。
- `train_accuracy()` 和 `holdout_accuracy()` 在 JSON 中体现为 rewards/attempts，需要自己计算或看报告入口。

### 7. 技能包格式

内部默认：

```text
.ap/skills/external/<domain>-current.apbin
.ap/skills/interactive/current.apbin
```

`.apbin` 使用 bincode，适合程序内部读写。

外部边缘：

- 请求 JSON。
- 输出 bundle JSON。
- 报告 Markdown。
- 如果确实要人工检查技能包，可以把 `--agent-out` 指向 `.json`，系统会按扩展名写 JSON。

示例：

```bash
cargo run --bin ap_learn -- \
  --input request.json \
  --domain shapes \
  --agent-out .ap/skills/external/shapes-debug.json \
  --mode learn
```

### 8. 课程生成建议

好的训练集：

- 每个 task_id 稳定且唯一。
- stimulus 尽量表达可泛化特征，而不是只给样本 ID。
- expected_action 是 AP 应该学到的动作标签或文本答案。
- rubric 简短说明评分标准。
- 至少保留一组 teacher-off holdout。

不好的训练集：

- task_id 里直接藏答案。
- train 和 holdout 完全一样，却声称泛化。
- `TeacherOff` 里还要求写记忆。
- LLM 先算好 probe 答案，再把答案作为 AP 输出。

### 9. 数学训练给 agent 的特别说明

当前数学能力依赖 AP 已实现的 arithmetic skill：

- 训练样本奖励过某个运算符后，AP 才能在 teacher-off 中尝试该运算符。
- 未训练过的运算符不会当计算器硬算。
- 多步表达式和括号依赖已学过的基本运算。
- 适合做小整数、过程可审计的课程，不适合直接当通用数学求解器。

可用示例：

```bash
cargo run --bin ap_learn -- \
  --input examples/ap_learn_basic_math_train.json \
  --domain generated_math \
  --mode learn

cargo run --bin ap_learn -- \
  --input examples/ap_learn_basic_math_probe.json \
  --domain generated_math \
  --agent-in .ap/skills/external/generated_math-current.apbin \
  --mode probe
```

### 10. 通用语言训练 V1

当前已开始实现语言状态接地，不是 token 语言模型训练。V1 训练的是：

```text
文本 + 语境 -> LanguageFrame -> 动作倾向
```

`LanguageFrame` 目前包含：

```text
time       时间取向，例如 present contact / past irreversible / future threat / present need
affect     情感状态，例如 warm contact / self-blame pain / vigilant fear / confused gap
relation   关系模式，例如 open channel / repair rupture / seek safety / ask service
agency     主体责任，例如 mutual / user goal / agent expected / shared unknown
action     动作倾向，例如 greet / repair / protect / help / explain / correct
```

已接入的实验是 `language_grounding`，当前训练的状态包括：

```text
你好 -> 建立/维持交流通道 -> Greet
后悔 -> 过去不可逆 + 自责痛苦 + 修复关系 -> Repair
害怕 -> 未来威胁 + 警惕 + 寻求安全 -> Protect
请求 -> 当前需求 + 期待 AP 行动 -> Help
解释 -> 理解缺口 + 需要依据 -> Explain
纠错 -> 对齐偏差 + 用户修正 -> Correct
选择 -> 多个未来分支 + 取舍 -> Choose
目标 -> 用户计划 + 后续追踪 -> TrackGoal
评价 -> 用户反馈 + 调整信号 -> Evaluate
不确定 -> 共享未知 + 需要澄清 -> Clarify
```

TUI 普通聊天已经会先经过语言接地：

```text
用户输入 -> LanguageGroundingLearner -> DialogUnderstanding -> ResponsePolicy -> ResponseSurface -> teacher-off probe
```

聊天 trace 会出现类似 `language frame:request/service/help -> dialog:serve-request` 的记录。这里不是按固定句子硬编码判断，而是用训练得到的 feature-frame 分数预测状态。

TUI 普通聊天主窗口显示面向用户的短回复，例如：

```text
我会先识别目标和约束，再给出可执行的下一步。
```

`ResponsePolicy` 也是训练出来的策略层，用来决定“应该采用哪类响应行为”。白箱标签、frame 和 evidence 会进入 trace，不直接显示在聊天主窗口。`ResponseSurface` 负责把策略映射到可读回复；它是独立的表述层，后续可以继续用外部数据训练或替换为 LLM 生成。

可以从 TUI 导入外部语言接地数据：

```text
/import-language
/import-language path/to/language-grounding.jsonl
```

不带路径时默认读取 `.ap/exports/language/language-grounding.jsonl`。JSONL 每行一个样本：

```json
{"text":"请你帮我处理","context":"用户请求帮助","expected_frame":"frame:request/service/help","split":"train"}
{"text":"说明一下依据","context":"需要解释","expected_frame":"frame:question/reason/explain","split":"holdout"}
```

也支持 JSON 对象格式：

```json
{
  "train": [
    {"text":"我不知道怎么做","context":"需要澄清","expected_frame":"frame:uncertain/gap/clarify"}
  ],
  "holdout": [
    {"text":"这个结果很好","context":"用户评价","expected_frame":"frame:evaluation/feedback/evaluate"}
  ]
}
```

外部 agent 不进 TUI 也可以验证语言数据：

```bash
cargo run --bin language_grounding_report -- \
  --input .ap/exports/language/language-grounding.jsonl \
  --output .ap/reports/language/grounding-report.json
```

输出包含 train/holdout 数量、最终训练准确率、teacher-off holdout 准确率和是否通过。

响应策略也可以导入外部数据：

```text
/import-response-policy
/import-response-policy path/to/response-policy.jsonl
```

不带路径时默认读取 `.ap/exports/language/response-policy.jsonl`。JSONL 每行一个样本：

```json
{"text":"先比较两个办法","context":"用户需要分支取舍","expected_policy":"response:compare-tradeoffs","split":"train"}
{"text":"继续写还是先跑测试","context":"两个方案需要选择","expected_policy":"response:compare-tradeoffs","split":"holdout"}
```

可选字段 `frame` 和 `dialog_act` 可以显式指定语言状态；不填时会按 `expected_policy` 的默认白箱状态构造训练样本。这个数据集训练的是响应行为策略，不是自然语言回复文本。

运行相关测试：

```bash
cargo test --test language_grounding
```

运行完整实验记录时也会包含 `language_grounding`：

```bash
cargo run --bin experiments_local
```

后续如果要扩展语言能力，优先增加新的状态帧、语境特征和 holdout 语境，而不是直接训练长文本回答。

### 11. 外部 agent 推荐流程

1. 读取用户目标或材料。
2. 生成训练 `TaskSet`，包含 stimulus、expected_action、rubric。
3. 用 `--mode learn` 训练并保存 `.apbin`。
4. 生成不泄露答案的 probe 请求。
5. 用 `--mode probe` 加载 `.apbin` 验证。
6. 读取 bundle/report，判断是否通过。
7. 不通过就补充训练样本，回到第 2 步。

推荐命令模板：

```bash
cargo run --bin ap_learn -- \
  --input train.json \
  --output train-bundle.json \
  --domain <domain> \
  --agent-out .ap/skills/external/<domain>-current.apbin \
  --mode learn

cargo run --bin ap_learn -- \
  --input probe.json \
  --output probe-bundle.json \
  --domain <domain> \
  --agent-in .ap/skills/external/<domain>-current.apbin \
  --mode probe
```

### 12. 当前限制

- AP 现在不是完整通用智能体。
- TUI 对话目前已接入语言状态接地和 teacher-off probe，但不是接入真实 LLM 的开放聊天。
- LLM adapter 当前主要是接口和安全边界，不是生产级 API client。
- 多模态输出现在有 artifact 和 GL 计划路径，真实图片/音频渲染能力仍需继续扩展。
- 训练效果取决于已实现的 learner、课程质量和 teacher-off 验证。

### 13. 给 agent 的最低合规清单

提交训练前检查：

```text
[ ] intent 是 Learn
[ ] teacher_mode 允许写记忆
[ ] TaskSet 中训练任务有 expected_action
[ ] feedback_policy 能产生 Reward/Punishment
[ ] agent-out 使用 .apbin，除非明确要人工 JSON
```

提交 probe 前检查：

```text
[ ] intent 是 Probe
[ ] teacher_mode 是 TeacherOff
[ ] feedback_policy 是 NoFeedback
[ ] 使用 --mode probe
[ ] 使用 --agent-in 加载已训练技能包
[ ] 不把答案写入 teacher-off 训练路径
```
