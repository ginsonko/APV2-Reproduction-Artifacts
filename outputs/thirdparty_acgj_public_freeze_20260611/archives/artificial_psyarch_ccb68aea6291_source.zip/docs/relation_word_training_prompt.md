# Relation Word Visual Training Prompt

把下面整段提示词发给外部 AI/agent。它的任务是生成严格视觉约束数据，然后调用本仓库的 `relation_word_report` 框架训练和审计。

```text
你是 AP 外部训练 agent。你的任务不是替 AP 回答问题，而是为 AP 生成严格无泄漏的视觉关系词课程，并调用本地 AP 项目完成训练、审计和报告。

项目目录：
/home/ation_ciger/Projects/artificial_psyarch

目标：
训练 AP 学习中文空间关系词。AP 必须从图片引用、对象属性、坐标、bbox、端点和几何数值特征中学习，不允许从文件名、样本 ID、relation 标签或答案字符串查表。

训练配置：
skill_id = skill.relation.spatial_words.zh.v1
domain = relation_words
spec_path = .ap/exports/lessons/scaffold-relation-zh-v1-strict.json
holdout_spec_path = .ap/exports/lessons/scaffold-relation-zh-v1-holdout.json
media_dir = .ap/exports/media/relation_spatial_zh_strict/
holdout_media_dir = .ap/exports/media/relation_spatial_zh_holdout/
bundle_path = .ap/exports/bundles/scaffold-relation-zh-v1-strict-bundle.json
skill_path = .ap/skills/external/skill.relation.spatial_words.zh.v1.apbin
report_path = .ap/reports/learning/relation-word-report.json

必须覆盖的 action：
RelationWordLeft
RelationWordRight
RelationWordParallel
RelationWordPerpendicular
RelationWordAbove
RelationWordBelow

必须覆盖的场景：
point_point
line_line
shape_shape

最低样本要求：
总 steps >= 24
每个 action 至少 3 条
每个 step 必须恰好引用 1 张图片
每个 step 必须使用唯一图片
holdout spec 也必须满足这些要求，并且不能复用训练图片、对象名、坐标或端点。

第一步：生成 SVG 图片

在 media_dir 下生成 SVG 图片。图片文件名必须是无语义随机 ID，例如：
img_0001.svg
img_0002.svg
asset_7f3a91.svg

严禁文件名或路径中出现：
left
right
parallel
perp
perpendicular
above
below
RelationWord
answer

图片内容应包含：
点-点左右/上下关系
线-线平行/垂直关系
图形-图形左右/上下关系

第二步：生成 scaffold spec JSON

保存到：
.ap/exports/lessons/scaffold-relation-zh-v1-strict.json

JSON 字段必须包含：
skill_id
title
goal
domain_tags
building_blocks
phases
steps
mastery
guardrails
notes

phases 必须按顺序包含：
demonstrate
strong_scaffold
weak_scaffold
feedback_only
teacher_off
cold_retest

teacher_off 和 cold_retest 必须严格为：
state_items=false
action_biases=false
feedback=false

feedback_only 必须严格为：
state_items=false
action_biases=false
feedback=true

每个 step 必须包含：
step_id
title
scenario_tags
state_items
action_biases
feedback
expected_evidence
notes

state_items 必须包含：
image::<无语义 SVG 路径>
object::<对象属性>
axis::<坐标/差值特征>
geometry::<斜率/角度/dot/bbox 等几何特征>

state_items 禁止包含：
relation::left
relation::right
relation::parallel
relation::perpendicular
relation::above
relation::below
answer::
action::
RelationWordLeft
RelationWordRight
RelationWordParallel
RelationWordPerpendicular
RelationWordAbove
RelationWordBelow

step 示例：
{
  "step_id": "sample-0001",
  "title": "visual relation sample 0001",
  "scenario_tags": ["relation_word", "point_point"],
  "state_items": [
    "image::.ap/exports/media/relation_spatial_zh_strict/img_0001.svg",
    "object::a color=red shape=circle center=(20,50) bbox=(16,46,8,8)",
    "object::b color=blue shape=circle center=(80,50) bbox=(76,46,8,8)",
    "axis::x(a)=20",
    "axis::x(b)=80",
    "axis::x_delta(a,b)=-60",
    "axis::abs_y_delta(a,b)=0"
  ],
  "action_biases": [
    {"action": "RelationWordLeft", "strength": 1.0}
  ],
  "feedback": "Reward",
  "expected_evidence": [
    "teacher-off recalls action from coordinate features, not filename or relation label"
  ],
  "notes": []
}

第三步：生成独立 holdout scaffold spec JSON

保存到：
.ap/exports/lessons/scaffold-relation-zh-v1-holdout.json

要求：
holdout spec 使用同一 skill_id 和 action 集合。
总 steps >= 24。
每个 action 至少 3 条。
图片必须放在 holdout_media_dir。
图片路径不能和训练 spec 重复。
对象名建议使用 p/q、node_1/node_2、shape_m/shape_n 等，不要复用训练 spec 的 a/b。
坐标、bbox、端点必须是新组合，但要保留可迁移的数值/几何特征，例如 axis::x_delta(p,q)=-42、geometry::angle(line_m,line_n)=90。
holdout spec 只作为纯 TeacherOff probe 输入，不能依赖 demonstrate/strong/weak 阶段重新训练。

第四步：运行框架审计、训练和独立 holdout probe

在项目目录执行：

cargo run --bin relation_word_report -- \
  --spec .ap/exports/lessons/scaffold-relation-zh-v1-strict.json \
  --holdout-spec .ap/exports/lessons/scaffold-relation-zh-v1-holdout.json \
  --bundle .ap/exports/bundles/scaffold-relation-zh-v1-strict-bundle.json \
  --skill .ap/skills/external/skill.relation.spatial_words.zh.v1.apbin \
  --report .ap/reports/learning/relation-word-report.json \
  --domain relation_words

如果框架审计失败，不要修改 AP core。修复 train/holdout scaffold spec 或图片命名后重跑。
框架默认还会运行 control probes：
geometry_only 应通过；
no_geometry 应失败；
shuffled_expected 应失败。
这些 control probes 用来证明结果依赖几何数值特征，不是图片路径、对象名或评分路径污染。

第五步：运行基础检查

cargo fmt --check
cargo check
cargo test
cargo clippy --all-targets --all-features -- -D warnings
cargo crap

第六步：输出中文最终报告

报告必须包含：
scaffold spec 路径
holdout spec 路径
media_dir
holdout_media_dir
SVG 数量
bundle 路径
skill package 路径
relation-word report 路径
steps 数量
每个 action 的样本数
每个 scenario 的样本数
teacher_off_accuracy
cold_retest_accuracy
teacher_off_clean
cold_retest_clean
reload_same_spec_probe accuracy
independent_holdout_probe accuracy
independent_holdout_probe clean
control_probes.geometry_only accuracy
control_probes.no_geometry accuracy
control_probes.shuffled_expected accuracy
审计是否通过
如果失败，列出具体 issue 和修复动作

重要原则：
AP 才是学习主体。
外部 AI 只是课程生成器、审计器和训练调度器。
不得用文件名、路径、样本 ID、relation 标签或答案字符串泄漏答案。
不得修改 AP core 来让训练通过。
```
