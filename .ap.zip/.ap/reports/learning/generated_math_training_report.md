# Generated Math Training Report

status: PASS
closed_loop: true
train_tasks: 89
memory_rows: 89
train_accuracy: 1.00
teacher_off_holdout_accuracy: 1.00
teacher_off_generalization_accuracy: 1.00
skill_reload_generalization_accuracy: 1.00
untrained_operator_accuracy: 0.00
taint_audit: PASS

## Generalization Probe

- questions: `9 + 4`, `9 - 7`, `9 * 2`, `8 / 2`, `2 + 3 * 4`, `(2 + 3) * 4`
- answers: ["13", "2", "18", "4", "14", "20"]
- expected: `["13", "2", "18", "4", "14", "20"]`

## Reload Probe

- questions: `11 + 4`, `11 - 8`, `7 * 3`, `12 / 3`, `2 + 3 * 5`, `(2 + 3) * 5`
- answers: ["15", "3", "21", "4", "17", "25"]
- expected: `["15", "3", "21", "4", "17", "25"]`

## Boundary Probe

- untrained division expression answer: ["ObserveText"]
- expected boundary behavior: `ObserveText`, no false positive

## Interpretation

The generic learning loop is usable for this generated arithmetic slice: it trains from generated examples, audits teacher-off holdout, generalizes to unseen questions for operators observed with rewarded feedback, persists skill memory, and reloads it for later teacher-off probes. It does not claim unrestricted mathematics; untrained operators remain unavailable.
